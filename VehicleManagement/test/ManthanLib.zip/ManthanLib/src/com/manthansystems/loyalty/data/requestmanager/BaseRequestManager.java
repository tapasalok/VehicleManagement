
package com.manthansystems.loyalty.data.requestmanager;

/**
 * {@link BaseRequestManager} is the superclass of the classes that will be
 * implemented in your project. It contains constants used in the library.
 * 
 */
public abstract class BaseRequestManager {

    public static final String RECEIVER_EXTRA_REQUEST_ID = "com.manthansystems.loyalty.buyvia.extras.requestId";
    public static final String RECEIVER_EXTRA_RESULT_CODE = "com.manthansystems.loyalty.buyvia.extras.code";
    public static final String RECEIVER_EXTRA_PAYLOAD = "com.manthansystems.loyalty.buyvia.extras.payload";
    public static final String RECEIVER_EXTRA_ERROR_TYPE = "com.manthansystems.loyalty.buyvia.extras.error";
    public static final int RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION = 1;
    public static final int RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA = 2;
}
