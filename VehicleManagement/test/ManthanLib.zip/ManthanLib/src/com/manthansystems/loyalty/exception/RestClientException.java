
package com.manthansystems.loyalty.exception;

/**
 * Thrown to indicate that a compulsory parameter is missing.
 * 
 */
public class RestClientException extends Exception {

    private static final long serialVersionUID = 4658308128254827562L;

    private String mNewUrl;

    /**
     * Constructs a new {@link RestClientException} that includes the current
     * stack trace.
     */
    public RestClientException() {
        super();
    }

    /**
     * Constructs a new {@link RestClientException} that includes the current
     * stack trace, the specified detail message and the specified cause.
     * 
     * @param detailMessage the detail message for this exception.
     * @param throwable the cause of this exception.
     */
    public RestClientException(final String detailMessage, final Throwable throwable) {
        super(detailMessage, throwable);
    }

    /**
     * Constructs a new {@link RestClientException} that includes the current
     * stack trace and the specified detail message.
     * 
     * @param detailMessage the detail message for this exception.
     */
    public RestClientException(final String detailMessage) {
        super(detailMessage);
    }

    /**
     * Constructs a new {@link RestClientException} that includes the current
     * stack trace and the specified detail message.
     * 
     * @param detailMessage the detail message for this exception.
     * @param redirection url.
     */
    public RestClientException(final String detailMessage, final String redirectionUrl) {
        super(detailMessage);
        mNewUrl = redirectionUrl;
    }

    /**
     * Constructs a new {@link RestClientException} that includes the current
     * stack trace and the specified cause.
     * 
     * @param throwable the cause of this exception.
     */
    public RestClientException(final Throwable throwable) {
        super(throwable);
    }

    public String getRedirectionUrl() {
        return mNewUrl;
    }

}
