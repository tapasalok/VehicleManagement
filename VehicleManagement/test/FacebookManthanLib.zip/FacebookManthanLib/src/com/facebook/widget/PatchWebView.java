/**
 * Copyright 2013 XYMOB INC. All rights reserved.
 */
package com.facebook.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.webkit.WebView;

/**
 * Facebook android SDK, embdeds webview kit in Dialog and pops it up when user
 * calls authorize,dialog method. Usually on motorola droid phone with android
 * 2.2 os and few other devices, for first time WebView crashes with Null Pointer exception in
 * {@link WebView#onWindowFocusChanged(boolean)}.
 * 
 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
 */
public class PatchWebView extends WebView {

    public PatchWebView(Context context) {
        super(context);
    }

    public PatchWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public PatchWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        try{
            super.onWindowFocusChanged(hasWindowFocus);
        }catch(NullPointerException e){
        	Log.w("PatchWebView", "Known issue of Facebook: " + e);
        }
    }
}