package com.example.test.helper;

import java.io.Serializable;
/**
 * Created by anisha on 28/10/15.
 */
public class NameValuePair implements Serializable {
    private String keyName;
    private String valueName;

    public NameValuePair(){}

    public NameValuePair(String valueName, String keyName) {
        this.valueName = valueName;
        this.keyName = keyName;
    }

    public String getKeyName() {
        return keyName;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }

    public String getValueName() {
        return valueName;
    }

    public void setValueName(String valueName) {
        this.valueName = valueName;
    }
}
