package com.example.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.support.v4.content.CursorLoader;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.test.helper.Constants;
import com.example.test.helper.CustomGallery;
import com.example.test.helper.HttpRequest;
import com.example.test.helper.HttpRequest.HttpRequestException;
import com.example.test.helper.URLConstants;
import com.restuarant.utils.CommonUtils;
import com.restuarant.utils.MultipartRequest;
import com.restuarant.utils.ProgressBarHelper;
import com.squareup.picasso.Picasso;

public class Restaurant_Environment extends Activity implements OnClickListener {
	private EditText description;
	private EditText name;
	ExpandableListView expandableListView;
	ExpandableListAdapter expandableListAdapter;
	List expandableListTitle;
	HashMap expandableListDetail;
	private ImageView restaurantpic;
	private int PICK_IMAGE_REQUEST = 200;
	static final int REQUEST_TAKE_PHOTO = 100;
	static final int REQUEST_IMAGE_CAPTURE = 300;
	static final int REQUEST_IMAGE_MENU_CAPTURE = 400;
	private Uri fileUri;
	public static final int MEDIA_TYPE_IMAGE = 1;
	private Button submitbutton;
	private String UPLOAD_URL = "http://130.211.255.181/places-impl-web/rest/attachment/upload_menus";
	private String KEY_IMAGE = "uploadedFile";
	private String KEY_NAME = "filename";
	String mCurrentPhotoPath;
	private GridView gridview;
	private LinearLayout layout;
	public ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();
	private LinkedList<String> restaurantProfilePics;
	private LinkedHashMap<String, String> linkedHashMapProfilePics;
	private LinkedList<String> restaurantMenuPics;
	private LinkedHashMap<String, String> linkedHashMapMenuPics;
	private ProgressBarHelper progressBarHelper;
	private List<String> restaurantNames = new ArrayList<String>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.restaurant_environment);

		name = (EditText) findViewById(R.id.name);
		expandableListView = (ExpandableListView) findViewById(R.id.expandableListView);
		submitbutton = (Button) findViewById(R.id.submit);
		description = (EditText) findViewById(R.id.description);
		restaurantpic = (ImageView) findViewById(R.id.restaurantpic);
		layout = (LinearLayout) findViewById(R.id.linear);

		progressBarHelper = ProgressBarHelper.getSingletonInstance();

		restaurantProfilePics = new LinkedList<String>();
		restaurantMenuPics = new LinkedList<String>();
		linkedHashMapProfilePics = new LinkedHashMap<String, String>();
		linkedHashMapMenuPics = new LinkedHashMap<String, String>();

		ActionBar actionbar = getActionBar();
		actionbar.setLogo(R.drawable.backbutton);
		actionbar.setHomeButtonEnabled(true);
		actionbar.setBackgroundDrawable(new ColorDrawable(Color
				.parseColor("#ba68c8")));
		actionbar.setTitle(" Add Restaurant");

		Intent intent = getIntent();
		restaurantNames = intent.getStringArrayListExtra("restaurant_names");

		Bundle bundle = intent.getExtras();
		if (bundle != null) {
			String name = bundle.getString("name");
			String description = bundle.getString("description");
			String profilePhoto = bundle.getString("profilePhoto");

			this.name.setText(name);
			this.description.setText(description);

			Picasso.with(Restaurant_Environment.this).load(profilePhoto)
					.resize(350, 350).error(R.drawable.no_media)
					.into(restaurantpic);

			// Similarly do for other views
		}

		expandableListDetail = ExpandableListDataPump.getData();
		expandableListTitle = new ArrayList(expandableListDetail.keySet());
		expandableListAdapter = new ExpandableListAdapter(this,
				expandableListTitle, expandableListDetail);
		expandableListView.setAdapter(expandableListAdapter);
		expandableListView
				.setOnGroupExpandListener(new OnGroupExpandListener() {

					@Override
					public void onGroupExpand(int groupPosition) {
						Toast.makeText(
								getApplicationContext(),
								expandableListTitle.get(groupPosition)
										+ " List Expanded.", Toast.LENGTH_SHORT)
								.show();
					}
				});

		expandableListView
				.setOnGroupCollapseListener(new OnGroupCollapseListener() {

					@Override
					public void onGroupCollapse(int groupPosition) {

					}
				});

		expandableListView.setOnChildClickListener(new OnChildClickListener() {
			@Override
			public boolean onChildClick(ExpandableListView parent, View v,
					int groupPosition, int childPosition, long id) {
				/*
				 * if (groupPosition == 3 && childPosition == 1) {
				 * showFileChooser();
				 */
				if (groupPosition == 3 && childPosition == 0) {
					takePhotoForMenu();
				}
				Toast.makeText(Restaurant_Environment.this,
						"GP" + groupPosition + "CP" + childPosition, 0).show();
				return false;
			}
		});

		restaurantpic.setOnClickListener(restaurantPicture);
		submitbutton.setOnClickListener(this);
		// expandableListView.expandGroup(3);
	}

	OnClickListener restaurantPicture = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			takePhotoForIdentity();
		}
	};

	protected void takePhotoForIdentity() {
		// TODO Auto-generated method stub
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
			startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
		}

	}

	protected void takePhotoForMenu() {
		// TODO Auto-generated method stub
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
			startActivityForResult(takePictureIntent,
					REQUEST_IMAGE_MENU_CAPTURE);
		}

	}

	private File createImageFile() throws IOException {
		// Create an image file name
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
				.format(new Date());
		String imageFileName = "JPEG_" + timeStamp + "_";
		File storageDir = Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

		File image = File.createTempFile(imageFileName, /* prefix */
				".jpg", /* suffix */
				storageDir /* directory */
		);

		// Save a file: path for use with ACTION_VIEW intents
		mCurrentPhotoPath = "file:" + image.getAbsolutePath();
		galleryAddPic();
		return image;
	}

	public void takePhoto() {
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		// Ensure that there's a camera activity to handle the intent
		if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
			// Create the File where the photo should go
			File photoFile = null;
			try {
				photoFile = createImageFile();
			} catch (IOException ex) {

			}
			// Continue only if the File was successfully created
			if (photoFile != null) {
				takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
						Uri.fromFile(photoFile));
				startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
			}

		}
	}

	private void galleryAddPic() {
		Intent mediaScanIntent = new Intent(
				Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
		File f = new File(mCurrentPhotoPath);
		Uri contentUri = Uri.fromFile(f);
		mediaScanIntent.setData(contentUri);
		this.sendBroadcast(mediaScanIntent);
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.submit) {
			try {
				if (validateFields()) {
					progressBarHelper.showProgressBarSmall(
							"Uploading... Please wait...", true,
							Restaurant_Environment.this);

					String url = "http://130.211.255.181/places-impl-web/rest/attachment/upload_menus";
					uploadRestaurantProfilePic(url);
				}

			} catch (Exception e) {
				// TODO: handle exception
			} finally {

			}

		} else {

		}
	}

	private void uploadRestaurantProfilePic(final String url) {
		for (String filePath : restaurantProfilePics) {
			File file = new File(filePath);
			String filePartName = "uploadedFile";
			Listener<NetworkResponse> resultDelivery = new Listener<NetworkResponse>() {

				@Override
				public void onResponse(NetworkResponse response) {
					// TODO Auto-generated method stub
					Toast.makeText(Restaurant_Environment.this,
							"Response: Profile Picture Success ", 0).show();
					Log.i("anisha",
							"Receive time"
									+ response.headers
											.get("X-Android-Received-Millis"));
					try {
						String profilePicResponse = new String(response.data,
								HttpHeaderParser.parseCharset(response.headers));
						Log.i("anisha", "ImageResponse: " + profilePicResponse);

						linkedHashMapProfilePics.put(response.headers
								.get("X-Android-Received-Millis"),
								profilePicResponse);

						uploadRestaurantMenuPic(url);

					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						Toast.makeText(
								Restaurant_Environment.this,
								"Some problem in uploading Restaurant Profile Picture.",
								0).show();
						if (progressBarHelper != null) {
							progressBarHelper.dismissProgressBar();
						}
					} catch (Exception e) {
						// TODO: handle exception
						Toast.makeText(
								Restaurant_Environment.this,
								"Some problem in uploading Restaurant Profile Picture.",
								0).show();
						if (progressBarHelper != null) {
							progressBarHelper.dismissProgressBar();
						}
					}

				}
			};
			ErrorListener errorListener = new ErrorListener() {

				@Override
				public void onErrorResponse(VolleyError errorResponse) {
					// TODO Auto-generated method stub
					Toast.makeText(
							Restaurant_Environment.this,
							"Some problem in uploading Restaurant Profile Picture.",
							0).show();
					if (progressBarHelper != null) {
						progressBarHelper.dismissProgressBar();
					}

				}
			};
			Map<String, String> params = new HashMap<String, String>();
			params.put("filename", "test");

			uploadImage(url, file, filePartName, resultDelivery, errorListener,
					params);
		}
	}

	private void uploadRestaurantMenuPic(final String url) {
		for (final String filePath : restaurantMenuPics) {
			File file = new File(filePath);
			String filePartName = "uploadedFile";
			Listener<NetworkResponse> resultDelivery = new Listener<NetworkResponse>() {

				@Override
				public void onResponse(NetworkResponse response) {
					// TODO Auto-generated method stub
					Toast.makeText(Restaurant_Environment.this,
							"Response: Menu Picture Success", 0).show();
					Log.i("anisha",
							"Receive time"
									+ response.headers
											.get("X-Android-Received-Millis"));
					try {
						String profilePicResponse = new String(response.data,
								HttpHeaderParser.parseCharset(response.headers));
						Log.i("anisha", "ImageResponse: " + profilePicResponse);

						linkedHashMapMenuPics.put(response.headers
								.get("X-Android-Received-Millis"),
								profilePicResponse);
						if (filePath.equals(restaurantMenuPics.getLast())) {
							submitRestaurantInfo();
						}

					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						Toast.makeText(
								Restaurant_Environment.this,
								"Some problem in uploading Restaurant Menu Picture.",
								0).show();
						if (progressBarHelper != null) {
							progressBarHelper.dismissProgressBar();
						}
					} catch (Exception e) {
						// TODO: handle exception
						Toast.makeText(
								Restaurant_Environment.this,
								"Some problem in uploading Restaurant Menu Picture inside Exception.",
								0).show();
						if (progressBarHelper != null) {
							progressBarHelper.dismissProgressBar();
						}
					}

				}
			};
			ErrorListener errorListener = new ErrorListener() {

				@Override
				public void onErrorResponse(VolleyError errorResponse) {
					// TODO Auto-generated method stub
					Toast.makeText(
							Restaurant_Environment.this,
							"Some problem in uploading Restaurant Menu Picture onErrorResponse.",
							0).show();
					if (progressBarHelper != null) {
						progressBarHelper.dismissProgressBar();
					}

				}
			};
			Map<String, String> params = new HashMap<String, String>();
			params.put("filename", "test");

			uploadImage(url, file, filePartName, resultDelivery, errorListener,
					params);
		}
	}

	public Uri getImageUri(Context inContext, Bitmap inImage) {
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
		String path = Images.Media.insertImage(inContext.getContentResolver(),
				inImage, "Title", null);
		return Uri.parse(path);
	}

	public String getStoragePath(Uri uri) {
		String filePath = "";
		String wholeID = uri.getPath();

		// Split at colon, use second item in the array
		try {
			String id = wholeID.split(":")[1];

			String[] column = { MediaStore.Images.Media.DATA };

			// where id is equal to
			String sel = MediaStore.Images.Media._ID + "=?";

			Cursor cursor = getContentResolver().query(
					MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel,
					new String[] { id }, null);

			int columnIndex = cursor.getColumnIndex(column[0]);

			if (cursor.moveToFirst()) {
				filePath = cursor.getString(columnIndex);
			}
			cursor.close();
		} catch (Exception e) {
			// TODO: handle exception
			try {
				String[] proj = { MediaStore.Images.Media.DATA };
				String result = null;

				CursorLoader cursorLoader = new CursorLoader(
						Restaurant_Environment.this, uri, proj, null, null,
						null);
				Cursor cursor = cursorLoader.loadInBackground();

				if (cursor != null) {
					int column_index = cursor
							.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
					cursor.moveToFirst();
					result = cursor.getString(column_index);
				}
				return result;
			} catch (Exception e2) {
				// TODO: handle exception
				String[] proj = { MediaStore.Images.Media.DATA };
				Cursor cursor = Restaurant_Environment.this
						.getContentResolver()
						.query(uri, proj, null, null, null);
				int column_index = cursor
						.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
				cursor.moveToFirst();
				return cursor.getString(column_index);
			}

		}

		return filePath;
	}

	protected <T> void uploadImage(final String url, final File file,
			final String filePartName,
			final Response.Listener<NetworkResponse> resultDelivery,
			final Response.ErrorListener errorListener,
			Map<String, String> params) {

		MultipartRequest mr = new MultipartRequest(url, errorListener,
				resultDelivery, file, filePartName, params);
		Volley.newRequestQueue(this).add(mr);
	}

	private boolean validateFields() {
		// TODO Auto-generated method stub
		String name = this.name.getText().toString();
		String description = this.description.getText().toString();
		String ownerName = expandableListAdapter.getChildData(0, 0);

		String ownerEmail = expandableListAdapter.getChildData(0, 1);
		String ownerPhoneNo = expandableListAdapter.getChildData(0, 2);
		String address = expandableListAdapter.getChildData(0, 3);
		String numberOfTables = expandableListAdapter.getChildData(1, 0);
		String numberOfWaiters = expandableListAdapter.getChildData(1, 1);
		String establishMentType = expandableListAdapter.getChildData(1, 2);
		String wifiavailable = expandableListAdapter.getChildData(1, 3);
		String signalstrength = expandableListAdapter.getChildData(1, 4);
		String deliverfood = expandableListAdapter.getChildData(2, 0);
		String deliveredBy = expandableListAdapter.getChildData(2, 1);
		String deliverwithin = expandableListAdapter.getChildData(2, 2);
		String deliveraround = expandableListAdapter.getChildData(2, 3);

		if (TextUtils.isEmpty(name)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Restuarant Name", Toast.LENGTH_SHORT).show();
			return false;
		}

		if (restaurantNames != null && restaurantNames.contains(name)) {
			Toast.makeText(Restaurant_Environment.this,
					"This Restaurant is already registered with us",
					Toast.LENGTH_SHORT).show();
			return false;
		}

		if (restaurantMenuPics == null || restaurantMenuPics.size() <= 0) {
			Toast.makeText(Restaurant_Environment.this,
					"Please upload Restuarant Profile Picture",
					Toast.LENGTH_SHORT).show();
			return false;
		}
		if (restaurantMenuPics == null || restaurantMenuPics.size() <= 0) {
			Toast.makeText(Restaurant_Environment.this,
					"Please upload at least one menu picture",
					Toast.LENGTH_SHORT).show();
			return false;
		}

		if (TextUtils.isEmpty(description)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Restuarant Description", Toast.LENGTH_SHORT)
					.show();
			return false;
		}

		if (TextUtils.isEmpty(ownerName)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Owner Name", Toast.LENGTH_SHORT).show();
			return false;
		}

		if (!CommonUtils.isValidEmail(ownerEmail)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter valid Email ID", Toast.LENGTH_SHORT).show();
			return false;
		}
		if (TextUtils.isEmpty(ownerPhoneNo)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Owner Phone No", Toast.LENGTH_SHORT).show();
			return false;
		}
		if (TextUtils.isEmpty(address)) {
			Toast.makeText(Restaurant_Environment.this, "Please enter Address",
					Toast.LENGTH_SHORT).show();
			return false;
		}

		if (TextUtils.isEmpty(numberOfTables)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Number of Tables", Toast.LENGTH_SHORT).show();
			return false;
		}

		if (TextUtils.isEmpty(numberOfWaiters)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Number of Waiters", Toast.LENGTH_SHORT)
					.show();
			return false;
		}

		if (TextUtils.isEmpty(establishMentType)
				|| establishMentType
						.equals(ExpandableListAdapter.establishment[0])) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Type of Establishment", Toast.LENGTH_SHORT)
					.show();
			return false;
		}

		if (TextUtils.isEmpty(wifiavailable)
				|| establishMentType
						.equals(ExpandableListAdapter.wifiAvailable[0])) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Type of Wifi Available", Toast.LENGTH_SHORT)
					.show();
			return false;
		}

		if (TextUtils.isEmpty(signalstrength)
				|| establishMentType.equals(ExpandableListAdapter.signal[0])) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Type of Wifi Available", Toast.LENGTH_SHORT)
					.show();
			return false;
		}

		if (TextUtils.isEmpty(deliverfood)
				|| establishMentType
						.equals(ExpandableListAdapter.deliverfood[0])) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Type of Delivery Food", Toast.LENGTH_SHORT)
					.show();
			return false;
		}

		if (TextUtils.isEmpty(deliveredBy)
				|| establishMentType
						.equals(ExpandableListAdapter.deliveredby[0])) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Type of Delivery By", Toast.LENGTH_SHORT)
					.show();
			return false;
		}

		if (TextUtils.isEmpty(deliverwithin)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Delivered Witin", Toast.LENGTH_SHORT).show();
			return false;
		}

		if (TextUtils.isEmpty(deliveraround)) {
			Toast.makeText(Restaurant_Environment.this,
					"Please enter Delivered Around", Toast.LENGTH_SHORT).show();
			return false;
		}

		return true;

	}

	private void submitRestaurantInfo() {
		String photoUrl = "";
		Set<String> keySet = linkedHashMapProfilePics.keySet();
		for (String string : keySet) {
			photoUrl = "http://130.211.255.181/places-impl-web/rest/attachment/images/"
					+ linkedHashMapProfilePics.get(string)
					+ "?timestamp="
					+ string;
		}
		String name = this.name.getText().toString();
		String description = this.description.getText().toString();
		String ownerName = expandableListAdapter.getChildData(0, 0);

		String ownerEmail = expandableListAdapter.getChildData(0, 1);
		String ownerPhoneNo = expandableListAdapter.getChildData(0, 2);
		String address = expandableListAdapter.getChildData(0, 3);
		String numberOfTables = expandableListAdapter.getChildData(1, 0);
		String numberOfWaiters = expandableListAdapter.getChildData(1, 1);
		String establishMentType = expandableListAdapter.getChildData(1, 2);
		String wifiavailable = expandableListAdapter.getChildData(1, 3);
		String signalstrength = expandableListAdapter.getChildData(1, 4);
		String deliverfood = expandableListAdapter.getChildData(2, 0);
		String deliveredBy = expandableListAdapter.getChildData(2, 1);
		String deliverwithin = expandableListAdapter.getChildData(2, 2);
		String deliveraround = expandableListAdapter.getChildData(2, 3);
		List<String> menus = new ArrayList<String>();
		Set<String> menuPics = linkedHashMapMenuPics.keySet();
		for (String string : menuPics) {
			menus.add("http://130.211.255.181/places-impl-web/rest/attachment/images/"
					+ linkedHashMapMenuPics.get(string)
					+ "?timestamp="
					+ string);
		}

		RestaurantDetails restaurantDetails = new RestaurantDetails();
		restaurantDetails.ownerName = ownerName;
		restaurantDetails.ownerEmail = ownerEmail;
		restaurantDetails.ownerPhoneNo = ownerPhoneNo;
		restaurantDetails.name = name;
		restaurantDetails.description = description;
		// restaurantDetails.address = address;

		// PhotoUrl and menus should be actual URL
		restaurantDetails.photoUrl = photoUrl;

		restaurantDetails.menus = menus.toArray(new String[menus.size()]);
		restaurantDetails.numberOfTables = numberOfTables;
		restaurantDetails.numberOfWaiters = numberOfWaiters;

		if (establishMentType.equals(ExpandableListAdapter.establishment[1])) {
			restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.DineIn;
		} else if (establishMentType
				.equals(ExpandableListAdapter.establishment[2])) {
			restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.Buffet;
		} else if (establishMentType
				.equals(ExpandableListAdapter.establishment[3])) {
			restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.TakeAway;
		} else if (establishMentType
				.equals(ExpandableListAdapter.establishment[4])) {
			restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.QSR;
		}
		if (wifiavailable.equals(ExpandableListAdapter.wifiAvailable[1])) {
			restaurantDetails.wifiAvailable = true;
		} else {
			restaurantDetails.wifiAvailable = false;
		}

		restaurantDetails.networkStrength = signalstrength;
		if (deliverfood.equals(ExpandableListAdapter.deliverfood[1])) {
			restaurantDetails.foodDeilvery = true;
		} else {
			restaurantDetails.foodDeilvery = false;
		}

		restaurantDetails.deliveredBy = deliveredBy;
		restaurantDetails.deliverWithin = deliverwithin;
		restaurantDetails.deliverAround = deliveraround;

		// Longitude and Latitude should be from mobile GPS

		restaurantDetails.location.setLatitude("12.9124733");
		restaurantDetails.location.setLongitude("77.633685");

		new UpdateDetails().execute(restaurantDetails);
	}

	public class UpdateDetails extends
			AsyncTask<RestaurantDetails, Void, Integer> {

		@Override
		protected Integer doInBackground(RestaurantDetails... params) {
			// TODO Auto-generated method stub
			RestaurantDetails restaurantDetails = params[0];
			ObjectMapper m = new ObjectMapper();
			try {

				HttpRequest httpRequest = HttpRequest
						.post(URLConstants.PLACES_DETAILS)
						.contentType("application/json")
						.json(m.writeValueAsString(restaurantDetails));
				String response = httpRequest.body();
				Log.i("anisha Response", response);
				int responseCode = httpRequest.code();
				Log.i("anisha Response Code", "" + responseCode);
				return responseCode;
			} catch (JsonGenerationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (HttpRequestException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return 0;
		}

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			if (progressBarHelper != null) {
				progressBarHelper.dismissProgressBar();
			}
			if (result == 200) {
				Toast.makeText(Restaurant_Environment.this,
						"Successfully Uploaded to Server", 0).show();
				restaurantMenuPics = new LinkedList<String>();
				restaurantMenuPics = new LinkedList<String>();
				linkedHashMapProfilePics = new LinkedHashMap<String, String>();
				linkedHashMapMenuPics = new LinkedHashMap<String, String>();
				finish();
			} else {
				Toast.makeText(Restaurant_Environment.this,
						"Server Unavailable. Please have patience", 0).show();
				// finish();
			}

		}

	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);
		if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
			expandableListView.setIndicatorBounds(
					expandableListView.getWidth() - 40,
					expandableListView.getWidth());
		} else {
			expandableListView.setIndicatorBoundsRelative(
					expandableListView.getWidth() - 40,
					expandableListView.getWidth());
		}
	}

	public String getStringImage(Bitmap bmp) {

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		bmp.compress(CompressFormat.JPEG, 75, bos);
		byte[] data = bos.toByteArray();
		String encodedImage = Base64.encodeToString(data, Base64.DEFAULT);
		return encodedImage;
	}

	public class UploadImage extends AsyncTask<CustomGallery, Void, Void> {
		CustomGallery customGallery;
		final ProgressDialog loading = ProgressDialog.show(
				Restaurant_Environment.this, "Uploading...", "Please wait...",
				false, false);

		@Override
		protected Void doInBackground(CustomGallery... params) {
			customGallery = params[0];

			StringRequest stringRequest = new StringRequest(
					Request.Method.POST, UPLOAD_URL,
					new Response.Listener<String>() {
						@Override
						public void onResponse(String s) {
							// Disimissing the progress dialog
							loading.dismiss();
							// Showing toast message of the response
							Toast.makeText(Restaurant_Environment.this, s,
									Toast.LENGTH_SHORT).show();
						}
					}, new Response.ErrorListener() {
						@Override
						public void onErrorResponse(VolleyError volleyError) {
							// Dismissing the progress dialog
							loading.dismiss();

							// Showing toast
							Toast.makeText(Restaurant_Environment.this,
									"Error: " + volleyError.getMessage(),
									Toast.LENGTH_SHORT).show();
						}
					}) {

				@Override
				protected Map<String, String> getParams()
						throws AuthFailureError {
					// Converting Bitmap to String
					String image = getStringImage(customGallery.bitmap);

					// Getting Image Name
					String name = "arriveguru.png";

					// Creating parameters
					Map<String, String> params = new Hashtable<String, String>();

					// Adding parameters
					params.put(KEY_IMAGE, image);
					params.put(KEY_NAME, name);
					/* params.put(KEY_UPLOADEDFILE, uploadedfile); */

					// returning parameters
					return params;
				}
			};

			// Creating a Request Queue
			RequestQueue requestQueue = Volley
					.newRequestQueue(Restaurant_Environment.this);

			// Adding request to the queue
			requestQueue.add(stringRequest);
			return null;

		}

	}

	private void showFileChooser() {

		Intent intent1 = new Intent(Constants.ACTION_MULTIPLE_PICK);
		startActivityForResult(intent1, PICK_IMAGE_REQUEST);

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		try {
			if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
				Bundle extras = data.getExtras();
				Bitmap imageBitmap = (Bitmap) extras.get("data");

				Uri uri = getImageUri(Restaurant_Environment.this, imageBitmap);
				String restaurantpicPath = getStoragePath(uri);

				while (!restaurantProfilePics.isEmpty()) {
					restaurantProfilePics.remove();
				}
				restaurantProfilePics.add(restaurantpicPath);

				imageBitmap = imageBitmap.createScaledBitmap(imageBitmap, 350,
						350, true);

				restaurantpic.setImageBitmap(imageBitmap);

			} else if (requestCode == REQUEST_IMAGE_MENU_CAPTURE
					&& resultCode == RESULT_OK) {
				Bundle extras = data.getExtras();
				Bitmap imageBitmap = (Bitmap) extras.get("data");
				ImageView imageView = new ImageView(this);
				imageView.setPadding(2, 2, 2, 2);

				Uri uri = getImageUri(Restaurant_Environment.this, imageBitmap);
				String restaurantMenuPath = getStoragePath(uri);

				restaurantMenuPics.add(restaurantMenuPath);

				imageBitmap = imageBitmap.createScaledBitmap(imageBitmap, 350,
						350, true);

				imageView.setImageBitmap(imageBitmap);
				imageView.setScaleType(ScaleType.FIT_XY);
				layout.addView(imageView);

			} else if (requestCode == REQUEST_TAKE_PHOTO
					&& resultCode == Activity.RESULT_OK) {
				// gotTOGalleryActivity();
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	protected void gotTOGalleryActivity() {
		showFileChooser();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		switch (id) {
		case R.id.action_logout:
			Intent intent = new Intent(Restaurant_Environment.this,
					MainActivity.class);
			startActivity(intent);
			restaurantProfilePics = new LinkedList<String>();
			restaurantMenuPics = new LinkedList<String>();
			linkedHashMapProfilePics = new LinkedHashMap<String, String>();
			linkedHashMapMenuPics = new LinkedHashMap<String, String>();
			finish();
			break;
		case android.R.id.home:
			onBackPressed();
			break;
		default:
			break;
		}

		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
	}
}
