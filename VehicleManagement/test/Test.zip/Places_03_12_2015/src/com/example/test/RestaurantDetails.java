package com.example.test;

import java.io.Serializable;

public class RestaurantDetails implements Serializable {
	/**
	 * 
	 */

	enum EstablishMentType {
		DineIn, Buffet, TakeAway, QSR
	}

	private static final long serialVersionUID = -3598182390685435138L;
	public String name;
	public String description;
	public String ownerName;

	public String ownerEmail;
	public String photoUrl;
	public String[] menus;
	public String ownerPhoneNo;

	// public String address;

	public String numberOfTables;
	public String numberOfWaiters;
	public EstablishMentType establishMentType;
	public boolean wifiAvailable;
	public String networkStrength;
	public boolean foodDeilvery;
	public String deliveredBy;
	public String deliverWithin;
	public String deliverAround;
	public Location location = new Location();
}
