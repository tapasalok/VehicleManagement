package com.example.test.helper;

/**
 * Created by anisha on 28/10/15.
 */
public class URLConstants {
	private static final String CONTEXT_NAME = "http://yoursec.in";
	// 4C71F55A53D94BCA85C457E08BDD8AD2DD9AE44596E24396965DF3564690B9E5
	public static String OPEN_BRASSICAS = "{";
	public static String CLOSE_BRASSICAS = "}";
	public static String GET_PRINTER_LIST_BY_COMPANY = CONTEXT_NAME
			.concat("/adminsettings/v1/company/{companySid}/printers");
	public static String UPDATE_PRINTER_STATUS = CONTEXT_NAME
			.concat("/adminsettings/v1/company/{companySid}/printer/update");
	public static String GET_MENU_LIST = CONTEXT_NAME
			.concat("/catalogservices/v1/get/all/item/company/{companySid}/project/{projectSid}");
	public static String GET_TABLE_LIST = CONTEXT_NAME.concat(
			"/adminsettings/v1/get/table/by/agent/{virtualAccountSid}/project/{projectSid}/company/{companySid}");
	public static String UPDATE_PRINTER = CONTEXT_NAME.concat("/adminsettings/v1/company/{companySid}/printer/update");
	public static String DELETE_PRINTER = CONTEXT_NAME.concat("/adminsettings/v1/company/{companySid}/printer/");
	public static String ADD_PRINTER = CONTEXT_NAME.concat("/adminsettings/v1/company/{companySid}/printer");
	public static String PLACE_ORDER = CONTEXT_NAME.concat("/idine-ordermanagement/idineorder/create/tableorder");
	public static String GET_TABLE_ORDER_LIST = CONTEXT_NAME
			.concat("/idine-ordermanagement/idineorder/getcurrentordersanditems/project/{projectsid}/table/{tablesid}");
	public static String APP_LOGIN = CONTEXT_NAME.concat("/security/rest/app/login");
	public static final String GET_USERS = CONTEXT_NAME + "/adminsettings/v1/listagents/project/";
	public static final String APP_LOGOUT = CONTEXT_NAME.concat("/security/rest/app/logout");
	public static final String ASSOCIATE_TABLE_USERS = CONTEXT_NAME.concat("/adminsettings/v1/associate/tables/users");
	public static final String CHECK_OUT_URL = CONTEXT_NAME.concat("/idine-ordermanagement/idineorder/checkout");
	public static final String CHECK_IN_URL = CONTEXT_NAME.concat("/idine-ordermanagement/idineorder/checkin");
	public static final String PLACES_URL = "http://130.211.255.181/places-impl-web/rest/business/nearby";
	public static final String PLACES_DETAILS = "http://130.211.255.181/places-impl-web/rest/business";
	public static final String PLACES_IMAGES = "http://130.211.255.181/places-impl-web/rest/attachment/upload_menus";
}
