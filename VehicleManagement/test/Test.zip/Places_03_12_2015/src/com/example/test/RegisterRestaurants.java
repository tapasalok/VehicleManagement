package com.example.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

public class RegisterRestaurants extends Activity {
	private String[] establishment = { "Dine In", "Buffet", "Take Away", "QSR" };
	private String[] signal = { "Excellent", "Moderate", "poor" };
	private String[] deliveredby = { "Restaurant", "Third Party" };
	private Spinner spinner;
	private Spinner spinnertwo;
	private Spinner spinnerthree;
	private Button next;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registerrestaurants);
		spinner = (Spinner) findViewById(R.id.spinner1);
		spinnertwo = (Spinner) findViewById(R.id.spinner2);
		spinnerthree = (Spinner) findViewById(R.id.spinner3);
		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(RegisterRestaurants.this,
				android.R.layout.simple_spinner_item, establishment);
		ArrayAdapter<String> arrayAdaptertwo = new ArrayAdapter<String>(RegisterRestaurants.this,
				android.R.layout.simple_spinner_item, signal);
		ArrayAdapter<String> arrayAdapterthree = new ArrayAdapter<String>(RegisterRestaurants.this,
				android.R.layout.simple_spinner_item, deliveredby);
		arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(arrayAdapter);
		spinnertwo.setAdapter(arrayAdaptertwo);
		spinnerthree.setAdapter(arrayAdapterthree);
		OnItemSelectedListener listener = new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}

		};
		spinner.setOnItemSelectedListener(listener);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_logout) {
			Intent intent = new Intent(RegisterRestaurants.this, MainActivity.class);
			startActivity(intent);
			finish();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
