package com.example.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;

import com.example.test.helper.HttpRequest;
import com.example.test.helper.URLConstants;
import com.restuarant.utils.CommonUtils;
import com.restuarant.utils.ProgressBarHelper;
import com.restuarant.view.FloatingActionButton;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends Activity {
	Button btnGPSShowLocation;
	Button btnShowAddress;
	TextView tvAddress;
	double longitude;
	double latitude;
	AppLocationService appLocationService;

	private static final String TAG = "com.example.test.HomeActivity";
	private ListView listView;
	private TextView textView;
	private ImageView imageview;
	private Map<String, String> locationMap = new HashMap<String, String>();
	private ProgressBarHelper progressBarHelper;
	private ArrayList<String> restaurantNames;
	private List<BusinessSummary> resultFromServer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.homescreen);
		restaurantNames = new ArrayList<String>();
		resultFromServer = new ArrayList<BusinessSummary>();

		progressBarHelper = ProgressBarHelper.getSingletonInstance();
		LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

		if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			Toast.makeText(this, "GPS is Enabled in your devide",
					Toast.LENGTH_SHORT).show();
		} else {
			showSettingsAlert();
		}

		ActionBar actionbar = getActionBar();
		actionbar.setLogo(R.drawable.actionbarlogo);
		actionbar.setHomeButtonEnabled(true);
		actionbar.setBackgroundDrawable(new ColorDrawable(Color
				.parseColor("#ba68c8")));
		imageview = (ImageView) findViewById(R.id.imageview);
		listView = (ListView) findViewById(R.id.listView);
		listView.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HomeActivity.this,
						Restaurant_Environment.class);

				Bundle bundle = new Bundle();
				bundle.putString("name", resultFromServer.get(position)
						.getName());
				bundle.putString("description", resultFromServer.get(position)
						.getDescription());
				bundle.putString("profilePhoto", resultFromServer.get(position)
						.getPhotoUrl());

				// Do for remaining items

				intent.putExtras(bundle);
				startActivity(intent);
				// Log.v("long clicked","pos: " + pos);
				return true;
			}

		});

		FloatingActionButton fabButton = new FloatingActionButton.Builder(this)
				.withDrawable(getResources().getDrawable(R.drawable.fab))
				.withButtonColor(Color.WHITE)
				.withGravity(Gravity.BOTTOM | Gravity.RIGHT)
				.withMargins(0, 0, 16, 16).create();

		OnClickListener l = new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HomeActivity.this,
						Restaurant_Environment.class);
				intent.putStringArrayListExtra("restaurant_names",
						restaurantNames);
				startActivity(intent);

			}
		};
		fabButton.setOnClickListener(l);
		/* tvAddress = (TextView) findViewById(R.id.tvAddress); */

		String provider = locationManager.getBestProvider(
				CommonUtils.createCoarseCriteria(), false);
		if (TextUtils.isEmpty(provider)) {
			provider = locationManager.getBestProvider(
					CommonUtils.createFineCriteria(), false);
		}
		appLocationService = new AppLocationService(HomeActivity.this, provider);

		Location location = appLocationService.getLocation(provider);
		if (location != null) {
			longitude = location.getLongitude();
			latitude = location.getLatitude();
			locationMap.put("latitude", String.valueOf(latitude));
			locationMap.put("longitude", String.valueOf(longitude));
		}

		if (location != null) {
			double latitude = location.getLatitude();
			double longitude = location.getLongitude();
			LocationAddress locationAddress = new LocationAddress();
			locationAddress.getAddressFromLocation(latitude, longitude,
					getApplicationContext(), new GeocoderHandler());
		}
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();

		latitude = 12.9124208;
		longitude = 77.634122;

		locationMap.put("latitude", String.valueOf(latitude));
		locationMap.put("longitude", String.valueOf(longitude));
		NearBy nearByAsyncTask = new NearBy();
		Log.i("anisha", "latitude " + latitude + "longitute " + longitude);
		nearByAsyncTask.execute(locationMap);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	public void showSettingsAlert() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(
				HomeActivity.this);
		alertDialog.setTitle("SETTINGS");
		alertDialog
				.setMessage("Enable Location Provider!If It is OFF! Go to settings menu?");
		alertDialog.setPositiveButton("Settings",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Intent intent = new Intent(
								Settings.ACTION_LOCATION_SOURCE_SETTINGS);
						HomeActivity.this.startActivity(intent);
					}
				});
		alertDialog.setNegativeButton("Cancel",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
					}
				});
		alertDialog.show();
	}

	private class GeocoderHandler extends Handler {
		@Override
		public void handleMessage(Message message) {
			String locationAddress;
			switch (message.what) {
			case 1:
				Bundle bundle = message.getData();
				locationAddress = bundle.getString("address");
				break;
			default:
				locationAddress = null;
			}
			// tvAddress.setText(locationAddress);
		}
	}

	public class NearBy extends
			AsyncTask<Map<String, String>, Void, List<BusinessSummary>> {

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressBarHelper.showProgressBarSmall(
					"Please Wait...Fetching Restaurants...", true,
					HomeActivity.this);

		}

		@Override
		protected List<BusinessSummary> doInBackground(
				Map<String, String>... params) {
			// TODO Auto-generated method stub
			Map<String, String> location = params[0];
			try {

				String response = HttpRequest.get(URLConstants.PLACES_URL)
						.headers(location).body();
				ObjectMapper mapper = new ObjectMapper();
				TypeFactory typeFactory = TypeFactory.defaultInstance();
				List<BusinessSummary> businessSummary = mapper.readValue(
						response, typeFactory.constructCollectionType(
								List.class, BusinessSummary.class));
				Log.i(TAG + " NEARBY RESPONSE IS ", response);
				return businessSummary;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(List<BusinessSummary> result) {
			// TODO Auto-generated method stub
			progressBarHelper.dismissProgressBar();
			resultFromServer = result;

			if (result == null) {
				Toast.makeText(HomeActivity.this, "No Restaurant Available.", 0)
						.show();
			} else {

				for (BusinessSummary businessSummary : result) {
					Log.i("anisha",
							"Image URL: " + businessSummary.getPhotoUrl());
					Log.i("anisha", "Name: " + businessSummary.getName());

					restaurantNames.add(businessSummary.getName());
				}

				listView.setAdapter(new CustomListAdapter(HomeActivity.this,
						result));
			}

		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.refreshmenu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		switch (id) {
		case R.id.action_logout:
			Intent intent = new Intent(HomeActivity.this, MainActivity.class);
			startActivity(intent);
			finish();
			break;
		case android.R.id.home:
			onBackPressed();
			break;
		case R.id.action_refresh:
			refreshRestaurant();
			break;

		default:
			break;
		}

		return super.onOptionsItemSelected(item);
	}

	private void refreshRestaurant() {
		// TODO Auto-generated method stub
		onStart();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
	}
}