package com.example.test.helper;

import android.graphics.Bitmap;

public class CustomGallery {

	public Bitmap bitmap;
	public String sdcardPath;
	public boolean isSeleted = false;

}
