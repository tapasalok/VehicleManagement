package com.example.test.helper;

public interface WSConstants {
	String MODULE_KEY = "module";

	String WS_KEY_LONGITUDE = "longitude";
	String WS_KEY_LATITUDE = "latitude";
	String WS_KEY_RESULT_BUNDLE = "resultbundle";

	String WS_MODULE_LIST_RESTAURANT = "list_restaurant";

}
