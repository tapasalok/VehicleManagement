package com.example.test;

import java.util.HashMap;
import java.util.List;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class ExpandableListAdapter extends BaseExpandableListAdapter {

	private Context context;
	private List<String> expandableListTitle;
	private HashMap<String, List<String>> expandableListDetail;
	private Spinner spinner;
	public static final String[] establishment = { "Type of Establishment ?", "Dine In", "Buffet", "Take Away", "QSR" };
	public static final String[] wifiAvailable = { "Wifi Availablity ?", "Yes", "No" };
	public static final String[] signal = { "Mobile Signal Strengh:", "Excellent", "Moderate", "Poor" };
	public static final String[] deliverfood = { "Do they deliver food ?", "Yes", "No" };
	public static final String[] deliveredby = { "Delivered By:", "Restaurant", "third party" };

	private String[] ownerInfo = { "", "", "", "" };
	private String[] restaurantEnvironment = { "", "", "", "", "", "" };
	private String[] homeDeliveryFacility = { "", "", "", "", "" };

	private int[] spinnerPositions = { 0, 0, 0, 0, 0 };

	public ExpandableListAdapter(Context context, List<String> expandableListTitle,
			HashMap<String, List<String>> expandableListDetail) {
		this.context = context;
		this.expandableListTitle = expandableListTitle;
		this.expandableListDetail = expandableListDetail;
	}

	@Override
	public Object getChild(int listPosition, int expandedListPosition) {
		return this.expandableListDetail.get(this.expandableListTitle.get(listPosition)).get(expandedListPosition);
	}

	public String getChildData(int listPosition, int expandedListPosition) {
		String data = "";
		switch (listPosition) {
		case 0:
			data = ownerInfo[expandedListPosition];
			break;

		case 1:
			data = restaurantEnvironment[expandedListPosition];
			break;

		case 2:
			data = homeDeliveryFacility[expandedListPosition];
			break;

		default:
			data = "";
			break;
		}
		return data;
	}

	@Override
	public long getChildId(int listPosition, int expandedListPosition) {
		return expandedListPosition;
	}

	@Override
	public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView,
			ViewGroup parent) {

		final String expandedListText = (String) getChild(groupPosition, childPosition);
		View newView = null;
		if (groupPosition == 0) {

			newView = View.inflate(context, R.layout.list_item, null);
			EditText expandedListTextView = (EditText) newView.findViewById(R.id.expandedListItem);
			expandedListTextView.setEnabled(true);
			expandedListTextView.setHint(expandedListText);
			if (childPosition == 0) {
				expandedListTextView.setInputType(InputType.TYPE_CLASS_TEXT);
			}

			if (childPosition == 1) {
				expandedListTextView.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
			}
			if (childPosition == 2) {
				expandedListTextView.setInputType(InputType.TYPE_CLASS_PHONE);
			}
			expandedListTextView.setText(ownerInfo[childPosition]);

			expandedListTextView.addTextChangedListener(new TextWatcher() {
				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					// TODO Auto-generated method stub

				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
					// TODO Auto-generated method stub

				}

				@Override
				public void afterTextChanged(Editable s) {
					// TODO Auto-generated method stub
					if (!TextUtils.isEmpty(s)) {
						if (groupPosition == 0) {
							ownerInfo[childPosition] = s.toString();
						} else if (groupPosition == 1) {
							restaurantEnvironment[childPosition] = s.toString();
						} else if (groupPosition == 2) {
							homeDeliveryFacility[childPosition] = s.toString();
						}
					}

				}
			});
		}
		if (groupPosition == 1) {
			newView = View.inflate(context, R.layout.list_item, null);
			newView = View.inflate(context, R.layout.list_item, null);
			EditText expandedListTextView = (EditText) newView.findViewById(R.id.expandedListItem);
			if (childPosition == 0) {

				expandedListTextView.setInputType(InputType.TYPE_CLASS_NUMBER);
			}
			if (childPosition == 1) {

				expandedListTextView.setInputType(InputType.TYPE_CLASS_NUMBER);
			}
			if (childPosition == 2) {
				// EditText expandedListTextView = (EditText)
				// newView.findViewById(R.id.expandedListItem);
				expandedListTextView.setVisibility(View.GONE);
				spinner = (Spinner) newView.findViewById(R.id.spinner);
				spinner.setVisibility(View.VISIBLE);
				ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
						android.R.layout.simple_spinner_item, establishment);
				arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				spinner.setAdapter(arrayAdapter);
				spinner.setSelection(spinnerPositions[0]);
				spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
						// TODO Auto-generated method stub
						spinnerPositions[0] = position;
						String selectedTypeOfEstablishment = establishment[position];
						if (!TextUtils.isEmpty(selectedTypeOfEstablishment)) {
							if (groupPosition == 1) {
								restaurantEnvironment[childPosition] = selectedTypeOfEstablishment;
							} else if (groupPosition == 2) {
								homeDeliveryFacility[childPosition] = selectedTypeOfEstablishment;
							}
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> parent) {
						// TODO Auto-generated method stub

					}
				});

			} else if (childPosition == 3) {
				// EditText expandedListTextView = (EditText)
				// newView.findViewById(R.id.expandedListItem);
				expandedListTextView.setVisibility(View.GONE);
				spinner = (Spinner) newView.findViewById(R.id.spinner);
				spinner.setVisibility(View.VISIBLE);
				ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
						android.R.layout.simple_spinner_item, wifiAvailable);
				arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				spinner.setAdapter(arrayAdapter);
				spinner.setSelection(spinnerPositions[1]);
				spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
					@Override
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
						// TODO Auto-generated method stub
						spinnerPositions[1] = position;
						String wifi = wifiAvailable[position];
						if (!TextUtils.isEmpty(wifi)) {
							if (groupPosition == 1) {
								restaurantEnvironment[childPosition] = wifi;
							} else if (groupPosition == 2) {
								homeDeliveryFacility[childPosition] = wifi;
							}
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> parent) {
						// TODO Auto-generated method stub

					}
				});
			} else if (childPosition == 4) {
				// EditText expandedListTextView = (EditText)
				// newView.findViewById(R.id.expandedListItem);
				expandedListTextView.setVisibility(View.GONE);
				spinner = (Spinner) newView.findViewById(R.id.spinner);
				spinner.setVisibility(View.VISIBLE);
				ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
						android.R.layout.simple_spinner_item, signal);
				arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				spinner.setAdapter(arrayAdapter);
				spinner.setSelection(spinnerPositions[2]);
				spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
					@Override
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
						// TODO Auto-generated method stub
						spinnerPositions[2] = position;
						String signalStrength = signal[position];
						if (!TextUtils.isEmpty(signalStrength)) {
							if (groupPosition == 1) {
								restaurantEnvironment[childPosition] = signalStrength;
							} else if (groupPosition == 2) {
								homeDeliveryFacility[childPosition] = signalStrength;
							}
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> parent) {
						// TODO Auto-generated method stub

					}
				});
			} else {
				// EditText expandedListTextView = (EditText)
				// newView.findViewById(R.id.expandedListItem);
				expandedListTextView.setEnabled(true);
				expandedListTextView.setHint(expandedListText);
				expandedListTextView.setText(restaurantEnvironment[childPosition]);
				expandedListTextView.addTextChangedListener(new TextWatcher() {

					@Override
					public void onTextChanged(CharSequence s, int start, int before, int count) {
						// TODO Auto-generated method stub

					}

					@Override
					public void beforeTextChanged(CharSequence s, int start, int count, int after) {
						// TODO Auto-generated method stub

					}

					@Override
					public void afterTextChanged(Editable s) {
						// TODO Auto-generated method stub
						if (!TextUtils.isEmpty(s)) {
							if (groupPosition == 0) {
								ownerInfo[childPosition] = s.toString();
							} else if (groupPosition == 1) {
								restaurantEnvironment[childPosition] = s.toString();
							} else if (groupPosition == 2) {
								homeDeliveryFacility[childPosition] = s.toString();
							}
						}

					}
				});
			}
		}
		if (groupPosition == 2) {
			newView = View.inflate(context, R.layout.list_item, null);
			if (childPosition == 0) {
				EditText expandedListTextView = (EditText) newView.findViewById(R.id.expandedListItem);
				expandedListTextView.setVisibility(View.GONE);
				spinner = (Spinner) newView.findViewById(R.id.spinner);
				spinner.setVisibility(View.VISIBLE);
				ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
						android.R.layout.simple_spinner_item, deliverfood);
				arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				spinner.setAdapter(arrayAdapter);
				spinner.setSelection(spinnerPositions[3]);
				spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
						// TODO Auto-generated method stub
						spinnerPositions[3] = position;
						String doTheyDeliver = deliverfood[position];
						if (!TextUtils.isEmpty(doTheyDeliver)) {
							if (groupPosition == 1) {
								restaurantEnvironment[childPosition] = doTheyDeliver;
							} else if (groupPosition == 2) {
								homeDeliveryFacility[childPosition] = doTheyDeliver;
							}
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> parent) {
						// TODO Auto-generated method stub

					}
				});

			} else if (childPosition == 1) {
				EditText expandedListTextView = (EditText) newView.findViewById(R.id.expandedListItem);
				expandedListTextView.setVisibility(View.GONE);
				spinner = (Spinner) newView.findViewById(R.id.spinner);
				spinner.setVisibility(View.VISIBLE);
				ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
						android.R.layout.simple_spinner_item, deliveredby);
				arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
				spinner.setAdapter(arrayAdapter);
				spinner.setSelection(spinnerPositions[4]);
				spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
						// TODO Auto-generated method stub
						spinnerPositions[4] = position;
						String deliveredB = deliveredby[position];
						if (!TextUtils.isEmpty(deliveredB)) {
							if (groupPosition == 1) {
								restaurantEnvironment[childPosition] = deliveredB;
							} else if (groupPosition == 2) {
								homeDeliveryFacility[childPosition] = deliveredB;
							}
						}
					}

					@Override
					public void onNothingSelected(AdapterView<?> parent) {
						// TODO Auto-generated method stub

					}
				});

			} else {
				EditText expandedListTextView = (EditText) newView.findViewById(R.id.expandedListItem);

				expandedListTextView.setEnabled(true);
				expandedListTextView.setHint(expandedListText);
				expandedListTextView.setText(homeDeliveryFacility[childPosition]);
				if (childPosition == 2) {

					expandedListTextView.setInputType(InputType.TYPE_CLASS_NUMBER);
				}
				if (childPosition == 3) {

					expandedListTextView.setInputType(InputType.TYPE_CLASS_NUMBER);
				}
				expandedListTextView.addTextChangedListener(new TextWatcher() {

					@Override
					public void onTextChanged(CharSequence s, int start, int before, int count) {
						// TODO Auto-generated method stub

					}

					@Override
					public void beforeTextChanged(CharSequence s, int start, int count, int after) {
						// TODO Auto-generated method stub

					}

					@Override
					public void afterTextChanged(Editable s) {
						// TODO Auto-generated method stub
						if (!TextUtils.isEmpty(s)) {
							if (groupPosition == 0) {
								ownerInfo[childPosition] = s.toString();
							} else if (groupPosition == 1) {
								restaurantEnvironment[childPosition] = s.toString();
							} else if (groupPosition == 2) {
								homeDeliveryFacility[childPosition] = s.toString();
							}
						}

					}
				});
			}

		}
		if (groupPosition == 3) {
			newView = View.inflate(context, R.layout.list_item_1, null);
			ImageView imageView = (ImageView) newView.findViewById(R.id.camera);

			/*
			 * if (childPosition == 1) {
			 * imageView.setBackground(context.getDrawable(R.drawable.gallery));
			 * }
			 */
		}
		newView.invalidate();

		return newView;
	}

	@Override
	public int getChildrenCount(int listPosition) {
		return this.expandableListDetail.get(this.expandableListTitle.get(listPosition)).size();
	}

	@Override
	public Object getGroup(int listPosition) {
		return this.expandableListTitle.get(listPosition);
	}

	@Override
	public int getGroupCount() {
		return this.expandableListTitle.size();
	}

	@Override
	public long getGroupId(int listPosition) {
		return listPosition;
	}

	@Override
	public View getGroupView(int listPosition, boolean isExpanded, View convertView, ViewGroup parent) {
		String listTitle = (String) getGroup(listPosition);
		if (convertView == null) {
			LayoutInflater layoutInflater = (LayoutInflater) this.context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = layoutInflater.inflate(R.layout.list_group, null);
		}
		TextView listTitleTextView = (TextView) convertView.findViewById(R.id.listTitle);
		listTitleTextView.setTypeface(null, Typeface.BOLD);
		listTitleTextView.setText(listTitle);
		return convertView;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public boolean isChildSelectable(int listPosition, int expandedListPosition) {
		return true;
	}
}