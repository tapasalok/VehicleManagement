package com.restuarant.background;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.example.test.BusinessSummary;
import com.example.test.helper.HttpRequest;
import com.example.test.helper.URLConstants;
import com.example.test.helper.WSConstants;
import com.restuarant.utils.ProgressBarHelper;

public class CommonAsyncTask extends AsyncTask<Bundle, Integer, Bundle> {
	private Context context;
	private ProgressBarHelper progressBarHelper;
	private Map<String, String> locationInfo = new HashMap<String, String>();;
	private static final String TAG = "CommonAsyncTask";

	public CommonAsyncTask(Context context) {
		// TODO Auto-generated constructor stub
		this.context = context;
		progressBarHelper = ProgressBarHelper.getSingletonInstance();
	}

	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		progressBarHelper.showProgressBarSmall("Please wait...", true, context);
	}

	@Override
	protected Bundle doInBackground(Bundle... params) {
		// TODO Auto-generated method stub

		String module = params[0].getString(WSConstants.MODULE_KEY);
		String response = "";
		if (TextUtils.isEmpty(module)) {
			Toast.makeText(context, "Please mentione module while calling", 0)
					.show();
		} else if (module.equals(WSConstants.WS_MODULE_LIST_RESTAURANT)) {
			String latitude = params[0].getString("latitude");
			String longitude = params[0].getString("longitude");

			locationInfo.put(WSConstants.WS_KEY_LATITUDE, latitude);
			locationInfo.put(WSConstants.WS_KEY_LONGITUDE, longitude);

			Map<String, String> location = locationInfo;
			try {

				response = HttpRequest.get(URLConstants.PLACES_URL)
						.headers(location).body();
				ObjectMapper mapper = new ObjectMapper();
				TypeFactory typeFactory = TypeFactory.defaultInstance();
				List<BusinessSummary> businessSummary = mapper.readValue(
						response, typeFactory.constructCollectionType(
								List.class, BusinessSummary.class));
				Log.i(TAG + " NEARBY RESPONSE IS ", response);

				Bundle restaurantBundle = new Bundle();
				restaurantBundle.putParcelableArrayList(
						WSConstants.WS_KEY_RESULT_BUNDLE,
						(ArrayList<? extends Parcelable>) businessSummary);

				return restaurantBundle;

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		Log.i("CommonAsyncTask", response);

		return null;
	}

	@Override
	protected void onPostExecute(Bundle result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
		progressBarHelper.dismissProgressBar();
	}

}
