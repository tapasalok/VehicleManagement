/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.actionbarsherlock.app.SherlockFragment;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.LoyaltyCardWorker.LoyaltyCardWorkerMode;

/**
 * A Fragment class that will provide user to enter card number manually. This
 * class extends {@link SherlockFragment}.
 * 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 * 
 */
public class EnterCardNumberFragment extends SherlockFragment {

	private final String LOG_TAG = "EnterCardNumberFragment";
	private ViewGroup mView;
	private boolean mShowProgressBar = false;
	private String mErrorDialogTitle;
	private String mErrorDialogMessage;
	private CustomSwipeDetector mCustomSwipeDetector;
	private AlertDialog mAlertDialog;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogConfig.logd(LOG_TAG, "onCreate()");
		mCustomSwipeDetector = new CustomSwipeDetector(getActivity(), (OnSwipeListener) getActivity());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_enter_card_number, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		dismissActiveDialog();
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logd(LOG_TAG, "onResume()");
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.label_tab_loyalty_card, false, true, false, getSherlockActivity());
		final EditText editTextCardNumber = (EditText) mView.findViewById(R.id.editText_card_number);
		InputFilter[] filterArray = new InputFilter[1];
		filterArray[0] = new InputFilter.LengthFilter(PreferenceConfig.getBarCodeMaxRange(getActivity()));
		editTextCardNumber.setFilters(filterArray);
		Button buttonGo	= (Button) mView.findViewById(R.id.button_go);
		buttonGo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String barcode = editTextCardNumber.getText().toString();
				if (TextUtils.isEmpty(barcode)) {
					Resources res = getResources();
					mErrorDialogTitle = res
							.getString(R.string.title_invalid_barcode);
					mErrorDialogMessage = res
							.getString(R.string.label_enter_card_no);
					showDialog(DialogConfig.DIALOG_ERROR);
					return;
				} else if (barcode.length() < PreferenceConfig.getBarCodeMinRange(getActivity())
						|| barcode.length() > PreferenceConfig.getBarCodeMaxRange(getActivity())) {
					Resources res = getResources();
					mErrorDialogTitle = res
							.getString(R.string.title_invalid_barcode);
					mErrorDialogMessage = res
							.getString(R.string.msg_invalid_barcode);
					showDialog(DialogConfig.DIALOG_ERROR);
					return;
				}
				//if (UIUtils.isValidBarcode(barcode)) {
					if (!NetworkHelper.isNetworkAvailable(getActivity())) {
						mErrorDialogMessage = getResources().getString(R.string.network_not_available_msg);
						mErrorDialogTitle = getResources().getString(R.string.network_not_available_title);
						showDialog(DialogConfig.DIALOG_ERROR);
						return;
					}
					PreferenceConfig.setLoyaltyCardWorkerMode(
							LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_MANUAL_ADD, getActivity());
					PreferenceConfig.setLoyaltyCardNumber(barcode, getActivity());
					PreferenceConfig.setLaunchLoyaltyCardDetailsScreen(true, getActivity());
					PreferenceConfig.setBarCodeType(-1, getActivity());
					getActivity().finish();
				/*} else {
					Resources resources = getResources();
					mErrorDialogTitle = resources
							.getString(R.string.title_invalid_barcode);
					mErrorDialogTitle = mErrorDialogTitle + "\n" + barcode;
					mErrorDialogMessage = resources
							.getString(R.string.msg_invalid_barcode);
					showDialog(DialogConfig.DIALOG_ERROR);
				}*/
			}
		});
		
		mView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return mCustomSwipeDetector.onTouchEvent(event);
            }
        });
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logd(LOG_TAG, "onDestroy()");
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_loyalty_card_enter_card_number));
		   System.gc();
	   }
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {

			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorDialogTitle)
			.setMessage(mErrorDialogMessage)
			.setCancelable(true)
			.setPositiveButton(android.R.string.ok,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,
							int which) {
						dialog.dismiss();
					}
				});
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
}
