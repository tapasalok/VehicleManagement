/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.factory;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import android.text.TextUtils;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;

/**
 * A base json parser class that holds the common methods that can be
 * called from by its sub classes who extends this class.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public abstract class BaseJsonParser {

	protected static boolean parseErrorJSON(JSONObject response, HashMap<String, Object> map)
		throws JSONException {
		
		if (response==null || response.optString(JSONTagConstants.RESPONSE_TAG_ERROR)==null || response.optString(JSONTagConstants.RESPONSE_TAG_ERROR).equals("null")) {
			return false;
		}
		
		
		if (response.has(JSONTagConstants.RESPONSE_TAG_ERROR)) {
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			JSONObject errorCode = response.getJSONObject(JSONTagConstants.RESPONSE_TAG_ERROR);
			if (errorCode.has(JSONTagConstants.RESPONSE_TAG_CODE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_CODE, errorCode.getString(JSONTagConstants.RESPONSE_TAG_CODE));
			}
			if (errorCode.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, errorCode.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			} else if (errorCode.has(JSONTagConstants.RESPONSE_TAG_MSG)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, errorCode.getString(JSONTagConstants.RESPONSE_TAG_MSG));
			}
			return true;
		}
		return false;
	}
}
