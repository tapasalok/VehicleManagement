/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Application;
import android.content.Context;
import android.util.SparseArray;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.crashinvocation.CrashInvocationHandler;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.HomeCoupon;
import com.manthansystems.loyalty.util.BitmapManager;

/**
 * An {@link Application} class. 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class UIApplication extends Application {
	
	private ArrayList<Integer> mFavoriteOffersIds = new ArrayList<Integer>();
	
	private SparseArray<Coupon> mCouponArray = new SparseArray<Coupon>();
	
	private SparseArray<HomeCoupon> mCouponArrayHome = new SparseArray<HomeCoupon>();
	
	private ArrayList<String> mNotificationOfferArrayList = new ArrayList<String>();
	
	private Map<String, String> mExtraHttpHeaders = new HashMap<String, String>();
	
	private BitmapManager mBitmapManager;
	
	//All Category
	public static String ALL_CATEGORY_TITLE = "ALL";
	public static final String All_CATEGORY_ID = "9999999999";
	
	//New Category
	public static String NEW_CATEGORY_TITLE = "New Offers";
	public static final String NEW_CATEGORY_ID = "345453425";
	// Marketing Message/Promotional Offer's category id.
	public static final String PROMO_CATEGORY_ID = "1234321";
	
	@Override
	public void onCreate() {
		super.onCreate();
		init();

//		Registering the CrashInvocationHandler for getting Crash Report in terms of Email
		CrashInvocationHandler.registerCrashListener(this , getString(R.string.admin_emailid));
		
	}

	/** Set the favorite offer id list for future use while favorite sync. */
	public void setFavoriteOffersIds(final ArrayList<Integer> favoriteOfferIdList) {
		mFavoriteOffersIds = favoriteOfferIdList;
	}
	
	/** Remove the favorite offer id */
	public void removeFavoriteOffersId(final Integer favoriteOfferId) {
		if (mFavoriteOffersIds !=null && mFavoriteOffersIds.contains(favoriteOfferId)) {
			mFavoriteOffersIds.remove(favoriteOfferId);
		}
	}
	
	/** Remove the favorite offer id */
	public void addFavoriteOffersId(final Integer favoriteOfferId) {
		if (mFavoriteOffersIds !=null && !mFavoriteOffersIds.contains(favoriteOfferId)) {
			mFavoriteOffersIds.add(favoriteOfferId);
		}
	}
	
	/** Get the favorite offer id list to use while favorite sync. */
	public ArrayList<Integer> getFavoriteOfferIds() {
		return mFavoriteOffersIds;
	}
	
	/** Set the Coupon Model Array list. */
	public void setCouponModelArray(SparseArray<Coupon> couponArray) {
		mCouponArray = couponArray;
	}
	
	/** Get the coupon ModelArray  List. */
	public SparseArray<Coupon> getCouponModelArray() {
		return mCouponArray;
	}
	
	/** Set the Coupon Model Array list. */
	public void setCouponModelArrayHome(SparseArray<HomeCoupon> couponArray) {
		mCouponArrayHome = couponArray;
	}
	/** Get the coupon ModelArray  List. */
	public SparseArray<HomeCoupon> getCouponModelArrayHome() {
		return mCouponArrayHome;
	}
	
	/** Set the Notification Coupon id Array list. */
	public void setNoficationCouponIdList(ArrayList<String> notificationOfferArrayList) {
		mNotificationOfferArrayList = notificationOfferArrayList;
	}
	
	/** Get the Notification Coupon id Array list. */
	public ArrayList<String> getNoficationCouponIdList() {
		return mNotificationOfferArrayList;
	}
	
	/** Method to get the {@link BitmapManager} singleton instance. */
	public BitmapManager getBitmapManagerInstance(Context context) {
		if (mBitmapManager == null) {
			mBitmapManager = new BitmapManager(context);
		}
		return mBitmapManager;
	}
	
	/** Method to initialise locals. */
	private void init() {
		ALL_CATEGORY_TITLE = getResources().getString(R.string.title_all_category);
		NEW_CATEGORY_TITLE = getResources().getString(R.string.title_new_category);
	}
	
	/** Method to hold custom http headers for webview to set when required. */
	public void setCustomHttpHeaderToWebView(Map<String, String> headers) {
		if (mExtraHttpHeaders != null) {
			mExtraHttpHeaders.clear();
			mExtraHttpHeaders = null;
		}
		mExtraHttpHeaders = headers;
	}
	
	/** Method to get custom http headers for webview if any. */
	public Map<String, String> getCustomHttpHeaderForWebView() {
		return mExtraHttpHeaders;
	}
}