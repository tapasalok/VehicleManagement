/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.config;

/**
 * A config interface that holds the various server urls that are required to
 * communicate with the server in different operations.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public interface WSConfig {

	public final String SECRET_ID = "secretId";
	public final String PLATFORM_ID = "platform_id";
	public final String APP_VER = "app_version";
	public final String CLIENT_VERSION = "version";
	public final String LOGIN_ID = "loginId";
	public final String STORE_ID = "store_id";
	public final String DEVICE_ID = "device_id";
	public final String LOGIN_TOKEN = "login_token";
	public final String SESSION_ID = "session_id";
	public final String UTC_OFFSET = "utc_offset";

	// Set the Retailer Store ID at build time.
	public final String RETAILER_STORE_ID = "2";

	public final String WS_SEARCH_TEXT = "search_text";
	public final String WS_LAT = "lat_val";
	public final String WS_LON = "lon_val";
	public final String WS_ZIP_CODE = "zip_code";
	public final String WS_LOCAL_OFFER_ID = "local_offer_id";
	public final String WS_RADIUS = "radius_val";
	public final String WS_OFFER_IDS = "coupon_id";
	public final String WS_SCAN_CODE = "val_scan_code";
	public final String WS_FAVORITE_IDS = "coupon_id";

	// Trigger
	public final String WS_TRIGGER_EVENT_TYPE = "WS_TRIGGER_EVENT_TYPE";
	public final String WS_TRIGGER_SHARE_CHANNEL_NAME = "WS_TRIGGER_SHARE_CHANNEL_NAME";
	public final String WS_TRIGGER_LAT = "WS_TRIGGER_LAT";
	public final String WS_TRIGGER_LON = "WS_TRIGGER_LON";
	public final String WS_TRIGGER_COUPON_ID = "WS_TRIGGER_COUPON_ID";

	public final String WS_BARCODE_TYPE = "WS_BARCODE_TYPE";

	// Base Feed URL
	// public final String API_BASE_URL = "http://54.85.73.159:8110/cpnvlt";

	// Prduction URL
	// public final String API_BASE_URL = "http://54.208.143.33:8110/cpnvlt";

	//Robinsons Staging Environment
//		public final String API_BASE_URL = "http://54.85.71.45:8080/cpnvlt/";
	
	// Base Feed URL
		//Robinsons Sandbox URL
//		public final String API_BASE_URL = "http://54.85.73.159:8110/cpnvlt";
		
	//Robinsons Prduction URL
	//	public final String API_BASE_URL = "http://54.208.143.33:8110/cpnvlt/";
										
		//Robinsons Staging Environment
//		public final String API_BASE_URL = "http://54.85.71.45:8080/cpnvlt/";
		
		//QA URL
//		public final String API_BASE_URL = "http://203.109.116.125:8080/cpnvlt/";
	
	

	// Dev URL
	// public final String API_BASE_URL = "http://172.20.3.141:8080/cpnvlt";
	//FG
	 public final String API_BASE_URL = "http://54.86.33.252:8090/cpnvlt";
	// IVIZ URL
	 //  public final String API_BASE_URL = "https://54.84.132.243/";
	// public final String API_BASE_URL = "https://appiviz.arcloyalty247.com/";

    public final String HOME_URL =  API_BASE_URL+"/home?store_id="+RETAILER_STORE_ID+"&radius="+WS_RADIUS;
	   
	public final String PRIVACY_POLICY_URL = "http://www.manthansystems.com/privacy-loyalty247.html";
	public final String ABOUT_US_URL = API_BASE_URL + "/aboutus?store_id="
			+ RETAILER_STORE_ID + "&version=";

	// Get Common Offers
	final String URL_GET_COMMON_OFFERS = API_BASE_URL + "/coupons/common";
	public String URL_GET_COMMON_OFFERS_GPS = URL_GET_COMMON_OFFERS + "?lat="
			+ WS_LAT + "&lon=" + WS_LON + "&radius=" + WS_RADIUS;
	public String URL_GET_COMMON_OFFERS_ZIP = URL_GET_COMMON_OFFERS
			+ "?zipcode=" + WS_ZIP_CODE + "&radius=" + WS_RADIUS;

	// Get Home Page Common Offers
		final String URL_GET_HOME_COUPON_DETAILS = API_BASE_URL + "/coupons/homedetails";
		public String URL_GET_HOME_COUPON_DETAILS_GPS = URL_GET_HOME_COUPON_DETAILS + "?lat="
				+ WS_LAT + "&lon=" + WS_LON + "&radius=" + WS_RADIUS;
		public String URL_GET_HOME_COUPON_DETAILS_ZIP = URL_GET_HOME_COUPON_DETAILS
				+ "?zipcode=" + WS_ZIP_CODE + "&radius=" + WS_RADIUS;
	
	// Get Personal Offers
	final String URL_GET_PERSONAL_OFFERS = API_BASE_URL + "/coupons/personal";
	public String URL_GET_PERSONAL_OFFERS_GPS = URL_GET_PERSONAL_OFFERS
			+ "?lat=" + WS_LAT + "&lon=" + WS_LON + "&radius=" + WS_RADIUS;
	public String URL_GET_PERSONAL_OFFERS_ZIP = URL_GET_PERSONAL_OFFERS
			+ "?zipcode=" + WS_ZIP_CODE + "&radius=" + WS_RADIUS;

	// User Registration
	public String URL_REGISTER_EMAIL_ADDRESS = API_BASE_URL + "/user/register";
	public String URL_ACTIVATE_USER = API_BASE_URL + "/user/activate";
	public String URL_UPDATE_USER_PROFILE = API_BASE_URL + "/user/profile";

	// Get/Sync Favorite Offers
	final String URL_GET_FAVORITE_OFFERS = API_BASE_URL + "/coupons/favorites";
	public final String URL_GET_FAVORITE_OFFERS_GPS = URL_GET_FAVORITE_OFFERS
			+ "?lat=" + WS_LAT + "&lon=" + WS_LON + "&radius=" + WS_RADIUS;
	public final String URL_GET_FAVORITE_OFFERS_ZIP = URL_GET_FAVORITE_OFFERS
			+ "?zipcode=" + WS_ZIP_CODE + "&radius=" + WS_RADIUS;
	
	//Add favorite
	final String URL_ADD_FAVORITE_OFFERS =  API_BASE_URL+"/coupons/favorites?store_id="+RETAILER_STORE_ID+"&couponId="+WS_FAVORITE_IDS;
	
	//Get All Stores
		final String GET_STORES =  API_BASE_URL+"/stores/all?store_id="+RETAILER_STORE_ID;
		
	// Get Category
	public final String URL_GET_ALL_CATEGORY = API_BASE_URL + "/categories";
	public final String URL_USER_CATEGORY = API_BASE_URL + "/user/categories";

	// push notification
	public final String URL_ENABLE_PUSH_NOTIFICATION = API_BASE_URL
			+ "/notification/register";
	public final String URL_DISABLE_PUSH_NOTIFICATION = API_BASE_URL
			+ "/notification/unregister";

	// get application config properties.
	public final String URL_GET_APP_CONFIG = API_BASE_URL + "/appconfig";

	// get lat lon for zipcode.
	public final String URL_GET_LOCATION_FOR_ZIPCODE = "http://maps.googleapis.com/maps/api/geocode/json?address="
			+ WS_ZIP_CODE + "&sensor=true";

	// Validate user Zip code.
	public final String URL_VALIDATE_ZIPCODE = API_BASE_URL
			+ "/validate/zipcode?zipcode=" + WS_ZIP_CODE;

	// Login user.
	public final String URL_LOGIN_USER = API_BASE_URL + "/user/login";

	// Offer Counts based on location settings.
	final String URL_GET_OFFER_COUNTS = API_BASE_URL + "/coupons/counts";
	public String URL_OFFER_COUNTS_GPS = URL_GET_OFFER_COUNTS + "?lat="
			+ WS_LAT + "&lon=" + WS_LON + "&radius=" + WS_RADIUS;
	public String URL_OFFER_COUNTS_ZIP = URL_GET_OFFER_COUNTS + "?zipcode="
			+ WS_ZIP_CODE + "&radius=" + WS_RADIUS;

	// Trigger
	public final String URL_TRIGGER = API_BASE_URL
			+ "/user/trigger?trigger_type=" + WS_TRIGGER_EVENT_TYPE;
	public final String URL_TRIGGER_GL = URL_TRIGGER + "&lat=" + WS_TRIGGER_LAT
			+ "&lon=" + WS_TRIGGER_LON;
	public final String URL_TRIGGER_CS = URL_TRIGGER + "&coupon_id="
			+ WS_TRIGGER_COUPON_ID + "&channel="
			+ WS_TRIGGER_SHARE_CHANNEL_NAME;
	public final String URL_TRIGGER_CD = URL_TRIGGER + "&coupon_id="
			+ WS_TRIGGER_COUPON_ID;

	// Loyalty Card
	public final String URL_LOYALTY_CARD_SCAN = API_BASE_URL
			+ "/loyalty/scan?card=" + WS_SCAN_CODE + "&symboltype="
			+ WS_BARCODE_TYPE;
	public final String URL_LOYALTY_CARD_DISPLAY = API_BASE_URL
			+ "/loyalty/view";
	public final String URL_LOYALTY_CARD_EDIT = API_BASE_URL + "/loyalty/edit";
	public final String URL_LOYALTY_CARD_DELETE = API_BASE_URL
			+ "/loyalty/delete";
	public final String URL_LOYALTY_CARD_JOIN = API_BASE_URL + "/loyalty/join";

	// Coupon Redemption
	public final String URL_REDEMPTION_CONFIRMATION = API_BASE_URL
			+ "/redeem/couponconfirm";
	public final String URL_REDEMPTION_CHECK_AVAILABILITY = API_BASE_URL
			+ "/redeem/couponcheck";

	// Check app update
	public final String URL_CHECK_APP_UPDATE = API_BASE_URL + "/check/update";
}
