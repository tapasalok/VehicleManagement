/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDaoColumns;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDao;
import com.manthansystems.loyalty.data.provider.DatabaseProvider;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.CouponUsageType;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.phone.CustomWebViewActivity;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.ui.phone.OfferDetailActivity;
import com.manthansystems.loyalty.ui.phone.OfferDetailActivity.OfferDetailIntentKey;
import com.manthansystems.loyalty.ui.phone.StoreListActivity;
import com.manthansystems.loyalty.util.AnalyticsHelper;
import com.manthansystems.loyalty.util.BitmapManager;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.ShareHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.CouponRedemptionWorker;
import com.manthansystems.loyalty.worker.FavoriteOffersWorker;
import com.manthansystems.loyalty.worker.OffersWorker;

/**
 * A Fragment class that will show detail of offers. This class extends
 * {@link SherlockFragmentActivity}.
 * 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 * 
 */
public class OfferDetailFragment extends SherlockFragment implements Observer,
    LoaderManager.LoaderCallbacks<Cursor>,OnRequestFinishedListener {

	private static final String LOG_TAG = "OfferDetailFragment";

	private ViewGroup mView;
	private boolean mShowProgressBar = false;
	private Button mButtonViewStore;
	private Button mButtonViewDetail;
	private ImageView mImageViewOfferImage;
	private ImageView mImageViewBarCodeImage;
	private TextView mTextViewDescriptionText;
	private TextView mTextViewOfferTitle;
	private TextView mTextViewOfferDiscount;
	private TextView mTextViewCouponCode;
	private TextView mTextViewBarCodeText;
	private String mId;
	private int mCouponId;
	private String mCouponName;
	private int mCouponChooser;
	private String mCouponDescription;
	private int mCouponFavoriteFlag;
	private int mIsMarketingMessageFlag;
	private String mCouponImageUrl;
	private String mCouponType;
	private String mCouponUrl;
	private ArrayList<String> mCouponDecorator;
	private String mCouponDiscount;
	private int mCouponExpires;
	private String mCouponExpiryDate;
	private ArrayList<String> mCouponStoreIds;
	private String mCouponCode;
	private String mCouponLargeImageUrl;
	private int mIsCouponRedeemable;
	private int mCouponUsageType;
	private int mRedeemThresholdLimit;
	private int mIsExhausted;
	private String mCouponBarcodeImageUrl;
	private String mCouponBarcode;
	private String mCouponLongDescription;
	private BitmapManager mBitmapManager;
	private ProgressBar mProgressBarOfferLogo;

	private String mDialogMessage;
	private String mDialogTitle;
	private Handler mHandler;
	private Bundle mResponseBundle;
	private RequestManager mRequestManager;
	private int mRequestId = -1;
	private int mRequestType = -1;

	private ProgressBar mProgressBarBarCode;
	private AlertDialog mAlertDialog;
	private Button mButtonRedeeemNow;
	private ProgressBar mProgressBarOfferLogoRedeem;
	private ProgressBar mProgressBarBarCodeRedeem;
	private ImageView mImageViewOfferImageRedeem;
	private ImageView mImageViewBarCodeImageRedeem;
	private TextView mTextViewCouponCodeRedeem;
	private TextView mTextViewBarCodeTextRedeem;
	private Dialog mRedeemDialog;
	private boolean mIsFavoriteClicked = false;
	
    /** To check if no network case occurs or not.*/
    private boolean mIsNoNetworkCaseOccurs = false;
    private boolean mSearchResultShowing = false;
    private String mErrorMessage;
    private String mDlgMessage;
    private static MenuItem menuItem;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState == null) {
			prepareDataFromModel();
		} else {
			prepareDataFromSavedInstance(savedInstanceState);
		}
		mBitmapManager = new BitmapManager(getActivity());
		mBitmapManager.setPlaceholder(BitmapFactory.decodeResource(
				getActivity().getResources(), R.drawable.background_trans));
		mHandler = new Handler();
		mRequestManager = RequestManager.from(getActivity());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(
				R.layout.fragment_offer_detail_screen, null);

		// For some reason, if we omit this, NoSaveStateFrameLayout thinks we
		// are
		// FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top
		// of the activity.
		root.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT));
		mView = root;
		bindViews();
		populateView();
		return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onPause() {
		super.onPause();
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager
					.removeOnRequestFinishedListener(OfferDetailFragment.this);
		}
		dismissActiveDialog();
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logv(LOG_TAG, "onResume() " + mCouponName);
		if (mRequestId != -1) {
			if (mRequestManager.isRequestInProgress(mRequestId)) {
				mRequestManager
						.addOnRequestFinishedListener(OfferDetailFragment.this);
			} else {
				ProgressBarHelper.dismissProgressbarFromOtherScreen();
				mRequestId = -1;
			}
		}
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		}
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_ID, mId);
		outState.putInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_ID, mCouponId);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_NAME,
				mCouponName);
		outState.putInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_CHOOSER,
				mCouponChooser);
		outState.putString(
				OfferDetailIntentKey.OFFER_DETAIL_COUPON_LONG_DESCRIPTION,
				mCouponLongDescription);
		outState.putInt(OfferDetailIntentKey.OFFER_DETAIL_FAVORITE_FLAG,
				mCouponFavoriteFlag);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_IMAGE_URL,
				mCouponImageUrl);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_TYPE,
				mCouponType);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_URL,
				mCouponUrl);
		outState.putStringArrayList(
				OfferDetailIntentKey.OFFER_DETAIL_DECORATOR, mCouponDecorator);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_DISCOUNT,
				mCouponDiscount);
		outState.putInt(OfferDetailIntentKey.OFFER_DETAIL_EXPIRES,
				mCouponExpires);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_EXPIRY_DATE,
				mCouponExpiryDate);
		outState.putStringArrayList(OfferDetailIntentKey.OFFER_DETAIL_STORE_ID,
				mCouponStoreIds);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_BARCODE,
				mCouponBarcode);
		outState.putString(
				OfferDetailIntentKey.OFFER_DETAIL_COUPON_BARCODE_IMAGE_URL,
				mCouponBarcodeImageUrl);
		outState.putString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_CODE,
				mCouponCode);
		outState.putString(
				OfferDetailIntentKey.OFFER_DETAIL_COUPON_LARGE_IMAGE_URL,
				mCouponLargeImageUrl);
		outState.putString(
				OfferDetailIntentKey.OFFER_DETAIL_COUPON_DESCRIPTION,
				mCouponDescription);
		outState.putInt(
				OfferDetailIntentKey.OFFER_DETAIL_MARKETING_MESSAGE_FLAG,
				mIsMarketingMessageFlag);
		outState.putInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_REDEEMABLE,
				mIsCouponRedeemable);
		outState.putInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_USAGE_TYPE,
				mCouponUsageType);
		outState.putInt(
				OfferDetailIntentKey.OFFER_DETAIL_COUPON_REDEEM_THRESHOLD_LIMIT,
				mRedeemThresholdLimit);
		outState.putInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_EXHAUSTED,
				mIsExhausted);
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		menu.clear();
		if ((mCouponUsageType == CouponUsageType.TYPE_NORMAL
				|| mCouponUsageType == CouponUsageType.TYPE_MULTIPLE
				|| mCouponUsageType == CouponUsageType.TYPE_MULTIPLE_WITH_THRESHOLD || mIsMarketingMessageFlag == CouponDao.FLAG_VALUE_MARKETING_MESSAGE)
				&& (mIsExhausted == CommonConfig.FLAG_FALSE)) {
			inflater.inflate(R.menu.facebook_menu_item, menu);
			if (mCouponFavoriteFlag== 1) {
				 menu.findItem(R.id.ImageView_fav_icon).setIcon(R.drawable.ic_star_selected);				
			} else {
				 menu.findItem(R.id.ImageView_fav_icon).setIcon(R.drawable.ic_star_deselected);				
			}
		}	   
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			showNoNetworkConnectionDialog();
			super.onOptionsItemSelected(item);
		}
		
		if (item.getItemId() == R.id.menu_facebook) {
			publishFacebookFeed();
		}
		else if((item.getItemId() == R.id.ImageView_fav_icon)){	
					
		if (mCouponFavoriteFlag== 1) {
			item.setIcon(R.drawable.ic_star_selected);
		} else {
			item.setIcon(R.drawable.ic_star_deselected);
		}
		menuItem = item;
	   if (!PreferenceConfig.isValidUser(getActivity())) {
			// pre-condition
			mDlgMessage =getString(R.string.dialog_signup_user_message_fav_tab);
			showDialog(DialogConfig.DIALOG_SIGN_UP);	
			return true;
		}
		else if (mCouponFavoriteFlag == 0) {
			System.out.println("IF****************0");
			
			mRequestType = NetworkHelper.REQUEST_TYPE.ADD_FAVORITE;
			callSyncFavoriteOffersWS(true);
			AnalyticsHelper.sendFavoriteStarClickedAnalytics(getActivity(),mCouponName,true);
//			mCouponFavoriteFlag=1;			
		}
		else if (mCouponFavoriteFlag == 1) {
			System.out.println("IF****************1");
			
			mRequestType = NetworkHelper.REQUEST_TYPE.REMOVE_FAVORITE;
			callSyncFavoriteOffersWS(false);
			AnalyticsHelper.sendFavoriteStarClickedAnalytics(getActivity(), mCouponName, false);
//           mCouponFavoriteFlag=0;
		}
	
		}
		return super.onOptionsItemSelected(item);
	}
	

	/** Make server request to sync favorite Offers. */
	private void callSyncFavoriteOffersWS(final boolean addFav) {
		LogConfig.logv(LOG_TAG, "callSyncFavoriteOffersWS() ");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mDialogTitle = getResources().getString(R.string.network_not_available_title);
			queryFavoriteOffersFromDB();
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		
		// prepare the favorite offer ids.
//		prepareFavoriteOfferIds();		
		mRequestManager.addOnRequestFinishedListener(OfferDetailFragment.this);
		ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
				false, mHandler, getActivity());
		Bundle params = new Bundle();
		params.putByte(FavoriteOffersWorker.DOWNLOAD_MODE,
				PreferenceConfig.getDownloadMode(getActivity()));
		if (addFav) {
			params.putBoolean(FavoriteOffersWorker.ADD_FAVORITE_REQUEST, true);
		} else {
			params.putBoolean(FavoriteOffersWorker.REMOVE_FAVORITE_REQUEST, true);
		}
		params.putString(CouponDaoColumns.COUPON_ID,Integer.toString(mCouponId));
		mRequestId = mRequestManager.getFavoriteOffers(DownloadFormat.RETURN_FORMAT_JSON,
				params);
		
		// reset the search status once again, though it is also resetting from
		// onLoadFinished() method of search result query completion.
		mSearchResultShowing = false;

	}
		
	
	/** Method to call after favorite offers sync with server process completion. */
	private void favoriteOffersSyncedDoSomething() {
		queryFavoriteOffersFromDB();
	}
	/** Method to prepare query to fetch favorite offers from database. */
	private void queryFavoriteOffersFromDB() {
		ProgressBarHelper.dismissProgressBar(mHandler);
		getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST);
		getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST);
		// Load store offers from database
        getLoaderManager().initLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST, null, this);
	}
	
	/** Method to prepare favorite offer ids from database. This method must be
	 * called before going for favorite sync. */
	private void prepareFavoriteOfferIds() {
		CursorLoader loader = new CursorLoader(getActivity(), CouponDao.CONTENT_URI,
				new String[] { CouponDao.COUPON_ID },
				CouponDao.WHERE_CLAUSE_COUPON_CHOOSER + DatabaseConfig.DB_OFFER_TYPE_FAVORITE,
				null, null);
		Cursor c = loader.loadInBackground();
		UIApplication app = (UIApplication) getActivity().getApplication();
		ArrayList<Integer> favoriteOfferIds = new ArrayList<Integer>();
		if (c != null && c.getCount() > 0) {
			c.moveToPosition(-1);
			while (c.moveToNext()) {
				favoriteOfferIds.add(c.getInt(0));
			}
		}
		app.setFavoriteOffersIds(favoriteOfferIds);
		if (c != null) {
			c.close();
		}
	}
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		mImageViewOfferImage = (ImageView) mView
				.findViewById(R.id.imageView_offer_logo);
		mTextViewDescriptionText = (TextView) mView
				.findViewById(R.id.textView_offer_description_text);
		mTextViewOfferTitle = (TextView) mView
				.findViewById(R.id.textView_offer_title);
		mTextViewOfferDiscount = (TextView) mView
				.findViewById(R.id.textView_cououn_discount);
		mButtonViewStore = (Button) mView.findViewById(R.id.button_view_store);
		mButtonViewDetail = (Button) mView
				.findViewById(R.id.button_view_detail);
		mProgressBarOfferLogo = (ProgressBar) mView
				.findViewById(R.id.progress_bar_offer_logo);
		mProgressBarBarCode = (ProgressBar) mView
				.findViewById(R.id.progress_bar_barcode_image);
		mTextViewBarCodeText = (TextView) mView
				.findViewById(R.id.textView_barcode_text);
		mTextViewCouponCode = (TextView) mView
				.findViewById(R.id.textView_coupon_code);
		mImageViewBarCodeImage = (ImageView) mView
				.findViewById(R.id.imageView_barcode_image);
		mButtonRedeeemNow = (Button) mView.findViewById(R.id.Button_redeem);
		if (mIsMarketingMessageFlag == CouponDao.FLAG_VALUE_MARKETING_MESSAGE) {
			mButtonViewStore.setVisibility(View.GONE);
			mButtonViewDetail.setVisibility(View.GONE);
			mView.findViewById(R.id.frameLayout_barcode_image).setVisibility(
					View.GONE);
			mTextViewBarCodeText.setVisibility(View.GONE);
			mTextViewCouponCode.setVisibility(View.GONE);
			((TextView) mView
					.findViewById(R.id.textView_offer_description_title))
					.setText(getResources().getString(
							R.string.label_description));
			mTextViewOfferTitle.setGravity(Gravity.CENTER_HORIZONTAL);
		} else {
			if (mCouponType
					.equalsIgnoreCase(BusinessLogicConfig.OFFER_TYPE_ONLINE)) {
				mButtonViewStore.setVisibility(View.INVISIBLE);
			} else {
				mButtonViewStore.setVisibility(View.VISIBLE);
				mButtonViewStore.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						
						if (!NetworkHelper.isNetworkAvailable(getActivity())) {
							showNoNetworkConnectionDialog();
							return;
						}
						
						mRequestManager.addOnRequestFinishedListener(OfferDetailFragment.this);
						ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
								false, mHandler, getActivity());
						Bundle params = new Bundle();
						params.putByte(OffersWorker.DOWNLOAD_MODE,
								PreferenceConfig.getDownloadMode(getActivity()));
						params.putBoolean(OffersWorker.GET_STORES, true);
						mRequestType = NetworkHelper.REQUEST_TYPE.GET_STORES;
						mRequestId = mRequestManager.getAllStoreIds(DownloadFormat.RETURN_FORMAT_JSON,
								params);
						
						
					}
				});
				hideViewStoreButtonIfNoStoreLocationGiven();
			}
			// If coupon url is empty then hide the view stores button
			if (TextUtils.isEmpty(mCouponUrl)) {
				mButtonViewDetail.setVisibility(View.GONE);
			} else {
				mButtonViewDetail.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						launchWebViewToShowStoreDetail();
					}
				});
			}

			// If coupon is redeemable and not exhausted then show the
			// Redeem/Get Code button.
			if (mIsCouponRedeemable == CommonConfig.FLAG_TRUE
					&& mIsExhausted == CommonConfig.FLAG_FALSE) {
				mView.findViewById(R.id.frameLayout_barcode_image)
						.setVisibility(View.GONE);
				mTextViewBarCodeText.setVisibility(View.GONE);
				mTextViewCouponCode.setVisibility(View.GONE);
				mButtonRedeeemNow.setVisibility(View.VISIBLE);
				mButtonRedeeemNow.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						if (PreferenceConfig.isValidUser(getActivity())) {
							if (NetworkHelper.isNetworkAvailable(getActivity())) {
								// Reset the offers download timestamp to
								// refresh offers everytime
								// when user clicks on Redeem Button.
								PreferenceConfig.setCommonOffersTimestamp(0L,
										getActivity());
								PreferenceConfig.setPersonalOffersTimestamp(0L,
										getActivity());
							}
							// If the usage type is
							// CouponUsageType.TYPE_MULTIPLE_WITH_THRESHOLD,
							// then issue the request to check if the coupon
							// reached the threshold or not.
							if (mCouponUsageType == CouponUsageType.TYPE_MULTIPLE_WITH_THRESHOLD) {
								callCheckCouponRedemptionAvailabilityWS();
							} else {
								if (mCouponUsageType == CouponUsageType.TYPE_SINGLE) {
									mDialogMessage = getActivity()
											.getResources()
											.getString(
													R.string.dialog_single_redeem_permission_msg);
								} else {
									mDialogMessage = getActivity()
											.getResources()
											.getString(
													R.string.dialog_multiple_redeem_permission_msg);
								}
								showDialog(DialogConfig.DIALOG_COUPON_REDEMPTION_PERMISSION);
							}
						} else {
							mDlgMessage=getString(R.string.dialog_signup_user_message_redeem);
							showDialog(DialogConfig.DIALOG_SIGN_UP);
						}
					}
				});
				if (mCouponUsageType == CouponUsageType.TYPE_SINGLE) {
					mView.findViewById(R.id.TextView_redemption_status)
							.setVisibility(View.VISIBLE);
				}
			} else {
				// If coupon is Exhausted and a Single/Multiple use coupon, then
				// hide the barcode, coupon code,
				// And show it as Sold out Offer.
				if (mCouponUsageType == CouponUsageType.TYPE_MULTIPLE
						|| mCouponUsageType == CouponUsageType.TYPE_MULTIPLE_WITH_THRESHOLD
						|| mCouponUsageType == CouponUsageType.TYPE_SINGLE) {
					mView.findViewById(R.id.frameLayout_barcode_image)
							.setVisibility(View.GONE);
					mTextViewBarCodeText.setVisibility(View.GONE);
					mTextViewCouponCode.setVisibility(View.GONE);
					mButtonRedeeemNow.setVisibility(View.VISIBLE);
					mButtonRedeeemNow
							.setBackgroundResource(R.drawable.button_selected);
					if (mIsExhausted == CommonConfig.FLAG_TRUE) {
						mButtonRedeeemNow.setText(R.string.label_sold_out);
						TextView redemptionStatus = (TextView) mView
								.findViewById(R.id.TextView_redemption_status);
						redemptionStatus.setVisibility(View.VISIBLE);
						redemptionStatus
								.setText(R.string.label_coupon_no_longer_valid);
					}
				} else {
					mButtonRedeeemNow.setVisibility(View.GONE);
				}
			}
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mRedeemDialog != null) {
			mRedeemDialog.dismiss();
		}
		if (mView != null) {
			UIUtils.unbindDrawables(mView
					.findViewById(R.id.root_view_offer_detail_screen));
			System.gc();
			if (mBitmapManager != null) {
				mBitmapManager.deleteObserver(this);
				mBitmapManager.clearCache();
			}
		}
	}

	/** A method to populate data to view. **/
	private void populateView() {
		int currentFragment = getArguments().getInt(
				OfferDetailIntentKey.CURRENT_FRAGMENT_INDEX);
		LogConfig.logv(LOG_TAG, "populateView(): current fragment = "
				+ currentFragment);
		// Set the screen title.
		// UIUtils.setTitleView(R.string.title_offers_detail_screen, true,
		// false, false, getSherlockActivity());
		// setScreenTitle(getSherlockActivity());
		if (((OfferDetailActivity) getSherlockActivity())
				.canSetScreenTitle(getArguments().getInt(
						OfferDetailIntentKey.CURRENT_FRAGMENT_INDEX))) {
			// Set the screen title view.
			setScreenTitle(getSherlockActivity());
		}
		if (TextUtils.isEmpty(mCouponName)) {
			mTextViewOfferTitle.setText("");
		} else {
			mTextViewOfferTitle.setText(mCouponName);
		}
		if (TextUtils.isEmpty(mCouponDescription)) {
			mTextViewDescriptionText.setText("");
		} else {
			mTextViewDescriptionText.setText(mCouponDescription);
		}
		// if (TextUtils.isEmpty(mCouponDiscount)) {
		mTextViewOfferDiscount.setText("");
		// } else {
		// mTextViewOfferDiscount.setText(getResources().getString(R.string.discount)
		// + " " + mCouponDiscount);
		// }
		if (TextUtils.isEmpty(mCouponBarcode)) {
			mTextViewBarCodeText.setText("");
		} else {
			mTextViewBarCodeText.setText(mCouponBarcode);
		}
		if (TextUtils.isEmpty(mCouponCode)) {
			mTextViewCouponCode.setText("");
		} else {
			mTextViewCouponCode.setText(getResources().getString(
					R.string.coupon_code)
					+ " " + mCouponCode);
		}
		if (NetworkHelper.isNetworkAvailable(getActivity())) {
			mBitmapManager.addObserver(this);
			if (TextUtils.isEmpty(mCouponBarcodeImageUrl)) {
				mProgressBarBarCode.setVisibility(View.GONE);
			} else {
				mBitmapManager.loadBitmap(mCouponBarcodeImageUrl,
						mImageViewBarCodeImage, 150, 60);
			}
			if (TextUtils.isEmpty(mCouponLargeImageUrl)) {
				if (mIsMarketingMessageFlag == CouponDao.FLAG_VALUE_MARKETING_MESSAGE) {
					mBitmapManager.loadBitmap(
							PreferenceConfig
									.getMaketMessageImageUrl(getActivity()),
							mImageViewOfferImage,
							getResources().getInteger(
									R.integer.offer_detail_image_width),
							getResources().getInteger(
									R.integer.offer_detail_image_height));
				} else {
					mProgressBarOfferLogo.setVisibility(View.GONE);
				}
			} else {
				mBitmapManager.loadBitmap(
						mCouponLargeImageUrl,
						mImageViewOfferImage,
						getResources().getInteger(
								R.integer.offer_detail_image_width),
						getResources().getInteger(
								R.integer.offer_detail_image_height));
			}
		} else {
			mProgressBarOfferLogo.setVisibility(View.GONE);
			mProgressBarBarCode.setVisibility(View.GONE);
		}
	}

	@Override
	public void update(Observable observable, Object data) {
		final String downloadedUrl = (String) data;
		try {
			getSherlockActivity().runOnUiThread(new Runnable() {
				public void run() {
					if (downloadedUrl.equalsIgnoreCase(mCouponImageUrl)) {
						mProgressBarOfferLogo.setVisibility(View.GONE);
						if (mProgressBarOfferLogoRedeem != null) {
							mProgressBarOfferLogoRedeem
									.setVisibility(View.GONE);
						}
						LogConfig.logv(LOG_TAG,
								"update(): mCouponImageUrl = mProgressBarOfferLogo "
										+ mProgressBarOfferLogo.isShown());
					}
					if (downloadedUrl.equalsIgnoreCase(mCouponBarcodeImageUrl)) {
						mProgressBarBarCode.setVisibility(View.GONE);
						if (mProgressBarBarCodeRedeem != null) {
							mProgressBarBarCodeRedeem.setVisibility(View.GONE);
						}
						LogConfig.logv(LOG_TAG,
								"update(): mCouponBarcodeImageUrl = mProgressBarBarCode "
										+ mProgressBarBarCode.isShown());
					}
				}
			});
		} catch (Exception e) {
			Log.e(LOG_TAG, "Error loading image: url= " + downloadedUrl
					+ ", Error: " + e);
		}
	}

	/** A method to launch WebView activity to show store detail. **/
	private void launchWebViewToShowStoreDetail() {
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			showNoNetworkConnectionDialog();
			return;
		}
		Intent intent = new Intent(getActivity(), CustomWebViewActivity.class);
		intent.putExtra(CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_URL,
				mCouponUrl);
		startActivity(intent);
	}

	/** A method to prepare data from model. **/
	private void prepareDataFromModel() {
		UIApplication app = (UIApplication) getActivity()
				.getApplicationContext();
		Coupon coupon = app.getCouponModelArray().get(
				getArguments().getInt(
						OfferDetailIntentKey.CURRENT_FRAGMENT_INDEX));
		mCouponId = coupon.mId;
		mCouponName = coupon.mTitle;
		mCouponChooser = coupon.mCouponChooser;
		mCouponLongDescription = coupon.mLongDescription;
		mCouponFavoriteFlag = coupon.mFavoriteFlag;
		mCouponImageUrl = coupon.mImageUrl;
		mCouponType = coupon.mCouponType;
		mCouponUrl = coupon.mCouponUrl;
		mCouponDecorator = coupon.mDecorators;
		mCouponDiscount = coupon.mDiscount;
		mCouponExpires = coupon.mExpires;
		mCouponExpiryDate = coupon.mExpiryDate;
		mCouponStoreIds = coupon.mStoreIds;
		mCouponBarcode = coupon.mBarcode;
		mCouponBarcodeImageUrl = coupon.mBarcodeImageUrl;
		mCouponCode = coupon.mCouponCode;
		mCouponLargeImageUrl = coupon.mLargeImageUrl;
		mCouponDescription = coupon.mDescription;
		mIsMarketingMessageFlag = coupon.mIsMarketingMessageFlag;
		mIsCouponRedeemable = coupon.mRedeemableFlag;
		mCouponUsageType = coupon.mUsageType;
		mRedeemThresholdLimit = coupon.mThresholdLimit;
		mIsExhausted = coupon.mExhaustedFlag;
	}

	/** A method to prepare data from saved instance. **/
	private void prepareDataFromSavedInstance(Bundle savedInstanceState) {
		mId = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_ID);
		mCouponId = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_ID);
		mCouponName = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_NAME);
		mCouponChooser = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_CHOOSER);
		mCouponLongDescription = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_LONG_DESCRIPTION);
		mCouponFavoriteFlag = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_FAVORITE_FLAG);
		mCouponImageUrl = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_IMAGE_URL);
		mCouponType = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_TYPE);
		mCouponUrl = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_URL);
		mCouponDecorator = savedInstanceState
				.getStringArrayList(OfferDetailIntentKey.OFFER_DETAIL_DECORATOR);
		mCouponDiscount = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_DISCOUNT);
		mCouponExpires = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_EXPIRES);
		mCouponExpiryDate = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_EXPIRY_DATE);
		mCouponStoreIds = savedInstanceState
				.getStringArrayList(OfferDetailIntentKey.OFFER_DETAIL_STORE_ID);
		mCouponBarcode = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_BARCODE);
		mCouponBarcodeImageUrl = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_BARCODE_IMAGE_URL);
		mCouponCode = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_CODE);
		mCouponLargeImageUrl = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_LARGE_IMAGE_URL);
		mCouponDescription = savedInstanceState
				.getString(OfferDetailIntentKey.OFFER_DETAIL_COUPON_DESCRIPTION);
		mIsCouponRedeemable = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_REDEEMABLE);
		mCouponUsageType = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_USAGE_TYPE);
		mRedeemThresholdLimit = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_REDEEM_THRESHOLD_LIMIT);
		mIsExhausted = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_COUPON_EXHAUSTED);
		mIsMarketingMessageFlag = savedInstanceState
				.getInt(OfferDetailIntentKey.OFFER_DETAIL_MARKETING_MESSAGE_FLAG);
	}

	/** Method to launch map screen to locate stores on map. */
	private void locateStoresOnMap() {
		if (mCouponStoreIds != null && mCouponStoreIds.size() > 0) {
			Intent intent = new Intent(getActivity(), MapsActivity.class);
			intent.putStringArrayListExtra(
					MapsActivity.KEY_CONSTANTS.STORE_IDS, mCouponStoreIds);
			intent.putExtra(MapsActivity.KEY_CONSTANTS.OFFER_TITLE, mCouponName);
			startActivity(intent);
		} else {
			int radius = PreferenceConfig
					.getOffersProximityRadius(getActivity());
			if (radius == -1) {
				radius = BusinessLogicConfig.DEFAULT_OFFER_PROXIMITY_RADIUS;
			}
			mDialogMessage = String.format(
					getResources().getString(R.string.msg_no_stores_to_locate),
					"" + radius);
			mDialogTitle = getResources().getString(R.string.app_name);
			showDialog(DialogConfig.DIALOG_ERROR);
		}
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(mDialogTitle)
					.setMessage(mDialogMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;

		case DialogConfig.DIALOG_COUPON_REDEMPTION_PERMISSION:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.label_redeem_coupon)
					.setMessage(mDialogMessage)
					.setCancelable(false)
					.setNegativeButton(android.R.string.cancel,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							})
					.setPositiveButton(R.string.label_continue,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									callConfirmCouponRedemptionWS();
								}
							});
			break;

		case DialogConfig.DIALOG_SIGN_UP:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(mDlgMessage)
					.setCancelable(false);
			if (UIUtils.getRetailId(getActivity()) == CommonConfig.RETAILTYPE_ROBINSON) {
				dlg.setNegativeButton(R.string.label_sign_up,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								dialog.dismiss();
								getActivity().startActivity(new Intent(
										getActivity(), EnterEmailActivity.class));
							}
					})
					.setPositiveButton(android.R.string.cancel,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								dialog.dismiss();
							}
					});
			}else{
				dlg.setNegativeButton(android.R.string.cancel,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();

							}
						})
				.setPositiveButton(R.string.label_sign_up,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
								getActivity().startActivity(
										new Intent(getActivity(),
												EnterEmailActivity.class));
							}
						});
			}
					
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

	/** Method to publish the feed to facebook. */
	private void publishFacebookFeed() {
		String appName = getResources().getString(R.string.app_name) + ".";
		String couponName = mCouponName;
		if (!TextUtils.isEmpty(couponName)) {
			int length = couponName.length();
			if (couponName.charAt(length - 1) == '.') {
				couponName = couponName.substring(0, (length - 1));
			}
		}
		String message = String.format(
				getResources().getString(R.string.msg_feed_message),
				couponName, appName);

		if (mIsMarketingMessageFlag == CouponDao.FLAG_VALUE_MARKETING_MESSAGE) {
			message = message + "\n"
					+ getResources().getString(R.string.msg_download_app);

		} else if (mCouponUsageType == CouponUsageType.TYPE_NORMAL
				|| mCouponUsageType == CouponUsageType.TYPE_MULTIPLE
				|| mCouponUsageType == CouponUsageType.TYPE_MULTIPLE_WITH_THRESHOLD) {
			message = message
					+ "\n"
					+ getResources().getString(
							R.string.msg_download_app_for_coupon_code);

		}

		Bundle params = new Bundle();
		params.putString(FacebookActivity.KEY_CONSTANTS.COUPON_ID, mCouponId
				+ "");
		params.putString(FacebookActivity.KEY_CONSTANTS.FEED_MESSAGE, message);
		params.putString(FacebookActivity.KEY_CONSTANTS.FEED_CAPTION,
				mCouponName);
		params.putString(FacebookActivity.KEY_CONSTANTS.FEED_DESCRIPTION,
				mCouponDescription);
		if (!TextUtils.isEmpty(mCouponUrl)) {
			params.putString(FacebookActivity.KEY_CONSTANTS.FEED_LINK,
					mCouponUrl);
		}
		params.putString(FacebookActivity.KEY_CONSTANTS.FEED_NAME, appName);
		if (TextUtils.isEmpty(mCouponLargeImageUrl)
				&& mIsMarketingMessageFlag == CouponDao.FLAG_VALUE_MARKETING_MESSAGE) {
			params.putString(FacebookActivity.KEY_CONSTANTS.FEED_PICTURE,
					PreferenceConfig.getMaketMessageImageUrl(getActivity()));
		} else {
			params.putString(FacebookActivity.KEY_CONSTANTS.FEED_PICTURE,
					mCouponLargeImageUrl);
		}
		ShareHelper.publishFacebookFeed(getActivity(), params);
	}

	private void showNoNetworkConnectionDialog() {
		ProgressBarHelper.dismissProgressBar(mHandler);
		mDialogMessage = getResources().getString(
				R.string.network_not_available_msg);
		mDialogTitle = getResources().getString(
				R.string.network_not_available_title);
		showDialog(DialogConfig.DIALOG_ERROR);
		return;
	}

	// Note: showStoreListScreen() method will used later if google map use is
	// disabled from
	// server. It will show the store list where user can make call to stores.
	/** A method to show store list screen. */
	@SuppressWarnings("unused")
	private void showStoreListScreen() {
		Intent intent = new Intent(getActivity(), StoreListActivity.class);
		intent.putStringArrayListExtra(StoreListFragment.STORE_IDS,
				mCouponStoreIds);
		startActivity(intent);
	}

	/**
	 * Method to hide the <code>View Store</code> button if there is no lat or
	 * lon location data is attached to the stores for the current offer.
	 */
	private void hideViewStoreButtonIfNoStoreLocationGiven() {
		// Pre-condition.
		if (mCouponStoreIds.size() <= 0) {
			mButtonViewStore.setVisibility(View.INVISIBLE);
			return;
		}else{
			mButtonViewStore.setVisibility(View.VISIBLE);
		}
		
		boolean hideViewStoreButton = true;
		String storeIds = mCouponStoreIds.toString();
		storeIds = storeIds.replace("[", "").replace("]", "").replace(" ", "");

		// prepare and fetch the store data from database.
		CursorLoader loader = new CursorLoader(getActivity(),
				StoreDao.CONTENT_URI, null, StoreDao.WHERE_CLAUSE_STORE_IDS_IN
						+ "(" + storeIds + ")", null, null);
		Cursor cursor = loader.loadInBackground();
		if (cursor != null && cursor.getCount() > 0) {
			cursor.moveToPosition(-1);
			while (cursor.moveToNext()) {
				double storeLat = cursor
						.getDouble(StoreDao.CONTENT_STORE_LAT_COLUMN);
				double storeLon = cursor
						.getDouble(StoreDao.CONTENT_STORE_LONG_COLUMN);
				if (!(storeLat == 0 || storeLat == -1 || storeLon == 0 || storeLon == -1)) {
					hideViewStoreButton = false;
					break;
				}
			}
		}
		if (cursor != null) {
			cursor.close();
			cursor = null;
		}
		if (hideViewStoreButton == false) {
			mButtonViewStore.setVisibility(View.VISIBLE);
		}
	}

	/**
	 * Method to set the screen title. The title is assigned already by the
	 * owner activity.
	 */
	public void setScreenTitle(SherlockFragmentActivity activity) {
		// Set the screen title view.
		UIUtils.setTitleView(
				getArguments().getString(
						OfferDetailIntentKey.OFFER_DETAIL_TITLE), false, true,
				false, activity);
	}

	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}

	/** Method to show the coupon redeem dialog. */
	private void showRedeemCouponDialog() {
		if (mRedeemDialog != null) {
			mRedeemDialog.dismiss();
		}
		mRedeemDialog = new Dialog(getActivity());
		mRedeemDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mRedeemDialog.setContentView(R.layout.coupon_redemption_dialog);
		mRedeemDialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(android.R.color.transparent));
		mRedeemDialog.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0
						|| keyCode == KeyEvent.KEYCODE_BACK
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});
		mRedeemDialog.show();

		mProgressBarOfferLogoRedeem = (ProgressBar) mRedeemDialog
				.findViewById(R.id.progress_bar_offer_logo);
		mProgressBarBarCodeRedeem = (ProgressBar) mRedeemDialog
				.findViewById(R.id.progress_bar_barcode_image);
		mImageViewOfferImageRedeem = (ImageView) mRedeemDialog
				.findViewById(R.id.imageView_offer_logo);
		mImageViewBarCodeImageRedeem = (ImageView) mRedeemDialog
				.findViewById(R.id.imageView_barcode_image);
		mTextViewBarCodeTextRedeem = (TextView) mRedeemDialog
				.findViewById(R.id.textView_barcode_text);
		mTextViewCouponCodeRedeem = (TextView) mRedeemDialog
				.findViewById(R.id.textView_coupon_code);
		final ImageView imageViewDialogClose = (ImageView) mRedeemDialog
				.findViewById(R.id.ImageView_close_icon);
		imageViewDialogClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mRedeemDialog.dismiss();
				getActivity().finish();
				// Commented following Paper Shredder animation.
				/*
				 * final RelativeLayout containerLayout = (RelativeLayout)
				 * mView.findViewById(R.id.root_view_offer_detail_screen);
				 * LayoutInflater inflater = (LayoutInflater)
				 * getActivity().getSystemService(
				 * Context.LAYOUT_INFLATER_SERVICE);
				 * 
				 * final ImageView paperPieceImageView = new
				 * ImageView(getActivity()); RelativeLayout.LayoutParams
				 * paramsImg = new RelativeLayout.LayoutParams(
				 * RelativeLayout.LayoutParams.FILL_PARENT,
				 * RelativeLayout.LayoutParams.WRAP_CONTENT);
				 * paperPieceImageView.setLayoutParams(paramsImg);
				 * paperPieceImageView
				 * .setBackgroundResource(R.drawable.paper_cut_pieces);
				 * paperPieceImageView.setPadding(0, 100, 0, 0);
				 * paperPieceImageView.setVisibility(View.GONE); Animation
				 * animationImg = AnimationUtils.loadAnimation(getActivity(),
				 * R.anim.translate_slide_center_down);
				 * animationImg.setAnimationListener(new AnimationListener() {
				 * 
				 * @Override public void onAnimationStart(Animation animation) {
				 * mHandler.post(new Runnable() {
				 * 
				 * @Override public void run() {
				 * paperPieceImageView.setVisibility(View.VISIBLE); } }); }
				 * 
				 * @Override public void onAnimationRepeat(Animation animation)
				 * { // Do Nothing }
				 * 
				 * @Override public void onAnimationEnd(Animation animation) {
				 * paperPieceImageView.setVisibility(View.GONE); } });
				 * paperPieceImageView.setAnimation(animationImg);
				 * 
				 * final ImageView paperPieceImageView2 = new
				 * ImageView(getActivity());
				 * paperPieceImageView.setLayoutParams(paramsImg);
				 * paperPieceImageView
				 * .setBackgroundResource(R.drawable.paper_cut_pieces);
				 * paperPieceImageView.setPadding(0, 100, 0, 0);
				 * paperPieceImageView.setVisibility(View.GONE); Animation
				 * animationImg2 = AnimationUtils.loadAnimation(getActivity(),
				 * R.anim.translate_slide_center_down);
				 * animationImg2.setAnimationListener(new AnimationListener() {
				 * 
				 * @Override public void onAnimationStart(Animation animation) {
				 * mHandler.post(new Runnable() {
				 * 
				 * @Override public void run() {
				 * paperPieceImageView2.setVisibility(View.VISIBLE); } }); }
				 * 
				 * @Override public void onAnimationRepeat(Animation animation)
				 * { // Do Nothing }
				 * 
				 * @Override public void onAnimationEnd(Animation animation) {
				 * paperPieceImageView2.setVisibility(View.GONE); } });
				 * paperPieceImageView2.setAnimation(animationImg2);
				 * 
				 * final View shredderAnimView =
				 * inflater.inflate(R.layout.paper_shredder_layout, null);
				 * RelativeLayout.LayoutParams params = new
				 * RelativeLayout.LayoutParams(
				 * RelativeLayout.LayoutParams.FILL_PARENT,
				 * RelativeLayout.LayoutParams.FILL_PARENT);
				 * shredderAnimView.setLayoutParams(params); Animation animation
				 * = AnimationUtils.loadAnimation(getActivity(),
				 * R.anim.translate_slide_bottom_up);
				 * shredderAnimView.setAnimation(animation);
				 * animation.setAnimationListener(new AnimationListener() {
				 * 
				 * @Override public void onAnimationStart(Animation animation) {
				 * // Do Nothing }
				 * 
				 * @Override public void onAnimationRepeat(Animation animation)
				 * { // Do Nothing }
				 * 
				 * @Override public void onAnimationEnd(Animation animation) {
				 * mHandler.post(new Runnable() {
				 * 
				 * @Override public void run() { Animation animation =
				 * AnimationUtils.loadAnimation(getActivity(),
				 * R.anim.translate_slide_top_down);
				 * animation.setAnimationListener(new AnimationListener() {
				 * 
				 * @Override public void onAnimationStart(Animation animation) {
				 * // Do Nothing }
				 * 
				 * @Override public void onAnimationRepeat(Animation animation)
				 * { // Do Nothing }
				 * 
				 * @Override public void onAnimationEnd(Animation animation) {
				 * mHandler.post(new Runnable() {
				 * 
				 * @Override public void run() {
				 * containerLayout.setVisibility(View.GONE);
				 * getActivity().finish(); } }); } });
				 * containerLayout.setAnimation(animation); } }); } });
				 * containerLayout.addView(shredderAnimView); // start paper cut
				 * pieces fly animation with some delay.
				 * mHandler.postDelayed(new Runnable() {
				 * 
				 * @Override public void run() {
				 * containerLayout.addView(paperPieceImageView); } }, 800); //
				 * start paper cut pieces fly animation with some delay.
				 * mHandler.postDelayed(new Runnable() {
				 * 
				 * @Override public void run() {
				 * containerLayout.addView(paperPieceImageView2); } }, 1500);
				 */
			}
		});
		if (TextUtils.isEmpty(mCouponBarcode)) {
			mTextViewBarCodeTextRedeem.setText("");
		} else {
			mTextViewBarCodeTextRedeem.setText(mCouponBarcode);
		}
		if (TextUtils.isEmpty(mCouponCode)) {
			mTextViewCouponCodeRedeem.setText("");
		} else {
			mTextViewCouponCodeRedeem.setText(getResources().getString(
					R.string.label_code_colon)
					+ " " + mCouponCode);
		}
		if (NetworkHelper.isNetworkAvailable(getActivity())) {
			mBitmapManager.addObserver(OfferDetailFragment.this);
			if (TextUtils.isEmpty(mCouponBarcodeImageUrl)) {
				mProgressBarBarCodeRedeem.setVisibility(View.GONE);
			} else {
				mBitmapManager.loadBitmap(mCouponBarcodeImageUrl,
						mImageViewBarCodeImageRedeem, 150, 60);
			}
			if (TextUtils.isEmpty(mCouponLargeImageUrl)) {
				mProgressBarOfferLogoRedeem.setVisibility(View.GONE);
			} else {
				mBitmapManager.loadBitmap(
						mCouponLargeImageUrl,
						mImageViewOfferImageRedeem,
						getResources().getInteger(
								R.integer.offer_detail_image_width),
						getResources().getInteger(
								R.integer.offer_detail_image_height));
			}
		} else {
			mProgressBarOfferLogoRedeem.setVisibility(View.GONE);
			mProgressBarBarCodeRedeem.setVisibility(View.GONE);
		}
	}

	/**
	 * Method to check the coupon redemption availability from server. If
	 * redemption is availble for selected coupon then server says success
	 * response or else it sends appropriate error message.
	 */
	private void callCheckCouponRedemptionAvailabilityWS() {
		LogConfig.logv(LOG_TAG, "callCheckCouponRedemptionAvailabilityWS() ");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mDialogTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}

		mRequestType = NetworkHelper.REQUEST_TYPE.CHECK_COUPON_REDEMPTION_AVAILABILITY;
		mRequestManager.addOnRequestFinishedListener(OfferDetailFragment.this);
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getActivity());
		}
		Bundle params = new Bundle();
		params.putByte(
				CouponRedemptionWorker.KEY_NAME_WORKER_MODE,
				CouponRedemptionWorker.WorkerModes.WORKER_MODE_CHECK_REDEMPTION_AVAILABILITY);
		params.putInt(CouponRedemptionWorker.KEY_NAME_COUPON_ID, mCouponId);
		mRequestId = mRequestManager.handleCouponRedemption(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/** Method to confirm the coupon redemption on server. */
	private void callConfirmCouponRedemptionWS() {
		LogConfig.logv(LOG_TAG, "callConfirmCouponRedemptionWS() ");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mDialogTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		mRequestType = NetworkHelper.REQUEST_TYPE.CONFIRM_COUPON_REDEMPTION;
		mRequestManager.addOnRequestFinishedListener(OfferDetailFragment.this);
		ProgressBarHelper.showProgressBarSmall(
				R.string.progress_bar_please_wait, false, mHandler,
				getActivity());
		Bundle params = new Bundle();
		params.putByte(
				CouponRedemptionWorker.KEY_NAME_WORKER_MODE,
				CouponRedemptionWorker.WorkerModes.WORKER_MODE_CONFIRM_REDEMPTION);
		params.putInt(CouponRedemptionWorker.KEY_NAME_COUPON_ID, mCouponId);
		mRequestId = mRequestManager.handleCouponRedemption(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(OfferDetailFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE, -1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mDialogMessage = getResources().getString(
								R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mDialogMessage = getResources().getString(
								R.string.toast_server_connection_error);
					} else {
						mDialogMessage = getResources().getString(
								R.string.toast_response_error);
					}
				} else {
					mDialogMessage = getResources().getString(
							R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}

	/**
	 * This runnable will invoke to handle the success state when request
	 * finished.
	 */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {	
			ProgressBarHelper.dismissProgressBar(mHandler);
			String responseStatus = mResponseBundle
					.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				
				if (mRequestType == NetworkHelper.REQUEST_TYPE.GET_STORES) {
					locateStoresOnMap();
				} else if (mRequestType == REQUEST_TYPE.ADD_FAVORITE) {
					Toast.makeText(getActivity(),
							getString(R.string.label_add_favorite),
							Toast.LENGTH_SHORT).show();
					menuItem.setIcon(R.drawable.ic_star_selected);
					
					mCouponFavoriteFlag = 1;
					
					final String whereClause = CouponDao.WHERE_CLAUSE_COUPON_ID + mCouponId;
					final ContentValues contentValues = new ContentValues();
					contentValues.put(CouponDao.COUPON_FAVORITE_FLAG, CouponDao.FLAG_VALUE_FAVOURITE_ENABLE);
					contentValues.put(DatabaseProvider.KEY_SQL_INJECT, true);
					getActivity().getContentResolver().update(CouponDao.CONTENT_URI, 
						contentValues, whereClause, null);
					
					PreferenceConfig.setFavoriteOfferCount(
							PreferenceConfig.getFavoriteOfferCount(getActivity()) + 1, getActivity());
					
					System.out.println("After Favorite---->"+PreferenceConfig.getFavoriteOfferCount(getActivity()));
					
					UIApplication app = (UIApplication) getActivity().getApplication();
					app.addFavoriteOffersId(mCouponId);
					
				} else if (mRequestType == REQUEST_TYPE.REMOVE_FAVORITE) {
					Toast.makeText(getActivity(),
							getString(R.string.label_remove_favorite),
							Toast.LENGTH_SHORT).show();
					menuItem.setIcon(R.drawable.ic_star_deselected);
					mCouponFavoriteFlag = 0;
					final String whereClause = CouponDao.WHERE_CLAUSE_COUPON_ID + mCouponId;
					final ContentValues contentValues = new ContentValues();
					contentValues.put(CouponDao.COUPON_FAVORITE_FLAG, CouponDao.FLAG_VALUE_FAVOURITE_DISABLE);
					contentValues.put(DatabaseProvider.KEY_SQL_INJECT, true);
					getActivity().getContentResolver().update(CouponDao.CONTENT_URI, 
						contentValues, whereClause, null);
					
					if(PreferenceConfig.getFavoriteOfferCount(getActivity())>0){
						PreferenceConfig.setFavoriteOfferCount(
								PreferenceConfig.getFavoriteOfferCount(getActivity()) - 1, getActivity());
					}
					
					System.out.println("After Favorite---->"+PreferenceConfig.getFavoriteOfferCount(getActivity()));
					
					UIApplication app = (UIApplication) getActivity().getApplication();
					app.removeFavoriteOffersId(mCouponId);
				} else if (mRequestType == REQUEST_TYPE.CHECK_COUPON_REDEMPTION_AVAILABILITY) {
					String isRedeemAvailable = mResponseBundle
							.getString(CommonConfig.KEY_NAME_REDEEM_AVAILABLE);
					if (!TextUtils.isEmpty(isRedeemAvailable)
							&& isRedeemAvailable.equalsIgnoreCase("true")) {
						mDialogMessage = getActivity()
								.getResources()
								.getString(
										R.string.dialog_multiple_redeem_permission_msg);
						showDialog(DialogConfig.DIALOG_COUPON_REDEMPTION_PERMISSION);
					} else {
						mDialogMessage = mResponseBundle
								.getString(CommonConfig.KEY_NAME_RESULTS_MESSAGE);
						if (!TextUtils.isEmpty(mDialogMessage)) {
							mDialogTitle = getResources().getString(
									R.string.dialog_error_title);
							showDialog(DialogConfig.DIALOG_ERROR);
						}
						// Redemption is not available so we set this offer as
						// SOLD OUT.
						setOfferAsExhausted();
					}
				} else if (mRequestType == REQUEST_TYPE.CONFIRM_COUPON_REDEMPTION) {
					showRedeemCouponDialog();
				}
			} else if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				String errorCode = mResponseBundle
						.getString(CommonConfig.KEY_NAME_ERROR_CODE);
				if (!TextUtils.isEmpty(errorCode)
						&& errorCode
								.equalsIgnoreCase(CommonConfig.ERROR_CODE_OFFER_EXHAUSTED)) {
					// Redemption is not available so we set this offer as SOLD
					// OUT.
					setOfferAsExhausted();
				}
				mDialogMessage = mResponseBundle
						.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mDialogMessage)) {
					mDialogTitle = getResources().getString(
							R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
			}
			else{			
				if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
					favoriteOffersSyncedDoSomething();
				} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
					queryFavoriteOffersFromDB();
					mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
					if (!TextUtils.isEmpty(mErrorMessage)) {
						mDialogTitle = getResources().getString(R.string.dialog_error_title);
						showDialog(DialogConfig.DIALOG_ERROR);
					}
				} else {
					ProgressBarHelper.dismissProgressBar(mHandler);
					queryFavoriteOffersFromDB();
				}
			}
		}
	};

	/**
	 * This runnable will invoke to handle the error state when request
	 * finished.
	 */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {

		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			queryFavoriteOffersFromDB();
			if (!TextUtils.isEmpty(mDialogMessage)) {
				mDialogTitle = getResources().getString(
						R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
		}
	};

	/**
	 * Method to set current offer as exhausted by setting the button label to
	 * 'Sold Out' and also update the exhausted flag in local database plus hide
	 * the share icons.
	 */
	private void setOfferAsExhausted() {
		LogConfig.logv(LOG_TAG, "setOfferAsExhausted()");
		// Redemption is not available so we set this offer as SOLD OUT.
		mButtonRedeeemNow.setVisibility(View.VISIBLE);
		mButtonRedeeemNow.setBackgroundResource(R.drawable.button_selected);
		mButtonRedeeemNow.setText(R.string.label_sold_out);
		mButtonRedeeemNow.setOnClickListener(null);
		TextView redemptionStatus = (TextView) mView
				.findViewById(R.id.TextView_redemption_status);
		redemptionStatus.setVisibility(View.VISIBLE);
		redemptionStatus.setText(R.string.label_coupon_no_longer_valid);
		// Also update the db cache.
		ContentValues contentValues = new ContentValues();
		contentValues.put(CouponDao.EXHAUSTED_FLAG, CommonConfig.FLAG_TRUE);
		contentValues.put(DatabaseProvider.KEY_SQL_INJECT, true);
		int rowsUpdated = getActivity().getContentResolver().update(
				CouponDao.CONTENT_URI, contentValues,
				CouponDao.COUPON_ID + "=" + mCouponId, null);
		LogConfig.logv(LOG_TAG, "Set offer as Exhausted: db rowsUpdated = "
				+ rowsUpdated);
		// Update the option menu
		mIsExhausted = CommonConfig.FLAG_TRUE;
		getSherlockActivity().supportInvalidateOptionsMenu();
	}

	@Override
	public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> arg0, Cursor arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
}
