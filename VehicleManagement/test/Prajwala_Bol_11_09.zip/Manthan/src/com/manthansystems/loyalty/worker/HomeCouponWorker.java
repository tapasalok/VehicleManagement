package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.ContentProviderOperation;
import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDaoHome;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDaoHome;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDaoHome;
import com.manthansystems.loyalty.data.provider.DatabaseProvider;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.HomeOffersJSONParserFactory;
import com.manthansystems.loyalty.location.LocationHandler;
import com.manthansystems.loyalty.model.HomeCategoryCount;
import com.manthansystems.loyalty.model.HomeCoupon;
import com.manthansystems.loyalty.model.HomeStore;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;
import com.manthansystems.loyalty.ui.OffersFragment.OffersType;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 * make the network request to get common home offers. It handles the parsing,
 * db caching and error states while of these processes.
 * 
 */
public class HomeCouponWorker extends BaseWorker {

	private final static String LOG_TAG = "HomeCouponWorker";
	public static final String DOWNLOAD_MODE = "com.manthansystems.loyalty.worker.HomeCouponWorker#DownloadMode";
	public static final String OFFERS_TYPE = "com.manthansystems.loyalty.worker.HomeCouponWorker#OffersType";

	/** Start processing the request. */
	public static Bundle start(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
			throws IllegalStateException, IOException, URISyntaxException,
			RestClientException, ParserConfigurationException, SAXException,
			JSONException, Exception, OperationApplicationException,
			ConnectionException {

		final Bundle bundle = new Bundle();
		byte offersType = inBudleData.getByte(OFFERS_TYPE);
		String serverRequestUrl = prepareRequestUrl(inContext, inBudleData,
				offersType);
		ArrayList<Header> headerList = getBasicHeaders(inContext);
		LogConfig.logv(LOG_TAG, "HomeCoupon offer serverRequestUrl= "
				+ serverRequestUrl);
		NetworkConnectionResult wsResult = NetworkConnection
				.retrieveResponseFromService(serverRequestUrl, Method.POST,
						null, headerList, true, false, inContext);

		HashMap<String, Object> hashMap = HomeOffersJSONParserFactory
				.parseCouponsAndStores(wsResult.wsResponse);
		final String responseStatus = (String) hashMap
				.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
		bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
		bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE,
				(String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));

		if (responseStatus
				.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
			String errorMsg = (String) hashMap
					.get(CommonConfig.KEY_NAME_ERROR_MSG);
			if (TextUtils.isEmpty(errorMsg)) {
				errorMsg = inContext.getResources().getString(
						R.string.msg_invalid_response_error);
			}
			bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
		} else {
			bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE,
					(String) hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
		}

		if (responseStatus
				.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
			writeOffersInDBHome(hashMap, offersType, inContext);
		}
		return bundle;
	}

	/** Prepare the server request url to get the home offers. */
	private static String prepareRequestUrl(final Context inContext,
			Bundle bundle, byte offersType) throws URISyntaxException {
		if (bundle != null) {
			byte downloadMode = bundle.getByte(DOWNLOAD_MODE);
			StringBuilder url = new StringBuilder();
			int valuePosition = 0;
    		int radius = PreferenceConfig.getOffersProximityRadius(inContext);
    		System.out.println("DOWNLOAD_MODE "+downloadMode);
			switch (downloadMode) {
			case DownloadMode.MODE_GPS:	   
	    		url.append(WSConfig.URL_GET_HOME_COUPON_DETAILS_GPS);
    	    	valuePosition = 0;
    	    	double[] locationData = LocationHandler.getSavedLocation(true, inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_LAT);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LAT.length()), "" 
	    				+ locationData[LocationHandler.LATTITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_LON);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LON.length()), "" 
	    				+ locationData[LocationHandler.LONGITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_ZIPCODE:	  
	    		url = new StringBuilder(WSConfig.URL_GET_HOME_COUPON_DETAILS_ZIP);
    	    	valuePosition = 0;
    	    	String zip = PreferenceConfig.getUserEnteredZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zip));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_HOME_ZIPCODE:
	    		url = new StringBuilder(WSConfig.URL_GET_HOME_COUPON_DETAILS_ZIP);
	    		valuePosition = 0;
	    		String zipcode = PreferenceConfig.getHomeZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zipcode));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		
	    		return url.toString();
	    		
	    	default:
	    			
	    			url = new StringBuilder(WSConfig.URL_GET_HOME_COUPON_DETAILS);
					return url.toString();	

			}

		}
		return null;
	}

	/** Call this method to write the offers and stores into home offer database. */
	private static void writeOffersInDBHome(HashMap<String, Object> map,
			byte inOffersType, Context inContext) throws Exception,
			OperationApplicationException {
		@SuppressWarnings("unchecked")
		ArrayList<HomeCoupon> offerList = (ArrayList<HomeCoupon>) map
				.get(CommonConfig.KEY_NAME_OFFER_LIST);
		@SuppressWarnings("unchecked")
		ArrayList<HomeStore> storeList = (ArrayList<HomeStore>) map
				.get(CommonConfig.KEY_NAME_STORE_LIST);
		@SuppressWarnings("unchecked")
		ArrayList<HomeCategoryCount> categoryCountList = (ArrayList<HomeCategoryCount>) map
				.get(CommonConfig.KEY_NAME_CATEGORY_COUNT);

		int totalOffers = 0;
		if (offerList != null) {
			totalOffers = offerList.size();
		}
		int totalStores = 0;
		if (storeList != null) {
			totalStores = storeList.size();
		}
		int categoryCountSize = 0;
		if (categoryCountList != null) {
			categoryCountSize = categoryCountList.size();
		}

		ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
		int couponChooser = -1;
		if (inOffersType == OffersType.PERSONAL_OFFERS) {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
		} else {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
		}
		ops.add(ContentProviderOperation
				.newDelete(CouponDaoHome.CONTENT_URI)
				.withSelection(
						CouponDaoHome.WHERE_CLAUSE_COUPON_CHOOSER
								+ couponChooser, null).build());
		ops.add(ContentProviderOperation.newDelete(StoreDaoHome.CONTENT_URI)
				.build());
		ops.add(ContentProviderOperation
				.newDelete(CategoryCountDaoHome.CONTENT_URI)
				.withSelection(
						CategoryCountDaoHome.WHERE_CLAUSE_OFFER_TYPE
								+ couponChooser, null).build());
		for (int i = 0; i < totalOffers; ++i) {
			final HomeCoupon coupon = offerList.get(i);
			// based on coupon chooser we will distinguish between type of Offer
			// i.e. either Personal or Common coupon. In Home Page case only common
			coupon.mCouponChooser = couponChooser;
			CouponDaoHome.addContentValues(CouponDaoHome.CONTENT_URI, ops,
					coupon);
		}
		for (int i = 0; i < totalStores; i++) {
			StoreDaoHome.addContentValues(StoreDaoHome.CONTENT_URI, ops,
					storeList.get(i));
		}
		for (int i = 0; i < categoryCountSize; ++i) {
			final HomeCategoryCount categoryCount = categoryCountList.get(i);
			categoryCount.mOfferType = couponChooser;
			CategoryCountDaoHome.addContentValues(
					CategoryCountDaoHome.CONTENT_URI, ops, categoryCount);
		}
		// executing all queries added above in batch
		inContext.getContentResolver().applyBatch(DatabaseProvider.AUTHORITY,
				ops);
	}

}
