/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

import android.database.Cursor;
import android.view.View;
import android.widget.ImageView;

/**
 * A base view holder that shouldn't be used directly; instead, view holder classes should
 * implement from {@link BaseViewHolder}.
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 *
 */
public interface BaseViewHolder {
	
	/** Populate view via view holder with cursor data. */
	public abstract void populateView(Cursor inCursor, View view);
	
	/** Method to set the row position of list as well as the current selected
	 * position in offer list. */
	public abstract void setRowPosition(int position, int selectedPosition);
	
	/** Method to get the ImageView instance of favourite icon of list row view. */
	public ImageView getFavoriteIconView();
	
	/** Method to get the ImageView instance of offer icon of list row view. */
	public ImageView getOfferIconView();
}
