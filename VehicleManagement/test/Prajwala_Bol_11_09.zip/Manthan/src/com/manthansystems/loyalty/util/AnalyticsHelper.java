/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import java.util.ArrayList;

import android.content.Context;

/**
 * A helper class to manage all analytics in app. 
 * @author Gaurav Agrawal {gaurav.agrawal@xymob.com}
 *
 */
public class AnalyticsHelper {
	
	/** A method to init analytics **/
	public static void initAnalytics(Context context) {
		FlurryHelper.initFlurry(context);
	}
	
	/** A method to stop Analytics sessions**/
	public static void stopAnalytics(Context context) {
		FlurryHelper.stopFlurry(context);
	}
	
	/** A method to track app launch analytics. **/
	public static void sendAppLaunchAnalytics(Context context) {
		FlurryHelper.sendAppLaunchAnalytics(context);
	}
	
	/** A method to track  in offer clicked analytics. **/
	public static void sendOfferClickedAnalytics(Context context, String offerTitle) {
		 FlurryHelper.sendOfferClickedAnalytics(context, offerTitle);
	}
	
	/** A method to track push notification clicked analytics. **/
	public static void sendPushNotificationClickedAnalytics(Context context, String status) {
		 FlurryHelper.sendPushNotificationClickedAnalytics(context, status);
	}
	
	/** A method to track my category clicked analytics. **/
	public static void sendMyCategoryClickedAnalytics(Context context, ArrayList<String> categoryNameList) {
		FlurryHelper.sendMyCategoryClickedAnalytics(context, categoryNameList);
	}
	
	/** A method to track favorite star clicked analytics. **/
	public static void sendFavoriteStarClickedAnalytics(Context context, String offerTitle, boolean isAddToFav) {
		 FlurryHelper.sendFavoriteStarClickedAnalytics(context, offerTitle, isAddToFav);
	}
	
	/** A method to track my favorite tab clicked analytics. **/
	public static void sendMyFavoriteTabClickedAnalytics(Context context) {
		FlurryHelper.sendMyFavoriteTabClickedAnalytics(context);
	}
}
