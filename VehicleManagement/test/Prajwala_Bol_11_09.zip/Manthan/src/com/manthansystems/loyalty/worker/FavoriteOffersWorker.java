/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.ContentProviderOperation;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDaoColumns;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDao;
import com.manthansystems.loyalty.data.provider.DatabaseProvider;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.OffersJSONParserFactory;
import com.manthansystems.loyalty.location.LocationHandler;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.Store;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;
import com.manthansystems.loyalty.ui.UIApplication;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 *  make the network request to get the favorite offers. It handles the parsing,
 *  db caching and error states while of these processes. 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class FavoriteOffersWorker extends BaseWorker {

	private final static String LOG_TAG = "FavoriteOffersWorker";
	
	public static final String DOWNLOAD_MODE = "com.manthansystems.loyalty.worker.FavoriteOffersWorker#DownloadMode";
	public static final String FLAG_FAVORITE_OFFER_SYNC_REQUEST =
		"com.manthansystems.loyalty.worker.FavoriteOffersWorker#favOfferSyncRequested";
	public static final String ADD_FAVORITE_REQUEST =
			"com.manthansystems.loyalty.worker.FavoriteOffersWorker#addFavRequest";
	public static final String REMOVE_FAVORITE_REQUEST =
			"com.manthansystems.loyalty.worker.FavoriteOffersWorker#removeFavRequest";
	
	/** Start processing the request. */
	public static Bundle start(final Context inContext, final int inReturnFormat,
    		final Bundle inBudleData) throws IllegalStateException,
    		IOException, URISyntaxException, RestClientException, ParserConfigurationException,
    		SAXException, JSONException, Exception, OperationApplicationException, ConnectionException {
    	
    	Bundle bundle = new Bundle();
    	String serverRequestUrl = prepareRequestUrl(inContext, inBudleData);
    	ArrayList<Header> headerList = getBasicHeaders(inContext);
		
    	// if request method is GET that means get the favorite offer for first time when app get
    	// launched. If method is POST that means sync the favorite offer with the server.
    	Method requestMethod = Method.GET;
    	resetPostBuffer();
    	boolean addFav = inBudleData.getBoolean(ADD_FAVORITE_REQUEST);
    	boolean remFav = inBudleData.getBoolean(REMOVE_FAVORITE_REQUEST);
    	if (addFav) {
    		requestMethod = Method.PUT;
		}else if (remFav){
			requestMethod = Method.DELETE;
		}else if (PreferenceConfig.isFavoriteOffersFirstSyncDone(inContext)) {
    		requestMethod = Method.POST;
    		boolean syncRequested = bundle.getBoolean(FLAG_FAVORITE_OFFER_SYNC_REQUEST)
				|| PreferenceConfig.isFavoriteOffersFirstSyncDone(inContext);
			if (syncRequested) {
				LogConfig.logv(LOG_TAG, "start(): prepare fav id list");
				String offerIds = "";
				UIApplication app = (UIApplication) inContext.getApplicationContext();
				ArrayList<Integer> favOfferIdArray = app.getFavoriteOfferIds();
				if (favOfferIdArray != null && !favOfferIdArray.isEmpty()) {
					offerIds = favOfferIdArray.toString();
					offerIds = offerIds.replace("[", "").replace("]", "").replaceAll(" ", "");
					LogConfig.logv(LOG_TAG, "start(): offerIds= " + offerIds);
				}
				addToPostBuffer(WSConfig.WS_OFFER_IDS, offerIds);
			}
    	}
    	
    	NetworkConnectionResult wsResult = NetworkConnection.retrieveResponseFromService(
        		serverRequestUrl, requestMethod, mParameters, headerList, true, false, inContext);
        
    	System.out.println("*****************************************Result From Server*************"+wsResult);
    	
        HashMap<String, Object> hashMap = OffersJSONParserFactory.parseCouponsAndStores(wsResult.wsResponse);
        
        final String responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        } else {
        	bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
        }
        
		if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
			
			if (remFav || addFav) {
				// Do nothing
			} else {
				writeFavoriteOffersInDB(hashMap, inContext);
			}
		}
        return bundle;
    }
    
    /** Prepare the server request url to get the local offers. */
    private static String prepareRequestUrl(final Context inContext, Bundle bundle) throws URISyntaxException{
    	if (bundle != null) {
    		byte downloadMode = bundle.getByte(DOWNLOAD_MODE);
    		StringBuilder url = new StringBuilder();
    		boolean addFav = bundle.getBoolean(ADD_FAVORITE_REQUEST);
    		boolean remFav = bundle.getBoolean(REMOVE_FAVORITE_REQUEST);
    		if (addFav || remFav) {
    			url.append(WSConfig.URL_ADD_FAVORITE_OFFERS);
    			int valuePosition = 0;
    			valuePosition = url.indexOf(WSConfig.WS_FAVORITE_IDS);
    			String offerId = bundle.getString(CouponDaoColumns.COUPON_ID);
    			url.replace(valuePosition, (valuePosition + WSConfig.WS_FAVORITE_IDS.length()), "" 
	    				+offerId );
    			return url.toString();
			}
    		
    		LogConfig.logv(LOG_TAG, "prepareRequestUrl(): downloadMode = " + downloadMode);
    		int radius = PreferenceConfig.getOffersProximityRadius(inContext);
			if (radius == -1) {
				radius = BusinessLogicConfig.DEFAULT_OFFER_PROXIMITY_RADIUS;
			}
			
    		switch (downloadMode) {
	    	case DownloadMode.MODE_GPS:
	    		
	    		
	    		url.append(WSConfig.URL_GET_FAVORITE_OFFERS_GPS);
    	    	int valuePosition = 0;
    	    	double[] locationData = LocationHandler.getSavedLocation(true, inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_LAT);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LAT.length()), "" 
	    				+ locationData[LocationHandler.LATTITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_LON);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LON.length()), "" 
	    				+ locationData[LocationHandler.LONGITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		
	    		
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_ZIPCODE:
	    		url = new StringBuilder(WSConfig.URL_GET_FAVORITE_OFFERS_ZIP);
    	    	valuePosition = 0;
    	    	String zip = PreferenceConfig.getUserEnteredZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zip));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_HOME_ZIPCODE:
	    		url = new StringBuilder(WSConfig.URL_GET_FAVORITE_OFFERS_ZIP);
	    		valuePosition = 0;
	    		String zipcode = PreferenceConfig.getHomeZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zipcode));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    	}
    	}
    	return null;
    }
    
    /** Call this method to write the favorite offers and stores into database. */
    private static void writeFavoriteOffersInDB(HashMap<String, Object>map, Context inContext)
    	throws Exception, OperationApplicationException  {
    	@SuppressWarnings("unchecked")
		ArrayList<Coupon> offerList = (ArrayList<Coupon>) map.get(CommonConfig.KEY_NAME_OFFER_LIST);
//    	@SuppressWarnings("unchecked")
//		ArrayList<Store> storeList = (ArrayList<Store>) map.get(CommonConfig.KEY_NAME_STORE_LIST);
    	int totalOffers = 0;
    	if (offerList != null) {
    		totalOffers = offerList.size();
    	}
//    	int totalStores = 0;
//    	if (storeList != null) {
//    		totalStores = storeList.size();
//    	}
    	
		ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
//        ops.add(ContentProviderOperation.newDelete(CouponDao.CONTENT_URI)
//    		.withSelection(CouponDao.WHERE_CLAUSE_COUPON_CHOOSER 
//    				+ DatabaseConfig.DB_OFFER_TYPE_FAVORITE, null)
//    		.build());
//        if (totalStores > 0) {
//        	// Delete old stores from db, the store ids comes with favorite response.
//        	// Afterwards insert fresh stores comes from server.
//        	ArrayList<String> storeIds = new ArrayList<String>();
//        	for (int i = 0; i<totalStores; i++) {
//        		storeIds.add(storeList.get(i).mId);
//            }
//        	String storeIdList = storeIds.toString().replace("[", "").replace("]", "");
//        	ops.add(ContentProviderOperation.newDelete(StoreDao.CONTENT_URI)
//    			.withSelection(StoreDao.WHERE_CLAUSE_STORE_IDS_IN + "(" + storeIdList + ")", null)
//    			.build());
//        }
        
        if (totalOffers > 0) {
        	// update the favorite flag of offer based on its id as favorite.
        	ArrayList<String> favOfferIds = new ArrayList<String>();
        	for (int i = 0; i<totalOffers; i++) {
        		favOfferIds.add("" + offerList.get(i).mId);
            }
        	
        	String whereClause = CouponDao.WHERE_CLAUSE_COUPON_ID;
        	UIApplication app = (UIApplication) inContext.getApplicationContext();
        	for (int i = 0; i < favOfferIds.size(); i++) {
        		app.addFavoriteOffersId(Integer.parseInt(favOfferIds.get(i).toString()));
				if (i == 0) {
					whereClause += "'"+favOfferIds.get(i)+"'";
				} else {
					whereClause = whereClause + " OR " + CouponDao.WHERE_CLAUSE_COUPON_ID + "'"+favOfferIds.get(i)+"'";
				}
			}
        	
			
        	final ContentValues contentValues = new ContentValues();
			contentValues.put(CouponDao.COUPON_FAVORITE_FLAG, CouponDao.FLAG_VALUE_FAVOURITE_ENABLE);
			contentValues.put(DatabaseProvider.KEY_SQL_INJECT, true);
			int numberChanged = inContext.getContentResolver().update(CouponDao.CONTENT_URI, 
				contentValues, whereClause, null);
			System.out.println("*********************numberChanged************************"+numberChanged);
			
			
			
			
//        	String favOfferIdList = favOfferIds.toString().replace("[", "").replace("]", "");
//        	ops.add(ContentProviderOperation.newUpdate(CouponDao.CONTENT_URI)
//        			.withSelection(CouponDao.WHERE_CLAUSE_COUPON_IDS_IN + "(" + favOfferIdList + ")", null)
//        			.withValue(CouponDao.COUPON_FAVORITE_FLAG, CouponDao.FLAG_VALUE_FAVOURITE_ENABLE)
//            		.build());
        }
		//executing all queries added above in batch
//    	inContext.getContentResolver().applyBatch(DatabaseProvider.AUTHORITY, ops);
    	
    	// Disable the favorite offer fetch for first time.
    	if (!PreferenceConfig.isFavoriteOffersFirstSyncDone(inContext)) {
//    		PreferenceConfig.setFavoriteOffersFirstSyncStatus(true, inContext);
    	}
    	
    	UIApplication app = (UIApplication) inContext.getApplicationContext();
    	
    	PreferenceConfig.setFavoriteOfferCount(totalOffers, inContext);
    }
}
