/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.methods.HttpHead;

import android.content.Context;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.util.EDUtils;
import com.manthansystems.loyalty.util.UIUtils;

/**
 * A base worker class that should be extends by every worker. It holds the common constants
 * thats helps the worker task.
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 *
 */
public class BaseWorker {
	
	protected static HashMap<String, String> mParameters = new HashMap<String, String>();
	protected static String mPlatformId;
	
	/** Constants to represent the download mode, It can be used when we prepare server url. */
	public interface DownloadMode {
		public final byte MODE_GPS = 0;
		public final byte MODE_HOME_ZIPCODE = 1;
		public final byte MODE_ZIPCODE = 2;
		public final byte MODE_NONE = -1;
//		public final byte MODE_HOME_URL = 3;
	}
	
	/** Constants to represent the returning data format from server as response. */
	public interface DownloadFormat{
		public final int RETURN_FORMAT_XML = 0;
	    public final int RETURN_FORMAT_JSON = 1;
	}
	
	/**
	 * Call this method to get the basic headers info before making the server request.
	 * @return ArrayList<Header> instance with all basic headers.
	 */
	public static ArrayList<Header> getBasicHeaders(Context context) {
		String deviceName;
		String osVersion;
		String appVersion;
		if (UIUtils.isTablet(context) || UIUtils.isHoneycombTablet(context)) {
			deviceName = "Android Tablet";
		} else {
			deviceName = "Android Phone";
		}
		appVersion = context.getResources().getString(R.string.version_name);
		osVersion = android.os.Build.VERSION.RELEASE;
		StringBuilder platformId = new StringBuilder();
		platformId.append(appVersion).append(" ").append(osVersion)
				.append(" ").append(deviceName);
		mPlatformId = platformId.toString();
		String clientVersion = context.getResources().getString(R.string.client_version);
		ArrayList<Header> headerList = new ArrayList<Header>();
		
		HttpHead head = new HttpHead();
		head.addHeader(WSConfig.PLATFORM_ID, mPlatformId);
		head.addHeader(WSConfig.APP_VER, appVersion);
		head.addHeader(WSConfig.CLIENT_VERSION, clientVersion);
		head.addHeader(WSConfig.STORE_ID, WSConfig.RETAILER_STORE_ID);
		head.addHeader(WSConfig.DEVICE_ID, UIUtils.getDeviceUniqueId(context));
		head.addHeader(WSConfig.UTC_OFFSET, UIUtils.getUTCTimeOffset() + "");
		
		String loginToken = EDUtils.getLoginToken(context);
		System.out.println("****************************************loginToken"+loginToken);
		if (!TextUtils.isEmpty(loginToken)) {
			head.addHeader(WSConfig.LOGIN_TOKEN, loginToken);
		}
		String sessionId = PreferenceConfig.getSessionId(context);
		if (!TextUtils.isEmpty(sessionId)) {
			head.addHeader(WSConfig.SESSION_ID, sessionId);
		}
		
		Header headers[] = head.getAllHeaders();
		for (int i = 0; i < headers.length; ++i) {
			headerList.add(headers[i]);
		}
		return headerList;
	}
	
	/** Add key value pair to network request parameters. */
	public static void addToPostBuffer(String name, String value) {
		mParameters.put(name, value);
	}

	/** Reset the network request parameters. */
	public static void resetPostBuffer() {
		mParameters.clear();
	}
}
