/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.text.TextUtils;

/**
 * A helper for showing Registration screen and storing entered Zipcode to {@link SharedPreferences}
 *  as user's home Zipcode.
 * 
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 *
 */
public class RegistrationHelper {
	public static boolean hasRegistred(final Context inContext) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(inContext);
        return (!TextUtils.isEmpty(sp.getString("user_home_zipcode", "")));
    }

    public static void setAsRegisteredUser(final String inZipCode, final Context inContext) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(inContext);
                sp.edit().putString("user_home_zipcode", inZipCode.trim()).commit();
                return null;
            }
        }.execute();
    }
    
    public static void showRegistrationScreen(final Context inContext) {
    	// launch activity to show registration screen
    	//inContext.startActivity(new Intent(inContext, Reg));
    }
}
