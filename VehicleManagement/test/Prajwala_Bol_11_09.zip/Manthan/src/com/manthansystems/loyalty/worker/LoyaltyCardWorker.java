/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.LoyaltyCardJsonParserFactory;
import com.manthansystems.loyalty.model.LoyaltyCardHistory;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;
import com.manthansystems.loyalty.util.FileHandler;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 * make various Loyalty Card related network requests to the server and 
 * save or delete the details based on the type of the requests.
 * 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 * 
 */
public class LoyaltyCardWorker extends BaseWorker {

	private final static String LOG_TAG = "LoyaltyCardWorker";
	
	/** Start processing the Loyalty card related network requests.  */
	public static Bundle start(final Context inContext, final int inReturnFormat,
			final Bundle inBundleData) throws IllegalStateException,
			IOException, URISyntaxException, RestClientException,
			ParserConfigurationException, SAXException, JSONException,
			Exception, OperationApplicationException, ConnectionException {

		final byte workerMode = inBundleData
				.getByte(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_LOYALTY_CARD_WORKER_MODE);
		LogConfig.logd(LOG_TAG, "workerMode = " + workerMode);
		Bundle bundle = new Bundle();
		HashMap<String, Object> hashMap = null;
    	NetworkConnectionResult wsResult = null;
    	String responseStatus = null;
		String serverRequestUrl = prepareRequestUrl(workerMode, inBundleData, inContext);
		ArrayList<Header> headerList = getBasicHeaders(inContext);
		switch (workerMode) {
		case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_SCAN:
			/* FALL-THROUGH */
		case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_MANUAL_ADD:
			LogConfig.logd(LOG_TAG, "serverRequestUrl = " + serverRequestUrl);
			wsResult = NetworkConnection.retrieveResponseFromService(serverRequestUrl,
					Method.POST, null, headerList, false, inContext);
			LogConfig.logd(LOG_TAG, "wsResult.wsResponse = " + wsResult.wsResponse);
			hashMap = LoyaltyCardJsonParserFactory.parseLoyaltyCardResponse(wsResult.wsResponse, workerMode);
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				saveLoyaltyCardDetails(hashMap, inContext);
	        }
			break;
			
		case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY:
			wsResult = NetworkConnection.retrieveResponseFromService(serverRequestUrl,
					Method.GET, null, headerList, false, inContext);
			LogConfig.logd(LOG_TAG, "wsResult.wsResponse = " + wsResult.wsResponse);
			hashMap = LoyaltyCardJsonParserFactory.parseLoyaltyCardResponse(wsResult.wsResponse, workerMode);
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				saveLoyaltyCardDetails(hashMap, inContext);
	        }
			break;
			
		case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DELETE:
			wsResult = NetworkConnection.retrieveResponseFromService(serverRequestUrl,
					Method.POST, null, headerList, false, inContext);
			hashMap = LoyaltyCardJsonParserFactory.parseLoyaltyCardResponse(wsResult.wsResponse, workerMode);
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				// Delete local cached information of Loyalty card.
				deleteLoyaltyCardDetails(inContext);
			}
			break;
		}
		
		responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        } else {
        	bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
        }
        return bundle;
		
	}
	
	/** Method to prepare the appropriate server request url based on the worker mode. 
	 * @throws URISyntaxException */
    private static String prepareRequestUrl(final byte workerMode,
    		Bundle bundle, Context inContext) throws URISyntaxException {
    	int valuePosition = 0;
    	StringBuilder url = new StringBuilder();
    	switch (workerMode) {
    	case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_SCAN:
			/* FALL-THROUGH */
		case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_MANUAL_ADD:
			url.append(WSConfig.URL_LOYALTY_CARD_SCAN);
			valuePosition = url.indexOf(WSConfig.WS_SCAN_CODE);
			String barcode = bundle.getString(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_LOYALTY_CARD_NUMBER);
    		url.replace(valuePosition, (valuePosition + WSConfig.WS_SCAN_CODE.length()),
    				URLEncoder.encode(barcode));
    		valuePosition = url.indexOf(WSConfig.WS_BARCODE_TYPE);
    		int barCodeType = bundle.getInt(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_BARCODE_TYPE);
    		url.replace(valuePosition, (valuePosition + WSConfig.WS_BARCODE_TYPE.length()), barCodeType + "");
			return url.toString();
			
		case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DELETE:
			return WSConfig.URL_LOYALTY_CARD_DELETE;
			
		case LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY:
			return WSConfig.URL_LOYALTY_CARD_DISPLAY;
			
		default:
			throw new URISyntaxException("LoyaltyCardWorker mode not set.",
					"The caller for method prepareRequestUrl() has not set the" +
					"worker mode. "+ workerMode);
		}
    }
	
	/** An interface to hold loyalty card worker mode constanta.. */
	public interface LoyaltyCardWorkerMode {
		public String KEY_NAME_BUNDLE_LOYALTY_CARD_WORKER_MODE = 
			"com.manthansystems.loyalty.worker.LoyaltyCardWorker$LoyaltyCardWorkerMode#WorkerMode";
		public String KEY_NAME_BUNDLE_LOYALTY_CARD_NUMBER = 
			"com.manthansystems.loyalty.worker.LoyaltyCardWorker$LoyaltyCardWorkerMode#CardNumber";
		public String KEY_NAME_BUNDLE_BARCODE_TYPE = 
			"com.manthansystems.loyalty.worker.LoyaltyCardWorker$LoyaltyCardWorkerMode#barcodeType";
		
		public final byte WORKER_MODE_LOYALTY_CARD_SCAN = 1;
		public final byte WORKER_MODE_LOYALTY_CARD_DELETE = 2;
		public final byte WORKER_MODE_LOYALTY_CARD_JOIN_PROGRAM = 3;
		public final byte WORKER_MODE_LOYALTY_CARD_DISPLAY = 4;
		public final byte WORKER_MODE_LOYALTY_CARD_MANUAL_ADD = 5;
		public final byte WORKER_MODE_LOYALTY_CARD_NONE = 6;
	}
	
	/** Method to save loyalty card details in Preferences. */
	private static void saveLoyaltyCardDetails(HashMap<String, Object> map, Context inContext) {
		String email = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_EMAIL);
		String firstName = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_FIRST_NAME);
		String imageUrl = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_IMAGE_URL);
		String totalRewardsDay = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_TOTAL_REWARDS_DAY);
		String totalRewards = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_TOTAL_REWARDS);
		String expiryDays = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_EXPIRY_DAYS);
		String expiryRewards = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_EXPIRY_REWARDS);
		String loyaltyCardNumber = (String)map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_NUMBER);

		@SuppressWarnings("unchecked")
		ArrayList<LoyaltyCardHistory> loyaltyCardHistoryList = (ArrayList<LoyaltyCardHistory>) 
			map.get(CommonConfig.KEY_NAME_LOYALTY_CARD_HISTORY_LIST);
		int loyaltyCardHistoryListSize = loyaltyCardHistoryList.size();
		for (int i = 0; i < loyaltyCardHistoryListSize; i++) {
			LoyaltyCardHistory loyaltyCardHistory =  loyaltyCardHistoryList.get(i);
			PreferenceConfig.setLoyaltyCardTransactionId(loyaltyCardHistory.mTransactionId, inContext, i);
			PreferenceConfig.setLoyaltyCardRewards(loyaltyCardHistory.mRewards, inContext, i);
			PreferenceConfig.setLoyaltyCardDate(loyaltyCardHistory.mDate, inContext, i);
		}
		PreferenceConfig.setLoyaltyCardHistoryCount(loyaltyCardHistoryListSize, inContext);
		PreferenceConfig.setLoyaltyCardEmail(email, inContext);
		PreferenceConfig.setLoyaltyCardExpiryDays(expiryDays, inContext);
		PreferenceConfig.setLoyaltyCardExpiryRewards(expiryRewards, inContext);
		PreferenceConfig.setLoyaltyCardFirstName(firstName, inContext);
		PreferenceConfig.setLoyaltyCardImageUrl(imageUrl, inContext);
		PreferenceConfig.setLoyaltyCardTotalRewardsDay(totalRewardsDay, inContext);
		PreferenceConfig.setLoyaltyCardTotalRewards(totalRewards, inContext);
		PreferenceConfig.setLoyaltyCardNumber(loyaltyCardNumber, inContext);
		PreferenceConfig.setIsLoyaltyCardCreated(true, inContext);
		saveBarCodeImageInDevice(inContext);
	}
	
	/** Method to delete loyalty card details from Preferences. */
	private static void deleteLoyaltyCardDetails(Context inContext) {
		int loyaltyCardHistoryListSize = PreferenceConfig.getLoyaltyCardHistoryCount(inContext);
		for (int i = 0; i < loyaltyCardHistoryListSize; i++) {
			PreferenceConfig.setLoyaltyCardTransactionId("", inContext, i);
			PreferenceConfig.setLoyaltyCardRewards("", inContext, i);
			PreferenceConfig.setLoyaltyCardDate("", inContext, i);
		}
		PreferenceConfig.setLoyaltyCardHistoryCount(0, inContext);
		PreferenceConfig.setLoyaltyCardEmail("", inContext);
		PreferenceConfig.setLoyaltyCardExpiryDays("", inContext);
		PreferenceConfig.setLoyaltyCardExpiryRewards("", inContext);
		PreferenceConfig.setLoyaltyCardFirstName("", inContext);
		PreferenceConfig.setLoyaltyCardImageUrl("", inContext);
		PreferenceConfig.setLoyaltyCardTotalRewards("", inContext);
		PreferenceConfig.setLoyaltyCardNumber("", inContext);
		PreferenceConfig.setIsLoyaltyCardCreated(false, inContext);
		// delete barcode image.
		FileHandler.deleteFile(PreferenceConfig.getLoyaltyCardImagePath(inContext));
	}
	
	/**
	 * Method to save bar code image in device. This method check free space in
	 * appropriate memory and save image on device.
	 */
	private static void saveBarCodeImageInDevice(Context inContext) {
		LogConfig.logd(LOG_TAG, "saveBarCodeImageInDevice()");
		String filePath = "11034";
		InputStream inputStream = null;
		try {
			inputStream = (InputStream) new URL(
				PreferenceConfig.getLoyaltyCardImageUrl(inContext)).getContent();
		} catch (Exception e) {
			Log.e(LOG_TAG, "saveBarCodeImageInDevice(): Exception: " + e);
		}
		if (inputStream != null) {
			LogConfig.logd(LOG_TAG, "saveBarCodeImageInDevice(): save barcode image stream");
			String filePathOnSuccess = FileHandler.saveFile(filePath, inputStream, inContext);
			PreferenceConfig.setLoyaltyCardImagePath(filePathOnSuccess, inContext) ;
		} else {
			LogConfig.logv(LOG_TAG, "saveBarCodeImageInDevice(): barcode img stream null");
		}
	}
}
