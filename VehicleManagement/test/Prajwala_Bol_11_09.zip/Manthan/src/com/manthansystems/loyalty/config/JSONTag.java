/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.config;

/**
 * This class holds the tag names that are comming with JSON server response.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class JSONTag {

	/**
	 * An interface that holds the various json related constants.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	public interface JSONTagConstants {
		// Response status
		public final String RESPONSE_TAG_STATUS ="status";
		public final String RESPONSE_TAG_STATUS_CODE ="status_code";
		public final String RESPONSE_TAG_STATUS_CODE_STATUS ="statusCode";
		public final String RESPONSE_TAG_CODE = "code";
		public final String RESPONSE_TAG_ERROR = "error";
		public final String RESPONSE_TAG_MESSAGE = "message";
		public final String RESPONSE_TAG_MSG = "msg";
		public final String RESPONSE_CODE_OK = "200";
		public final String RESPONSE_CODE_ERROR = "500";
		public final String RESPONSE_STATUS_SUCCESS = "Success";
		public final String RESPONSE_STATUS_FAILURE = "Failure";
		public final String RESPONSE_RESULTS = "results";
		public final String RESPONSE_RESULTS_MESSAGE = "message";
		public final String RESPONSE_STATUS_OK = "OK";
		
		// User registration
		public final String REGISTRATION_DEVICE_ID = "deviceID";
		public final String REGISTRATION_PLATFORM_ID = "platformID";
		
		
		// Offers
		public final String OFFERS_RESULTS_TAG = "results";
		public final String OFFERS_ROOT_TAG = "coupons";
		public final String OFFERS_ID = "id";
		public final String OFFERS_TITLE = "title";
		public final String OFFERS_DESCRIPTION = "description";
		public final String OFFERS_IMAGE_URL = "image_url";
		public final String OFFERS_EXPIRY_DATE = "expiry_date";
		public final String OFFERS_COUPON_URL = "coupon_url";
		public final String OFFERS_COUPON_TYPE = "coupon_type";
		public final String OFFERS_DISCOUNT = "discount";
		public final String OFFERS_STORE_IDS = "store_ids";
		public final String OFFERS_EXPIRES = "expires";
		public final String OFFERS_DECORATORES = "decorators";
		public final String OFFERS_DECORATORES_BOLD = "bold";
		public final String OFFERS_BARCODE = "barcode";
		public final String OFFERS_BARCODE_IMAGE_URL = "barcode_image_url";
		public final String OFFERS_COUPON_CODE = "coupon_code";
		public final String OFFERS_LARGE_IMAGE_URL = "large_image_url";
		public final String OFFERS_IS_NEW_COUPON = "new";
		public final String OFFER_LONG_DESCRIPTION = "long_description";
		public final String OFFERS_IS_MARKETING_MESSAGE = "marketing_message";
		public final String OFFERS_REDEEMABLE = "redeemable";
		public final String OFFERS_USAGE_TYPE = "usage_type";
		public final String OFFERS_THRESHOLD_LIMIT = "threshold_limit";
		public final String OFFERS_EXHAUSTED = "exhausted";
		
		// Stores
		public final String STORE_ROOT_TAG = "stores";
		public final String STORE_ID = "id";
		public final String STORE_ADDRESS1 = "address1";
		public final String STORE_ADDRESS2 = "address2";
		public final String STORE_CITY = "city";
		public final String STORE_STATE = "state";
		public final String STORE_ZIP = "zip";
		public final String STORE_LAT = "lat";
		public final String STORE_LON = "lon";
		public final String STORE_PHONE = "phone"; 
		public final String STORE_NAME = "name";
		
		public final String EMAIL_ID_TAG = "email_id";
		public final String TOKEN_TAG = "activation_code";
		public final String ZIP_CODE = "zipcode";
		
		public final String RESPONSE_LOGIN_TOKEN = "login_token";
		public final String RESPONSE_SESSION_ID= "session_id";
		
		public final String CATEGORY_ID_TAG = "id";
		public final String CATEGORY_NAME_TAG = "name";
		public final String SUBCATEGORIES_TAG = "subcategories";
		public final String PUSH_TOKEN_TAG = "push_token";
		public final String NAME_TAG = "name";
		public final String VALUE_TAG = "value";
		public final String GEOMETRY_TAG = "geometry"; 
		public final String LOCATION_TAG = "location"; 
		public final String LAT_TAG = "lat";
		public final String LNG_TAG = "lng";
		
		//offer count related
		public final String COUNT_TAG = "count";
		public final String PERSONAL_TAG = "personal";
		public final String COMMON_TAG = "common";
		public final String FAVORITES_TAG = "favourites";
		
		public final String CATEGORY_CODE_TAG = "category_code";
		public final String SUBCATEGORY_CODE_TAG = "subcategory_code";
		
		//Notification
		public final String RESPONSE_TAG_APS = "aps";
		public final String RESPONSE_TAG_ALERT = "alert";
		public final String RESPONSE_TAG_BADGE = "badge";
		public final String RESPONSE_TAG_TYPE = "type";
		public final String RESPONSE_TAG_CID = "cid";
		public final String RESPONSE_TAG_MCID = "mcid";
		
		public final String RESPONSE_TAG_CATEGORY_IDS = "category_ids";
		public final String RESPONSE_TAG_CATEGORY= "category";
		
		// Configurations coming from server.
		public final String CONFIG_REFRESH_INTERVAL = "refresh_interval";
		public final String CONFIG_ACTIVE_TRIGGER_LIST = "triggers";
		public final String CONFIG_GEO_SIGNIFICANT_DISTANCE = "geo_significant_distance";
		public final String CONFIG_GEO_SIGNIFICANT_FREQUENCY = "geo_significant_frequency";
		public final String CONFIG_STORE_SEARCH_DISTANCE = "STORE_SEARCH_DISTANCE";
		public final String CONFIG_COLOR_CODE = "COLOR_CODE";
		public final String CONFIG_MARKETING_MESSAGE_IMAGE_URL = "MARKETING_MESSAGE_IMAGE_URL";
		public final String CONFIG_MIN_BAR_CODE_DIGIT  = "MIN_BAR_CODE_DIGIT";
		public final String CONFIG_MAX_BAR_CODE_DIGIT = "MAX_BAR_CODE_DIGIT";
		public final String COUPON_BURNING_ENABLED = "COUPON_BURNING_ENABLED";
		public final String CONFIG_SEARCH_COLUMN = "SEARCH_COLUMN";
		public final String CONFIG_LMS_INTEGRATED = "LMS_INTEGRATED";
		public final String URL_GET_ALL_CATEGORIES = "URL_GET_ALL_CATEGORIES";
		public final String CONFIG_OFFER_LIST = "CONFIG_OFFER_LIST";
		public  String ZIP = "zip";
		public final String HOME_PAGE_CONFIG_STATUS = "HOME_PAGE_CONFIG_STATUS";
		
		// loyalty card
		public final String RESPONSE_TAG_FIRST_NAME = "first_name";
		public final String RESPONSE_TAG_IMAGE_URL = "image_url";
		public final String RESPONSE_TAG_TOTAL_REWARDS_DAY = "activeBalString";
		public final String RESPONSE_TAG_TOTAL_REWARDS = "activeBalance";
		public final String RESPONSE_TAG_EXPIRY_DAYS = "expiryBalString";
		public final String RESPONSE_TAG_EXPIRY_REWARDS = "expiryBalance";
		public final String RESPONSE_TAG_EMAIL = "email";
		public final String RESPONSE_TAG_HISTORY = "history";
		public final String RESPONSE_TAG_TRANSACTION_ID= "transactionId";
		public final String RESPONSE_TAG_DATE = "date";
		public final String RESPONSE_TAG_REWARDS = "rewards";
		public final String RESPONSE_TAG_CARD_NUM = "card_number";

		public final String REDEEM_AVAILABLE = "available";
		
		public final String APP_UPDATE_TYPE_TAG = "type";
		public final String APP_UPDATE_AVAILABLE_TAG = "available";
		public final String APP_UPDATE_MESSAGE_TAG = "message";
		public final String APP_UPDATE_VERSION_TAG = "version";
		public final String APP_UPDATE_OBSOLETE_TAG = "obsolete";
	}
	
	/**
	 * Method to convert the String into JSON type.
	 * 
	 * @param data
	 *            - String
	 * @return - JSON supportive data
	 */
	public static String jsonize(String data, boolean withQuotes) {
		if (data != null) {
			data = replaceAll(data, "\\", "\\\\");
			data = replaceAll(data, "\"", "\\\"");
			data = replaceAll(data, "%", "%25");
			data = replaceAll(data, "+", "%2B");
			data = replaceAll(data, "&", "%26");
			data = replaceAll(data, "?", "%3F");
			data = replaceAll(data, "=", "%3D");
			data = replaceAll(data, "\r", "");
			data = replaceAll(data, "\n", "");
			if (withQuotes) {
				data = (new String("\"")).concat(data).concat("\"");
			}
		}
		return data;
	}
		
	/**
	 * Method to replace a supplied string from a given destination string.
	 * 
	 * @param text
	 *            Destination string
	 * @param searchString
	 *            string to be replaced
	 * @param replacementString
	 *            New string to be replaced with
	 * @return updated string after replacement
	 */
	private static String replaceAll(String text, String searchString,
			String replacementString) {
		StringBuffer sBuffer = new StringBuffer();
		int pos = 0;
		while ((pos = text.indexOf(searchString)) != -1) {
			sBuffer.append(text.substring(0, pos) + replacementString);
			text = text.substring(pos + searchString.length());
		}
		sBuffer.append(text);
		return sBuffer.toString();
	}
}
