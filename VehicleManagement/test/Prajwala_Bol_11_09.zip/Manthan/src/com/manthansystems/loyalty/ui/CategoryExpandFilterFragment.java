/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockListFragment;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDao;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.SettingsWorker;

/**
 * A class to provide user to filter category. It extends
 * {@link SherlockListFragment}.
 *
 *
 */
public class CategoryExpandFilterFragment extends SherlockFragment implements
		LoaderManager.LoaderCallbacks<Cursor>, OnRequestFinishedListener {

	private static final String LOG_TAG = "CategoryExpandFilterFragment";
	private final String SAVED_STATE_REQUEST_TYPE = "com.manthansystems.loyalty.ui.CategoryFilterFragment#RequestType";
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.CategoryFilterFragment#RequestId";
	private String mErrorMessage;
	private String mErrorTitle;
	private Bundle mResponseBundle;
	private boolean mShowProgressBar = false;
	private boolean mIsNoNetworkCaseOccurs = false;
	private AlertDialog mAlertDialog;
	private Handler mHandler;
	private RequestManager mRequestManager;
	private int mRequestId = -1;
	private static byte mRequestType;
	private ArrayList<String> mCategoryIdList;
	private SparseArray<String> mSerialCategoryIds = new SparseArray<String>();

	private ViewGroup mView;
	public static String OFFER_TYPE = "OFFER_TYPE";
	ExpandableListAdapter listAdapter;
	ExpandableListView expListView;
	List<String> listGroupCheck;
	private int mOfferType;
	private ArrayList<String> mSelectedCategoryIdList;
	private List<String> categoryList;
	private List<String> categoryListId;
	private Map<String, List<String>> itemMap = new LinkedHashMap<String, List<String>>();
	private List storageList = new ArrayList<String>();
	private String key = null;
	HashMap<String, String> categoryItemCount = new HashMap<String, String>();
	private ArrayList<String> categoryIds;

	private Map<String, List<String>> CategoryIdMap = new LinkedHashMap<String, List<String>>();
	private List CategoryIDList = new ArrayList<String>();
	private String keyId = null;
	String childSelectId = null;
	private List<String> SubList= new ArrayList<String>();
	private ArrayList<Integer> mExpandIdList;
	private ArrayList<String> expandCategory;
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState == null) {
			mOfferType = getActivity().getIntent().getIntExtra(OFFER_TYPE,
					DatabaseConfig.DB_OFFER_TYPE_COMMON);
		} else {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
			mRequestType = savedInstanceState.getByte(SAVED_STATE_REQUEST_TYPE);
			mOfferType = savedInstanceState.getInt(OFFER_TYPE);
		}
		mHandler = new Handler();
		mRequestManager = RequestManager.from(getActivity());
		mSelectedCategoryIdList = new ArrayList<String>();
		categoryList = new ArrayList<String>();
		categoryListId = new ArrayList<String>();
		mCategoryIdList = new ArrayList<String>();
		categoryIds = new ArrayList<String>();
		mExpandIdList = new ArrayList<Integer>();
		expandCategory = new ArrayList<String>();
		mSelectedCategoryIdList.clear();
		mCategoryIdList.clear();
		SubList.clear();
		mExpandIdList.clear();
		expandCategory.clear();

	}

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(
				R.layout.fragment_expand_filter, null);
		// For some reason, if we omit this, NoSaveStateFrameLayout thinks we
		// are
		// FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top
		// of the activity.
		root.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT));
		mView = root;
		bindViews();
		expListView = (ExpandableListView) mView.findViewById(R.id.lvExp);
		expListView.setOnGroupExpandListener(new OnGroupExpandListener() {

	        @Override
	        public void onGroupExpand(int groupPosition) {
	        	System.out.println("LISTENR------------------------");
	        	if(expListView!=null){	             
	        	   if(!mExpandIdList.contains(groupPosition)){	        		
	            	 mExpandIdList.add(groupPosition);
	            	 PreferenceConfig.setCategoryExpandFilterId(mExpandIdList.toString(), getActivity());
	        		}
	        	}
	        }
	    });
		
		expListView.setOnGroupCollapseListener(new OnGroupCollapseListener() {
			
			@Override
			public void onGroupCollapse(int groupPosition) {
	        	System.out.println("LISTENR------------------------");
	        	if(expListView!=null){	             
	        	   if(mExpandIdList.contains(groupPosition)){
	        		   if (groupPosition >0) {
	        			   mExpandIdList.remove(Integer.valueOf(groupPosition));
	  	            	 if (mExpandIdList !=null) {
	  	            		 PreferenceConfig.setCategoryExpandFilterId(mExpandIdList.toString(), getActivity());
	  	            	 }
					}
	        		}
	        	}
	        }
		});
		return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		mSelectedCategoryIdList = UIUtils.stringToArrayList(PreferenceConfig
				.getCategoryFilterId(getActivity()));		
		if (PreferenceConfig.isAllCategoryTimestampExpired(getActivity())) {
			LogConfig.logv(LOG_TAG,
					"onResume(): Timestamp expired: downloaded categories");
			callGetCategoryWS();
		} else {
			LogConfig.logv(LOG_TAG, "onResume(): Timestamp Valid");
			callGetCategoryWS();
			populateCategoryList();
		}
		
	}

	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logv(LOG_TAG, "onPause() ");
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager
					.removeOnRequestFinishedListener(CategoryExpandFilterFragment.this);
		}
		dismissActiveDialog();
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logv(LOG_TAG, "onResume()");
		if (mRequestId != -1) {
			if (mRequestManager.isRequestInProgress(mRequestId)) {
				mRequestManager
						.addOnRequestFinishedListener(CategoryExpandFilterFragment.this);
			} else {
				mRequestId = -1;
			}
		}
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		}
		mShowProgressBar = true;
		
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putByte(SAVED_STATE_REQUEST_TYPE, mRequestType);
		outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		outState.putInt(OFFER_TYPE, mOfferType);
		super.onSaveInstanceState(outState);
	}

	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.label_filter, false, true, false,
				getSherlockActivity());
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		menu.clear();
		if (isAllCategorySelected()) {
			inflater.inflate(R.menu.category_all_deselect_menu_items, menu);
		} else {
			inflater.inflate(R.menu.category_all_select_menu_items, menu);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.menu_category_select_all
				|| item.getItemId() == R.id.menu_category_deselect_all) {			
			if (isAllCategorySelected()) {
				mSelectedCategoryIdList.clear();
				PreferenceConfig.setAllCategoryFiltersSelected(false,
						getActivity());
				PreferenceConfig.setCategoryFilterId(
						mSelectedCategoryIdList.toString(), getActivity());
			} else {
				mSelectedCategoryIdList.clear();
				int size = mCategoryIdList.size();
				for (int i = 0; i < size; ++i) {
					mSelectedCategoryIdList.add(mCategoryIdList.get(i));
				}
				PreferenceConfig.setAllCategoryFiltersSelected(true,
						getActivity());
				PreferenceConfig.setCategoryFilterId(
						mSelectedCategoryIdList.toString(), getActivity());
			}
			if(listAdapter!=null){
			listAdapter.notifyDataSetChanged();
			getSherlockActivity().invalidateOptionsMenu();
			}

			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/** Make server request to get category from server. */
	private void callGetCategoryWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			populateCategoryList();
			mErrorMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}

		ProgressBarHelper.showProgressBarSmall(
				R.string.progress_bar_please_wait, false, mHandler,
				getSherlockActivity());
		Bundle params = new Bundle();
		mRequestManager
				.addOnRequestFinishedListener(CategoryExpandFilterFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.GET_ALL_CATEGORIES;
		params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
				SettingsWorker.WorkerModes.WORKER_MODE_GET_ALL_CATEGORY);
		mRequestId = mRequestManager.getAllCategories(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		// TODO Auto-generated method stub
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(CategoryExpandFilterFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE, -1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(
								R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(
								R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(
								R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(
							R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}

	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			String responseStatus = mResponseBundle
					.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.GET_ALL_CATEGORIES) {
					allCategoriesDownloadedDoSomething();
				}
			} else if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				mErrorMessage = mResponseBundle
						.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(
							R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
				if (mRequestType == REQUEST_TYPE.GET_ALL_CATEGORIES) {
					populateCategoryList();
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(
						R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
			if (mRequestType == REQUEST_TYPE.GET_ALL_CATEGORIES) {
				populateCategoryList();
			}
		}
	};

	

	public class ExpandableListAdapter extends BaseExpandableListAdapter {

		private Context _context;
		private List<String> _listDataHeader;
		private Map<String, List<String>> _listDataChild;
		int child_pos = 0;
		int group_pos = 0;

		public ExpandableListAdapter(Context context,
				List<String> listDataHeader,
				Map<String, List<String>> listChildData) {
			this._context = context;
			this._listDataHeader = listDataHeader;
			this._listDataChild = listChildData;
		}

		@Override
		public Object getChild(int groupPosition, int childPosititon) {
			return this._listDataChild.get(
					this._listDataHeader.get(groupPosition))
					.get(childPosititon);
		}

		@Override
		public long getChildId(int groupPosition, int childPosition) {
			group_pos = groupPosition;
			child_pos = childPosition;
			return childPosition;
		}

		@Override
		public View getChildView(final int groupPosition,
				final int childPosition, boolean isLastChild, View convertView,
				ViewGroup parent) {
			String childText = (String) getChild(groupPosition, childPosition);
			if (convertView == null) {
				LayoutInflater infalInflater = (LayoutInflater) this._context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = infalInflater.inflate(R.layout.filter_listitem,
						null);
			}
			TextView txtListChild = (TextView) convertView
					.findViewById(R.id.lblListItem);
			final CheckBox checkBoxCategoryChild = (CheckBox) convertView
					.findViewById(R.id.checkBox_select_category);
			final List<String> ListIDstrings = CategoryIdMap.get(categoryListId
					.get(groupPosition));

			childSelectId = ListIDstrings.get(childPosition);
			if (mSelectedCategoryIdList.contains(childSelectId)) {
				checkBoxCategoryChild.setChecked(true);
			} else {
				checkBoxCategoryChild.setChecked(false);
			}

			checkBoxCategoryChild.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					
					List<String> ListIDstrings = CategoryIdMap
							.get(categoryListId.get(groupPosition));
					childSelectId = ListIDstrings.get(childPosition);
					if (mSelectedCategoryIdList.contains(categoryListId
							.get(groupPosition))) {
						mSelectedCategoryIdList.remove(categoryListId
								.get(groupPosition));
						mSelectedCategoryIdList.remove(childSelectId);
					} else {
						if (mSelectedCategoryIdList.contains(childSelectId)) {
							mSelectedCategoryIdList.remove(categoryListId
									.get(groupPosition));
							mSelectedCategoryIdList.remove(childSelectId);
						} else {
							mSelectedCategoryIdList.add(childSelectId);
						}
						SubList.add(childSelectId);
					}
					if (mSelectedCategoryIdList.contains(childSelectId)) {						
						checkBoxCategoryChild.setChecked(true);
					} else {
						checkBoxCategoryChild.setChecked(false);
					}

					if(mSelectedCategoryIdList.containsAll(ListIDstrings)){
						mSelectedCategoryIdList.add(categoryListId.get(groupPosition));
					}else{
						
					}
					PreferenceConfig.setAllCategoryFiltersSelected(false,
							getActivity());
					PreferenceConfig.setCategoryFilterId(
							mSelectedCategoryIdList.toString(), getActivity());
					
					handleCategoryClickingGroup();
				}
			});

			txtListChild.setText(childText);
			return convertView;
		}

		@Override
		public int getChildrenCount(int groupPosition) {
			return this._listDataChild.get(
					this._listDataHeader.get(groupPosition)).size();
		}

		@Override
		public Object getGroup(int groupPosition) {
			return this._listDataHeader.get(groupPosition);
		}

		@Override
		public int getGroupCount() {
			return this._listDataHeader.size();
		}

		@Override
		public long getGroupId(int groupPosition) {
			return groupPosition;
		}

		@Override
		public View getGroupView(final int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {
			final String headerTitle = (String) getGroup(groupPosition);
			if (convertView == null) {
				LayoutInflater infalInflater = (LayoutInflater) this._context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = infalInflater.inflate(
						R.layout.filter_groupitemxml, null);
			}
			TextView categorGorupyName = (TextView) convertView
					.findViewById(R.id.textView_category_name);
			TextView mTextViewCategoryCount = (TextView) convertView
					.findViewById(R.id.textView_category_item_count);
			final ImageView mCheckBoxCategory = (ImageView) convertView
					.findViewById(R.id.checkBox_select_category);
			categorGorupyName.setTypeface(null, Typeface.BOLD);
			categorGorupyName.setText(headerTitle);

			final String categoryID = categoryListId.get(groupPosition);
			String categoryCount = categoryItemCount.get(categoryID);
			if (TextUtils.isEmpty(categoryCount)) {
				mTextViewCategoryCount.setText("(0)");
			} else {
				mTextViewCategoryCount.setText("(" + categoryCount + ")");
			}
           mCheckBoxCategory.setBackgroundResource(R.drawable.checked);
			if (mSelectedCategoryIdList.contains(categoryListId
					.get(groupPosition))) {
				mCheckBoxCategory.setBackgroundResource(R.drawable.checked);
			} else {
				mCheckBoxCategory.setBackgroundResource(R.drawable.unchecked);
			}
			mCheckBoxCategory.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					if (mSelectedCategoryIdList.contains(categoryListId
							.get(groupPosition))) {
						mCheckBoxCategory
								.setBackgroundResource(R.drawable.unchecked);
						List<String> IDstrings = CategoryIdMap
								.get(categoryListId.get(groupPosition));
						mSelectedCategoryIdList.remove(categoryListId
								.get(groupPosition));
						if (IDstrings.size() > 0) {
							for (int i = 0; i < IDstrings.size(); ++i) {
								mSelectedCategoryIdList.remove(IDstrings.get(i));
							}
						}
						PreferenceConfig.setAllCategoryFiltersSelected(false,
								getActivity());
						PreferenceConfig.setCategoryFilterId(
								mSelectedCategoryIdList.toString(),
								getActivity());

					} else {
						mCheckBoxCategory
								.setBackgroundResource(R.drawable.checked);
						List<String> IDstrings = CategoryIdMap
								.get(categoryListId.get(groupPosition));
						mSelectedCategoryIdList.add(categoryListId
								.get(groupPosition));
						if (IDstrings.size() > 0) {
							for (int i = 0; i < IDstrings.size(); ++i) {
								if (mSelectedCategoryIdList.contains(IDstrings.get(i))) {
									
								}else{
								mSelectedCategoryIdList.add(IDstrings.get(i));
								}
							}
						}
						PreferenceConfig.setAllCategoryFiltersSelected(false,
								getActivity());
						PreferenceConfig.setCategoryFilterId(
								mSelectedCategoryIdList.toString(),
								getActivity());
					}
					
					handleCategoryClickingGroup();
				}
			});

			return convertView;
		}

		@Override
		public boolean hasStableIds() {
			return false;
		}

		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}
	}

	/**
	 * A method to perform action after successfully downloading of all
	 * category.
	 **/
	private void allCategoriesDownloadedDoSomething() {
		ProgressBarHelper.dismissProgressBar(mHandler);
		populateCategoryList();
		// preparing list data
		renderCategoryList();
		prepareCategoryCount(mOfferType);
		listAdapter = new ExpandableListAdapter(getActivity(), categoryList,
				itemMap);
		// setting list adapter
		expListView.setAdapter(listAdapter);
		// expListView.setGroupIndicator(null);
		
		 // collapseAll();
		System.out.println("------------------Rajani------------------"+PreferenceConfig
				.getCategoryExpandFilterId(getActivity()));
		
	  expandCategory = UIUtils.stringToArrayList(PreferenceConfig
				.getCategoryExpandFilterId(getActivity()));
	  expandAll(expandCategory);
	}

	/** A method to populate category list from DataBase. */
	private void populateCategoryList() {
		getLoaderManager().destroyLoader(
				DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST);
		getLoaderManager().initLoader(
				DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST, null, this);
	}

	/** A method to prepare category count from DB. */
	private HashMap<String, String> prepareCategoryCount(int couponChooser) {
		categoryItemCount.clear();
		final int COLUMN_CATEGORY_ID = 0;
		final int COLUMN_CATEGORY_COUNT = 1;
		String where = "select TBL_CATEGORY_COUNT.CATEGORY_ID, COUNT(TBL_CATEGORY_COUNT.CATEGORY_ID) "
				+ "from TBL_CATEGORY_COUNT WHERE TBL_CATEGORY_COUNT.OFFER_TYPE = "
				+ couponChooser + " GROUP BY TBL_CATEGORY_COUNT.CATEGORY_ID";
		CursorLoader cursorLoader = new CursorLoader(getActivity(),
				CategoryCountDao.CONTENT_URI, null, where, null, null);
		Cursor c = cursorLoader.loadInBackground();
		if (c != null && c.getCount() > 0) {
			c.moveToPosition(-1);
			while (c.moveToNext()) {
				String categoryId = c.getString(COLUMN_CATEGORY_ID);
				String categoryCount = c.getString(COLUMN_CATEGORY_COUNT);
				categoryItemCount.put(categoryId, categoryCount);
			}
		}
		if (c != null) {
			c.close();
		}
		return categoryItemCount;
	}

	/** A method to render category list from database. */
	private void renderCategoryList() {
		Activity activity = getActivity();
		categoryList.clear();
		categoryListId.clear();
		itemMap.clear();
		storageList.clear();
		CursorLoader cursorLoader = new CursorLoader(activity,
				CategoryDao.CONTENT_URI, null, CategoryDao.CATEGORY_ID + " != "
						+ UIApplication.All_CATEGORY_ID, null, null);
		Cursor cursor = cursorLoader.loadInBackground();
		if (cursor != null && cursor.getCount() > 0) {
			cursor.moveToPosition(-1);
			while (cursor.moveToNext()) {
				String categoryName = cursor
						.getString(CategoryDao.CONTENT_CATEGORY_NAME_COLUMN);
				final String categoryId = cursor
						.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN);
				categoryIds.add(categoryId);
				if (!TextUtils.isEmpty(categoryName)) {
					if (categoryName.startsWith(" ")) {
						storageList = itemMap.get(key);
						storageList.add(categoryName);
						itemMap.put(key, (ArrayList<String>) storageList);

						CategoryIDList = CategoryIdMap.get(keyId);
						CategoryIDList.add(categoryId);
						CategoryIdMap.put(keyId,
								(ArrayList<String>) CategoryIDList);

					} else {
						key = categoryName;
						categoryList.add(key);
						categoryListId.add(categoryId);
						itemMap.put(key, new ArrayList<String>());

						keyId = categoryId;
						CategoryIdMap.put(keyId, new ArrayList<String>());

					}
				}
			}
		}
		if (cursor != null) {
			cursor.close();
		}
	}

	@Override
	public Loader<Cursor> onCreateLoader(int token, Bundle arg1) {
		// TODO Auto-generated method stub
		if (token == DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST) {
			return new CursorLoader(getActivity(), CategoryDao.CONTENT_URI,
					null, CategoryDao.CATEGORY_ID + " != "
							+ UIApplication.All_CATEGORY_ID, null, null);
		}
		return null;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		// TODO Auto-generated method stub
		final int token = loader.getId();
		LogConfig.logd(LOG_TAG, "onloadFinished");
		if (token == DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST) {
			if (cursor != null) {
				LogConfig.logd(LOG_TAG, "count is " + cursor.getCount());
			}
			mSerialCategoryIds.clear();
			// mSectionAdapter.swapCursor(cursor);
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					cursor.moveToPosition(-1);
					int position = 0;
					while (cursor.moveToNext()) {
						mSerialCategoryIds
								.put(position,
										cursor.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
						position++;
					}
					cursor.moveToPosition(-1);
					if (mSelectedCategoryIdList.size() == 0) {
						while (cursor.moveToNext()) {
							mCategoryIdList
									.add(cursor
											.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
							mSelectedCategoryIdList
									.add(cursor
											.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
						}
						PreferenceConfig.setAllCategoryFiltersSelected(true,
								getActivity());
					} else {
						while (cursor.moveToNext()) {
							mCategoryIdList
									.add(cursor
											.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
						}
						PreferenceConfig.setAllCategoryFiltersSelected(
								isAllCategorySelected(), getActivity());
					}
				} else if (cursor.getCount() <= 0 && !mIsNoNetworkCaseOccurs) {
					mHandler.post(new Runnable() {

						@Override
						public void run() {
							if (mResponseBundle != null) {
								mErrorMessage = mResponseBundle
										.getString(CommonConfig.KEY_NAME_RESULTS_MESSAGE);
								if (!TextUtils.isEmpty(mErrorMessage)) {
									mErrorTitle = getResources().getString(
											R.string.app_name);
									showDialog(DialogConfig.DIALOG_ERROR);
								}
							}
						}
					});
				}
				mIsNoNetworkCaseOccurs = false;
				getSherlockActivity().invalidateOptionsMenu();
			}
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		// TODO Auto-generated method stub

	}

	/** Method to handle back key press. */
	public boolean handleBackKeyPress() {
		if (mSelectedCategoryIdList.size() == 0 && mCategoryIdList.size() > 0) {
			showDialog(DialogConfig.DIALOG_SELECT_ATLEAST_ONE_CATEGORY);
			return true;
		} else {
			PreferenceConfig.setCategoryFilterId(
					mSelectedCategoryIdList.toString(), getActivity());
			return false;
		}
	}

	/** Method to handle category clicking. */
	@SuppressLint("NewApi")
	private void handleCategoryClickingGroup() {		
		listAdapter.notifyDataSetChanged();
		getSherlockActivity().invalidateOptionsMenu();
	}

	/** Method to handle category clicking. */
	@SuppressLint("NewApi")
	private void handleCategoryClicking(String categoryId) {
		if (!TextUtils.isEmpty(categoryId)) {
			if (isAllCategorySelected()) {
				mSelectedCategoryIdList.clear();
				mSelectedCategoryIdList.add(categoryId);
				PreferenceConfig.setAllCategoryFiltersSelected(true,
						getActivity());
				PreferenceConfig.setCategoryFilterId(
						mSelectedCategoryIdList.toString(), getActivity());
			} else {
				if (mSelectedCategoryIdList.contains(categoryId)) {
					mSelectedCategoryIdList.remove(categoryId);
				} else {
					mSelectedCategoryIdList.add(categoryId);
				}
				PreferenceConfig.setAllCategoryFiltersSelected(
						isAllCategorySelected(), getActivity());
				PreferenceConfig.setCategoryFilterId(
						mSelectedCategoryIdList.toString(), getActivity());
			}
			listAdapter.notifyDataSetChanged();
			getSherlockActivity().invalidateOptionsMenu();
		}
	}

	/**
	 * A method to check whether all category is selected or not. Return true if
	 * all category is selected.
	 **/
	private boolean isAllCategorySelected() {		
		if (mSelectedCategoryIdList.size() == mCategoryIdList.size()) {
			if (mSelectedCategoryIdList.size() == 0) {
				return false;
			}
			return true;
		}
		return false;
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(mErrorTitle)
					.setMessage(mErrorMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;

		case DialogConfig.DIALOG_SELECT_ATLEAST_ONE_CATEGORY:
			dlg.setIcon(R.drawable.icon)
					.setTitle(getResources().getString(R.string.app_name))
					.setMessage(
							getResources()
									.getString(
											R.string.label_select_at_least_one_category))
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mView != null) {
			UIUtils.unbindDrawables(mView
					.findViewById(R.id.root_view_fragment_cateegory_filter));
			System.gc();
		}

	}

	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
	
	// method to expand all groups
    private void expandAll(List<String> toExpandList) {
    	if(listAdapter!=null){
            for (int i = 0; i < toExpandList.size(); i++) {
            	expListView.expandGroup(Integer.parseInt(toExpandList.get(i)));
            }
    	}

    }

    // method to collapse all groups
    private void collapseAll() {
    	   if(listAdapter!=null){
    		   int count = listAdapter.getGroupCount();
               for (int i = 0; i < count; i++) {
            	   if(expListView!=null)
               	   expListView.collapseGroup(i);
               }
    	   }
          
    }

}
