package com.manthansystems.loyalty.ui.phone;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.KeyEvent;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDaoHome;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.model.HomeCoupon;
import com.manthansystems.loyalty.ui.HomeOfferDetailFragment;
import com.manthansystems.loyalty.ui.UIApplication;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.TriggerWorker.TriggerConstants;

/**
 * An activity class that will show detail of home offers / coupons. This class
 * extends {@link SherlockFragmentActivity}.
 * 
 */
public class HomeOfferDetailActivity extends SherlockFragmentActivity {

	private final static String LOG_TAG = "HomeOfferDetailActivity";
	private OfferPagerAdapter mOfferPagerAdapter;
	private ViewPager mViewPager;
	private static int mOfferCount;
	private int mCurrentItemPosition;
	private int mPreviousItemPosition;
	private Handler mHandler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_offer_detail);
		mHandler = new Handler();
		if (savedInstanceState == null) {
			mOfferCount = getIntent().getIntExtra(
					HomeOfferDetailIntentKey.OFFER_COUNT, 1);
			mCurrentItemPosition = getIntent().getIntExtra(
					HomeOfferDetailIntentKey.CURRENTLY_SELECTED_ITEM, 1);
			mPreviousItemPosition = -1;
		} else {
			mOfferCount = savedInstanceState
					.getInt(HomeOfferDetailIntentKey.OFFER_COUNT);
			mCurrentItemPosition = savedInstanceState
					.getInt(HomeOfferDetailIntentKey.CURRENTLY_SELECTED_ITEM);
			mPreviousItemPosition = savedInstanceState
					.getInt(HomeOfferDetailIntentKey.PREVIOUS_ITEM_POSITION);
		}
		mOfferPagerAdapter = new OfferPagerAdapter(getSupportFragmentManager(),
				this);
		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mOfferPagerAdapter);
		mViewPager.setCurrentItem(mCurrentItemPosition, true);
		// Override the OnPageChangeListener to go back to offers listing
		// in case of the left swipe upon top offer's description.
		mViewPager
				.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
					@Override
					public void onPageSelected(int position) {
						// Do Nothing
					}

					@Override
					public void onPageScrolled(int position,
							float positionOffset, int positionOffsetPixels) {
						mCurrentItemPosition = position;
					}

					@Override
					public void onPageScrollStateChanged(int state) {
						if (state == ViewPager.SCROLL_STATE_IDLE) {
							if (mPreviousItemPosition == 0
									&& mCurrentItemPosition == 0) {
								HomeOfferDetailActivity.this.finish();
							} else {
								if (mPreviousItemPosition == mCurrentItemPosition) {
									// Scroll made on last page and trigger is
									// already sent for it.
									return;
								}
								mPreviousItemPosition = mCurrentItemPosition;
								mHandler.post(new Runnable() {
									@Override
									public void run() {
										((HomeOfferDetailFragment) ((OfferPagerAdapter) mViewPager
												.getAdapter())
												.getItem(mCurrentItemPosition))
												.setScreenTitle(HomeOfferDetailActivity.this);
										callCouponDetailTriggerWS();
									}
								});
							}
						}
					}
				});
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * A {@link android.support.v4.app.FragmentStatePagerAdapter} that returns a
	 * fragment representing an object in the collection.
	 */
	public static class OfferPagerAdapter extends FragmentStatePagerAdapter {

		private Activity mActivity;

		public OfferPagerAdapter(FragmentManager fm, Activity activity) {
			super(fm);
			mActivity = activity;
		}

		@Override
		public Fragment getItem(int i) {
			UIApplication app = (UIApplication) mActivity
					.getApplicationContext();
			HomeCoupon coupon = app.getCouponModelArrayHome().get(i);
			if (coupon == null) {
				mActivity.finish();
			}
			Fragment fragment = new HomeOfferDetailFragment();
			Bundle args = new Bundle();
			args.putInt(HomeOfferDetailIntentKey.CURRENT_FRAGMENT_INDEX, i);
			if (coupon.mIsMarketingMessageFlag == CouponDaoHome.FLAG_VALUE_MARKETING_MESSAGE) {
				args.putString(
						HomeOfferDetailIntentKey.OFFER_DETAIL_TITLE,
						mActivity.getResources().getString(
								R.string.promo_coupon_description));
			} else {
				args.putString(
						HomeOfferDetailIntentKey.OFFER_DETAIL_TITLE,
						mActivity.getResources().getString(
								R.string.coupon_description));
			}
			fragment.setArguments(args);
			return fragment;
		}

		@Override
		public int getCount() {
			return mOfferCount;
		}

	}

	/**
	 * An interface class to hold key related to OfferDetail data.
	 * 
	 * 
	 */
	public interface HomeOfferDetailIntentKey {
		public final String OFFER_DETAIL_ID = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#CommonConfig#id";
		public final String OFFER_DETAIL_COUPON_ID = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#coupon_id";
		public final String OFFER_DETAIL_COUPON_NAME = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#name";
		public final String OFFER_DETAIL_COUPON_CHOOSER = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#chooser";
		public final String OFFER_DETAIL_COUPON_LONG_DESCRIPTION = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#longDescription";
		public final String OFFER_DETAIL_FAVORITE_FLAG = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#favorite_flag";
		public final String OFFER_DETAIL_IMAGE_URL = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#image_url";
		public final String OFFER_DETAIL_COUPON_TYPE = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#type";
		public final String OFFER_DETAIL_COUPON_URL = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#url";
		public final String OFFER_DETAIL_DECORATOR = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#decorator";
		public final String OFFER_DETAIL_DISCOUNT = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#discount";
		public final String OFFER_DETAIL_EXPIRES = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#expires";
		public final String OFFER_DETAIL_EXPIRY_DATE = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#expiry_date";
		public final String OFFER_DETAIL_STORE_ID = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#store_id";
		public final String OFFER_COUNT = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#count";
		public final String CURRENTLY_SELECTED_ITEM = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#current_item";
		public final String CURRENT_FRAGMENT_INDEX = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#CURRENT_FRAGMENT_INDEX";
		public final String OFFER_DETAIL_COUPON_BARCODE = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#barcode";
		public final String OFFER_DETAIL_COUPON_BARCODE_IMAGE_URL = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#barcode_imageurl";
		public final String OFFER_DETAIL_COUPON_CODE = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#coupon_code";
		public final String OFFER_DETAIL_COUPON_LARGE_IMAGE_URL = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#coupon_large_image_url";
		public final String OFFER_DETAIL_COUPON_DESCRIPTION = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#coupon_description";
		public final String PREVIOUS_ITEM_POSITION = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#PREVIOUS_ITEM_POSITION";
		public final String OFFER_DETAIL_MARKETING_MESSAGE_FLAG = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#marketing_msg_flag";
		public final String OFFER_DETAIL_TITLE = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#screenTitle";
		public final String OFFER_DETAIL_COUPON_REDEEMABLE = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#coupon_redeemable";
		public final String OFFER_DETAIL_COUPON_USAGE_TYPE = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#UsageType";
		public final String OFFER_DETAIL_COUPON_REDEEM_THRESHOLD_LIMIT = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#ThresholdLimit";
		public final String OFFER_DETAIL_COUPON_EXHAUSTED = "com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey#Exhausted";
	}

	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(0, R.anim.translate_slide_right_out);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putInt(HomeOfferDetailIntentKey.OFFER_COUNT, mOfferCount);
		outState.putInt(HomeOfferDetailIntentKey.CURRENTLY_SELECTED_ITEM,
				mCurrentItemPosition);
		outState.putInt(HomeOfferDetailIntentKey.PREVIOUS_ITEM_POSITION,
				mPreviousItemPosition);
		super.onSaveInstanceState(outState);
	}

	/**
	 * Method to check from inside the fragment that whether from caller
	 * fragment screen title can be set or not. Basically from {@link ViewPager}
	 * these fragments are created before hand to display later on while swipe
	 * only the current active fragment should only can set the screen title.
	 * 
	 * @param fragmentIndex
	 *            Index value of the caller fragment.
	 */
	public boolean canSetScreenTitle(int fragmentIndex) {
		if (mViewPager != null && mViewPager.getCurrentItem() == fragmentIndex) {
			return true;
		}
		return false;
	}

	/** Method to call coupon detail trigger network request. */
	private void callCouponDetailTriggerWS() {
		LogConfig.logv(LOG_TAG, "callCouponDetailTriggerWS()");
		String activeTriggerList = PreferenceConfig
				.getActiveTriggersList(HomeOfferDetailActivity.this);
		if (TextUtils.isEmpty(activeTriggerList)) {
			return;
		}
		if (NetworkHelper.isNetworkAvailable(HomeOfferDetailActivity.this)
				&& PreferenceConfig.isValidUser(HomeOfferDetailActivity.this)
				&& activeTriggerList
						.contains(TriggerConstants.TRIGGER_TYPE_COUPON_DETAIL)) {
			UIApplication app = (UIApplication) getApplicationContext();
			HomeCoupon coupon = app.getCouponModelArrayHome().get(
					mCurrentItemPosition);
			if (coupon != null) {
				Bundle params = new Bundle();
				params.putByte(
						TriggerConstants.KEY_NAME_BUNDLE_TRIGGER_WORKER_MODE,
						TriggerConstants.WORKER_MODE_TRIGGER_VIEW_COUPON_DETAIL);
				params.putString(TriggerConstants.KEY_NAME_BUNDLE_COUPON_ID,
						coupon.mId + "");
				RequestManager requestManager = RequestManager
						.from(HomeOfferDetailActivity.this);
				requestManager.triggerEvent(DownloadFormat.RETURN_FORMAT_JSON,
						params);
			}
		}
	}

	@Override
	protected void onStart() {
		super.onStart();
		LogConfig.logv(LOG_TAG, "onStart()");
		callCouponDetailTriggerWS();
	}
}
