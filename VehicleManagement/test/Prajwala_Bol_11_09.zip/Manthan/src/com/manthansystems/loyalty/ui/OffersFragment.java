/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Observable;
import java.util.Observer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentProviderOperation;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;



import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.app.SherlockListFragment;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.data.provider.DatabaseProvider;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.location.GeoUtils;
import com.manthansystems.loyalty.location.LocationHandler;
import com.manthansystems.loyalty.model.BaseViewHolder;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.ViewHolderOfferList;
import com.manthansystems.loyalty.model.ViewHolderPromoOfferList;
import com.manthansystems.loyalty.service.GpsListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.phone.CategoryFilterActivity;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.ui.phone.LocationSettingsAcitivity;
import com.manthansystems.loyalty.ui.phone.OfferDetailActivity;
import com.manthansystems.loyalty.ui.phone.OfferDetailActivity.OfferDetailIntentKey;
import com.manthansystems.loyalty.ui.widget.RefreshableListView;
import com.manthansystems.loyalty.ui.widget.RefreshableListView.OnUpdateTask;
import com.manthansystems.loyalty.util.AnalyticsHelper;
import com.manthansystems.loyalty.util.BitmapManager;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.ToastHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadMode;
import com.manthansystems.loyalty.worker.FavoriteOffersWorker;
import com.manthansystems.loyalty.worker.LoginWorker;
import com.manthansystems.loyalty.worker.OffersWorker;
import com.manthansystems.loyalty.worker.SettingsWorker;

/**
 * A class to display the offers listing. It extends
 * {@link SherlockListFragment}.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class OffersFragment extends SherlockListFragment implements
		LoaderManager.LoaderCallbacks<Cursor>, OnRequestFinishedListener {

	protected static String LOG_TAG = "OffersFragment";
	private final String SAVED_STATE_REQUEST_TYPE = "com.manthansystems.loyalty.ui.OffersFragment#RequestType";
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.OffersFragment#RequestId";
	private final String SAVED_STATE_IS_FROM_SETTINGS_SCREEN = "com.manthansystems.loyalty.ui.OffersFragment#FromSettingsScreen";
	private final String SAVED_STATE_IS_FROM_LOCATION_SETTINGS_SCREEN = "com.manthansystems.loyalty.ui.OffersFragment#FromLocationSettingsScreen";

	private ViewGroup mView;

	private SectionAdapter mSectionAdapter;
	private int mSectionGroupColumn;

	private Handler mHandler;
	private LocationHandler mLocationHandler;
	private LocationUpdateListener mLocationUpdateListener;
	private RequestManager mRequestManager;
	private int mRequestId = -1;
	private static byte mRequestType;

	private String mDialogMessage;
	private String mErrorTitle;
	private Bundle mResponseBundle;

	/**
	 * To set the flag true if app control is coming from settings screen or set
	 * false otherwise.
	 */
	private boolean mIsFromSettingScreen = false;
	private boolean mShowProgressBar = false;
	/** To check if offer list refresh is requested by user. */
	private boolean mIsRefreshing = false;

	private SparseArray<FavoriteData> mFavStatusArray = new SparseArray<FavoriteData>();
	private SparseArray<FavoriteData> mFavDeletedArray = new SparseArray<FavoriteData>();
	private SparseArray<Coupon> mCouponArray = new SparseArray<Coupon>();

	private BitmapManager mBitmapManager;

	private byte mDownloadMode;

	private EditText mEditTextSearch;
	private boolean mSearchResultShowing = false;
	/**
	 * To set the flag true if app control is coming from location settings
	 * screen or set false otherwise.
	 */
	private boolean mIsComingFromLocationSettingsScreen = false;
	/** To check if app control is coming from offer details screen or not. */
	private boolean mIsComingFromOfferDetailsScreen = false;
	/** To check if no network case occurs or not. */
	private boolean mIsNoNetworkCaseOccurs = false;
	/**
	 * Get the status TURE if search result is showing by keypress search event
	 * or else get FALSE. <br>
	 * <br>
	 * Note: The basic intent of using this variable is to avoid showing the
	 * <code>"No Offers Found"</code> message while offer searched via keypress
	 * event of search text box.
	 */
	private boolean mKeyPressSearchResultShowing = false;

	private AlertDialog mAlertDialog;

	private LocationManager mLocationManager;
	private RefreshableListView mListView;
	private TextView mTextViewTapToRefresh;

	private int mRadius;
	boolean mIsOffersProximityRadiusChanged = false;
	private String mResponseMessageOffers = "";
	private Context mContext;
	@SuppressWarnings("static-access")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = getActivity().getApplicationContext();
		LogConfig.logv(LOG_TAG, "onCreate()");
		// Update the log tag for logging.
		updateLogTag();
		
		if (savedInstanceState == null) {
			mIsFromSettingScreen = false;
			mIsComingFromLocationSettingsScreen = false;
		} else {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
			mRequestType = savedInstanceState.getByte(SAVED_STATE_REQUEST_TYPE);
			mIsFromSettingScreen = savedInstanceState
					.getBoolean(SAVED_STATE_IS_FROM_SETTINGS_SCREEN);
			mIsComingFromLocationSettingsScreen = savedInstanceState
					.getBoolean(SAVED_STATE_IS_FROM_LOCATION_SETTINGS_SCREEN);
		}
		mHandler = new Handler();
		mLocationHandler = new LocationHandler();
		mLocationUpdateListener = new LocationUpdateListener();
		mRequestManager = RequestManager.from(getActivity());
		mDownloadMode = PreferenceConfig.getDownloadMode(getActivity());
		UIApplication app = (UIApplication) getActivity().getApplication();
		mBitmapManager = app.getBitmapManagerInstance(getActivity());
		mLocationManager = (LocationManager) getActivity().getSystemService(
				getActivity().LOCATION_SERVICE);
		
		
		LogConfig
				.logv(LOG_TAG, "onCreate() : mDownloadMode = " + mDownloadMode);
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(
				R.layout.fragment_pulldown_list, null);

		// For some reason, if we omit this, NoSaveStateFrameLayout thinks we
		// are
		// FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top
		// of the activity.
		root.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT));
		mView = root;			
		bindViews();
		return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		LogConfig.logv(LOG_TAG, "onActivityCreated()");
		mSectionAdapter = new SectionAdapter(getActivity(), null,
				R.layout.list_header, getSectionGroupColumn());
		mListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		mListView.setAdapter(mSectionAdapter);
		mListView.setOnTouchListener(mOnTouchListenerScreen);
		mListView.setOnUpdateTask(new OnUpdateTask() {
			@Override
			public void onUpdateStart() {
				refreshOffers();
			}

			@Override
			public void updateBackground() {
			}

			@Override
			public void updateUI() {
			}
		});
		
		// Set the screen title view.
				UIUtils.setTitleView(getTitleResId(), false, true, true,
						getSherlockActivity());
				
				View view = ((SherlockFragmentActivity) getActivity())
						.getSupportActionBar().getCustomView();
				if (view != null) {
					view.findViewById(R.id.ImageView_Slide_Menu_more_icon)
							.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View v) {
									((BaseSlidingActivity) getActivity())
											.getSlidingMenu().showMenu(true);
								}
							});

					view.findViewById(R.id.ImageView_Slide_Menu_icon)
							.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View v) {if (PreferenceConfig
										.getHomeTabEnabled(getActivity()) == 0) {
									Toast.makeText(
											getActivity(),
											getString(R.string.label_no_home_page),
											Toast.LENGTH_SHORT).show();

								} else if (!NetworkHelper.isNetworkAvailable(getActivity())) {
									mDialogMessage = getResources().getString(
											R.string.network_not_available_msg);
									mErrorTitle = getResources().getString(
											R.string.network_not_available_title);
									showDialog(DialogConfig.DIALOG_ERROR);
									// must reset refreshing, if requested or not.
									return;
								}else {
									PreferenceConfig.putComingFromHomeIcon(
											getActivity(), true);
									startActivity(new Intent(getActivity(),
											HomeActivity.class));
								}}
							});
				}

				// register sliding menu open listener to hide the vkeyboard if open.
				((HomeActivity) getActivity()).getSlidingMenu().setOnOpenListener(
						onSlidingMenuOpenListener);
				if (mRequestId != -1) {
					if (mRequestManager.isRequestInProgress(mRequestId)) {
						mRequestManager
								.addOnRequestFinishedListener(OffersFragment.this);
					} else {
						mRequestId = -1;
					}
				}
				if (mShowProgressBar) {
					ProgressBarHelper.dismissProgressbarFromOtherScreen();
				}
				mShowProgressBar = true;
				boolean isOfferExpired = true;
				if (getOffersType() == OffersType.COMMON_OFFERS) {
					isOfferExpired = PreferenceConfig
							.isOffersTimestampExpired(getActivity());
				} else {
					isOfferExpired = PreferenceConfig
							.isPersonalOffersTimestampExpired(getActivity());
				}

				if (mIsFromSettingScreen) {
					mIsFromSettingScreen = false;
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, false, mHandler,
							getSherlockActivity());
					if (!GeoUtils.isGpsLocationProviderEnabled(getActivity())) {
						mIsRefreshing = false;
					}
					if (PreferenceConfig.isValidUser(getActivity())) {
						LogConfig.logv(LOG_TAG, "onResume(): fetchOfferCounts()");
						// get offer count from server.
						fetchOfferCounts(PreferenceConfig
								.getDownloadMode(getActivity()));
					} else {
						LogConfig.logv(LOG_TAG, "onResume(): fetchOffers()");
						fetchOffers(PreferenceConfig.getDownloadMode(getActivity()));
					}
				} else if (!(mIsComingFromLocationSettingsScreen || mIsComingFromOfferDetailsScreen)
						|| (isOfferExpired && !mIsComingFromLocationSettingsScreen)) {
					// If coming from background or is a normal resume fetch offers.
					LogConfig
							.logv(LOG_TAG,
									"onResume(): Normal resume or offer expired: fetchOffers()");
					if (isOfferExpired) {
						mIsComingFromLocationSettingsScreen = false;
						mIsComingFromOfferDetailsScreen = false;
					}
					if (PreferenceConfig.isAppUpdateAvailable(getActivity())) {
						LogConfig.logv(LOG_TAG, "onResume(): APP Update Available");
						showDialog(DialogConfig.DIALOG_UPGRADE_APP);
					} else if (!PreferenceConfig.isAppUpdateChecked(getActivity())) {
						callCheckAppUpdateWS();
					} else if (PreferenceConfig.isValidUser(getActivity())
							&& PreferenceConfig.isSessionIdExpired(getActivity())) {
						callGetSessionIdWS();
					} else {
						ProgressBarHelper.showProgressBarSmall(
								R.string.progress_bar_please_wait, false, mHandler,
								getSherlockActivity());
						if (PreferenceConfig.isAppConfigDownloaded(getActivity())
								&& !PreferenceConfig.isAppConfigExpired(getActivity())) {
							if (PreferenceConfig.isValidUser(getActivity())) {
								LogConfig.logv(LOG_TAG,
										"onResume(): fetchOfferCounts()");
								// get offer count from server.
								fetchOfferCounts(PreferenceConfig
										.getDownloadMode(getActivity()));
							} else {
								LogConfig.logv(LOG_TAG, "onResume(): fetchOffers()");
								fetchOffers(PreferenceConfig
										.getDownloadMode(getActivity()));
							}
						} else {
							callGetAppConfigWS();
						}
					}
				} else {
					mIsComingFromLocationSettingsScreen = false;
					mIsComingFromOfferDetailsScreen = false;
				}

//				Get GPS Location and set it to preference only if GPS is on
				LocationManager locationManager = (LocationManager) mContext.getSystemService(Activity.LOCATION_SERVICE);
				if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
					getGPSLocation();
				}
	}

	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logv(LOG_TAG, "onPause()");
		// un-register sliding menu open listener.
		((HomeActivity) getActivity()).getSlidingMenu().setOnOpenListener(null);
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager
					.removeOnRequestFinishedListener(OffersFragment.this);
		}
		updateOffersFavoriteFlags();
		if (!mIsComingFromOfferDetailsScreen) {
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST);
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST);
			} else {
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST);
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST);
			}

			// reset the search status once again, though it is also resetting
			// from
			// onLoadFinished() method of search result query completion.
			mSearchResultShowing = false;
			// set empty text at search text box
			mEditTextSearch.setText("");
		}
		removeLocationUpdate();
		dismissActiveDialog();
		// Call to hide list refresh animation, though refresh would done.
		listRefreshed();
	}


	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logv(LOG_TAG, "onResume()");
		// Set the screen title view.
		
		if (mRequestId != -1) {
			if (mRequestManager.isRequestInProgress(mRequestId)) {
				mRequestManager
						.addOnRequestFinishedListener(OffersFragment.this);
			} else {
				mRequestId = -1;
			}
		}
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		}
		mShowProgressBar = true;
		boolean isOfferExpired = true;
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			isOfferExpired = PreferenceConfig
					.isOffersTimestampExpired(getActivity());
		} else {
			isOfferExpired = PreferenceConfig
					.isPersonalOffersTimestampExpired(getActivity());
		}

		if (mIsFromSettingScreen) {
			mIsFromSettingScreen = false;
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
			if (!GeoUtils.isGpsLocationProviderEnabled(getActivity())) {
				mIsRefreshing = false;
			}
			if (PreferenceConfig.isValidUser(getActivity())) {
				LogConfig.logv(LOG_TAG, "onResume(): fetchOfferCounts()");
				// get offer count from server.
				fetchOfferCounts(PreferenceConfig
						.getDownloadMode(getActivity()));
			} else {
				LogConfig.logv(LOG_TAG, "onResume(): fetchOffers()");
				fetchOffers(PreferenceConfig.getDownloadMode(getActivity()));
			}
		} else if (!(mIsComingFromLocationSettingsScreen || mIsComingFromOfferDetailsScreen)
				|| (isOfferExpired && !mIsComingFromLocationSettingsScreen)) {
			// If coming from background or is a normal resume fetch offers.
			LogConfig
					.logv(LOG_TAG,
							"onResume(): Normal resume or offer expired: fetchOffers()");
			if (isOfferExpired) {
				mIsComingFromLocationSettingsScreen = false;
				mIsComingFromOfferDetailsScreen = false;
			}
			if (PreferenceConfig.isAppUpdateAvailable(getActivity())) {
				LogConfig.logv(LOG_TAG, "onResume(): APP Update Available");
				showDialog(DialogConfig.DIALOG_UPGRADE_APP);
			} else if (!PreferenceConfig.isAppUpdateChecked(getActivity())) {
				callCheckAppUpdateWS();
			} else if (PreferenceConfig.isValidUser(getActivity())
					&& PreferenceConfig.isSessionIdExpired(getActivity())) {
				callGetSessionIdWS();
			} else {
				ProgressBarHelper.showProgressBarSmall(
						R.string.progress_bar_please_wait, false, mHandler,
						getSherlockActivity());
				if (PreferenceConfig.isAppConfigDownloaded(getActivity())
						&& !PreferenceConfig.isAppConfigExpired(getActivity())) {
					if (PreferenceConfig.isValidUser(getActivity())) {
						LogConfig.logv(LOG_TAG,
								"onResume(): fetchOfferCounts()");
						// get offer count from server.
						fetchOfferCounts(PreferenceConfig
								.getDownloadMode(getActivity()));
					} else {
						LogConfig.logv(LOG_TAG, "onResume(): fetchOffers()");
						fetchOffers(PreferenceConfig
								.getDownloadMode(getActivity()));
					}
				} else {
					callGetAppConfigWS();
				}
			}
		} else {
			mIsComingFromLocationSettingsScreen = false;
			mIsComingFromOfferDetailsScreen = false;
		}

//		Get GPS Location and set it to preference only if GPS is on
		LocationManager locationManager = (LocationManager) mContext.getSystemService(Activity.LOCATION_SERVICE);
		if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			getGPSLocation();
		}
		System.out.println("-------------------Tapas-----------------"+PreferenceConfig.getDownloadMode(getActivity()));
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putByte(SAVED_STATE_REQUEST_TYPE, mRequestType);
		outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		outState.putBoolean(SAVED_STATE_IS_FROM_SETTINGS_SCREEN,
				mIsFromSettingScreen);
		outState.putBoolean(SAVED_STATE_IS_FROM_LOCATION_SETTINGS_SCREEN,
				mIsComingFromLocationSettingsScreen);
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		menu.clear();
		super.onCreateOptionsMenu(menu, inflater);
		inflater.inflate(R.menu.category_filter_menu_items, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		if (item.getItemId() == R.id.menu_category_filter) {
			int couponChooser;
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
			} else {
				couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
			}
			Intent intent = new Intent(getActivity(),
					CategoryFilterActivity.class);
			intent.putExtra(CategoryExpandFilterFragment.OFFER_TYPE, couponChooser);
			startActivity(intent);
			mSectionAdapter.setSelectedPosition(-1);
		}
		return super.onOptionsItemSelected(item);
	}
public void getGPSLocation(){
	GpsListener gps = new GpsListener(getActivity());
	double latitude = 0,longitude = 0;

	// check if GPS enabled
	if (gps.canGetLocation()) {
		latitude = gps.getLatitude();
		longitude = gps.getLongitude();
	} else {
		gps.showSettingsAlert();
	}
	
	try {
		Geocoder geocoder = new Geocoder(
				getActivity(), Locale.getDefault());

		List<Address> addresses = geocoder.getFromLocation(
				latitude, longitude, 1);
		
	} catch (Exception e) {
		//System.out.println("errror");
	}
}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		mEditTextSearch = (EditText) mView
				.findViewById(R.id.editText_search_text);
		mEditTextSearch
				.setOnEditorActionListener(new EditText.OnEditorActionListener() {

					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (event != null
								&& event.getAction() != KeyEvent.ACTION_DOWN) {
							return false;
						} else if (actionId == EditorInfo.IME_ACTION_SEARCH
								|| actionId == EditorInfo.IME_ACTION_DONE
								|| actionId == EditorInfo.IME_NULL
								|| event == null
								|| event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
							mKeyPressSearchResultShowing = false;
							UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
							if (TextUtils.isEmpty(mEditTextSearch.getText()
									.toString().trim())) {
								mErrorTitle = getResources().getString(
										R.string.app_name);
								mDialogMessage = getResources().getString(
										R.string.dialog_msg_enter_search_text);
								showDialog(DialogConfig.DIALOG_ERROR);
								return true;
							} else if (mEditTextSearch.getText().toString()
									.trim().length() > 40) {
								mErrorTitle = getResources().getString(
										R.string.app_name);
								mDialogMessage = getResources().getString(
										R.string.dialog_msg_search_text_limit);
								showDialog(DialogConfig.DIALOG_ERROR);
								return true;
							}
							updateOffersFavoriteFlags();
							return true;
						}
						return false;
					}
				});
		mEditTextSearch.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// Do nothing
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// Do nothing
			}

			@Override
			public void afterTextChanged(Editable s) {
				final String searchText = s.toString().trim();
				if (TextUtils.isEmpty(searchText)) {
					mKeyPressSearchResultShowing = false;
					// reset search
					if (mSearchResultShowing) {
						// Update the favorite status of offers if modified in
						// search result screen.
						updateOffersFavoriteFlags();
						// reset the search status once again, though it is also
						// resetting from
						// onLoadFinished() method.
						mSearchResultShowing = false;

						// re-query the offers list from cache.
						prepareOffersListCursor();
					}
				} else {
					searchOffersOnKeyPress(mEditTextSearch.getText().toString()
							.trim());
				}
			}
		});
		

		final LinearLayout searchIcon = (LinearLayout) mView
				.findViewById(R.id.search_ic_container);
		searchIcon.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				mKeyPressSearchResultShowing = false;
				UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
				if (TextUtils.isEmpty(mEditTextSearch.getText().toString()
						.trim())) {
					mErrorTitle = getResources().getString(R.string.app_name);
					mDialogMessage = getResources().getString(
							R.string.dialog_msg_enter_search_text);
					showDialog(DialogConfig.DIALOG_ERROR);
					return;
				} else if (mEditTextSearch.getText().toString().trim().length() > 40) {
					mErrorTitle = getResources().getString(R.string.app_name);
					mDialogMessage = getResources().getString(
							R.string.dialog_msg_search_text_limit);
					showDialog(DialogConfig.DIALOG_ERROR);
					return;
				}
				updateOffersFavoriteFlags();
			}
		});

		final RelativeLayout rootView = (RelativeLayout) mView
				.findViewById(R.id.root_view_pulldown_list);
		rootView.setOnTouchListener(mOnTouchListenerScreen);

		mListView = (RefreshableListView) mView.findViewById(android.R.id.list);
		mTextViewTapToRefresh = (TextView) mView
				.findViewById(R.id.TextView_tap_to_refresh);
		mTextViewTapToRefresh.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				refreshOffers();
			}
		});

		final ImageButton imageButtonLocation = (ImageButton) mView
				.findViewById(R.id.imageButton_location);
		imageButtonLocation.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// Open the Locatin settings screen.
				// get the last offers proximity radius so that when control
				// comes
				// from Location Settings screen we can check for the radius
				// changes.
				mRadius = PreferenceConfig
						.getOffersProximityRadius(getActivity());
				if (mRadius == -1) {
					mRadius = BusinessLogicConfig.DEFAULT_OFFER_PROXIMITY_RADIUS;
				}
				mIsComingFromLocationSettingsScreen = true;
				startActivityForResult(new Intent(getActivity(),
						LocationSettingsAcitivity.class),
						CommonConfig.REQUEST_CODE_FOR_LOCATION_SETTINGS);
			}
		});
	}
	
	/** Make server request to get the Offers based on location mode. */
	private void callOffersListWS(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "callOffersListWS(): downloadMode = "
				+ downloadMode);
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			ProgressBarHelper.dismissProgressBar(mHandler);
			prepareOffersListCursor();
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			// must reset refreshing, if requested or not.
			mIsRefreshing = false;
			return;
		}

		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}

		// Set download mode again as this methods calls independently.
		mDownloadMode = downloadMode;

		Bundle params = new Bundle();
		params.putByte(OffersWorker.DOWNLOAD_MODE, downloadMode);
		params.putByte(OffersWorker.OFFERS_TYPE, getOffersType());
		mRequestManager.addOnRequestFinishedListener(OffersFragment.this);
		mRequestType = REQUEST_TYPE.FETCH_OFFERS;
		mRequestId = mRequestManager.getOfferList(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(OffersFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE, -1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mDialogMessage = getResources().getString(
								R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mDialogMessage = getResources().getString(
								R.string.toast_server_connection_error);
					} else {
						mDialogMessage = getResources().getString(
								R.string.toast_response_error);
					}
				} else {
					mDialogMessage = getResources().getString(
							R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}

	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle
					.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.FETCH_OFFERS) {
					offersDownloadedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.INITIAL_SYNC_FAVORITE_OFFERS) {
					favoriteOfferIdsDownloadedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.GET_APP_CONFIG) {
					appConfigurationDownloadedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.GET_SESSION_ID) {
					sessionIdFetchedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.GET_OFFER_COUNT) {
					offerCountDownloadedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.CHECK_APP_UPDATE) {
					appUpdateCheckedDoSomething();
				}
			} else if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				mDialogMessage = mResponseBundle
						.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mDialogMessage)
						&& (mRequestType != REQUEST_TYPE.GET_APP_CONFIG)
						&& (mRequestType != REQUEST_TYPE.GET_OFFER_COUNT)) {
					mErrorTitle = getResources().getString(
							R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
				// must reset refreshing, if requested or not.
				mIsRefreshing = false;

				if (mRequestType == REQUEST_TYPE.GET_APP_CONFIG) {
					if (!ProgressBarHelper.isProgressBarRunning()) {
						ProgressBarHelper.showProgressBarSmall(
								R.string.progress_bar_please_wait, false,
								mHandler, getSherlockActivity());
					}
					if (PreferenceConfig.isValidUser(getActivity())) {
						// get offer count from server.
						fetchOfferCounts(PreferenceConfig
								.getDownloadMode(getActivity()));
					} else {
						fetchOffers(PreferenceConfig
								.getDownloadMode(getActivity()));
					}
				} else {
					ProgressBarHelper.dismissProgressBar(mHandler);
					prepareOffersListCursor();
					// must reset refreshing, if requested or not.
					mIsRefreshing = false;
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
				prepareOffersListCursor();
				// must reset refreshing, if requested or not.
				mIsRefreshing = false;
			}
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			getListView().setVisibility(View.INVISIBLE);
			// must reset refreshing, if requested or not.
			mIsRefreshing = false;
			prepareOffersListCursor();
			if (!TextUtils.isEmpty(mDialogMessage)
					&& (mRequestType != REQUEST_TYPE.GET_APP_CONFIG)
					&& (mRequestType != REQUEST_TYPE.GET_OFFER_COUNT)) {
				mErrorTitle = getResources().getString(
						R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
			if (mRequestType == REQUEST_TYPE.GET_APP_CONFIG) {
				if (!ProgressBarHelper.isProgressBarRunning()) {
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, false, mHandler,
							getSherlockActivity());
				}
				if (PreferenceConfig.isValidUser(getActivity())) {
					// get offer count from server.
					fetchOfferCounts(PreferenceConfig
							.getDownloadMode(getActivity()));
				} else {
					fetchOffers(PreferenceConfig.getDownloadMode(getActivity()));
				}
			} else if (mRequestType == REQUEST_TYPE.GET_SESSION_ID) {
				if (!ProgressBarHelper.isProgressBarRunning()) {
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, false, mHandler,
							getSherlockActivity());
				}
				if (PreferenceConfig.isAppConfigDownloaded(getActivity())
						&& !PreferenceConfig.isAppConfigExpired(getActivity())) {
					if (PreferenceConfig.isValidUser(getActivity())) {
						// get offer count from server.
						fetchOfferCounts(PreferenceConfig
								.getDownloadMode(getActivity()));
					} else {
						fetchOffers(PreferenceConfig
								.getDownloadMode(getActivity()));
					}
				} else {
					callGetAppConfigWS();
				}
			} else if (mRequestType == REQUEST_TYPE.GET_OFFER_COUNT) {
				fetchOffers(PreferenceConfig.getDownloadMode(getActivity()));
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};

	/**
	 * Method to initiate offers fetching process. First it checks for the
	 * location access permission. If permitted then go for the offer fetch flow
	 * or else it will show the location permission dialog.
	 */
	private void fetchOffers(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "fetchOffers()");
		if (downloadMode == DownloadMode.MODE_GPS) {
			if (isLocationAccessPermitted()) {
				checkBusinessLogicToDownloadOffers();
			} else if (PreferenceConfig
					.canShowGpsAccessPermissionDialog(getActivity())) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				// Show location access permission dialog.
				showDialog(DialogConfig.DIALOG_LOCATION_ACCESS_PERMISSION);
				// set the flag false, so to avoid asking gps access allow
				// permission everytime.
				// This will be reset again when gps button is clicked from
				// location
				// setting screen by user.
				PreferenceConfig.setGpsAccessPermissionDialogStatus(false,
						getActivity());
			} else {
				byte mode = PreferenceConfig.getDownloadMode(getActivity());
				if (mode == DownloadMode.MODE_GPS) {
					fetchZipcodeBasedOffers(DownloadMode.MODE_HOME_ZIPCODE);
				} else {
					fetchZipcodeBasedOffers(mode);
				}
			}
		} else {
			fetchZipcodeBasedOffers(downloadMode);
		}
	}

	/**
	 * Method to check GPS access permission. If permitted then it checks the
	 * location expiration. In case of expired location fresh location
	 * requested. Afterwards Offers download check initiated. <b>Note:</b> Call
	 * this method only if app has the location access permission.
	 */
	private void checkBusinessLogicToDownloadOffers() {
		LogConfig.logv(LOG_TAG, "checkBusinessLogicToDownloadOffers()");
		if (!isLocationDataExpired()) {
			// Location is valid.
			LogConfig.logd(LOG_TAG,
					"checkBusinessLogicToDownloadOffers(): Location is valid");
			boolean isOfferExpired = true;
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				isOfferExpired = PreferenceConfig
						.isOffersTimestampExpired(getActivity());
			} else {
				isOfferExpired = PreferenceConfig
						.isPersonalOffersTimestampExpired(getActivity());
			}
			if (isOfferExpired || mIsRefreshing) {
				downloadOffers(DownloadMode.MODE_GPS);
			} else {
				LogConfig
						.logv(LOG_TAG,
								"checkBusinessLogicToDownloadOffers(): offers not expired: Query offers");
				prepareOffersListCursor();
			}
		} else { // Location expired
			LogConfig.logd(LOG_TAG,
					"checkBusinessLogicToDownloadOffers(): Location is expire");
			// Check if network available
			if (!NetworkHelper.isNetworkAvailable(getActivity())) {
				mIsNoNetworkCaseOccurs = true;
				ProgressBarHelper.dismissProgressBar(mHandler);
				prepareOffersListCursor();
				mDialogMessage = getResources().getString(
						R.string.network_not_available_msg);
				mErrorTitle = getResources().getString(
						R.string.network_not_available_title);
				showDialog(DialogConfig.DIALOG_ERROR);
				// must reset refreshing, if requested or not.
				mIsRefreshing = false;
				return;
			}
			if (GeoUtils.isGpsLocationProviderEnabled(getActivity())) {
				
//				if (!ProgressBarHelper.isProgressBarRunning()) {
//					ProgressBarHelper.showProgressBarSmall(
//							R.string.progress_bar_message_getting_current_location, false, mHandler,
//							getSherlockActivity());
//				}
				
				if (ProgressBarHelper.isProgressBarRunning()) {
					ProgressBarHelper
							.setProgressMessage(
									R.string.progress_bar_message_getting_current_location,
									getActivity());
					ProgressBarHelper
							.setProgressOnCancelListener(mCancelListener);
					ProgressBarHelper.setCancelable(true);
				} else {
					ProgressBarHelper
							.showProgressBarCancellable(
									R.string.progress_bar_message_getting_current_location,
									getSherlockActivity(), mHandler,
									mCancelListener);
				}
				requestLocationUpdate();
			} else { // Location provider is OFF
				LogConfig
						.logd(LOG_TAG,
								"checkBusinessLogicToDownloadOffers(): Location provider is OFF");
				ProgressBarHelper.dismissProgressBar(mHandler);
				showDialog(DialogConfig.DIALOG_GPS_SETTINGS);
			}
		}
	}

	/** Method to check if location access is permitted or not. */
	private boolean isLocationAccessPermitted() {
		return mLocationHandler.getGpsLocationPermissionStatus(getActivity());
	}

	/** Method to check if the last location data timestamp is expired or not. */
	private boolean isLocationDataExpired() {
		return mLocationHandler.isLocationTimestampExpired(getActivity());
	}

	/**
	 * Method to download offers based on the timestamp expiration. It does
	 * requery the offers if timestamp is not expired.
	 */
	private void downloadOffers(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "downloadOffers(): downloadMode = "
				+ downloadMode);
		if (!mIsRefreshing) {
			boolean isOffersExpired = true;
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				isOffersExpired = PreferenceConfig
						.isOffersTimestampExpired(getActivity());
			} else {
				isOffersExpired = PreferenceConfig
						.isPersonalOffersTimestampExpired(getActivity());
			}
			if (isOffersExpired) {
				LogConfig.logv(LOG_TAG,
						"downloadOffers(): offers timestamp expired");
				callOffersListWS(downloadMode);
			} else {
				LogConfig.logv(LOG_TAG,
						"downloadOffers(): offers not expired: Query offers");
				prepareOffersListCursor();
			}
		} else {
			LogConfig.logv(LOG_TAG, "downloadOffers(): REFRESH");
			callOffersListWS(downloadMode);
		}
	}

	/** Method to call after successful download of offers list from server. */
	public void offersDownloadedDoSomething() {
		LogConfig.logv(LOG_TAG, "offersDownloadedDoSomething()");
		mResponseMessageOffers = mResponseBundle
				.getString(CommonConfig.KEY_NAME_RESULTS_MESSAGE);
		if (PreferenceConfig.isValidUser(getActivity())) {
			performInitialFavoriteSync(mDownloadMode);
		} else {
			// must reset refreshing, if requested or not.
			mIsRefreshing = false;

			// Set the current download mode for successful download of offers
			// based on current
			// download mode.
			PreferenceConfig.setDownloadMode(mDownloadMode, getActivity());

			// populate the offer list.
			populateViews();
		}
	}

	/**
	 * Method to call after successful download of favorite offers id list from
	 * server.
	 */
	public void favoriteOfferIdsDownloadedDoSomething() {
		LogConfig.logv(LOG_TAG, "favoriteOfferIdsDownloadedDoSomething()");
		mResponseBundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE,
				mResponseMessageOffers);
		// must reset refreshing, if requested or not.
		mIsRefreshing = false;

		// Set the current download mode for successful download of offers based
		// on current
		// download mode.
		PreferenceConfig.setDownloadMode(mDownloadMode, getActivity());
		// update offer count
		// callGetOfferCountWS(mDownloadMode);
		// populate the offer list.
		populateViews();
	}

	/** Method to populate the view on the screen. */
	private void populateViews() {
		LogConfig.logv(LOG_TAG, "populateViews()");
		prepareOffersListCursor();
	}

	/** Prepare offers list cursor by db query. */
	private void prepareOffersListCursor() {
		LogConfig.logv(LOG_TAG, "prepareOffersListCursor()");
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST);
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST);
			getLoaderManager().initLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST, null, this);
		} else {
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST);
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST);
			getLoaderManager().initLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST, null, this);
		}
	}

	/**
	 * A custom {@link CursorAdapter} class to render the product list.
	 * 
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 * 
	 */
	private class SectionAdapter extends SectionCursorAdapter {

		private Activity mActivity;
		private int mPosition;
		private int mSelectedPosition = -1;
		private int mImageWidth;
		private int mImageHeight;

		/** Parameterized constructor. */
		public SectionAdapter(Context context, Cursor c, int headerLayout,
				int groupColumn) {
			super(context, c, headerLayout, groupColumn);
			mActivity = (Activity) context;
			mBitmapManager.setPlaceholder(BitmapFactory.decodeResource(
					context.getResources(), R.drawable.background_trans));
			mImageWidth = context.getResources().getInteger(
					R.integer.image_width);
			mImageHeight = context.getResources().getInteger(
					R.integer.image_height);
		}

		/** {@inheritDoc} */
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			mPosition = position;
			final Cursor c = (Cursor) getItem(position);
			final int cursorPos = getSectionForPosition(position);
			c.moveToPosition(cursorPos);
			final int isMarketingMessage = c
					.getInt(CouponDao.CONTENT_IS_MARKETING_MESSAGE_COLUMN);
			if (isMarketingMessage == CouponDao.FLAG_VALUE_MARKETING_MESSAGE) {
				PromoOfferListViewHolder viewHolder = null;
				if ((convertView == null)
						|| !(convertView.getTag() instanceof PromoOfferListViewHolder)) {
					convertView = mActivity.getLayoutInflater().inflate(
							R.layout.row_for_promo_offers, null);
					viewHolder = new PromoOfferListViewHolder(convertView);
					convertView.setTag(viewHolder);
				}
			} else {
				boolean listType = PreferenceConfig.getOfferListTypeEnabled(getActivity());
				if(!listType){
				OfferListViewHolder viewHolder = null;
				if ((convertView == null)
						|| !(convertView.getTag() instanceof OfferListViewHolder)) {
					convertView = mActivity.getLayoutInflater().inflate(
							R.layout.row_for_offers, null);
					viewHolder = new OfferListViewHolder(convertView);
					convertView.setTag(viewHolder);
				}
			}
				else{
					OfferListViewHolder viewHolder = null;
					if ((convertView == null)
							|| !(convertView.getTag() instanceof OfferListViewHolder)) {
						convertView = mActivity.getLayoutInflater().inflate(
								R.layout.row_for_offers_custom, null);
						viewHolder = new OfferListViewHolder(convertView);
						convertView.setTag(viewHolder);
					}
				}
			}
			return super.getView(position, convertView, parent);
		}

		/** {@inheritDoc} */
		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {
			return null;
		}

		/** {@inheritDoc} */
		@Override
		public void bindView(final View view, Context context, Cursor cursor) {
			if (view != null) {
				final Cursor c = cursor;
				final int mapCursorPos = getSectionForPosition(mPosition);
				c.moveToPosition(mapCursorPos);
				final int offerId = c
						.getInt(CouponDao.CONTENT_COUPON_ID_COLUMN);
				final int couponChooser = c
						.getInt(CouponDao.CONTENT_COUPON_CHOOSER_COLUMN);
				final String offerTitle = c
						.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN);
				final String couponImageUrl = c
						.getString(CouponDao.CONTENT_COUPON_IMAGE_URL_COLUMN);

				final BaseViewHolder holder = (BaseViewHolder) view.getTag();
				holder.setRowPosition(mPosition, mSelectedPosition);
				holder.populateView(c, view);
//				if (mFavStatusArray.get(offerId) != null) {
//					holder.getFavoriteIconView().setBackgroundResource(
//							R.drawable.ic_star_selected);
//				} else {
//					holder.getFavoriteIconView().setBackgroundResource(
//							R.drawable.ic_star_deselected);
//				}
				if (holder.getOfferIconView() != null) {
					mBitmapManager.loadBitmap(couponImageUrl,
							holder.getOfferIconView(), mImageWidth,
							mImageHeight);
				}
	/*			holder.getFavoriteIconView().setOnClickListener(
						new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								if (!PreferenceConfig
										.isValidUser(getActivity())) {
									// pre-condition
									showDialog(DialogConfig.DIALOG_SIGN_UP);
									return;
								}
								if (mFavStatusArray.get(offerId) == null) {
									LogConfig.logd(LOG_TAG,
											"onFavouriteIconClicked(): Set FAV, offerId = "
													+ offerId
													+ ", mPosition = "
													+ mPosition);
									v.setBackgroundResource(R.drawable.ic_star_selected);
									PreferenceConfig.setFavoriteOfferCount(
											PreferenceConfig
													.getFavoriteOfferCount(getActivity()) + 1,
											getActivity());
									final FavoriteData favoriteData = new FavoriteData();
									if (mFavDeletedArray.get(offerId) != null) {
										mFavDeletedArray.delete(offerId);
										favoriteData.mFavoriteType = FavoriteData.FAVORITE_FROM_DATABASE;
									} else {
										favoriteData.mFavoriteType = FavoriteData.FAVORITE_MANUALLY;
									}
									favoriteData.mOfferId = offerId;
									favoriteData.mCouponChooser = couponChooser;
									mFavStatusArray.put(offerId, favoriteData);
									AnalyticsHelper
											.sendFavoriteStarClickedAnalytics(
													getActivity(), offerTitle,
													true);
								} else {
									LogConfig.logd(LOG_TAG,
											"onFavouriteIconClicked(): Set UN-FAV, 	storeId = "
													+ offerId
													+ ", mPosition = "
													+ mPosition);

									v.setBackgroundResource(R.drawable.ic_star_deselected);
									PreferenceConfig.setFavoriteOfferCount(
											PreferenceConfig
													.getFavoriteOfferCount(getActivity()) - 1,
											getActivity());
									if (mFavStatusArray.get(offerId).mFavoriteType == FavoriteData.FAVORITE_FROM_DATABASE) {
										mFavDeletedArray.put(offerId,
												mFavStatusArray.get(offerId));
									}
									mFavStatusArray.delete(offerId);
									AnalyticsHelper
											.sendFavoriteStarClickedAnalytics(
													getActivity(), offerTitle,
													false);
								}
							}
						});*/
			}
		}

		/** {@inheritDoc} */
		public String getGroupCustomFormat(Object obj) {
			return (String) obj;
		}

		/** Setter method to set the current selected position in list. */
		public void setSelectedPosition(final int inPosition) {
			mSelectedPosition = inPosition;
		}
	}

	/**
	 * Get the section group column name for list, the groups will be created
	 * based on this column name.
	 */
	private int getSectionGroupColumn() {
		return mSectionGroupColumn;
	}

	/**
	 * A view holder class that extends {@link BaseViewHolder} which holds the
	 * view of {@link Coupon} list row layout for Online and Instore coupons.
	 * 
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 * 
	 */
	private static class OfferListViewHolder extends ViewHolderOfferList {
		public OfferListViewHolder(View view) {
			super(view);
		}
	}

	/**
	 * A view holder class that extends {@link BaseViewHolder} which holds the
	 * view of {@link Coupon} list row layout for Promotioal type coupons.
	 * 
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 * 
	 */
	private static class PromoOfferListViewHolder extends
			ViewHolderPromoOfferList {
		public PromoOfferListViewHolder(View view) {
			super(view);
		}
	}

	@Override
	public void onListItemClick(ListView l, final View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		int itemPosition = position - getListView().getHeaderViewsCount();
		LogConfig.logv(LOG_TAG, "position = " + itemPosition);
		final Object obj = mSectionAdapter.getItem(itemPosition);
		if (obj instanceof Cursor) { // Normal row is clicked.
			final Cursor c = (Cursor) obj;
			if (c != null && c.getCount() > 0) {
				mSectionAdapter.setSelectedPosition(itemPosition);
				mSectionAdapter.notifyDataSetChanged();
				mIsComingFromOfferDetailsScreen = true;
				AnalyticsHelper.sendOfferClickedAnalytics(getActivity(),
						c.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN));
				final Intent intent = new Intent(getActivity(),
						OfferDetailActivity.class);
				intent.putExtra(OfferDetailIntentKey.CURRENTLY_SELECTED_ITEM,
						itemPosition);
				intent.putExtra(OfferDetailIntentKey.OFFER_COUNT, c.getCount());
				startActivity(intent);
			}
		}
	}

	@Override
	public Loader<Cursor> onCreateLoader(int token, Bundle bundle) {
		int couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON; // default.
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
		} else {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
		}
		if (token == DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST
				|| token == DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST) {
			String selection = "";
			String categoryId = PreferenceConfig
					.getCategoryFilterId(getActivity());
			if (TextUtils.isEmpty(categoryId)) {
				return new CursorLoader(getActivity(), CouponDao.CONTENT_URI,
						null, CouponDao.WHERE_CLAUSE_COUPON_CHOOSER
								+ couponChooser, null, null);
			} else {
				categoryId = categoryId.replace("[", "").replace("]", "");
				if (categoryId.contains(UIApplication.NEW_CATEGORY_ID)) {
					// If all category filter is selected then also show
					// marketing messages
					// that don't have the category associated, or else hide
					// them.
					if (PreferenceConfig
							.getAllCategoryFiltersSelected(getActivity())) {
						selection = "SELECT * FROM TBL_COUPON WHERE "
								+ CouponDao.COUPON_CHOOSER + " = "
								+ couponChooser + " AND ("
								+ CouponDao.IS_NEW_COUPON + " = "
								+ CouponDao.FLAG_VALUE_NEW_COUPON + " OR "
								+ CouponDao.COUPON_ID + " IN (SELECT "
								+ CategoryCountDao.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT WHERE "
								+ CategoryCountDao.OFFER_TYPE + " = "
								+ couponChooser + " AND ("
								+ CategoryCountDao.CATEGORY_ID + " IN ("
								+ categoryId + ") OR "
								+ CategoryCountDao.CATEGORY_ID + "='"
								+ UIApplication.PROMO_CATEGORY_ID + "')))"
								+ " order by " + CouponDao._ID;
					} else {
						selection = "SELECT * FROM TBL_COUPON WHERE "
								+ CouponDao.COUPON_CHOOSER + " = "
								+ couponChooser + " AND ("
								+ CouponDao.IS_NEW_COUPON + " = "
								+ CouponDao.FLAG_VALUE_NEW_COUPON + " OR "
								+ CouponDao.COUPON_ID + " IN (SELECT "
								+ CategoryCountDao.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT WHERE "
								+ CategoryCountDao.OFFER_TYPE + " = "
								+ couponChooser + " AND "
								+ CategoryCountDao.CATEGORY_ID + " IN ("
								+ categoryId + ")))" + " order by "
								+ CouponDao._ID;
					}
				} else {
					// If all category filter is selected then also show
					// marketing messages
					// that don't have the category associated, or else hide
					// them.
					if (PreferenceConfig
							.getAllCategoryFiltersSelected(getActivity())) {
						selection = "SELECT * FROM TBL_COUPON WHERE "
								+ CouponDao.COUPON_CHOOSER + " = "
								+ couponChooser + " AND " + CouponDao.COUPON_ID
								+ " IN (SELECT " + CategoryCountDao.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT WHERE "
								+ CategoryCountDao.OFFER_TYPE + " = "
								+ couponChooser + " AND ("
								+ CategoryCountDao.CATEGORY_ID + " IN ("
								+ categoryId + ") OR "
								+ CategoryCountDao.CATEGORY_ID + "='"
								+ UIApplication.PROMO_CATEGORY_ID + "'))"
								+ " ORDER BY " + CouponDao._ID;
					} else {
						selection = "SELECT * FROM TBL_COUPON WHERE "
								+ CouponDao.COUPON_CHOOSER + " = "
								+ couponChooser + " AND " + CouponDao.COUPON_ID
								+ " IN (SELECT " + CategoryCountDao.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT WHERE "
								+ CategoryCountDao.OFFER_TYPE + " = "
								+ couponChooser + " AND "
								+ CategoryCountDao.CATEGORY_ID + " IN ("
								+ categoryId + "))" + " ORDER BY "
								+ CouponDao._ID;
					}
				}
				return new CursorLoader(getActivity(),
						CouponDao.CONTENT_URI_FILTER_COUPON, null, selection,
						null, null);
			}
		} else if (token == DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST
				|| token == DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST) {
			String categoryId = PreferenceConfig
					.getCategoryFilterId(getActivity());
			String searchText = mEditTextSearch.getText().toString().trim();
			searchText = searchText.replace("'", "''").replace("\"", "''");
			if (TextUtils.isEmpty(categoryId)) {
				return new CursorLoader(getActivity(), CouponDao.CONTENT_URI,
						null, "(" + CouponDao.COUPON_NAME + " LIKE '%"
								+ searchText + "%' OR " + CouponDao.COUPON_TYPE
								+ " LIKE '%" + searchText + "%' OR "
								+ CouponDao.COUPON_DESCRIPTION + " LIKE '%"
								+ searchText + "%') AND "
								+ CouponDao.WHERE_CLAUSE_COUPON_CHOOSER
								+ couponChooser, null, null);
			} else {
				categoryId = categoryId.replace("[", "").replace("]", "");
				String selection = "SELECT * FROM TBL_COUPON WHERE "
						+ CouponDao.COUPON_CHOOSER + " = " + couponChooser
						+ " AND (" + CouponDao.COUPON_NAME + " LIKE '%"
						+ searchText + "%' OR " + CouponDao.COUPON_TYPE
						+ " LIKE '%" + searchText + "%' OR "
						+ CouponDao.COUPON_DESCRIPTION + " LIKE '%"
						+ searchText + "%') AND " + CouponDao.COUPON_ID
						+ " IN (SELECT " + CategoryCountDao.OFFER_ID
						+ " FROM TBL_CATEGORY_COUNT WHERE "
						+ CategoryCountDao.OFFER_TYPE + " = " + couponChooser
						+ " AND (" + CategoryCountDao.CATEGORY_ID + " IN ("
						+ categoryId + ") OR " + CategoryCountDao.CATEGORY_ID
						+ "=" + UIApplication.PROMO_CATEGORY_ID + "))"
						+ " ORDER BY " + CouponDao._ID;
				return new CursorLoader(getActivity(),
						CouponDao.CONTENT_URI_FILTER_COUPON, null, selection,
						null, null);
			}
		}

		return null;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		final int token = loader.getId();
		LogConfig.logd(LOG_TAG, "onloadFinished()");
		if (token == DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST
				|| token == DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST) {
			if (cursor != null) {
				LogConfig.logd(LOG_TAG, "count is " + cursor.getCount());
			}
			populateFavoriteStatusArray(cursor);
			prepareOfferModelArray(cursor);
			mSectionAdapter.swapCursor(cursor);
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					getListView().setSelectionAfterHeaderView();
					// handling of single and multiple coupon notification.
					if (PreferenceConfig
							.getIsLaunchFromNotification(getActivity())) {
						LogConfig.logd(LOG_TAG,
								"onloadFinished(): Came from Notification");
						UIApplication uiApplication = (UIApplication) getActivity()
								.getApplication();
						// if there is single coupon notification then launch
						// Offer Detail Screen.
						if (uiApplication.getNoficationCouponIdList().size() == 1) {
							LogConfig.logd(LOG_TAG,
									"onloadFinished(): Show Offer detail");
							startOfferDetailScreen();
						} else {
							LogConfig
									.logd(LOG_TAG,
											"onloadFinished(): No offer id in notification");
						}
					} else {
						LogConfig.logd(LOG_TAG,
								"onloadFinished(): Not from notification");
					}
				} else if (cursor.getCount() <= 0 && !mIsNoNetworkCaseOccurs) {
					mHandler.post(new Runnable() {

						@Override
						public void run() {
							if (mResponseBundle != null) {
								mDialogMessage = mResponseBundle
										.getString(CommonConfig.KEY_NAME_RESULTS_MESSAGE);
								LogConfig.logv(LOG_TAG,
										"onloadFinished(): mDialogMessage = "
												+ mDialogMessage);
								if (!TextUtils.isEmpty(mDialogMessage)) {
									mErrorTitle = getResources().getString(
											R.string.app_name);
									showDialog(DialogConfig.DIALOG_ERROR);
								}
							}
							int totalOfferCount;
							if (getOffersType() == OffersType.COMMON_OFFERS) {
								totalOfferCount = PreferenceConfig
										.getCommonOfferCount(getActivity());
							} else {
								totalOfferCount = PreferenceConfig
										.getPersonalOfferCount(getActivity());
							}
							if (totalOfferCount > 0) {
								showDialog(DialogConfig.DIALOG_SELECT_ATLEAST_ONE_CATEGORY);
							}
						}
					});
				}
				if (PreferenceConfig.getIsLaunchFromNotification(getActivity())) {
					PreferenceConfig.setIsLaunchFromNotification(false,
							getActivity());
				}
				mIsNoNetworkCaseOccurs = false;
				// Show tap to refresh option instead of list if no data.
				if (mTextViewTapToRefresh != null) {
					if (cursor.getCount() <= 0) {
						mTextViewTapToRefresh.setVisibility(View.VISIBLE);
					} else {
						mTextViewTapToRefresh.setVisibility(View.GONE);
					}
				}
				mSectionAdapter.setSelectedPosition(-1);
			} else {
				// Show tap to refresh option instead of list if no data.
				if (mTextViewTapToRefresh != null) {
					mTextViewTapToRefresh.setVisibility(View.VISIBLE);
				}
			}
			getListView().setVisibility(View.VISIBLE);
		} else if (token == DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST
				|| token == DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST) {
			if (cursor != null) {
				LogConfig.logd(LOG_TAG, "count is " + cursor.getCount());
				if (cursor.getCount() <= 0 && !mKeyPressSearchResultShowing) {
					mHandler.post(new Runnable() {

						@Override
						public void run() {
							mErrorTitle = getResources().getString(
									R.string.app_name);
							mDialogMessage = getResources().getString(
									R.string.msg_no_result_found);
							showDialog(DialogConfig.DIALOG_ERROR);
						}
					});
				}
				mSectionAdapter.setSelectedPosition(-1);
			}
			populateFavoriteStatusArray(cursor);
			prepareOfferModelArray(cursor);
			mSectionAdapter.swapCursor(cursor);
			if (cursor != null && cursor.getCount() > 0) {
				getListView().setSelectionAfterHeaderView();
			}
			getListView().setVisibility(View.VISIBLE);
			ProgressBarHelper.dismissProgressBar(mHandler);
			// set if search result is showing.
			mSearchResultShowing = true;
		}

		// Call to notify that list is refreshed via list pull down event.
		listRefreshed();
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		// This is called when the last Cursor provided to onLoadFinished()
		// above is about to be closed. We need to make sure we are no
		// longer using it.
		mSectionAdapter.swapCursor(null);
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new DialogInterface.OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_LOCATION_ACCESS_PERMISSION:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(
							R.string.dialog_location_access_permission_message)
					.setCancelable(false)
					.setPositiveButton(R.string.btn_allow,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									mLocationHandler
											.setGpsLocationPermissionStatus(
													getActivity(), true);
									checkBusinessLogicToDownloadOffers();
								}
							})
					.setNegativeButton(R.string.btn_dont_allow,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									if (!mIsOffersProximityRadiusChanged) {
										mIsRefreshing = false;
									} else {
										mIsOffersProximityRadiusChanged = false;
									}
									byte downloadMode = PreferenceConfig
											.getDownloadMode(getActivity());
									if (downloadMode == DownloadMode.MODE_GPS) {
										fetchZipcodeBasedOffers(DownloadMode.MODE_HOME_ZIPCODE);
									} else {
										fetchZipcodeBasedOffers(downloadMode);
									}
								}
							});
			break;

		case DialogConfig.DIALOG_GPS_SETTINGS:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(R.string.gps_setting_msg)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									mIsFromSettingScreen = true;
									startActivity(new Intent(
											android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
								}
							})
					.setNegativeButton(android.R.string.cancel,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									mIsRefreshing = false;
									byte downloadMode = PreferenceConfig
											.getDownloadMode(getActivity());
									if (downloadMode == DownloadMode.MODE_GPS) {
										fetchZipcodeBasedOffers(DownloadMode.MODE_HOME_ZIPCODE);
									} else {
										fetchZipcodeBasedOffers(downloadMode);
									}
								}
							});
			break;

		case DialogConfig.DIALOG_BEST_LOCATION_PROVIDER_NOT_AVAILABLE:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(R.string.toast_no_location_provider_found)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									mIsRefreshing = false;
									byte downloadMode = PreferenceConfig
											.getDownloadMode(getActivity());
									if (downloadMode == DownloadMode.MODE_GPS) {
										fetchZipcodeBasedOffers(DownloadMode.MODE_HOME_ZIPCODE);
									} else {
										fetchZipcodeBasedOffers(downloadMode);
									}
								}
							});
			break;

		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(mErrorTitle)
					.setMessage(mDialogMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;

		case DialogConfig.DIALOG_NO_LOCATION_FOUND:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.title_sorry)
					.setMessage(R.string.dialog_no_location_found)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									mIsRefreshing = false;
									byte downloadMode = PreferenceConfig
											.getDownloadMode(getActivity());
									if (downloadMode == DownloadMode.MODE_GPS) {
										fetchZipcodeBasedOffers(DownloadMode.MODE_HOME_ZIPCODE);
									} else {
										fetchZipcodeBasedOffers(downloadMode);
									}
								}
							});
			break;

		case DialogConfig.DIALOG_SIGN_UP:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setCancelable(false);
			if (UIUtils.getRetailId(getActivity()) == CommonConfig.RETAILTYPE_ROBINSON) {
				dlg.setMessage(R.string.dialog_signup_user_message)
				.setNegativeButton(R.string.label_sign_up,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
								getActivity().startActivity(
										new Intent(getActivity(),
												EnterEmailActivity.class));
							}
						})
				.setPositiveButton(android.R.string.cancel,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
							}
						});
			}else{
				dlg.setMessage(R.string.dialog_signup_user_message_preferences).
				setPositiveButton(R.string.label_sign_up,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
								getActivity().startActivity(
										new Intent(getActivity(),
												EnterEmailActivity.class));

							}
						})
				.setNegativeButton(android.R.string.cancel,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();

							}
						});
			}
			
					
			break;

		case DialogConfig.DIALOG_UPGRADE_APP:
			final int positiveButtonRes;
			String updateType = PreferenceConfig
					.getAppUpdateType(getActivity());
			if (!TextUtils.isEmpty(updateType)
					&& updateType
							.equalsIgnoreCase(BusinessLogicConfig.APP_UPDATE_TYPE_OPTIONAL)) {
				positiveButtonRes = android.R.string.cancel;
				LogConfig.logd(LOG_TAG,
						"Its an optional update proceed to normal flow.");
				// Its an optional update proceed to normal flow.
				if (mIsRefreshing) {
					callGetAppConfigWS();
				} else {
					if (PreferenceConfig.isValidUser(getActivity())
							&& PreferenceConfig
									.isSessionIdExpired(getActivity())) {
						callGetSessionIdWS();
					} else {
						ProgressBarHelper.showProgressBarSmall(
								R.string.progress_bar_please_wait, false,
								mHandler, getSherlockActivity());
						if (PreferenceConfig
								.isAppConfigDownloaded(getActivity())
								&& !PreferenceConfig
										.isAppConfigExpired(getActivity())) {
							fetchOffers(PreferenceConfig
									.getDownloadMode(getActivity()));
						} else {
							callGetAppConfigWS();
						}
					}
				}
				return;
			} else {
				positiveButtonRes = R.string.label_exit;
			}
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(
							PreferenceConfig.getAppUpdateMessage(getActivity()))
					.setCancelable(false)
					.setNegativeButton(R.string.label_update,
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									Intent intent = new Intent(
											Intent.ACTION_VIEW,
											Uri.parse("market://details?id=com.manthansystems.loyalty"));
									startActivity(intent);
									getActivity().finish();
								}
							})
					.setPositiveButton(positiveButtonRes,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									if (positiveButtonRes == R.string.label_exit) {
										// Its an mandatory update so exit will
										// close the app.
										getActivity().finish();
									} else {
										// Its an optional update and user has
										// pressed cancel, proceed to normal
										// flow.
										if (mIsRefreshing) {
											callGetAppConfigWS();
										} else {
											if (PreferenceConfig
													.isValidUser(getActivity())
													&& PreferenceConfig
															.isSessionIdExpired(getActivity())) {
												callGetSessionIdWS();
											} else {
												ProgressBarHelper
														.showProgressBarSmall(
																R.string.progress_bar_please_wait,
																false,
																mHandler,
																getSherlockActivity());
												if (PreferenceConfig
														.isAppConfigDownloaded(getActivity())
														&& !PreferenceConfig
																.isAppConfigExpired(getActivity())) {
													fetchOffers(PreferenceConfig
															.getDownloadMode(getActivity()));
												} else {
													callGetAppConfigWS();
												}
											}
										}
									}
								}
							});
			break;

		case DialogConfig.DIALOG_SELECT_ATLEAST_ONE_CATEGORY:
			dlg.setIcon(R.drawable.icon)
					.setTitle(getResources().getString(R.string.app_name))
					.setMessage(
							getResources()
									.getString(
											R.string.label_select_at_least_one_category))
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
		mResponseMessageOffers = "";
		mDialogMessage = "";
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	public void onDestroy() {
		LogConfig.logv(LOG_TAG, "onDestroy");
		super.onDestroy();
		
		if (!mIsComingFromOfferDetailsScreen) {
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST);
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST);
			} else {
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST);
				getLoaderManager().destroyLoader(
						DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST);
			}

			// reset the search status once again, though it is also resetting
			// from
			// onLoadFinished() method of search result query completion.
			mSearchResultShowing = false;
			// set empty text at search text box
			mEditTextSearch.setText("");
		}
		removeLocationUpdate();

		
		if (mBitmapManager != null) {
			// Clear bitmap cache if user pressed refresh button
			mBitmapManager.clearCache();
		}
		// reset the app config flag so that on next app launch app config can
		// be
		// downloaded from server.
		PreferenceConfig.setAppConfigDownloadStatus(false, getActivity());
		if (mView != null) {
			UIUtils.unbindDrawables(mView
					.findViewById(R.id.root_view_pulldown_list));
			System.gc();
		}
	}

	/**
	 * A location update listener class which implements {@link Observer}, which
	 * listen for location updates.
	 * 
	 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
	 * 
	 */
	private class LocationUpdateListener implements Observer {

		@Override
		public void update(final Observable observable, final Object data) {
			removeLocationUpdate();
			
			
			if (data instanceof Location) {
				getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {
						locationUpdated((LocationHandler) observable,
								(Location) data);
					}
				});
			} else if (data instanceof String) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {			          
						Location location=LocationHandler.getSavedLocation(getActivity(), true);
						if (location == null || (location.getLongitude() == 0.0 && location.getLatitude() == 0.0)) {
							showDialog(DialogConfig.DIALOG_NO_LOCATION_FOUND);
						}else{
							locationUpdatedGPS(location);
						}
					}
				});

				// Show location status log for debugging.
				if (LogConfig.DDP_DEBUG_LOGS_ENABLED) {
					final String locationMessage = (String) data;
					if (locationMessage
							.equalsIgnoreCase(LocationHandler.LOCATION_RESULT_INVALID)) {
						LogConfig
								.logd(LOG_TAG + ": LocationUpdateListener",
										"  location update(): "
												+ LocationHandler.LOCATION_RESULT_INVALID);
					} else if (locationMessage
							.equalsIgnoreCase(LocationHandler.LOCATION_RESULT_TIMEOUT)) {
						LogConfig
								.logd(LOG_TAG + ": LocationUpdateListener",
										"  location update(): "
												+ LocationHandler.LOCATION_RESULT_TIMEOUT);
					}
				}
			}
		}
	}

	/** Invoked when location update found. */
	private void locationUpdatedGPS(
			Location inLocation) {
		LogConfig.logd(LOG_TAG, "  locationUpdated(): " + inLocation);		
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		} else {
			ProgressBarHelper.setCancelable(false);
			ProgressBarHelper.setProgressMessage(
					R.string.progress_bar_please_wait, getActivity());
			ProgressBarHelper.setProgressOnCancelListener(null);
		}
		// if refreshing is requested then go for direct offer download.
		if (mIsRefreshing) {
			LogConfig.logv(LOG_TAG, "  locationUpdated(): OFFER REFRESH");
			if (NetworkHelper.isNetworkAvailable(getActivity())) {
				downloadOffers(DownloadMode.MODE_GPS);
			} else {
				mIsNoNetworkCaseOccurs = true;
				ToastHelper.showToastMessage(
						getActivity().getResources().getString(
								R.string.toast_network_not_available)
								+ "...\n"
								+ getActivity().getResources().getString(
										R.string.toast_loading_cache_data),
						getActivity(), false);
				prepareOffersListCursor();
			}
			return;
		}

		// put business logic on the basis of location request owner.
		double[] newLocation = LocationHandler.getSavedLocation(true,
				getActivity());
		double[] oldLocation = LocationHandler.getSavedLocation(false,
				getActivity());

		String geoSignificantDistanceStr = PreferenceConfig
				.getGeoSignificantDistance(getActivity());
		float minDistance = TextUtils.isEmpty(geoSignificantDistanceStr) ? BusinessLogicConfig.GPS_SIGNIFICANT_DISTANCE_MILES_THRESHOLD
				: Integer.parseInt(geoSignificantDistanceStr); // in miles

		if (!GeoUtils.isLocationDistanceCriteriaIsValid(newLocation,
				oldLocation, minDistance)) {
			LogConfig.logv(LOG_TAG,
					"locationUpdated(): Location is 5 miles away");
			if (NetworkHelper.isNetworkAvailable(getActivity())) {
				mIsRefreshing = true;
				LogConfig.logv(LOG_TAG, "locationUpdated(): fetch offers gps");
				downloadOffers(DownloadMode.MODE_GPS);
			} else {
				mIsNoNetworkCaseOccurs = true;
				ToastHelper.showToastMessage(
						getActivity().getResources().getString(
								R.string.toast_network_not_available)
								+ "...\n"
								+ getActivity().getResources().getString(
										R.string.toast_loading_cache_data),
						getActivity(), false);
				LogConfig.logv(LOG_TAG, "locationUpdated(): query offers");
				prepareOffersListCursor();
			}
		} else {
			LogConfig.logv(LOG_TAG,
					"locationUpdated(): Location is under 5 miles");
			boolean isOffersExpired = true;
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				isOffersExpired = PreferenceConfig
						.isOffersTimestampExpired(getActivity());
			} else {
				isOffersExpired = PreferenceConfig
						.isPersonalOffersTimestampExpired(getActivity());
			}
			if (isOffersExpired) {
				LogConfig.logv(LOG_TAG, "locationUpdated(): fetch offers gps");
				downloadOffers(DownloadMode.MODE_GPS);
			} else {
				LogConfig.logv(LOG_TAG, "locationUpdated(): query offers");
				prepareOffersListCursor();
			}
		}
	}
	
	
	
	
	/** Invoked when location update found. */
	private void locationUpdated(LocationHandler inLocationHadler,
			Location inLocation) {
		LogConfig.logd(LOG_TAG, "  locationUpdated(): " + inLocation);		
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		} else {
			ProgressBarHelper.setCancelable(false);
			ProgressBarHelper.setProgressMessage(
					R.string.progress_bar_please_wait, getActivity());
			ProgressBarHelper.setProgressOnCancelListener(null);
		}
		// if refreshing is requested then go for direct offer download.
		if (mIsRefreshing) {
			LogConfig.logv(LOG_TAG, "  locationUpdated(): OFFER REFRESH");
			if (NetworkHelper.isNetworkAvailable(getActivity())) {
				downloadOffers(DownloadMode.MODE_GPS);
			} else {
				mIsNoNetworkCaseOccurs = true;
				ToastHelper.showToastMessage(
						getActivity().getResources().getString(
								R.string.toast_network_not_available)
								+ "...\n"
								+ getActivity().getResources().getString(
										R.string.toast_loading_cache_data),
						getActivity(), false);
				prepareOffersListCursor();
			}
			return;
		}

		// put business logic on the basis of location request owner.
		double[] newLocation = LocationHandler.getSavedLocation(true,
				getActivity());
		double[] oldLocation = LocationHandler.getSavedLocation(false,
				getActivity());

		String geoSignificantDistanceStr = PreferenceConfig
				.getGeoSignificantDistance(getActivity());
		float minDistance = TextUtils.isEmpty(geoSignificantDistanceStr) ? BusinessLogicConfig.GPS_SIGNIFICANT_DISTANCE_MILES_THRESHOLD
				: Integer.parseInt(geoSignificantDistanceStr); // in miles

		if (!GeoUtils.isLocationDistanceCriteriaIsValid(newLocation,
				oldLocation, minDistance)) {
			LogConfig.logv(LOG_TAG,
					"locationUpdated(): Location is 5 miles away");
			if (NetworkHelper.isNetworkAvailable(getActivity())) {
				mIsRefreshing = true;
				LogConfig.logv(LOG_TAG, "locationUpdated(): fetch offers gps");
				downloadOffers(DownloadMode.MODE_GPS);
			} else {
				mIsNoNetworkCaseOccurs = true;
				ToastHelper.showToastMessage(
						getActivity().getResources().getString(
								R.string.toast_network_not_available)
								+ "...\n"
								+ getActivity().getResources().getString(
										R.string.toast_loading_cache_data),
						getActivity(), false);
				LogConfig.logv(LOG_TAG, "locationUpdated(): query offers");
				prepareOffersListCursor();
			}
		} else {
			LogConfig.logv(LOG_TAG,
					"locationUpdated(): Location is under 5 miles");
			boolean isOffersExpired = true;
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				isOffersExpired = PreferenceConfig
						.isOffersTimestampExpired(getActivity());
			} else {
				isOffersExpired = PreferenceConfig
						.isPersonalOffersTimestampExpired(getActivity());
			}
			if (isOffersExpired) {
				LogConfig.logv(LOG_TAG, "locationUpdated(): fetch offers gps");
				downloadOffers(DownloadMode.MODE_GPS);
			} else {
				LogConfig.logv(LOG_TAG, "locationUpdated(): query offers");
				prepareOffersListCursor();
			}
		}
	}

	/** Request the location updates. */
	private void requestLocationUpdate() {
		LogConfig.logd(LOG_TAG, "requestLocationUpdate()");
		mLocationHandler.addObserver(mLocationUpdateListener);
		int providerStatus = mLocationHandler.register(getActivity()
				.getApplicationContext(), mLocationManager);
		if (providerStatus == LocationHandler.LOCATION_PROVIDER_DISABLED) {
			removeLocationUpdate();
			ProgressBarHelper.dismissProgressBar(mHandler);
			showDialog(DialogConfig.DIALOG_BEST_LOCATION_PROVIDER_NOT_AVAILABLE);
		}
	}

	/** Remove the location updates. */
	private void removeLocationUpdate() {
		LogConfig.logd(LOG_TAG, "removeLocationUpdate()");
		mLocationHandler.deleteObserver(mLocationUpdateListener);
		mLocationHandler.unregister(mLocationManager);
	}

	/**
	 * A {@link OnCancelListener} instance that will be called when location
	 * fetch progress bar is cancelled.
	 */
	private OnCancelListener mCancelListener = new OnCancelListener() {

		@Override
		public void onCancel(DialogInterface dialog) {
			LogConfig.logd(LOG_TAG, "Location ProgressBar : onCancel()");
			removeLocationUpdate();
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, false, mHandler,
							getSherlockActivity());
					fetchZipcodeBasedOffers(DownloadMode.MODE_HOME_ZIPCODE);
				}
			});
		}
	};

	/** Method to fetch the zipcode based offers from server. */
	public void fetchZipcodeBasedOffers(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "fetchZipcodeBasedOffers()");
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}
		boolean isOffersExpired = true;
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			isOffersExpired = PreferenceConfig
					.isOffersTimestampExpired(getActivity());
		} else {
			isOffersExpired = PreferenceConfig
					.isPersonalOffersTimestampExpired(getActivity());
		}
		if (isOffersExpired || mIsRefreshing) {
			downloadOffers(downloadMode);
		} else {
			LogConfig
					.logv(LOG_TAG,
							"fetchZipcodeBasedOffers(): offers not expired: Query offers");
			prepareOffersListCursor();
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode,
			final Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
		LogConfig.logv(LOG_TAG, "onActivityResult()");
		if (intent == null) {
			prepareOffersListCursor();
			return;
		}
		if (requestCode == CommonConfig.REQUEST_CODE_FOR_LOCATION_SETTINGS) {
			final byte downloadMode = intent
					.getByteExtra(CommonConfig.KEY_NAME_DOWNLOAD_MODE,
							DownloadMode.MODE_NONE);
			LogConfig.logd(LOG_TAG, "onActivityResult(): downloadMode = "
					+ downloadMode);

			mHandler.post(new Runnable() {

				@Override
				public void run() {
					int radius = PreferenceConfig
							.getOffersProximityRadius(getActivity());
					if (radius == -1) {
						radius = BusinessLogicConfig.DEFAULT_OFFER_PROXIMITY_RADIUS;
					}
					if (mRadius != radius) {
						// Offers proximity radius has changed.
						mIsOffersProximityRadiusChanged = true;
						LogConfig
								.logv(LOG_TAG,
										"onActivityResult(): Offers proximity radius has changed.");
						// Reset the timestamp of Offers/MyOffers as radius has
						// changed.
						PreferenceConfig.setCommonOffersTimestamp(0L,
								getActivity());
						PreferenceConfig.setPersonalOffersTimestamp(0L,
								getActivity());
					}
					if (downloadMode == DownloadMode.MODE_ZIPCODE) {
						ProgressBarHelper.showProgressBarSmall(
								R.string.progress_bar_please_wait, false,
								mHandler, getSherlockActivity());
						String userZipcode = intent
								.getStringExtra(CommonConfig.KEY_NAME_ZIP_CODE);
						LogConfig.logv(LOG_TAG,
								"onActivityResult(): userZipcode = "
										+ userZipcode);
						LogConfig
								.logv(LOG_TAG,
										"onActivityResult(): cached userZipcode = "
												+ PreferenceConfig
														.getUserEnteredZipcode(getActivity()));
						boolean isNewUserZip = !PreferenceConfig
								.getUserEnteredZipcode(getActivity())
								.equalsIgnoreCase(userZipcode);
						if (isNewUserZip) {
							PreferenceConfig.setUserEnteredZipcode(userZipcode,
									getActivity());
						}
						String homeZip = PreferenceConfig
								.getHomeZipcode(getActivity());
						LogConfig.logv(LOG_TAG,
								"onActivityResult(): saved homeZip = "
										+ homeZip);
						boolean isSameAsHomeZip = false;
						byte lastDownloadMode = mDownloadMode;
						if (homeZip.equalsIgnoreCase(userZipcode)) {
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): UserZip and Home zip are Equal.");
							isSameAsHomeZip = true;
							mDownloadMode = DownloadMode.MODE_ZIPCODE;
							PreferenceConfig.setDownloadMode(mDownloadMode,
									getActivity());
						}
						boolean isOffersExpired = true;
						if (getOffersType() == OffersType.COMMON_OFFERS) {
							isOffersExpired = PreferenceConfig
									.isOffersTimestampExpired(getActivity());
						} else {
							isOffersExpired = PreferenceConfig
									.isPersonalOffersTimestampExpired(getActivity());
						}
						if ((isOffersExpired
								|| PreferenceConfig
										.getDownloadMode(getActivity()) != downloadMode
								|| isNewUserZip || mIsOffersProximityRadiusChanged)
								|| !(isSameAsHomeZip && lastDownloadMode != DownloadMode.MODE_GPS)) {
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): downloadOffers(DownloadMode.MODE_ZIPCODE)");
							mIsOffersProximityRadiusChanged = false;
							callOffersListWS(DownloadMode.MODE_ZIPCODE);
						} else {
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): offers not expired: Query offers");
							prepareOffersListCursor();
						}
					} else if (downloadMode == DownloadMode.MODE_GPS) {
						// set the flag true, so to asking for gps access
						// permission.
						PreferenceConfig.setGpsAccessPermissionDialogStatus(
								true, getActivity());
						LogConfig
								.logv(LOG_TAG,
										"onActivityResult(): call fetchOffers(): MODE_GPS");
						mIsRefreshing = true;
						ProgressBarHelper.showProgressBarSmall(
								R.string.progress_bar_please_wait, false,
								mHandler, getSherlockActivity());
						updateOffersFavoriteFlags();
						if (PreferenceConfig.isValidUser(getActivity())) {
							// get offer count from server.
							fetchOfferCounts(DownloadMode.MODE_GPS);
						} else {
							fetchOffers(DownloadMode.MODE_GPS);
						}
					} else if (downloadMode == DownloadMode.MODE_HOME_ZIPCODE) {
						ProgressBarHelper.showProgressBarSmall(
								R.string.progress_bar_please_wait, false,
								mHandler, getSherlockActivity());
						byte newHomeZipStatus = intent.getByteExtra(
								CommonConfig.KEY_NAME_IS_NEW_HOMEZIP,
								CommonConfig.OLD_HOMEZIP);
						boolean isNewHomeZip = (newHomeZipStatus == CommonConfig.NEW_HOMEZIP) ? true
								: false;
						String userZipcode = PreferenceConfig
								.getUserEnteredZipcode(getActivity());
						boolean isSameAsUserZip = false;
						byte lastDownloadMode = mDownloadMode;
						String homeZip = PreferenceConfig
								.getHomeZipcode(getActivity());
						LogConfig.logv(LOG_TAG,
								"onActivityResult(): saved userZipcode = "
										+ userZipcode);
						LogConfig.logv(LOG_TAG,
								"onActivityResult(): saved homeZip = "
										+ homeZip);
						if (userZipcode.equalsIgnoreCase(homeZip)) {
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): Homezip and User zip are Equal.");
							isSameAsUserZip = true;
							mDownloadMode = DownloadMode.MODE_HOME_ZIPCODE;
							PreferenceConfig.setDownloadMode(mDownloadMode,
									getActivity());
						}
						boolean isOffersExpired = true;
						if (getOffersType() == OffersType.COMMON_OFFERS) {
							isOffersExpired = PreferenceConfig
									.isOffersTimestampExpired(getActivity());
						} else {
							isOffersExpired = PreferenceConfig
									.isPersonalOffersTimestampExpired(getActivity());
						}
						if ((isOffersExpired
								|| PreferenceConfig
										.getDownloadMode(getActivity()) != downloadMode
								|| isNewHomeZip || mIsOffersProximityRadiusChanged)
								|| !(isSameAsUserZip && lastDownloadMode != DownloadMode.MODE_GPS)) {
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): downloadOffers(DownloadMode.MODE_HOME_ZIPCODE)");
							mIsOffersProximityRadiusChanged = false;
							callOffersListWS(DownloadMode.MODE_HOME_ZIPCODE);
						} else {
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): offers not expired: Query offers");
							prepareOffersListCursor();
						}
					} else {
						if (mIsOffersProximityRadiusChanged) {
							mIsOffersProximityRadiusChanged = false;
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): No location mode: Fetch offers");
							mIsRefreshing = true;
							if (PreferenceConfig.isValidUser(getActivity())) {
								// get offer count from server.
								fetchOfferCounts(PreferenceConfig
										.getDownloadMode(getActivity()));
							} else {
								fetchOffers(PreferenceConfig
										.getDownloadMode(getActivity()));
							}
						} else {
							LogConfig
									.logv(LOG_TAG,
											"onActivityResult(): No location mode: Query offers");
							prepareOffersListCursor();
						}
					}

					// reset the search status once again, though it is also
					// resetting from
					// onLoadFinished() method of search result query
					// completion.
					mSearchResultShowing = false;
					// set empty text at search text box
					mEditTextSearch.setText("");
				}
			});
		}
	}

	/**
	 * A model class that holds the {@link Coupon} favorite status.
	 * 
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 * 
	 */
	private class FavoriteData {
		public static final byte FAVORITE_MANUALLY = 1;
		public static final byte FAVORITE_FROM_DATABASE = 2;
		public int mOfferId;
		public byte mFavoriteType;
		@SuppressWarnings("unused")
		public int mCouponChooser;
	}

	/**
	 * Method to prepare favorite offer id status list to use in favorite sync
	 * and to show favorite icon enable disable at runtime.
	 * 
	 * @param cursor
	 */
	private void populateFavoriteStatusArray(final Cursor cursor) {
		if (LogConfig.DDP_DEBUG_LOGS_ENABLED) {
			if (mFavDeletedArray != null) {
				for (int len = mFavDeletedArray.size(), i = 0; i < len; ++i) {
					LogConfig.logv(LOG_TAG, "Del offerIds : "
							+ mFavDeletedArray.keyAt(i));
				}
			}
		}
		if (mFavStatusArray != null) {
			mFavStatusArray.clear();
			mFavStatusArray = null;
			mFavDeletedArray.clear();
			mFavDeletedArray = null;
		}
		mFavDeletedArray = new SparseArray<FavoriteData>();
		mFavStatusArray = new SparseArray<FavoriteData>();
		if (cursor != null) {
			cursor.moveToPosition(-1);
			LogConfig.logd(LOG_TAG, "populateFavoriteStatusArray()");

			while (cursor.moveToNext()) {
				try {
					boolean favoriteStatus = cursor
							.getInt(CouponDao.CONTENT_COUPON_FAVORITE_FLAG_COLUMN) == CouponDao.FLAG_VALUE_FAVOURITE_ENABLE;
					if (favoriteStatus) {
						FavoriteData favoriteData = new FavoriteData();
						favoriteData.mOfferId = Integer.parseInt(cursor
								.getString(CouponDao.CONTENT_COUPON_ID_COLUMN));
						favoriteData.mCouponChooser = cursor
								.getInt(CouponDao.CONTENT_COUPON_CHOOSER_COLUMN);
						favoriteData.mFavoriteType = FavoriteData.FAVORITE_FROM_DATABASE;

						LogConfig
								.logd(LOG_TAG, "sID: " + favoriteData.mOfferId);

						mFavStatusArray
								.put(favoriteData.mOfferId, favoriteData);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Method to update the {@link Coupon} favorite status which are being
	 * cached while of user favorite check/uncheck. This method must be get
	 * called inside {@link Fragment#onPause()} and before initiating the offer
	 * refresh flow.
	 */
	private void updateOffersFavoriteFlags() {
		try {
			ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
			int offerIdsForFavSize = mFavStatusArray.size();
			if (mFavStatusArray != null && offerIdsForFavSize > 0) {

				for (int i = 0; i < offerIdsForFavSize; ++i) {
					int key = mFavStatusArray.keyAt(i);
					final FavoriteData favoriteData = mFavStatusArray.get(key);
					if (favoriteData.mFavoriteType == FavoriteData.FAVORITE_MANUALLY) {
						LogConfig.logd(LOG_TAG,
								"updateOffersFavoriteFlags(): Update to Fav offerId = "
										+ favoriteData.mOfferId);

						final String whereClause = CouponDao.WHERE_CLAUSE_COUPON_ID
								+ favoriteData.mOfferId;
						ops.add(ContentProviderOperation
								.newUpdate(CouponDao.CONTENT_URI)
								.withSelection(whereClause, null)
								.withValue(CouponDao.COUPON_FAVORITE_FLAG,
										CouponDao.FLAG_VALUE_FAVOURITE_ENABLE)
								.build());
						// Add this coupon into table with Favorite chooser.
						// prepare coupon from cursor.
						CursorLoader cursorLoader = new CursorLoader(
								getActivity(),
								CouponDao.CONTENT_URI,
								null,
								CouponDao.WHERE_CLAUSE_COUPON_ID
										+ favoriteData.mOfferId
										+ " AND "
										+ CouponDao.WHERE_CLAUSE_COUPON_CHOOSER_NOT
										+ DatabaseConfig.DB_OFFER_TYPE_FAVORITE,
								null, null);
						Cursor couponCursor = cursorLoader.loadInBackground();
						if (couponCursor != null && couponCursor.getCount() > 0) {
							couponCursor.moveToFirst();
							final Coupon coupon = new Coupon();
							coupon.mCouponChooser = DatabaseConfig.DB_OFFER_TYPE_FAVORITE;
							coupon.mCouponType = couponCursor
									.getString(CouponDao.CONTENT_COUPON_TYPE_COLUMN);
							coupon.mCouponUrl = couponCursor
									.getString(CouponDao.CONTENT_COUPON_URL_COLUMN);
							coupon.mDescription = couponCursor
									.getString(CouponDao.CONTENT_COUPON_DESCRIPTION_COLUMN);
							coupon.mDiscount = couponCursor
									.getString(CouponDao.CONTENT_DISCOUNT_COLUMN);
							coupon.mExpiryDate = couponCursor
									.getString(CouponDao.CONTENT_EXPIRY_DATE_COLUMN);
							coupon.mFavoriteFlag = CouponDao.FLAG_VALUE_FAVOURITE_ENABLE;
							coupon.mId = couponCursor
									.getInt(CouponDao.CONTENT_COUPON_ID_COLUMN);
							coupon.mImageUrl = couponCursor
									.getString(CouponDao.CONTENT_COUPON_IMAGE_URL_COLUMN);
							coupon.mTitle = couponCursor
									.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN);
							coupon.mExpires = couponCursor
									.getInt(CouponDao.CONTENT_EXPIRES_COLUMN);
							coupon.mBarcode = couponCursor
									.getString(CouponDao.CONTENT_BARCODE_COLUMN);
							coupon.mBarcodeImageUrl = couponCursor
									.getString(CouponDao.CONTENT_BARCODE_IMAGE_URL_COLUMN);
							coupon.mCouponCode = couponCursor
									.getString(CouponDao.CONTENT_COUPON_CODE_COLUMN);
							coupon.mLargeImageUrl = couponCursor
									.getString(CouponDao.CONTENT_COUPON_LARGE_IMAGE_URL_COLUMN);
							coupon.mLongDescription = couponCursor
									.getString(CouponDao.CONTENT_COUPON_LONG_DESCRIPTION);
							coupon.mIsMarketingMessageFlag = couponCursor
									.getInt(CouponDao.CONTENT_IS_MARKETING_MESSAGE_COLUMN);
							coupon.mRedeemableFlag = couponCursor
									.getInt(CouponDao.CONTENT_REDEEMABLE_FLAG_COLUMN);
							coupon.mUsageType = couponCursor
									.getInt(CouponDao.CONTENT_USAGE_TYPE_COLUMN);
							coupon.mThresholdLimit = couponCursor
									.getInt(CouponDao.CONTENT_REDEEM_THRESHOLD_LIMIT_COLUMN);
							coupon.mExhaustedFlag = couponCursor
									.getInt(CouponDao.CONTENT_EXHAUSTED_FLAG_COLUMN);

							String decorators = couponCursor
									.getString(CouponDao.CONTENT_DECORATORS_COLUMN);
							if (!TextUtils.isEmpty(decorators)) {
								decorators = decorators.replace("[", "")
										.replace("]", "");
								if (!TextUtils.isEmpty(decorators)) {
									List<String> array = Arrays
											.asList(decorators.split(","));
									coupon.mDecorators = new ArrayList<String>(
											array);
								}
							}
							String storeIds = couponCursor
									.getString(CouponDao.CONTENT_STORE_IDS_COLUMN);
							if (!TextUtils.isEmpty(storeIds)) {
								storeIds = storeIds.replace("[", "").replace(
										"]", "");
								if (!TextUtils.isEmpty(storeIds)) {
									List<String> array = Arrays.asList(storeIds
											.split(","));
									coupon.mStoreIds = new ArrayList<String>(
											array);
								}
							}

							CouponDao.addContentValues(CouponDao.CONTENT_URI,
									ops, coupon);
						}
						if (couponCursor != null) {
							couponCursor.close();
						}
					}
				}
			}
			int deleteIdsize = mFavDeletedArray.size();
			if (mFavDeletedArray != null && deleteIdsize > 0) {

				for (int i = 0; i < deleteIdsize; ++i) {
					int key = mFavDeletedArray.keyAt(i);
					FavoriteData favoriteData = mFavDeletedArray.get(key);

					LogConfig.logd(LOG_TAG,
							"updateOffersFavoriteFlags(): Delete fav offerID = "
									+ favoriteData.mOfferId);

					final String whereClause = CouponDao.WHERE_CLAUSE_COUPON_ID
							+ favoriteData.mOfferId;
					ops.add(ContentProviderOperation
							.newUpdate(CouponDao.CONTENT_URI)
							.withSelection(whereClause, null)
							.withValue(CouponDao.COUPON_FAVORITE_FLAG,
									CouponDao.FLAG_VALUE_FAVOURITE_DISABLE)
							.build());
					// Delete this coupon from table with Favorite chooser.
					ops.add(ContentProviderOperation
							.newDelete(CouponDao.CONTENT_URI)
							.withSelection(
									CouponDao.WHERE_CLAUSE_COUPON_ID
											+ favoriteData.mOfferId
											+ " AND "
											+ CouponDao.WHERE_CLAUSE_COUPON_CHOOSER
											+ DatabaseConfig.DB_OFFER_TYPE_FAVORITE,
									null).build());
				}
			}
			if (offerIdsForFavSize > 0 || deleteIdsize > 0) {
				LogConfig.logd(LOG_TAG,
						"updateOffersFavoriteFlags(): call apply batch");
				getActivity().getContentResolver().applyBatch(
						DatabaseProvider.AUTHORITY, ops);
			}
		} catch (Exception e) {
			Log.e(LOG_TAG, "Exception in apply batch: " + e);
		}
	}

	/** Method to perform initial favorite sync of offers with the server. */
	private void performInitialFavoriteSync(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "performInitialFavoriteSync(): downloadMode = "
				+ downloadMode);
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			ProgressBarHelper.dismissProgressBar(mHandler);
			prepareOffersListCursor();
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			// must reset refreshing, if requested or not.
			mIsRefreshing = false;
			return;
		}

		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}

		if (PreferenceConfig.isFavoriteOffersFirstSyncDone(getActivity())) {
			// prepare the favorite offer ids.
			prepareFavoriteOfferIds();
		}

		// set the current download mode.
		mDownloadMode = downloadMode;

		Bundle params = new Bundle();
		params.putByte(FavoriteOffersWorker.DOWNLOAD_MODE, downloadMode);
		mRequestManager.addOnRequestFinishedListener(OffersFragment.this);
		mRequestType = REQUEST_TYPE.INITIAL_SYNC_FAVORITE_OFFERS;
		mRequestId = mRequestManager.getFavoriteOffers(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/** Method to search offers locally and render the result in a list. */
	@SuppressWarnings("unused")
	private void searchOffers(String searchText) {
		LogConfig.logv(LOG_TAG, "searchOffers(): " + searchText);
		UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
		mSectionAdapter.setSelectedPosition(-1);
		if (TextUtils.isEmpty(searchText)) {
			mErrorTitle = getResources().getString(R.string.app_name);
			mDialogMessage = getResources().getString(
					R.string.dialog_msg_enter_search_text);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		} else if (searchText.length() > 40) {
			mErrorTitle = getResources().getString(R.string.app_name);
			mDialogMessage = getResources().getString(
					R.string.dialog_msg_search_text_limit);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		updateOffersFavoriteFlags();
		ProgressBarHelper.showProgressBarSmall(
				R.string.progress_bar_please_wait, false, mHandler,
				getSherlockActivity());
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST);
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST);
			getLoaderManager().initLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST, null,
					this);
		} else {
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST);
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST);
			getLoaderManager().initLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST, null, this);
		}
	}

	/**
	 * This method should to be called when user is on search result screen and
	 * pressing back key to come to the offers list screen.
	 */
	public boolean onBackKeyPressEvent() {
		mKeyPressSearchResultShowing = false;
		if (mSearchResultShowing) {
			// Update the favorite status of offers if modified in search result
			// screen.
			updateOffersFavoriteFlags();
			// reset the search status once again, though it is also resetting
			// from
			// onLoadFinished() method.
			mSearchResultShowing = false;

			// set empty text at search text box
			mEditTextSearch.setText("");

			// re-query the offers list from cache.
			prepareOffersListCursor();
			return true;
		}
		return false;
	}

	/** A method to prepare offer model array. **/
	private void prepareOfferModelArray(Cursor c) {
		LogConfig.logv(LOG_TAG, "prepareOfferModelArray()");
		if (mCouponArray != null) {
			mCouponArray.clear();
			mCouponArray = null;
		}
		mCouponArray = new SparseArray<Coupon>();
		// If coming from notification then we have to load all offers in array
		// to show the
		// offers details screen.
		if (PreferenceConfig.getIsLaunchFromNotification(getActivity())) {
			int couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON; // default.
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
			} else {
				couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
			}
			CursorLoader loader = new CursorLoader(getActivity(),
					CouponDao.CONTENT_URI, null,
					CouponDao.WHERE_CLAUSE_COUPON_CHOOSER + couponChooser,
					null, null);
			c = loader.loadInBackground();
		}
		if (c != null) {
			c.moveToPosition(-1);
			while (c.moveToNext()) {
				try {
					Coupon coupon = new Coupon();
					coupon.mId = c.getInt(CouponDao.CONTENT_COUPON_ID_COLUMN);
					coupon.mTitle = c
							.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN);
					coupon.mImageUrl = c
							.getString(CouponDao.CONTENT_COUPON_IMAGE_URL_COLUMN);
					coupon.mDescription = c
							.getString(CouponDao.CONTENT_COUPON_DESCRIPTION_COLUMN);
					coupon.mExpiryDate = c
							.getString(CouponDao.CONTENT_EXPIRY_DATE_COLUMN);
					coupon.mCouponUrl = c
							.getString(CouponDao.CONTENT_COUPON_URL_COLUMN);
					coupon.mCouponType = c
							.getString(CouponDao.CONTENT_COUPON_TYPE_COLUMN);
					coupon.mDiscount = c
							.getString(CouponDao.CONTENT_DISCOUNT_COLUMN);
					coupon.mFavoriteFlag = c
							.getInt(CouponDao.CONTENT_COUPON_FAVORITE_FLAG_COLUMN);
					coupon.mCouponChooser = c
							.getInt(CouponDao.CONTENT_COUPON_CHOOSER_COLUMN);
					coupon.mStoreIds = UIUtils.stringToArrayList(c
							.getString(CouponDao.CONTENT_STORE_IDS_COLUMN));
					coupon.mExpires = c
							.getInt(CouponDao.CONTENT_EXPIRES_COLUMN);
					coupon.mDecorators = UIUtils.stringToArrayList(c
							.getString(CouponDao.CONTENT_DECORATORS_COLUMN));
					coupon.mBarcode = c
							.getString(CouponDao.CONTENT_BARCODE_COLUMN);
					coupon.mBarcodeImageUrl = c
							.getString(CouponDao.CONTENT_BARCODE_IMAGE_URL_COLUMN);
					coupon.mCouponCode = c
							.getString(CouponDao.CONTENT_COUPON_CODE_COLUMN);
					coupon.mLargeImageUrl = c
							.getString(CouponDao.CONTENT_COUPON_LARGE_IMAGE_URL_COLUMN);
					coupon.mLongDescription = c
							.getString(CouponDao.CONTENT_COUPON_LONG_DESCRIPTION);
					coupon.mIsMarketingMessageFlag = c
							.getInt(CouponDao.CONTENT_IS_MARKETING_MESSAGE_COLUMN);
					coupon.mRedeemableFlag = c
							.getInt(CouponDao.CONTENT_REDEEMABLE_FLAG_COLUMN);
					coupon.mUsageType = c
							.getInt(CouponDao.CONTENT_USAGE_TYPE_COLUMN);
					coupon.mThresholdLimit = c
							.getInt(CouponDao.CONTENT_REDEEM_THRESHOLD_LIMIT_COLUMN);
					coupon.mExhaustedFlag = c
							.getInt(CouponDao.CONTENT_EXHAUSTED_FLAG_COLUMN);
					mCouponArray.put(c.getPosition(), coupon);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			UIApplication app = (UIApplication) getActivity()
					.getApplicationContext();
			app.setCouponModelArray(mCouponArray);
			// Close the locally created cursor.
			if (PreferenceConfig.getIsLaunchFromNotification(getActivity())) {
				c.close();
			}
		}
	}

	/**
	 * Method to prepare favorite offer ids from database. This method must be
	 * called before going for favorite sync or to get favorite offers for first
	 * time.
	 */
	private void prepareFavoriteOfferIds() {
		LogConfig.logv(LOG_TAG, "prepareFavoriteOfferIds()");
		CursorLoader loader = new CursorLoader(getActivity(),
				CouponDao.CONTENT_URI, new String[] { CouponDao.COUPON_ID },
				CouponDao.COUPON_FAVORITE_FLAG + "="
						+ DatabaseConfig.DB_OFFER_TYPE_FAVORITE, null, null);
		Cursor c = loader.loadInBackground();
		UIApplication app = (UIApplication) getActivity().getApplication();
		ArrayList<Integer> favoriteOfferIds = new ArrayList<Integer>();
		if (c != null && c.getCount() > 0) {
			c.moveToPosition(-1);
			while (c.moveToNext()) {
				int i = c.getInt(0);
				favoriteOfferIds.add(i);
				LogConfig.logv(LOG_TAG,
						"prepareFavoriteOfferIds() : offerId = " + i);
			}
		}
		app.setFavoriteOffersIds(favoriteOfferIds);
		if (c != null) {
			c.close();
		}
	}

	/** Method to refresh the offers. */
	private void refreshOffers() {
		LogConfig.logd(LOG_TAG, "refreshOffers()");
		if (!mIsRefreshing) {
			mIsRefreshing = true;
			updateOffersFavoriteFlags();
			if (!NetworkHelper.isNetworkAvailable(getActivity())) {
				listRefreshed();
			}
			boolean isOptionalUpdate = false;
			String updateType = PreferenceConfig
					.getAppUpdateType(getActivity());
			if (!TextUtils.isEmpty(updateType)
					&& updateType
							.equalsIgnoreCase(BusinessLogicConfig.APP_UPDATE_TYPE_OPTIONAL)) {
				isOptionalUpdate = true;
			}
			if (PreferenceConfig.isAppUpdateAvailable(getActivity())
					&& !isOptionalUpdate) {
				LogConfig
						.logv(LOG_TAG, "refreshOffers(): APP Update Available");
				showDialog(DialogConfig.DIALOG_UPGRADE_APP);
			} else {
				ProgressBarHelper.showProgressBarSmall(
						R.string.progress_bar_please_wait, false, mHandler,
						getSherlockActivity());
				LogConfig
						.logv(LOG_TAG, "refreshOffers(): callCheckAppUpdateWS");
				callCheckAppUpdateWS();
			}

			// reset the search status once again, though it is also resetting
			// from
			// onLoadFinished() method of search result query completion.
			mSearchResultShowing = false;

			// set empty text at search text box
			mEditTextSearch.setText("");

			// hide virtual keyboard if visible.
			UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
		}
	}

	/**
	 * {@link OnTouchListener} to hide the virtual keyboard if visible while
	 * searching.
	 */
	private final OnTouchListener mOnTouchListenerScreen = new OnTouchListener() {

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// hide virtual keyboard if visible.
			UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
			return false;
		}
	};

	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}

	/** A method to make server request to get app config. **/
	private void callGetAppConfigWS() {
		LogConfig.logv(LOG_TAG, "callGetAppConfigWS()");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			ProgressBarHelper.dismissProgressBar(mHandler);
			mIsNoNetworkCaseOccurs = true;
			// must reset refreshing, if requested or not.
			mIsRefreshing = false;
			prepareOffersListCursor();
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(OffersFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.GET_APP_CONFIG;
		params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
				SettingsWorker.WorkerModes.WORKER_MODE_GET_APP_CONFIG);
		mRequestId = mRequestManager.getAppConfig(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/**
	 * Method to take action after app configuration download complete from
	 * server.
	 */
	private void appConfigurationDownloadedDoSomething() {
		Activity activity = getActivity();
		PreferenceConfig.setAppConfigDownloadStatus(true, activity);
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					activity);
		}
		if (PreferenceConfig.isValidUser(getActivity())) {
			// get offer count from server.
			fetchOfferCounts(PreferenceConfig.getDownloadMode(getActivity()));
		} else {
			fetchOffers(PreferenceConfig.getDownloadMode(getActivity()));
		}
	}

	/**
	 * Method to search offers locally on key press to enter search text and
	 * render the result in a list.
	 */
	private void searchOffersOnKeyPress(String searchText) {
		LogConfig.logv(LOG_TAG, "searchOffersOnKeyPress(): " + searchText);
		if (searchText.length() > 40) {
			mErrorTitle = getResources().getString(R.string.app_name);
			mDialogMessage = getResources().getString(
					R.string.dialog_msg_search_text_limit);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		updateOffersFavoriteFlags();
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST);
			if (getLoaderManager().getLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST) == null) {
				getLoaderManager().initLoader(
						DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST,
						null, this);
			} else {
				getLoaderManager().restartLoader(
						DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST,
						null, this);
			}
		} else {
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST);
			if (getLoaderManager().getLoader(
					DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST) == null) {
				getLoaderManager().initLoader(
						DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST, null,
						this);
			} else {
				getLoaderManager().restartLoader(
						DatabaseConfig.QUERY_TOKEN_MYOFFER_SEARCH_LIST, null,
						this);
			}
		}
		mKeyPressSearchResultShowing = true;
	}

	/** Method to make network request to check app update on server. */
	private void callCheckAppUpdateWS() {
		LogConfig.logv(LOG_TAG, "callCheckAppUpdateWS()");
		// Check if network available
		/*
		 * if (!NetworkHelper.isNetworkAvailable(getActivity())) {
		 * prepareOffersListCursor();
		 * ProgressBarHelper.dismissProgressBar(mHandler);
		 * mIsNoNetworkCaseOccurs = true; // must reset refreshing, if requested
		 * or not. mIsRefreshing = false; mDialogMessage =
		 * getResources().getString(R.string.network_not_available_msg);
		 * mErrorTitle =
		 * getResources().getString(R.string.network_not_available_title);
		 * showDialog(DialogConfig.DIALOG_ERROR); return; }
		 */
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			if (!ProgressBarHelper.isProgressBarRunning()) {
				ProgressBarHelper.showProgressBarSmall(
						R.string.progress_bar_please_wait, false, mHandler,
						getSherlockActivity());
			}
			if (PreferenceConfig.isValidUser(getActivity())
					&& PreferenceConfig.isSessionIdExpired(getActivity())) {
				LogConfig.logv(LOG_TAG,
						"callGetAppConfigWS(): callGetSessionIdWS()");
				callGetSessionIdWS();
			} else {
				ProgressBarHelper.showProgressBarSmall(
						R.string.progress_bar_please_wait, false, mHandler,
						getSherlockActivity());
				if (PreferenceConfig.isAppConfigDownloaded(getActivity())
						&& !PreferenceConfig.isAppConfigExpired(getActivity())) {
					if (PreferenceConfig.isValidUser(getActivity())) {
						LogConfig.logv(LOG_TAG,
								"callCheckAppUpdateWS(): fetchOfferCounts()");
						// get offer count from server.
						fetchOfferCounts(PreferenceConfig
								.getDownloadMode(getActivity()));
					} else {
						LogConfig.logv(LOG_TAG,
								"callCheckAppUpdateWS(): fetchOffers()");
						fetchOffers(PreferenceConfig
								.getDownloadMode(getActivity()));
					}
				} else {
					LogConfig.logv(LOG_TAG,
							"callGetAppConfigWS(): fetchOffers()");
					callGetAppConfigWS();
				}
			}
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(OffersFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.CHECK_APP_UPDATE;
		mRequestId = mRequestManager.checkAppUpdate(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/** method to make network request to get session id. **/
	private void callGetSessionIdWS() {
		LogConfig.logv(LOG_TAG, "callGetSessionIdWS()");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			if (!ProgressBarHelper.isProgressBarRunning()) {
				ProgressBarHelper.showProgressBarSmall(
						R.string.progress_bar_please_wait, false, mHandler,
						getSherlockActivity());
			}
			if (PreferenceConfig.isAppConfigDownloaded(getActivity())
					&& !PreferenceConfig.isAppConfigExpired(getActivity())) {
				if (PreferenceConfig.isValidUser(getActivity())) {
					// get offer count from server.
					fetchOfferCounts(PreferenceConfig
							.getDownloadMode(getActivity()));
				} else {
					fetchOffers(PreferenceConfig.getDownloadMode(getActivity()));
				}
			} else {
				callGetAppConfigWS();
			}
			return;
		}
		Bundle params = new Bundle();
		params.putByte(LoginWorker.KEY_NAME_BUNDLE_LOGIN_WORKER_MODE,
				LoginWorker.WORKER_MODE_LOGIN_USER);
		mRequestManager.addOnRequestFinishedListener(OffersFragment.this);
		mRequestType = REQUEST_TYPE.GET_SESSION_ID;
		mRequestId = mRequestManager.loginUser(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/** A method to perform action after successfully getting the session id. **/
	private void sessionIdFetchedDoSomething() {
		LogConfig.logv(LOG_TAG, "sessionIdFetchedDoSomething()");
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}
		if (PreferenceConfig.isAppConfigDownloaded(getActivity())
				&& !PreferenceConfig.isAppConfigExpired(getActivity())) {
			if (PreferenceConfig.isValidUser(getActivity())) {
				// get offer count from server.
				fetchOfferCounts(PreferenceConfig
						.getDownloadMode(getActivity()));
			} else {
				fetchOffers(PreferenceConfig.getDownloadMode(getActivity()));
			}
		} else {
			callGetAppConfigWS();
		}
	}

	/** Method to called after the list refresh completion. */
	private void listRefreshed() {
		mListView.post(new Runnable() {
			@Override
			public void run() {
				mListView.listRefreshed();
			}
		});
	}

	/** Listener that invokes for Sliging menu open event. */
	private SlidingMenu.OnOpenListener onSlidingMenuOpenListener = new SlidingMenu.OnOpenListener() {
		@Override
		public void onOpen() {
			// Hide the virtual keyboard if opened.
			if (mEditTextSearch != null) {
				UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
			}
			// Now update the offers count.
			SliderMenuFragment sliderMenuFragment = (SliderMenuFragment) getSherlockActivity()
					.getSupportFragmentManager().findFragmentById(
							R.id.menu_frame);
			if (sliderMenuFragment != null) {
				sliderMenuFragment.redrawView();
				if (getOffersType() == OffersType.COMMON_OFFERS) {
					sliderMenuFragment
							.setRowSelected(HomeActivity.POSITION_TAB_OFFERS);
				} else {
					sliderMenuFragment
							.setRowSelected(HomeActivity.POSITION_TAB_MYOFFERS);
				}
			}
		}
	};

	/**
	 * An interface to hold the offers type value i.e. either
	 * {@link OffersType#COMMON_OFFERS}, {@link OffersType#PERSONAL_OFFERS} or
	 * {@link OffersType#FAVORITE_OFFERS}.
	 * 
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 * 
	 */
	public interface OffersType {
		/**
		 * Screen type COMMON_OFFERS means all network requests and code
		 * decisions will be make for common Offers data.
		 */
		byte COMMON_OFFERS = 1;
		/**
		 * Screen type PERSONAL_OFFERS means all network requests and code
		 * decisions will be make for personalized offers data.
		 */
		byte PERSONAL_OFFERS = 2;
		/**
		 * Screen type FAVORITE_OFFERS means all network requests and code
		 * decisions will be make for Favorite data.
		 */
		byte FAVORITE_OFFERS = 3;
	}

	/** Method to set type of offers. */
	protected void updateLogTag() {
		LOG_TAG = "OffersFragment";
	}

	/**
	 * Method to get the current offer type.
	 * 
	 * @return Returns type of offers that can be
	 *         {@link OffersType#COMMON_OFFERS},
	 *         {@link OffersType#PERSONAL_OFFERS} or
	 *         {@link OffersType#FAVORITE_OFFERS}
	 * @see OffersType
	 */
	protected byte getOffersType() {
		return OffersType.COMMON_OFFERS;
	}

	/** Method to make server request to get offer count from server. */
	private void callGetOfferCountWS(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "callGetOfferCountWS()");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			ProgressBarHelper.dismissProgressBar(mHandler);
			prepareOffersListCursor();
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			// must reset refreshing, if requested or not.
			mIsRefreshing = false;
			return;
		}

		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}

		// Set download mode again as this methods calls independently.
		mDownloadMode = downloadMode;

		Bundle params = new Bundle();
		params.putByte(OffersWorker.DOWNLOAD_MODE, mDownloadMode);
		mRequestManager.addOnRequestFinishedListener(OffersFragment.this);
		mRequestType = REQUEST_TYPE.GET_OFFER_COUNT;
		mRequestId = mRequestManager.getOfferCount(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/**
	 * Method to perform required action after successful download of offer
	 * count.
	 */
	private void offerCountDownloadedDoSomething() {
		LogConfig.logv(LOG_TAG, "offerCountDownloadedDoSomething()");
		fetchOffers(mDownloadMode);
	}

	/** Method to get the resource id for screen title. */
	protected int getTitleResId() {
		return R.string.label_tab_offers;
	}

	/** An interface to hold offer notification type. */
	public interface OfferNotificationType {
		final String PERSONAL_OFFER = "personal";
		final String COMMON_OFFER = "category";
	}

	/**
	 * Method to show offer detail screen for coupon id that came from
	 * notification response.
	 */
	private void startOfferDetailScreen() {
		int position;
		int count;
		int couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON; // default.
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
		} else {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
		}
		CursorLoader cursorLoader = new CursorLoader(getActivity(),
				CouponDao.CONTENT_URI, null,
				CouponDao.WHERE_CLAUSE_COUPON_CHOOSER + couponChooser, null,
				null);
		Cursor c = cursorLoader.loadInBackground();
		if (c != null && c.getCount() > 0) {
			c.moveToPosition(-1);
			UIApplication uiApplication = (UIApplication) getActivity()
					.getApplication();
			String couponId = uiApplication.getNoficationCouponIdList().get(0)
					+ "";
			while (c.moveToNext()) {
				if (couponId.equalsIgnoreCase(c
						.getString(CouponDao.CONTENT_COUPON_ID_COLUMN))) {
					position = c.getPosition();
					count = c.getCount();
					AnalyticsHelper.sendOfferClickedAnalytics(getActivity(),
							c.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN));
					final Intent intent = new Intent(getActivity(),
							OfferDetailActivity.class);
					intent.putExtra(
							OfferDetailIntentKey.CURRENTLY_SELECTED_ITEM,
							position);
					intent.putExtra(OfferDetailIntentKey.OFFER_COUNT, count);
					startActivity(intent);
					break;
				}
			}
		}
		if (c != null) {
			c.close();
		}
	}

	/**
	 * Method to fetch counts for Common, Personal and favorite offers from
	 * server. If offers timestamp is expired then only we go for the count
	 * download.
	 */
	private void fetchOfferCounts(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "fetchOfferCounts()");
		boolean isOffersExpired = true;
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			isOffersExpired = PreferenceConfig
					.isOffersTimestampExpired(getActivity());
		} else {
			isOffersExpired = PreferenceConfig
					.isPersonalOffersTimestampExpired(getActivity());
		}
		if (isOffersExpired || mIsRefreshing) {
			callGetOfferCountWS(downloadMode);
		} else {
			fetchOffers(downloadMode);
		}
	}

	/** A method to perform action after successfully checking the app update. */
	private void appUpdateCheckedDoSomething() {
		LogConfig.logv(LOG_TAG, "appUpdateCheckedDoSomething()");
		if (PreferenceConfig.isAppUpdateAvailable(getActivity())) {
			LogConfig.logv(LOG_TAG,
					"appUpdateCheckedDoSomething(): APP Update Available");
			showDialog(DialogConfig.DIALOG_UPGRADE_APP);
		} else {
			LogConfig.logv(LOG_TAG,
					"appUpdateCheckedDoSomething(): NO update for APP");
			if (mIsRefreshing) {
				callGetAppConfigWS();
			} else {
				if (PreferenceConfig.isValidUser(getActivity()) 
						&& PreferenceConfig.isSessionIdExpired(getActivity())) {
					callGetSessionIdWS();
				} else {
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, false, mHandler,
							getSherlockActivity());
					if (PreferenceConfig.isAppConfigDownloaded(getActivity())
							&& !PreferenceConfig
									.isAppConfigExpired(getActivity())) {
						fetchOffers(PreferenceConfig
								.getDownloadMode(getActivity()));
					} else {
						callGetAppConfigWS();
					}
				}
			}
		}
	}
}
