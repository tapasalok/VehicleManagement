/**
 * Copyright 2012 Yaochangwei(yaochangwei@gmail.com)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */
package com.manthansystems.loyalty.ui.widget;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.util.UIUtils;

import android.content.Context;
import android.support.v4.view.MotionEventCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ListView;

/**
 * Refreshable ListView base class.
 * 
 * @author Yaochangwei (yaochangwei@gmail.com)
 */
public class RefreshableListView extends ListView {

	private static final int STATE_NORMAL = 0;
	private static final int STATE_READY = 1;
	private static final int STATE_PULL = 2;
	private static final int STATE_UPDATING = 3;
	private static final int INVALID_POINTER_ID = -1;

	protected ListHeaderView mListHeaderView;

	private int mActivePointerId;
	private float mLastY;

	private int mState;

	private OnUpdateTask mOnUpdateTask;

	private int mTouchSlop;

	public RefreshableListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initialize();
	}

	public RefreshableListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initialize();
	}

	/***
	 * Set the Header Content View.
	 * 
	 * @param id
	 *            The view resource.
	 */
	public void setContentView(int id) {
		final View view = LayoutInflater.from(getContext()).inflate(id,
				mListHeaderView, false);
		mListHeaderView.addView(view);
	}

	public void setContentView(View v) {
		mListHeaderView.addView(v);
	}

	public ListHeaderView getListHeaderView() {
		return mListHeaderView;
	}

	/**
	 * Setup the update task.
	 * 
	 * @param task
	 */
	public void setOnUpdateTask(OnUpdateTask task) {
		mOnUpdateTask = task;
	}

	/**
	 * Update immediately.
	 */
	public void startUpdateImmediate() {
		if (mState == STATE_UPDATING) {
			return;
		}
		setSelectionFromTop(0, 0);
		mListHeaderView.moveToUpdateHeight();
		update();
	}

	/**
	 * Set the Header View change listener.
	 * 
	 * @param listener
	 */
	public void setOnHeaderViewChangedListener(
			OnHeaderViewChangedListener listener) {
		mListHeaderView.mOnHeaderViewChangedListener = listener;
	}

	private void initialize() {
		final Context context = getContext();
		mListHeaderView = new ListHeaderView(context, this);
		addHeaderView(mListHeaderView, null, false);
		mState = STATE_NORMAL;
		final ViewConfiguration configuration = ViewConfiguration.get(context);
		mTouchSlop = configuration.getScaledTouchSlop();
	}

	private void update() {
		if (mListHeaderView.isUpdateNeeded()) {
			if (mOnUpdateTask != null) {
				mOnUpdateTask.onUpdateStart();
			}
			mListHeaderView.startUpdate(new Runnable() {
				public void run() {
					if (mOnUpdateTask != null) {
						mOnUpdateTask.updateBackground();
					}
				}
			});
			mState = STATE_UPDATING;
		} else {
			mListHeaderView.close(STATE_NORMAL);
		}
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		try {
			if (mState == STATE_UPDATING) {
				return super.dispatchTouchEvent(ev);
			}
			final int action = ev.getAction() & MotionEventCompat.ACTION_MASK;
			switch (action) {
			case MotionEvent.ACTION_DOWN:
				mActivePointerId = MotionEventCompat.getPointerId(ev, 0);
				mLastY = ev.getY();

				if (UIUtils.getRetailId(getContext()) == CommonConfig.RETAILTYPE_ROBINSON) {
					isFirstViewTop();
				} else {
					// isFirstViewTop();
				}
				
				break;
			case MotionEvent.ACTION_MOVE:
				if (mActivePointerId == INVALID_POINTER_ID) {
					break;
				}

				if (mState == STATE_NORMAL) {

					if (UIUtils.getRetailId(getContext()) == CommonConfig.RETAILTYPE_ROBINSON) {
						isFirstViewTop();
					} else {
						final int activePointerId = mActivePointerId;
						final int activePointerIndex = MotionEventCompat
								.findPointerIndex(ev, activePointerId);
						final float y = MotionEventCompat.getY(ev,
								activePointerIndex);
						final int deltaY = (int) (y - mLastY);
						mLastY = y;
						if (deltaY > 0 && Math.abs(deltaY) > mTouchSlop) {
							isFirstViewTop();
						}
						// isFirstViewTop();
					}
				}

				if (mState == STATE_READY) {
					final int activePointerId = mActivePointerId;
					final int activePointerIndex = MotionEventCompat
							.findPointerIndex(ev, activePointerId);
					final float y = MotionEventCompat.getY(ev,
							activePointerIndex);
					final int deltaY = (int) (y - mLastY);
					mLastY = y;
					
					boolean checkY = false;
					if (UIUtils.getRetailId(getContext()) == CommonConfig.RETAILTYPE_ROBINSON) {
						checkY = (deltaY <= 0 || Math.abs(y) < mTouchSlop);
					}else{
						checkY = (deltaY < 0 && Math.abs(deltaY) > mTouchSlop);
					}
					if (checkY) {
						mState = STATE_NORMAL;
					} else {
						mState = STATE_PULL;
						ev.setAction(MotionEvent.ACTION_CANCEL);
						super.dispatchTouchEvent(ev);
					}
				}

				if (mState == STATE_PULL) {
					final int activePointerId = mActivePointerId;
					final int activePointerIndex = MotionEventCompat
							.findPointerIndex(ev, activePointerId);
					final float y = MotionEventCompat.getY(ev,
							activePointerIndex);
					final int deltaY = (int) (y - mLastY);
					mLastY = y;

					final int headerHeight = mListHeaderView.getHeight();
					setHeaderHeight(headerHeight + deltaY * 5 / 9);
					return true;
				}

				break;
			case MotionEvent.ACTION_CANCEL:
			case MotionEvent.ACTION_UP:
				mActivePointerId = INVALID_POINTER_ID;
				if (mState == STATE_PULL) {
					update();
				}
				break;
			case MotionEventCompat.ACTION_POINTER_DOWN:
				final int index = MotionEventCompat.getActionIndex(ev);
				final float y = MotionEventCompat.getY(ev, index);
				mLastY = y;
				mActivePointerId = MotionEventCompat.getPointerId(ev, index);
				break;
			case MotionEventCompat.ACTION_POINTER_UP:
				onSecondaryPointerUp(ev);
				break;
			}
			return super.dispatchTouchEvent(ev);
		} catch (Exception e) {
			Log.e("RefreshableListView", "dispatchTouchEvent(): " + e);
			return true;
		}
	}

	private void onSecondaryPointerUp(MotionEvent ev) {
		final int pointerIndex = MotionEventCompat.getActionIndex(ev);
		final int pointerId = MotionEventCompat.getPointerId(ev, pointerIndex);
		if (pointerId == mActivePointerId) {
			final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
			mLastY = MotionEventCompat.getY(ev, newPointerIndex);
			mActivePointerId = MotionEventCompat.getPointerId(ev,
					newPointerIndex);
		}
	}

	void setState(int state) {
		mState = state;
	}

	private void setHeaderHeight(int height) {
		mListHeaderView.setHeaderHeight(height);
	}

	private boolean isFirstViewTop() {
		final int count = getChildCount();
		if (count == 0) {
			return true;
		}
		final int firstVisiblePosition = this.getFirstVisiblePosition();
		final View firstChildView = getChildAt(0);
		
		boolean needs = false;
		if (UIUtils.getRetailId(getContext()) == CommonConfig.RETAILTYPE_ROBINSON) {
			needs = firstChildView.getTop() == 0
					&& (firstVisiblePosition == 0);
		}else{
			needs = firstChildView.getTop() == 0
					|| (firstVisiblePosition == 0);
		}
		
		if (needs) {
			mState = STATE_READY;
		}

		return needs;
	}

	/**
	 * Will called to indicate list refresh completion and will close the
	 * refresh header and notify the refresh update listener to update the UI.
	 */
	public void listRefreshed() {
		post(new Runnable() {
			public void run() {
				mListHeaderView.close(STATE_NORMAL);
				if (mOnUpdateTask != null) {
					mOnUpdateTask.updateUI();
				}
			}
		});
	}

	/** When use custom List header view */
	public static interface OnHeaderViewChangedListener {
		/**
		 * When user pull the list view, we can change the header status here.
		 * for example: the arrow rotate down or up.
		 * 
		 * @param v
		 *            : the list view header
		 * @param canUpdate
		 *            : if the list view can update.
		 */
		void onViewChanged(View v, boolean canUpdate);

		/**
		 * Change the header status when we really do the update task. for
		 * example: display the progressbar.
		 * 
		 * @param v
		 *            the list view header
		 */
		void onViewUpdating(View v);

		/**
		 * Will called when the update task finished. for example: hide the
		 * progressbar and show the arrow.
		 * 
		 * @param v
		 *            the list view header.
		 */
		void onViewUpdateFinish(View v);
	}

	/** The callback when the updata task begin, doing. or finish. */
	public static interface OnUpdateTask {

		/**
		 * will called before the update task begin. Will Run in the UI thread.
		 */
		public void onUpdateStart();

		/**
		 * Will called doing the background task. Will Run in the background
		 * thread.
		 */
		public void updateBackground();

		/**
		 * Will called when doing the background task. Will Run in the UI
		 * thread.
		 */
		public void updateUI();

	}

}
