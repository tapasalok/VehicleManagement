/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.CursorLoader;
import android.text.Html;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDao;
import com.manthansystems.loyalty.location.LocationHandler;
import com.manthansystems.loyalty.util.CallHelper;

/**
 * A {@link FragmentActivity} class that shows store locations on Map. By clicking
 * on call icon or on phone number one can initiate call to that phone number.
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 *
 */
public class MapsActivity extends FragmentActivity implements OnInfoWindowClickListener {

	private final String LOG_TAG = "MapsActivity";
	
	private final int ZOOM_CONTROL_ID = 0x1; // Don't change it. Default id from SupportMapFragment.
	
	private SupportMapFragment mSupportMapFragment;
	private MyInfoWindowAdapter mMyInfoWindowAdapter;
	private GoogleMap mMap;
	private LocationManager mLocationManager;
	private LocationHandler mLocationHandler;
	private LocationUpdateListener mLocationUpdateListener;
	private AlertDialog mAlertDialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		int checkGooglePlayServices = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
	    if (checkGooglePlayServices != ConnectionResult.SUCCESS) {
			// google play services is missing!!!!
	    	showCustomDialog(DialogConfig.DIALOG_ERROR);
	        return;
	    }
		setContentView(R.layout.activity_maps);
		
		FragmentManager myFragmentManager = getSupportFragmentManager();
		mSupportMapFragment = (SupportMapFragment)
	    	myFragmentManager.findFragmentById(R.id.mapview);
	    mMap = mSupportMapFragment.getMap();
	    mLocationHandler = new LocationHandler();
	    mLocationUpdateListener = new LocationUpdateListener();	
	    mLocationManager = (LocationManager) this.getSystemService(
				Context.LOCATION_SERVICE);
	    
	    // render Map Overlay.
        renderMapOverlay(savedInstanceState);
	}
	
	/** Method to render the map overlay. */
	private void renderMapOverlay(Bundle savedInstanceState) {
		final LatLngBounds.Builder builder = new LatLngBounds.Builder();
		HashMap<String, String> phoneNumber = new HashMap<String, String>();
		LatLng userGeoPoint = null;
		
		double[] userLocation = LocationHandler.getSavedLocation(true, this);
		if (!mLocationHandler.isLocationTimestampExpired(this) 
				&& userLocation[LocationHandler.LATTITUDE] != 0) {
			LogConfig.logv(LOG_TAG, "Location is Valid.");
			userGeoPoint = new LatLng(userLocation[LocationHandler.LATTITUDE],
					userLocation[LocationHandler.LONGITUDE]);
		} else {
			if (isLocationAccessPermitted()) {
				LogConfig.logv(LOG_TAG, "Location access permission: YES");
				requestLocationUpdate();
			} else {
				LogConfig.logv(LOG_TAG, "Location access permission: NO");
				userGeoPoint = getZipBasedUserLocation();
			}
		}
		
		// Add the user location marker on map.
		addMarkerOnMap(userGeoPoint, getResources().getString(R.string.msg_user_current_location),
				BitmapDescriptorFactory.fromResource(R.drawable.pin_user_position));
		
		LatLng centerGeoPoint = userGeoPoint; // default map center is user location.
		// Prepare the addresses based on storeIds.
		ArrayList<String> storeIdList = getIntent().getStringArrayListExtra(KEY_CONSTANTS.STORE_IDS);
		String offerTitle = getIntent().getStringExtra(KEY_CONSTANTS.OFFER_TITLE);
		String offerTitleBottomBar = offerTitle;
		if (TextUtils.isEmpty(offerTitleBottomBar)) {
			offerTitleBottomBar = "";
		} else {
			offerTitleBottomBar = String.format(getResources().getString(R.string.label_map_bottom_bar),
					offerTitleBottomBar);
		}
		final TextView mTextViewBottomBar = (TextView) findViewById(R.id.TextView_bottom_bar);
		mTextViewBottomBar.setText(Html.fromHtml(offerTitleBottomBar));
		
		String storeIds = storeIdList.toString();
		storeIds = storeIds.replace("[", "").replace("]", "").replace(" ", "");
		LogConfig.logv(LOG_TAG, "storeIds = " + storeIds);
		
		// prepare and fetch the store data from database.
		CursorLoader loader = new CursorLoader(MapsActivity.this, StoreDao.CONTENT_URI,
				null, StoreDao.WHERE_CLAUSE_STORE_IDS_IN + "(" + storeIds + ")", null, null);
		Cursor cursor = loader.loadInBackground();
		if (cursor != null && cursor.getCount() > 0) {
			LogConfig.logv(LOG_TAG, "store count = " + cursor.getCount());
			String geoPointDefaultTitle = getResources().getString(R.string.label_manthan_stores);
			cursor.moveToPosition(-1);
			while (cursor.moveToNext()) {
				String storeAddress1 = cursor.getString(StoreDao.CONTENT_STORE_ADDRESS1_COLUMN);
				String storeAddress2 = cursor.getString(StoreDao.CONTENT_STORE_ADDRESS2_COLUMN);
		    	String storeCity = cursor.getString(StoreDao.CONTENT_STORE_CITY_COLUMN);
		    	String storeState = cursor.getString(StoreDao.CONTENT_STORE_STATE_COLUMN);
		    	String storeZipCode = cursor.getString(StoreDao.CONTENT_STORE_ZIP_COLUMN);
		    	String storePhoneNumber = cursor.getString(StoreDao.CONTENT_STORE_PHONE_COLUMN);
		    	String storeName = cursor.getString(StoreDao.CONTENT_STORE_NAME_COLUMN);
		    	double storeLat = cursor.getDouble(StoreDao.CONTENT_STORE_LAT_COLUMN);
		    	double storeLon = cursor.getDouble(StoreDao.CONTENT_STORE_LONG_COLUMN);
		    	
		    	// If any store lat or lon is not avail then don't process it.
		    	if (storeLat == 0 || storeLat == -1 || storeLon == 0 || storeLon == -1) {
		    		continue;
		    	}
		    	
		    	LogConfig.logv(LOG_TAG, "storeAddress = " + storeAddress1);
		    	
		    	StringBuilder locationStringBuilder = new StringBuilder();
		    	// For now we don't show offer title. Un-comment it later if required.
//		    	if (!TextUtils.isEmpty(offerTitle)) {
//		    		locationStringBuilder.append(offerTitle).append("\n");
//				}
		    	if (!TextUtils.isEmpty(storeAddress1)) {
		    		locationStringBuilder.append(storeAddress1).append(", ");
				}
		    	if (!TextUtils.isEmpty(storeAddress2)) {
		    		locationStringBuilder.append(storeAddress2).append(", ");
				}
				if (!TextUtils.isEmpty(storeCity)) {
					locationStringBuilder.append(storeCity).append(", ");
				}
				if (!TextUtils.isEmpty(storeState)) {
					locationStringBuilder.append(storeState).append(", ");
				}
				if (!TextUtils.isEmpty(storeZipCode)) {
					locationStringBuilder.append(storeZipCode);
				}
				String location = locationStringBuilder.toString();

				LatLng geoPoint = new LatLng(storeLat, storeLon); 
				if (cursor.isFirst()) {
					centerGeoPoint = geoPoint;
				}
				phoneNumber.put(location, storePhoneNumber);
		    	mMap.addMarker(new MarkerOptions()
					.position(geoPoint)
					.title((!TextUtils.isEmpty(storeName)? storeName : geoPointDefaultTitle))
					.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
					.snippet(location));
		    	builder.include(geoPoint);
		    	LogConfig.logv("Maps", "Marker added..: " + storeName);
			}
		}
		if (cursor != null) {
			cursor.close();
			cursor = null;
		}   
		
		if (centerGeoPoint != null) {
			LogConfig.logv("Maps", "Move Camera to store location");
			mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(centerGeoPoint, 11.0f));
		}
		
		// align the zoom controls to bottom-right.
        alignZoomControls();
        
	    mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
	    mMap.getUiSettings().setZoomControlsEnabled(true);
	    mMap.getUiSettings().setCompassEnabled(false);
	    mMap.setOnInfoWindowClickListener(this);
	    mMyInfoWindowAdapter = new MyInfoWindowAdapter(phoneNumber);
	    mMap.setInfoWindowAdapter(mMyInfoWindowAdapter);
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		dismissActiveDialog();
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    }
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * An interface that holds the constant strings used for data passing.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	public interface KEY_CONSTANTS {
		public final String STORE_IDS = "com.manthansystems.loyalty.ui.MapsActivity#storeIds";
		public final String OFFER_TITLE = "com.manthansystems.loyalty.ui.MapsActivity#offerTitle";
	}
	
	/** Method to align the zoom controls to the bottom-right of the screen. */
	private void alignZoomControls() {
		// Find ZoomControl view
		View zoomControls = mSupportMapFragment.getView().findViewById(ZOOM_CONTROL_ID);

		if (zoomControls != null && zoomControls.getLayoutParams() instanceof RelativeLayout.LayoutParams) {
		    // ZoomControl is inside of RelativeLayout
		    RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) zoomControls.getLayoutParams();

		    // Align it to - parent top|left
		    params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
		    params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);

		    // Update margins, set to 10dp
		    final int margin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 30,
		            getResources().getDisplayMetrics());
		    params.setMargins(0, 0, 0, margin);
		}
	}
	
	/**
	 * A custom {@link InfoWindowAdapter} to populate the {@link Marker} information.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	private class MyInfoWindowAdapter implements InfoWindowAdapter {

		private final View myContentsView;
		private HashMap<String, String> phoneNumberMap = new HashMap<String, String>();

		MyInfoWindowAdapter(HashMap<String, String> phoneNumberMap) {
			this.phoneNumberMap = phoneNumberMap;
			myContentsView = getLayoutInflater().inflate(
					R.layout.balloon_overlay, null);
		}

		@Override
		public View getInfoContents(Marker marker) {
			LogConfig.logv(LOG_TAG, "getInfoContents() : " + marker.getTitle());
			TextView tvTitle = (TextView) myContentsView.findViewById(R.id.balloon_item_title);
			tvTitle.setText(marker.getTitle());
			TextView tvSnippet = (TextView) myContentsView.findViewById(R.id.balloon_item_snippet);
			tvSnippet.setText(marker.getSnippet());
			
			TextView tvPhone = (TextView) myContentsView.findViewById(R.id.balloon_item_phone);
			final String phoneNumber = phoneNumberMap.get(marker.getSnippet());
			LogConfig.logv(LOG_TAG, "getInfoContents() : phoneNumber = " + phoneNumber);
			if (TextUtils.isEmpty(phoneNumber)) {
				tvPhone.setVisibility(View.GONE);
			} else {
				tvPhone.setVisibility(View.VISIBLE);
				tvPhone.setText(phoneNumber);
			}
			return myContentsView;
		}

		@Override
		public View getInfoWindow(Marker marker) {
			return null;
		}
		
		/** Method to initiate a call to given phone number. */
		private void makePhoneCall(Context context, Marker marker) {
			final String phoneNumber = phoneNumberMap.get(marker.getSnippet());
			if (!TextUtils.isEmpty(phoneNumber)) {
				CallHelper.getInstance().makeCall(phoneNumber, context);
			}
		}
	}

	@Override
	public void onInfoWindowClick(Marker marker) {
		mMyInfoWindowAdapter.makePhoneCall(mSupportMapFragment.getActivity(), marker);
	}
	
	/** Request the location updates. */
	private void requestLocationUpdate() {
		LogConfig.logd(LOG_TAG, "requestLocationUpdate()");
		mLocationHandler.addObserver(mLocationUpdateListener);
		int providerStatus = mLocationHandler.register(MapsActivity.this.getApplicationContext(),
				mLocationManager);
		if (providerStatus == LocationHandler.LOCATION_PROVIDER_DISABLED) {
			LogConfig.logv(LOG_TAG, "Location update() : Provider Disabled");
			removeLocationUpdate();
			LatLng userGeoPoint = getZipBasedUserLocation();
			// Add the user location marker on map.
			addMarkerOnMap(userGeoPoint, getResources().getString(R.string.msg_user_current_location),
					BitmapDescriptorFactory.fromResource(R.drawable.pin_user_position));
		}
	}

	/** Remove the location updates. */
	private void removeLocationUpdate() {
		LogConfig.logd(LOG_TAG, "removeLocationUpdate()");
		mLocationHandler.deleteObserver(mLocationUpdateListener);
		mLocationHandler.unregister(mLocationManager);
	}
	
	/** Method to check if location access is permitted or not. */
	private boolean isLocationAccessPermitted() {
		return mLocationHandler.getGpsLocationPermissionStatus(MapsActivity.this);
	}
	
	/**
	 * A location update listener class which implements {@link Observer}, which
	 * listen for location updates.
	 * 
	 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
	 * 
	 */
	private class LocationUpdateListener implements Observer {

		@Override
		public void update(final Observable observable, final Object data) {
			removeLocationUpdate();
			if (data instanceof Location) {
				MapsActivity.this.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						LogConfig.logv(LOG_TAG, "Location update() : Success");
						Location location = (Location) data;
						LatLng userGeoPoint = new LatLng(location.getLatitude(), location.getLongitude());
						addMarkerOnMap(userGeoPoint, getResources().getString(R.string.msg_user_current_location),
								BitmapDescriptorFactory.fromResource(R.drawable.pin_user_position));
					}
				});
			} else if (data instanceof String) {
				MapsActivity.this.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						LogConfig.logv(LOG_TAG, "Location update() : Fails");
						// try to get location via home zip code.
						LatLng userGeoPoint = getZipBasedUserLocation();
						// Add the user location marker on map.
						addMarkerOnMap(userGeoPoint, getResources().getString(R.string.msg_user_current_location),
								BitmapDescriptorFactory.fromResource(R.drawable.pin_user_position));
					}
				});
				
				// Show location status log for debugging.
				if (LogConfig.DDP_DEBUG_LOGS_ENABLED) {
					final String locationMessage = (String) data;
					if (locationMessage
							.equalsIgnoreCase(LocationHandler.LOCATION_RESULT_INVALID)) {
						LogConfig.logd(LOG_TAG + ": LocationUpdateListener",
								"  location update(): "
										+ LocationHandler.LOCATION_RESULT_INVALID);
					} else if (locationMessage
							.equalsIgnoreCase(LocationHandler.LOCATION_RESULT_TIMEOUT)) {
						LogConfig.logd(LOG_TAG + ": LocationUpdateListener",
								"  location update(): "
										+ LocationHandler.LOCATION_RESULT_TIMEOUT);
					}
				}
			}
		}
	}
	
	/** Method to get the user gps location based on the home zip code. */
	private LatLng getZipBasedUserLocation() {
		LatLng userLoc = null;
		// Get the user location from their home zip.
		String homeZip = PreferenceConfig.getHomeZipcode(this);
		if (!TextUtils.isEmpty(homeZip)) {
			// Get the user location from their home zip.
			String lat = PreferenceConfig.getLatForZipCode(this);
			if (!TextUtils.isEmpty(lat)) {
				String lng = PreferenceConfig.getLonForZipCode(this);
				double latValue = Double.parseDouble(lat);
				double lonValue = Double.parseDouble(lng);
				userLoc = new LatLng(latValue, lonValue);
			}
		}
		return userLoc;
	}
	
	/** Method to add the {@link Marker} on map.*/
	private void addMarkerOnMap(LatLng point, String title, BitmapDescriptor iconDescriptor) {
		if (point != null) {
			mMap.addMarker(new MarkerOptions()
				.position(point)
				.title(title)
				.icon(iconDescriptor));
		}
	}
	
	@Override
	public void finish() {
	    super.finish();
	    overridePendingTransition(0, R.anim.translate_slide_right_out);
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showCustomDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(this);
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(R.string.dialog_google_play_service_missing)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					MapsActivity.this.finish();
				}
			});
			break;
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
}