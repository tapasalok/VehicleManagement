/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.UnderlineSpan;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.phone.CustomWebViewActivity;
import com.manthansystems.loyalty.ui.phone.EnterHomeZipCodeActivity;
import com.manthansystems.loyalty.ui.phone.EnterTokenActivity;
import com.manthansystems.loyalty.util.EDUtils;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.ShareHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.LoginWorker;

/**
 * A Fragment class that will manage user email address. This class extends
 * {@link SherlockFragmentActivity}.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class EnterEmailFragment extends SherlockFragment  implements
		  OnRequestFinishedListener {

	private final String LOG_TAG = "EnterEmailFragment";
	
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.EnterEmailFragment#RequestId";
	
	private ViewGroup mView;
	private Handler mHandler;
    private RequestManager mRequestManager;
    private int mRequestId = -1;
    
    private String mErrorMessage;
    private String mErrorTitle;
    private Bundle mResponseBundle;
	
	private boolean mShowProgressBar = false;
	private Button mButtonOk;
	private Button mButtonCancel;
	private EditText mEditTextEmailAddress;

	private Context mContext;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogConfig.logd(LOG_TAG, "onCreate()");
		if (savedInstanceState == null) {
			// Do nothing.
		} else {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
		}
		mHandler = new Handler();
    	mRequestManager = RequestManager.from(getActivity());
    	mContext = getActivity().getApplicationContext();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_login_screen, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;   
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		UIUtils.hideKeyboard(getActivity(), mEditTextEmailAddress);
		PreferenceConfig.setEmailScreenVisiblity(true, getActivity());
	}
	
	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logd(LOG_TAG, "onPause()");
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(EnterEmailFragment.this);
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logd(LOG_TAG, "onResume()");
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(EnterEmailFragment.this);
            } else {
                mRequestId = -1;
            }
        }
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
        outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		super.onSaveInstanceState(outState);
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		Resources res = getResources();
		
		// Set the screen title view.
		UIUtils.setTitleView(R.string.app_name, false, true, false, getSherlockActivity());
		
		mView.findViewById(R.id.textView_enter_id).setVisibility(View.INVISIBLE);
		TextView textViewEmailSignUpMsg = (TextView) mView.findViewById(R.id.textView_disclaimer_title);
		if (UIUtils.getRetailId(getActivity()) == CommonConfig.RETAILTYPE_ROBINSON) {
			textViewEmailSignUpMsg.setText(res.getString(R.string.email_signup_msg));
		}
		else{
		if (PreferenceConfig.getIsAppSupportRedemption(getActivity())) {
			textViewEmailSignUpMsg.setText(res.getString(R.string.email_signup_redeem_msg_first) +" " +res.getString(R.string.email_signup_redeem_msg_second));
		} else {
			textViewEmailSignUpMsg.setText(res.getString(R.string.email_signup_msg));
		} }
		textViewEmailSignUpMsg.setVisibility(View.VISIBLE);
		
		TextView textViewInfoMsg = (TextView) mView.findViewById(R.id.textView_disclaimer_text);
		String labelPrivacyPolicy = res.getString(R.string.email_info_msg);
		textViewInfoMsg.setText(labelPrivacyPolicy);
		textViewInfoMsg.setVisibility(View.VISIBLE);
		
		final TextView textViewPrivacyPolicy = (TextView) mView.findViewById(R.id.textView_disclaimer_text3);
		SpannableString spanString = new SpannableString(textViewPrivacyPolicy.getText().toString());
		spanString.setSpan(new UnderlineSpan(), 0, spanString.length(), 0);
		textViewPrivacyPolicy.setText(spanString);
		textViewPrivacyPolicy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Activity activity = getActivity();
				if (!NetworkHelper.isNetworkAvailable(activity)) {
					mErrorMessage = getResources().getString(R.string.network_not_available_msg);
					mErrorTitle = getResources().getString(R.string.network_not_available_title);
					showDialog(DialogConfig.DIALOG_ERROR);
					return;
				}
				Intent intent = new Intent(getActivity(), CustomWebViewActivity.class);
				intent.putExtra(CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_TITLE,
						textViewPrivacyPolicy.getText().toString());
				intent.putExtra(CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_URL, WSConfig.PRIVACY_POLICY_URL);
				startActivity(intent);
			}
		});
		
		mView.findViewById(R.id.LinearLayout_privacy_policy_container).setVisibility(View.VISIBLE);
		
		mEditTextEmailAddress = (EditText) mView.findViewById(R.id.editText_enter_id);
		try {
			final String emailId = EDUtils.getEmailID(getActivity());
			mEditTextEmailAddress.setText(emailId);
		} catch (Exception e) {
			e.printStackTrace();
			mEditTextEmailAddress.setText("");
		}
		mEditTextEmailAddress.setOnEditorActionListener(new EditText.OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_DONE 
			            || actionId == EditorInfo.IME_NULL
			            || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
					registerEmailAddress();
					return true;
				}
				return false;
			}
		});
		mButtonOk = (Button) mView.findViewById(R.id.Button_ok);
		mButtonOk.setText(res.getString(R.string.label_sign_up));
		mButtonOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				registerEmailAddress();
			}
		});
		mButtonCancel = (Button) mView.findViewById(R.id.Button_cancel);
		mButtonCancel.setText(res.getString(R.string.no_thanks));
		mButtonCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				PreferenceConfig.setEmailScreenShown(true, getActivity());
				launchHomeZipCodeActivity();
			}
		});
	}
	
	/** Make server request to register user email address. */
	private void callRegisterEmailWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(EnterEmailFragment.this);
		params.putString(CommonConfig.KEY_NAME_EMAIL_ADDRESS,
				mEditTextEmailAddress.getText().toString().trim().toLowerCase());
		params.putByte(LoginWorker.KEY_NAME_BUNDLE_LOGIN_WORKER_MODE, LoginWorker.WORKER_MODE_REGISTER_EMAIL_ADDRESS);
		mRequestId = mRequestManager.registerEmailAddress(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			// must reset refreshing, if requested or not.
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(EnterEmailFragment.this);
			mRequestId = -1;
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
 
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				emailRegisteredSuccessfullyDoSomething();
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
		}
	};
	
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
			
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_INVALID_EMAIL:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.dialog_error_title)
			.setMessage(R.string.invalid_email)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int arg1) {
					dialog.dismiss();
				}
			}) ;
			break;
			
		case DialogConfig.DIALOG_EXIT_APP:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(R.string.msg_app_exit_confirmation)
			.setCancelable(true)
			.setPositiveButton(R.string.label_yes,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						dialog.dismiss();
						getActivity().finish();
						
						// Show the GPS Settings if GPS was switched off
						// initially while launching
						if (PreferenceConfig.isDefaultGPSStatus(mContext) != PreferenceConfig.getCurrentGPSStatus(mContext)) {
							startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
						}
					}
				})
			.setNegativeButton(R.string.label_no,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						// Removing dialog box
						dialog.dismiss();
					}
				});
			break;
		}
		dlg.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logd(LOG_TAG, "onDestroy()");
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_login_screen));
		   System.gc();
	   }
	   PreferenceConfig.setEmailScreenVisiblity(false, getActivity());
	}
	
	/** A method to perform required acton after successfully registering user email address. */
	private void emailRegisteredSuccessfullyDoSomething() {
		Intent intent = new Intent(getActivity(), EnterTokenActivity.class);
		intent.putExtra(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
				mResponseBundle.getString(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
		startActivity(intent);
		getActivity().finish();
	}
	
	/** A method to register email address. if valid email address is entered then it make network
	 * call to register user email address. 
	**/
	private void registerEmailAddress() {
		UIUtils.hideKeyboard(getActivity(), mEditTextEmailAddress);
		if (TextUtils.isEmpty(mEditTextEmailAddress.getText().toString().trim())) {
			showDialog(DialogConfig.DIALOG_INVALID_EMAIL);
		} else {
			if(ShareHelper.isValidEmail(mEditTextEmailAddress.getText().toString().trim().toLowerCase())) {
				callRegisterEmailWS();
			} else {
				showDialog(DialogConfig.DIALOG_INVALID_EMAIL);
			}
		}
	}
	
	/** A method to launch home zip code activity. */
	private void launchHomeZipCodeActivity() {
		startActivity(new Intent(getActivity(), EnterHomeZipCodeActivity.class));
		getActivity().finish();
	}
}
