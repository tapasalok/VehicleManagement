/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.config;


/**
 * A common configuration interface that will holds the various constants to use
 * anywhere in the app.
 * 
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 * 
 */
public interface CommonConfig {
	
	public final String KEY_NAME_RESPONSE_STATUS = "com.manthansystems.loyalty.config.CommonConfig#response_status";
	public final String KEY_NAME_ERROR_MSG = "com.manthansystems.loyalty.config.CommonConfig#error_msg";
	public final String KEY_NAME_ERROR_CODE = "com.manthansystems.loyalty.config.CommonConfig#error_code";
	public final String SERVER_RESPONSE = "com.manthansystems.loyalty.config.CommonConfig#server_response";
	
	public final String KEY_NAME_OFFER_LIST = "com.manthansystems.loyalty.config.CommonConfig#offerList";
	public final String KEY_NAME_STORE_LIST = "com.manthansystems.loyalty.config.CommonConfig#storeList";
	public final String KEY_NAME_EMAIL_ADDRESS = "com.manthansystems.loyalty.config.CommonConfig#emailAddress";
	public final String KEY_NAME_TOKEN = "com.manthansystems.loyalty.config.CommonConfig#token";
	public final String KEY_NAME_ZIP_CODE = "com.manthansystems.loyalty.config.CommonConfig#zipCode";
	public final String KEY_NAME_RESULTS_MESSAGE = "com.manthansystems.loyalty.config.CommonConfig#message";
	public final String KEY_NAME_LOGIN_TOKEN = "com.manthansystems.loyalty.config.CommonConfig#loginToken";
	public final String KEY_NAME_SESSION_ID = "com.manthansystems.loyalty.config.CommonConfig#sessionId";
	
	public final String KEY_NAME_DOWNLOAD_MODE = "com.manthansystems.loyalty.config.CommonConfig#downloadMode";
	public final String KEY_NAME_ALL_CATEGORY_LIST = "com.manthansystems.loyalty.config.CommonConfig#allCategoryList";
	public final String KEY_NAME_USER_CATEGORY_LIST = "com.manthansystems.loyalty.config.CommonConfig#userCategoryList";
	public final String KEY_NAME_APP_CONFIG_MAP = "com.manthansystems.loyalty.config.CommonConfig#appConfigMap";
	public final String KEY_NAME_IS_NEW_HOMEZIP = "com.manthansystems.loyalty.config.CommonConfig#newHomezip";
	
	public final String KEY_NAME_LAT_FOR_ZIPCODE = "com.manthansystems.loyalty.config.CommonConfig#latForZipCode";
	public final String KEY_NAME_LON_FOR_ZIPCODE = "com.manthansystems.loyalty.config.CommonConfig#lonForZipCode";
	
	public final String KEY_NAME_PERSONAL_OFFER_COUNT = "com.manthansystems.loyalty.config.CommonConfig#personalOfferCount";
	public final String KEY_NAME_COMMON_OFFER_COUNT= "com.manthansystems.loyalty.config.CommonConfig#commonOfferCount";
	public final String KEY_NAME_FAVORITE_OFFER_COUNT = "com.manthansystems.loyalty.config.CommonConfig#favoriteOfferCount";
	
	public final String KEY_NAME_NOTIFICATION_OFFER_TYPE = "com.manthansystems.loyalty.config.CommonConfig#offerType";
	public final String KEY_NAME_NOTIFICATION_OFFER_ARRAY_LIST = "com.manthansystems.loyalty.config.CommonConfig#offerArrayList";
	public final String KEY_NAME_NOTIFICATION_OFFER_ALERT = "com.manthansystems.loyalty.config.CommonConfig#offerAlert";
	public final String KEY_NAME_CATEGORY_COUNT = "com.manthansystems.loyalty.config.CommonConfig#categoryCount";
	
	//Loyalty Card
	public final String KEY_NAME_LOYALTY_CARD_EMAIL = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardEmail";
	public final String KEY_NAME_LOYALTY_CARD_FIRST_NAME = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardFirstName";
	public final String KEY_NAME_LOYALTY_CARD_IMAGE_URL = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardImageUrl";
	public final String KEY_NAME_LOYALTY_CARD_TOTAL_REWARDS = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardTotalRewards";
	public final String KEY_NAME_LOYALTY_CARD_TOTAL_REWARDS_DAY = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardTotalRewardsDay";
	public final String KEY_NAME_LOYALTY_CARD_EXPIRY_DAYS = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardExpiryDays";
	public final String KEY_NAME_LOYALTY_CARD_EXPIRY_REWARDS = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardExpiryRewards";
	public final String KEY_NAME_LOYALTY_CARD_HISTORY_LIST = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardHisoryList";
	public final String KEY_NAME_LOYALTY_CARD_NUMBER = "com.manthansystems.loyalty.config.CommonConfig#loyaltyCardNumber";
	
	public final String KEY_NAME_REDEEM_AVAILABLE = "com.manthansystems.loyalty.config.CommonConfig#redeemAvailable";
	
	public final String KEY_NAME_UPDATE_TYPE = "com.manthansystems.loyalty.config.CommonConfig#updateType";
	public final String KEY_NAME_UPDATE_AVAILABLE = "com.manthansystems.loyalty.config.CommonConfig#updateAvailable";
	public final String KEY_NAME_UPDATE_MESSAGE = "com.manthansystems.loyalty.config.CommonConfig#updateMessage";
	public final String KEY_NAME_UPDATE_VERSION = "com.manthansystems.loyalty.config.CommonConfig#updateVersion";
	public final String KEY_NAME_UPDATE_OBSOLETE = "com.manthansystems.loyalty.config.CommonConfig#updateObsolete";
    
	// used in activity results
	public final int REQUEST_CODE_FOR_LOCATION_SETTINGS = 1;
	public final int REQUEST_CODE_FOR_CATEGORY_FILTER = 2;
	
	// Used to check if home zip is new or is the old one from Location setting screen.
	public final byte OLD_HOMEZIP = 0;
	public final byte NEW_HOMEZIP = 1;
	
	// Used as common True/False flags.
	public final int FLAG_TRUE = 1;
	public final int FLAG_FALSE = 0;
	
	// Error code constant that comes from server when an offer is exhausted.
	public final String ERROR_CODE_OFFER_EXHAUSTED = "4002";
	// Error code constant that comes from server when there is no Loyalty Card registerd with user.
	public final String ERROR_CODE_NO_LOYALTY_CARD_REGISTERED = "3003";
	public final String ERROR_CODE_NO_LOYALTY_CARD_DELETED = "3005";
	public  final String ZIP = "zip";
	public  final String STORE_ID="store_id";
	
	public  final Integer RETAILTYPE_ROBINSON = 1;
	public  final Integer RETAILTYPE_COMMON = 0;
}
