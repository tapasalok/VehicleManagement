/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

/**
 * A model class that data for category counting. 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class HomeCategoryCount {
	public String mOfferId;
	public String mCategoryId;
	public int mOfferType;

	/** Default Constructor. */
	public HomeCategoryCount() {
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			// Do nothing.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.finalize();
		}
	}
}
