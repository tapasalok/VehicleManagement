/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.data.provider;

import java.util.ArrayList;

import android.content.ContentProviderOperation;
import android.content.ContentProviderOperation.Builder;
import android.content.ContentValues;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.provider.BaseColumns;

import com.manthansystems.loyalty.data.provider.util.DatabaseUtil;
import com.manthansystems.loyalty.model.Category;
import com.manthansystems.loyalty.model.CategoryCount;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.HomeCategoryCount;
import com.manthansystems.loyalty.model.HomeCoupon;
import com.manthansystems.loyalty.model.HomeStore;
import com.manthansystems.loyalty.model.Store;

/**
 * DataContent is the superclass of the various classes of content stored
 * by {@link DataProvider}. It adds to DataContent the
 * AUTHORITY and CONTENT_URI.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 */
public abstract class DatabaseContent {
    public static final Uri CONTENT_URI = Uri.parse("content://" + DatabaseProvider.AUTHORITY);
    
    /**
	 * This interface holds the column names of {@link Store} dao table.
	 * 
	 * @author Rakesh Saytode { rakesh.saytode@xymob.com }
	 */
	public interface StoreDaoColumns {
		public final String STORE_ID = "STORE_ID";
		public final String STORE_ADDRESS1 = "ADDRESS1";
		public final String STORE_CITY = "CITY";
		public final String STORE_STATE = "STATE";
		public final String STORE_ZIP = "ZIP";
		public final String STORE_LAT = "LAT";
		public final String STORE_LONG = "LONG";
		public final String STORE_ADDRESS2 = "ADDRESS2";
		public final String STORE_PHONE = "PHONE";
		public final String STORE_NAME = "NAME";
	}

	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link Store} dao table.
	 * 
	 * @author Rakesh Saytode { rakesh.saytode@xymob.com }
	 */
	public static final class StoreDao extends DatabaseContent implements
			StoreDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_STORE";
		public static final Uri CONTENT_URI = Uri
				.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.store";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.store";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_STORE_ID_COLUMN = 1;
		public static final int CONTENT_STORE_ADDRESS1_COLUMN = 2;
		public static final int CONTENT_STORE_CITY_COLUMN = 3;
		public static final int CONTENT_STORE_STATE_COLUMN = 4;
		public static final int CONTENT_STORE_ZIP_COLUMN = 5;
		public static final int CONTENT_STORE_LAT_COLUMN = 6;
		public static final int CONTENT_STORE_LONG_COLUMN = 7;
		public static final int CONTENT_STORE_ADDRESS2_COLUMN = 8;
		public static final int CONTENT_STORE_PHONE_COLUMN = 9;
		public static final int CONTENT_STORE_NAME_COLUMN = 10;

		public static final String WHERE_CLAUSE_STORE_ID = STORE_ID + "=";
		public static final String WHERE_CLAUSE_STORE_IDS_IN = STORE_ID + " IN ";
		
		/** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + STORE_ID
				+ " text, " + STORE_ADDRESS1 + " text, " + STORE_CITY 
				+ " text, " + STORE_STATE + " text, " + STORE_ZIP 
				+ " text, " + STORE_LAT + " text, " + STORE_LONG
				+ " text, " + STORE_ADDRESS2 + " text, " + STORE_PHONE 
				+ " text, " + STORE_NAME + " text);";

			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil
					.getCreateIndexString(TABLE_NAME, STORE_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(STORE_ID);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_ADDRESS1);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_CITY);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_STATE);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_ZIP);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_LAT);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_LONG);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_ADDRESS2);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_PHONE);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_NAME);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			String value = values.getAsString(STORE_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_ADDRESS1);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_CITY);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_STATE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_ZIP);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_LAT);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_LONG);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_ADDRESS2);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_PHONE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_NAME);
			stmt.bindString(i++, value != null ? value : "");
		}

		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final Store store) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(STORE_ID, store.mId)
				.withValue(STORE_ADDRESS1, store.mAddress1)
				.withValue(STORE_CITY, store.mCity)
				.withValue(STORE_STATE, store.mState)
				.withValue(STORE_ZIP, store.mZip)
				.withValue(STORE_LAT, store.mLat)
				.withValue(STORE_LONG, store.mLong)
				.withValue(STORE_ADDRESS2, store.mAddress2)
				.withValue(STORE_PHONE, store.mPhoneNumber)
				.withValue(STORE_NAME, store.mName);
			ops.add(builder.build());
		}
		
		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final Store store,
				final byte storeChooser, final int couponCount,
				final String firstCouponTitle) {
			ContentValues values = new ContentValues();
			values.put(STORE_ID, store.mId);
			values.put(STORE_ADDRESS1, store.mAddress1);
			values.put(STORE_CITY, store.mCity);
			values.put(STORE_STATE, store.mState);
			values.put(STORE_ZIP, store.mZip);
			values.put(STORE_LAT, store.mLat);
			values.put(STORE_LONG, store.mLong);
			values.put(STORE_ADDRESS2, store.mAddress2);
			values.put(STORE_PHONE, store.mPhoneNumber);
			values.put(STORE_NAME, store.mName);
			return values;
		}
	}

	/**
	 * This interface holds the column names of {@link Coupon} dao table.
	 * 
	 * @author Rakesh Saytode { rakesh.saytode@xymob.com }
	 */
	public interface CouponDaoColumns {
		public final String COUPON_ID = "COUPON_ID";
		public final String COUPON_NAME = "COUPON_NAME";
		public final String COUPON_DESCRIPTION = "DESCRIPTION";
		public final String COUPON_IMAGE_URL = "IMAGE_URL";
		public final String COUPON_URL = "COUPON_URL";
		public final String EXPIRY_DATE = "EXPIRY_DATE";
		public final String COUPON_TYPE = "COUPON_TYPE";
		public final String DISCOUNT = "DISCOUNT";
		public final String COUPON_FAVORITE_FLAG = "FAVORITE";
		public final String COUPON_CHOOSER = "COUPON_CHOOSER";
		public final String EXPIRES = "EXPIRES";
		public final String STORE_IDS = "STORE_IDS";
		public final String DECORATORS = "DECORATORS";
		public final String COUPON_LARGE_IMAGE_URL = "COUPON_LARGE_IMAGE_URL";
		public final String BARCODE = "BARCODE";
		public final String BARCODE_IMAGE_URL = "BARCODE_IMAGE_URL";
		public final String COUPON_CODE = "COUPON_CODE";
		public final String IS_NEW_COUPON = "IS_NEW_COUPON";
		public final String COUPON_LONG_DESCRIPTION = "LONG_DESCRIPTION";
		public final String IS_MARKETING_MESSAGE = "IS_MARKETING_MESSAGE";
		public final String REDEEMABLE_FLAG = "REDEEMABLE";
		public final String USAGE_TYPE = "USAGE_TYPE";
		public final String REDEEM_THRESHOLD_LIMIT = "REDEEM_THRESHOLD_LIMIT";
		public final String EXHAUSTED_FLAG = "EXHAUSTED";
	}
	
	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link Coupon} dao table.
	 * 
	 * @author Rakesh Saytode { rakesh.saytode@xymob.com }
	 */
	public static final class CouponDao extends DatabaseContent implements
			CouponDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_COUPON";
		public static final String TABLE_NAME_FAVORITE = "TBL_FAVORITE";
		public static final String TABLE_NAME_FILTER_COUPON = "TABLE_NAME_FILTER_COUPON";
		
		public static final Uri CONTENT_URI = Uri.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
	    public static final Uri CONTENT_URI_FAVORITE = Uri.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME_FAVORITE);
	    public static final Uri CONTENT_URI_FILTER_COUPON = Uri.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME_FILTER_COUPON);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.coupon";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.coupon";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_COUPON_ID_COLUMN = 1;
		public static final int CONTENT_COUPON_NAME_COLUMN = 2;
		public static final int CONTENT_COUPON_DESCRIPTION_COLUMN = 3;
		public static final int CONTENT_COUPON_IMAGE_URL_COLUMN = 4;
		public static final int CONTENT_COUPON_URL_COLUMN = 5;
		public static final int CONTENT_EXPIRY_DATE_COLUMN = 6;
		public static final int CONTENT_COUPON_TYPE_COLUMN = 7;
		public static final int CONTENT_DISCOUNT_COLUMN = 8;
		public static final int CONTENT_COUPON_FAVORITE_FLAG_COLUMN = 9;
		public static final int CONTENT_COUPON_CHOOSER_COLUMN = 10;
		public static final int CONTENT_EXPIRES_COLUMN = 11;
		public static final int CONTENT_STORE_IDS_COLUMN = 12;
		public static final int CONTENT_DECORATORS_COLUMN = 13;
		public static final int CONTENT_COUPON_LARGE_IMAGE_URL_COLUMN = 14;
		public static final int CONTENT_BARCODE_COLUMN = 15;
		public static final int CONTENT_BARCODE_IMAGE_URL_COLUMN = 16;
		public static final int CONTENT_COUPON_CODE_COLUMN = 17;
		public static final int CONTENT_IS_NEW_COUPON = 18;
		public static final int CONTENT_COUPON_LONG_DESCRIPTION = 19;
		public static final int CONTENT_IS_MARKETING_MESSAGE_COLUMN = 20;
		public static final int CONTENT_REDEEMABLE_FLAG_COLUMN = 21;
		public static final int CONTENT_USAGE_TYPE_COLUMN = 22;
		public static final int CONTENT_REDEEM_THRESHOLD_LIMIT_COLUMN = 23;
		public static final int CONTENT_EXHAUSTED_FLAG_COLUMN = 24;
		
		public static final int FLAG_VALUE_FAVOURITE_ENABLE = 1;
		public static final int FLAG_VALUE_FAVOURITE_DISABLE = 0;
		
		public static final int FLAG_VALUE_NEW_COUPON = 1;
		public static final int FLAG_VALUE_NOT_NEW_COUPON = 0;
		
		public static final int FLAG_VALUE_MARKETING_MESSAGE = 1;
		public static final int FLAG_VALUE_NON_MARKETING_MESSAGE = 0;
		
		public static final String WHERE_CLAUSE_COUPON_ID = COUPON_ID + "=";
		public static final String WHERE_CLAUSE_COUPON_IDS_IN = COUPON_ID + " IN ";
		public static final String WHERE_CLAUSE_COUPON_CHOOSER = COUPON_CHOOSER + "=";
		public static final String WHERE_CLAUSE_COUPON_CHOOSER_NOT = COUPON_CHOOSER + "!=";
		public static final String WHERE_CLAUSE_FAVORITE_COUPON = COUPON_FAVORITE_FLAG + "=";
		
        /** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + COUPON_ID
				+ " integer, " + COUPON_NAME + " text, " + COUPON_DESCRIPTION + " text, "
				+ COUPON_IMAGE_URL + " text, " + COUPON_URL + " text, " + EXPIRY_DATE 
				+ " text, " + COUPON_TYPE + " text, " + DISCOUNT + " text , " 
				+ COUPON_FAVORITE_FLAG + " integer, " + COUPON_CHOOSER
				+ " integer, " + EXPIRES + " integer, " + STORE_IDS + " text, "
				+ DECORATORS + " text, " + COUPON_LARGE_IMAGE_URL + " text, " + BARCODE + " text, " 
				+ BARCODE_IMAGE_URL + " text, " + COUPON_CODE + " text, " 
				+ IS_NEW_COUPON + " integer, " + COUPON_LONG_DESCRIPTION + " text, "
				+ IS_MARKETING_MESSAGE + " integer, "
				+ REDEEMABLE_FLAG + " integer, " + USAGE_TYPE + " integer, "
				+ REDEEM_THRESHOLD_LIMIT + " integer, " + EXHAUSTED_FLAG + " integer "  + ");";
			
			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil.getCreateIndexString(TABLE_NAME,
					COUPON_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(COUPON_ID);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_NAME);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_DESCRIPTION);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_IMAGE_URL);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_URL);
			sqlRequest.append(", ");
			sqlRequest.append(EXPIRY_DATE);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_TYPE);
			sqlRequest.append(", ");
			sqlRequest.append(DISCOUNT);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_FAVORITE_FLAG);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_CHOOSER);
			sqlRequest.append(", ");
			sqlRequest.append(EXPIRES);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_IDS);
			sqlRequest.append(", ");
			sqlRequest.append(DECORATORS);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_LARGE_IMAGE_URL);
			sqlRequest.append(", ");
			sqlRequest.append(BARCODE);
			sqlRequest.append(", ");
			sqlRequest.append(BARCODE_IMAGE_URL);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_CODE);
			sqlRequest.append(", ");
			sqlRequest.append(IS_NEW_COUPON);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_LONG_DESCRIPTION);
			sqlRequest.append(", ");
			sqlRequest.append(IS_MARKETING_MESSAGE);
			sqlRequest.append(", ");
			sqlRequest.append(REDEEMABLE_FLAG);
			sqlRequest.append(", ");
			sqlRequest.append(USAGE_TYPE);
			sqlRequest.append(", ");
			sqlRequest.append(REDEEM_THRESHOLD_LIMIT);
			sqlRequest.append(", ");
			sqlRequest.append(EXHAUSTED_FLAG);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			stmt.bindLong(i++, values.getAsInteger(COUPON_ID));
			String value = values.getAsString(COUPON_NAME);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_DESCRIPTION);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_IMAGE_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(EXPIRY_DATE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_TYPE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(DISCOUNT);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(COUPON_FAVORITE_FLAG));
			stmt.bindLong(i++, values.getAsInteger(COUPON_CHOOSER));
			stmt.bindLong(i++, values.getAsInteger(EXPIRES));
			value = values.getAsString(STORE_IDS);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(DECORATORS);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_LARGE_IMAGE_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(BARCODE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(BARCODE_IMAGE_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_CODE);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(IS_NEW_COUPON));
			value = values.getAsString(COUPON_LONG_DESCRIPTION);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(IS_MARKETING_MESSAGE));
			stmt.bindLong(i++, values.getAsInteger(REDEEMABLE_FLAG));
			stmt.bindLong(i++, values.getAsInteger(USAGE_TYPE));
			stmt.bindLong(i++, values.getAsInteger(REDEEM_THRESHOLD_LIMIT));
			stmt.bindLong(i++, values.getAsInteger(EXHAUSTED_FLAG));
		}
		
		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final Coupon coupon) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(COUPON_ID, coupon.mId)
				.withValue(COUPON_NAME, coupon.mTitle)
				.withValue(COUPON_DESCRIPTION, coupon.mDescription)
				.withValue(COUPON_IMAGE_URL, coupon.mImageUrl)
				.withValue(COUPON_URL, coupon.mCouponUrl)
				.withValue(EXPIRY_DATE, coupon.mExpiryDate)
				.withValue(COUPON_TYPE, coupon.mCouponType)
				.withValue(DISCOUNT, coupon.mDiscount)
				.withValue(COUPON_FAVORITE_FLAG, coupon.mFavoriteFlag)
				.withValue(COUPON_CHOOSER, coupon.mCouponChooser)
				.withValue(EXPIRES, coupon.mExpires)
				.withValue(STORE_IDS, coupon.mStoreIds.toString())
				.withValue(DECORATORS, coupon.mDecorators.toString())
				.withValue(COUPON_LARGE_IMAGE_URL, coupon.mLargeImageUrl)
				.withValue(BARCODE, coupon.mBarcode)
				.withValue(BARCODE_IMAGE_URL, coupon.mBarcodeImageUrl)
				.withValue(COUPON_CODE, coupon.mCouponCode)
				.withValue(IS_NEW_COUPON, coupon.mIsNewCouponFlag)
				.withValue(COUPON_LONG_DESCRIPTION, coupon.mLongDescription)
				.withValue(IS_MARKETING_MESSAGE, coupon.mIsMarketingMessageFlag)
				.withValue(REDEEMABLE_FLAG, coupon.mRedeemableFlag)
				.withValue(USAGE_TYPE, coupon.mUsageType)
				.withValue(REDEEM_THRESHOLD_LIMIT, coupon.mThresholdLimit)
				.withValue(EXHAUSTED_FLAG, coupon.mExhaustedFlag);
			ops.add(builder.build());
		}

		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final Coupon coupon) {
			ContentValues values = new ContentValues();
			values.put(COUPON_ID, coupon.mId);
			values.put(COUPON_NAME, coupon.mTitle);
			values.put(COUPON_DESCRIPTION, coupon.mDescription);
			values.put(COUPON_IMAGE_URL, coupon.mImageUrl);
			values.put(COUPON_URL, coupon.mCouponUrl);
			values.put(EXPIRY_DATE, coupon.mExpiryDate);
			values.put(COUPON_TYPE, coupon.mCouponType);
			values.put(DISCOUNT, coupon.mDiscount);
			values.put(COUPON_FAVORITE_FLAG, coupon.mFavoriteFlag);
			values.put(COUPON_CHOOSER, coupon.mCouponChooser);
			values.put(EXPIRES, coupon.mExpires);
			values.put(STORE_IDS, coupon.mStoreIds.toString());
			values.put(DECORATORS, coupon.mDecorators.toString());
			values.put(COUPON_LARGE_IMAGE_URL, coupon.mLargeImageUrl);
			values.put(BARCODE, coupon.mBarcode);
			values.put(BARCODE_IMAGE_URL, coupon.mBarcodeImageUrl);
			values.put(COUPON_CODE, coupon.mCouponCode);
			values.put(IS_NEW_COUPON, coupon.mIsNewCouponFlag);
			values.put(COUPON_LONG_DESCRIPTION, coupon.mLongDescription);
			values.put(IS_MARKETING_MESSAGE, coupon.mIsMarketingMessageFlag);
			values.put(REDEEMABLE_FLAG, coupon.mRedeemableFlag);
			values.put(USAGE_TYPE, coupon.mUsageType);
			values.put(REDEEM_THRESHOLD_LIMIT, coupon.mThresholdLimit);
			values.put(EXHAUSTED_FLAG, coupon.mExhaustedFlag);
			return values;
		}
	}
	
	/**
	 * This interface holds the column names of {@link Category} dao table.
	 * 
	 * @author Gaurav Agrawal { gaurav.agrawal@xymob.com }
	 */
	public interface CategoryDaoColumns {
		public static final String CATEGORY_ID = "CATEGORY_ID";
		public static final String CATEGORY_NAME = "CATEGORY_NAME";
		public static final String CATEGORY_CHECK_FLAG = "CATEGORY_CHECK_FLAG";
		public static final String CATEGORY_OWNER_ID = "CATEGORY_OWNER_ID";
		public static final String IS_MAIN_CATEGORY = "IS_MAIN_CATEGORY";
	}

	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link Category} dao table.
	 * 
	 * @author Gaurav Agrawal { gaurav.agrawal@xymob.com }
	 */
	public static final class CategoryDao extends DatabaseContent implements
			CategoryDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_CATEGORY";
		public static final Uri CONTENT_URI = Uri
				.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.category";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.category";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_CATEGORY_ID_COLUMN = 1;
		public static final int CONTENT_CATEGORY_NAME_COLUMN = 2;
		public static final int CONTENT_CATEGORY_CHECK_FLAG_COLUMN = 3;
		public static final int CONTENT_CATEGORY_OWNER_ID_COLUMN = 4;
		public static final int CONTENT_IS_MAIN_CATEGORY_COLUMN = 5;
		
		public static final int FLAG_VALUE_MAIN_CATEGORY = 1;
		public static final int FLAG_VALUE_SUB_CATEGORY = 0;
		
		/** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + CATEGORY_ID
				+ " text, " + CATEGORY_NAME + " text, " + CATEGORY_CHECK_FLAG 
				+ " text, " + CATEGORY_OWNER_ID + " text, " + IS_MAIN_CATEGORY + " integer);";

			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil
					.getCreateIndexString(TABLE_NAME, CATEGORY_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(CATEGORY_ID);
			sqlRequest.append(", ");
			sqlRequest.append(CATEGORY_NAME);
			sqlRequest.append(", ");
			sqlRequest.append(CATEGORY_CHECK_FLAG);
			sqlRequest.append(", ");
			sqlRequest.append(CATEGORY_OWNER_ID);
			sqlRequest.append(", ");
			sqlRequest.append(IS_MAIN_CATEGORY);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			String value = values.getAsString(CATEGORY_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(CATEGORY_NAME);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(CATEGORY_CHECK_FLAG);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(CATEGORY_OWNER_ID);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(IS_MAIN_CATEGORY));
		}

		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final Category category) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(CATEGORY_ID, category.mCategoryId)
				.withValue(CATEGORY_NAME, category.mCategoryName)
				.withValue(CATEGORY_CHECK_FLAG, category.mCategoryCheckFlag)
				.withValue(CATEGORY_OWNER_ID, category.mCategoryOwnerId)
				.withValue(IS_MAIN_CATEGORY, category.mIsCategory);
			ops.add(builder.build());
		}
		
		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final Category category) {
			ContentValues values = new ContentValues();
			values.put(CATEGORY_ID, category.mCategoryId);
			values.put(CATEGORY_NAME, category.mCategoryName);
			values.put(CATEGORY_CHECK_FLAG, category.mCategoryCheckFlag);
			values.put(CATEGORY_OWNER_ID, category.mCategoryOwnerId);
			values.put(IS_MAIN_CATEGORY, category.mIsCategory);
			return values;
		}
	}
	
	/**
	 * This interface holds the column names of {@link CategoryCountDao} dao table.
	 * 
	 * @author Gaurav Agrawal { gaurav.agrawal@xymob.com }
	 */
	public interface CategoryCountDaoColumns {
		public static final String CATEGORY_ID = "CATEGORY_ID";
		public static final String OFFER_ID = "OFFER_ID";
		public static final String OFFER_TYPE = "OFFER_TYPE";
	}

	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link CategoryCountDao} dao table.
	 * 
	 * @author Gaurav Agrawal { gaurav.agrawal@xymob.com }
	 */
	public static final class CategoryCountDao extends DatabaseContent implements
		CategoryCountDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_CATEGORY_COUNT";
		public static final Uri CONTENT_URI = Uri
				.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.categoryCount";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.categoryCount";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_CATEGORY_ID_COLUMN = 1;
		public static final int CONTENT_OFFER_ID_COLUMN = 2;
		public static final int CONTENT_OFFER_TYPE_COLUMN = 3;
		
		/** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + CATEGORY_ID
				+ " text, " + OFFER_ID + " text, " + OFFER_TYPE + " text);";

			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil
					.getCreateIndexString(TABLE_NAME, CATEGORY_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(CATEGORY_ID);
			sqlRequest.append(", ");
			sqlRequest.append(OFFER_ID);
			sqlRequest.append(", ");
			sqlRequest.append(OFFER_TYPE);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			String value = values.getAsString(CATEGORY_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(OFFER_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(OFFER_TYPE);
			stmt.bindString(i++, value != null ? value : "");
		}

		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final CategoryCount categoryCount) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(CATEGORY_ID, categoryCount.mCategoryId)
				.withValue(OFFER_ID, categoryCount.mOfferId)
				.withValue(OFFER_TYPE, categoryCount.mOfferType);
			ops.add(builder.build());
		}
		
		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final CategoryCount CategoryCount) {
			ContentValues values = new ContentValues();
			values.put(CATEGORY_ID, CategoryCount.mCategoryId);
			values.put(OFFER_ID, CategoryCount.mOfferId);
			values.put(OFFER_TYPE, CategoryCount.mOfferType);
			return values;
		}
		public static final String WHERE_CLAUSE_OFFER_TYPE = OFFER_TYPE + " = ";
	}
	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link Coupon} dao table.
	 * 
	 * @author Rakesh Saytode { rakesh.saytode@xymob.com }
	 */
	public static final class CouponDaoHome extends DatabaseContent implements
			CouponDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_COUPON_HOME";
		public static final String TABLE_NAME_FAVORITE = "TBL_FAVORITE_HOME";
		public static final String TABLE_NAME_FILTER_COUPON = "TABLE_NAME_FILTER_COUPON_HOME";
		
		public static final Uri CONTENT_URI = Uri.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
	    public static final Uri CONTENT_URI_FAVORITE = Uri.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME_FAVORITE);
	    public static final Uri CONTENT_URI_FILTER_COUPON = Uri.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME_FILTER_COUPON);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.coupon";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.coupon";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_COUPON_ID_COLUMN = 1;
		public static final int CONTENT_COUPON_NAME_COLUMN = 2;
		public static final int CONTENT_COUPON_DESCRIPTION_COLUMN = 3;
		public static final int CONTENT_COUPON_IMAGE_URL_COLUMN = 4;
		public static final int CONTENT_COUPON_URL_COLUMN = 5;
		public static final int CONTENT_EXPIRY_DATE_COLUMN = 6;
		public static final int CONTENT_COUPON_TYPE_COLUMN = 7;
		public static final int CONTENT_DISCOUNT_COLUMN = 8;
		public static final int CONTENT_COUPON_FAVORITE_FLAG_COLUMN = 9;
		public static final int CONTENT_COUPON_CHOOSER_COLUMN = 10;
		public static final int CONTENT_EXPIRES_COLUMN = 11;
		public static final int CONTENT_STORE_IDS_COLUMN = 12;
		public static final int CONTENT_DECORATORS_COLUMN = 13;
		public static final int CONTENT_COUPON_LARGE_IMAGE_URL_COLUMN = 14;
		public static final int CONTENT_BARCODE_COLUMN = 15;
		public static final int CONTENT_BARCODE_IMAGE_URL_COLUMN = 16;
		public static final int CONTENT_COUPON_CODE_COLUMN = 17;
		public static final int CONTENT_IS_NEW_COUPON = 18;
		public static final int CONTENT_COUPON_LONG_DESCRIPTION = 19;
		public static final int CONTENT_IS_MARKETING_MESSAGE_COLUMN = 20;
		public static final int CONTENT_REDEEMABLE_FLAG_COLUMN = 21;
		public static final int CONTENT_USAGE_TYPE_COLUMN = 22;
		public static final int CONTENT_REDEEM_THRESHOLD_LIMIT_COLUMN = 23;
		public static final int CONTENT_EXHAUSTED_FLAG_COLUMN = 24;
		
		public static final int FLAG_VALUE_FAVOURITE_ENABLE = 1;
		public static final int FLAG_VALUE_FAVOURITE_DISABLE = 0;
		
		public static final int FLAG_VALUE_NEW_COUPON = 1;
		public static final int FLAG_VALUE_NOT_NEW_COUPON = 0;
		
		public static final int FLAG_VALUE_MARKETING_MESSAGE = 1;
		public static final int FLAG_VALUE_NON_MARKETING_MESSAGE = 0;
		
		public static final String WHERE_CLAUSE_COUPON_ID = COUPON_ID + "=";
		public static final String WHERE_CLAUSE_COUPON_IDS_IN = COUPON_ID + " IN ";
		public static final String WHERE_CLAUSE_COUPON_CHOOSER = COUPON_CHOOSER + "=";
		public static final String WHERE_CLAUSE_COUPON_CHOOSER_NOT = COUPON_CHOOSER + "!=";
		
        /** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + COUPON_ID
				+ " integer, " + COUPON_NAME + " text, " + COUPON_DESCRIPTION + " text, "
				+ COUPON_IMAGE_URL + " text, " + COUPON_URL + " text, " + EXPIRY_DATE 
				+ " text, " + COUPON_TYPE + " text, " + DISCOUNT + " text , " 
				+ COUPON_FAVORITE_FLAG + " integer, " + COUPON_CHOOSER
				+ " integer, " + EXPIRES + " integer, " + STORE_IDS + " text, "
				+ DECORATORS + " text, " + COUPON_LARGE_IMAGE_URL + " text, " + BARCODE + " text, " 
				+ BARCODE_IMAGE_URL + " text, " + COUPON_CODE + " text, " 
				+ IS_NEW_COUPON + " integer, " + COUPON_LONG_DESCRIPTION + " text, "
				+ IS_MARKETING_MESSAGE + " integer, "
				+ REDEEMABLE_FLAG + " integer, " + USAGE_TYPE + " integer, "
				+ REDEEM_THRESHOLD_LIMIT + " integer, " + EXHAUSTED_FLAG + " integer "  + ");";
			
			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil.getCreateIndexString(TABLE_NAME,
					COUPON_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(COUPON_ID);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_NAME);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_DESCRIPTION);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_IMAGE_URL);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_URL);
			sqlRequest.append(", ");
			sqlRequest.append(EXPIRY_DATE);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_TYPE);
			sqlRequest.append(", ");
			sqlRequest.append(DISCOUNT);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_FAVORITE_FLAG);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_CHOOSER);
			sqlRequest.append(", ");
			sqlRequest.append(EXPIRES);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_IDS);
			sqlRequest.append(", ");
			sqlRequest.append(DECORATORS);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_LARGE_IMAGE_URL);
			sqlRequest.append(", ");
			sqlRequest.append(BARCODE);
			sqlRequest.append(", ");
			sqlRequest.append(BARCODE_IMAGE_URL);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_CODE);
			sqlRequest.append(", ");
			sqlRequest.append(IS_NEW_COUPON);
			sqlRequest.append(", ");
			sqlRequest.append(COUPON_LONG_DESCRIPTION);
			sqlRequest.append(", ");
			sqlRequest.append(IS_MARKETING_MESSAGE);
			sqlRequest.append(", ");
			sqlRequest.append(REDEEMABLE_FLAG);
			sqlRequest.append(", ");
			sqlRequest.append(USAGE_TYPE);
			sqlRequest.append(", ");
			sqlRequest.append(REDEEM_THRESHOLD_LIMIT);
			sqlRequest.append(", ");
			sqlRequest.append(EXHAUSTED_FLAG);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			stmt.bindLong(i++, values.getAsInteger(COUPON_ID));
			String value = values.getAsString(COUPON_NAME);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_DESCRIPTION);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_IMAGE_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(EXPIRY_DATE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_TYPE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(DISCOUNT);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(COUPON_FAVORITE_FLAG));
			stmt.bindLong(i++, values.getAsInteger(COUPON_CHOOSER));
			stmt.bindLong(i++, values.getAsInteger(EXPIRES));
			value = values.getAsString(STORE_IDS);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(DECORATORS);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_LARGE_IMAGE_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(BARCODE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(BARCODE_IMAGE_URL);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(COUPON_CODE);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(IS_NEW_COUPON));
			value = values.getAsString(COUPON_LONG_DESCRIPTION);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(IS_MARKETING_MESSAGE));
			stmt.bindLong(i++, values.getAsInteger(REDEEMABLE_FLAG));
			stmt.bindLong(i++, values.getAsInteger(USAGE_TYPE));
			stmt.bindLong(i++, values.getAsInteger(REDEEM_THRESHOLD_LIMIT));
			stmt.bindLong(i++, values.getAsInteger(EXHAUSTED_FLAG));
		}
		
		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final HomeCoupon coupon) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(COUPON_ID, coupon.mId)
				.withValue(COUPON_NAME, coupon.mTitle)
				.withValue(COUPON_DESCRIPTION, coupon.mDescription)
				.withValue(COUPON_IMAGE_URL, coupon.mImageUrl)
				.withValue(COUPON_URL, coupon.mCouponUrl)
				.withValue(EXPIRY_DATE, coupon.mExpiryDate)
				.withValue(COUPON_TYPE, coupon.mCouponType)
				.withValue(DISCOUNT, coupon.mDiscount)
				.withValue(COUPON_FAVORITE_FLAG, coupon.mFavoriteFlag)
				.withValue(COUPON_CHOOSER, coupon.mCouponChooser)
				.withValue(EXPIRES, coupon.mExpires)
				.withValue(STORE_IDS, coupon.mStoreIds.toString())
				.withValue(DECORATORS, coupon.mDecorators.toString())
				.withValue(COUPON_LARGE_IMAGE_URL, coupon.mLargeImageUrl)
				.withValue(BARCODE, coupon.mBarcode)
				.withValue(BARCODE_IMAGE_URL, coupon.mBarcodeImageUrl)
				.withValue(COUPON_CODE, coupon.mCouponCode)
				.withValue(IS_NEW_COUPON, coupon.mIsNewCouponFlag)
				.withValue(COUPON_LONG_DESCRIPTION, coupon.mLongDescription)
				.withValue(IS_MARKETING_MESSAGE, coupon.mIsMarketingMessageFlag)
				.withValue(REDEEMABLE_FLAG, coupon.mRedeemableFlag)
				.withValue(USAGE_TYPE, coupon.mUsageType)
				.withValue(REDEEM_THRESHOLD_LIMIT, coupon.mThresholdLimit)
				.withValue(EXHAUSTED_FLAG, coupon.mExhaustedFlag);
			ops.add(builder.build());
		}

		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final HomeCoupon coupon) {
			ContentValues values = new ContentValues();
			values.put(COUPON_ID, coupon.mId);
			values.put(COUPON_NAME, coupon.mTitle);
			values.put(COUPON_DESCRIPTION, coupon.mDescription);
			values.put(COUPON_IMAGE_URL, coupon.mImageUrl);
			values.put(COUPON_URL, coupon.mCouponUrl);
			values.put(EXPIRY_DATE, coupon.mExpiryDate);
			values.put(COUPON_TYPE, coupon.mCouponType);
			values.put(DISCOUNT, coupon.mDiscount);
			values.put(COUPON_FAVORITE_FLAG, coupon.mFavoriteFlag);
			values.put(COUPON_CHOOSER, coupon.mCouponChooser);
			values.put(EXPIRES, coupon.mExpires);
			values.put(STORE_IDS, coupon.mStoreIds.toString());
			values.put(DECORATORS, coupon.mDecorators.toString());
			values.put(COUPON_LARGE_IMAGE_URL, coupon.mLargeImageUrl);
			values.put(BARCODE, coupon.mBarcode);
			values.put(BARCODE_IMAGE_URL, coupon.mBarcodeImageUrl);
			values.put(COUPON_CODE, coupon.mCouponCode);
			values.put(IS_NEW_COUPON, coupon.mIsNewCouponFlag);
			values.put(COUPON_LONG_DESCRIPTION, coupon.mLongDescription);
			values.put(IS_MARKETING_MESSAGE, coupon.mIsMarketingMessageFlag);
			values.put(REDEEMABLE_FLAG, coupon.mRedeemableFlag);
			values.put(USAGE_TYPE, coupon.mUsageType);
			values.put(REDEEM_THRESHOLD_LIMIT, coupon.mThresholdLimit);
			values.put(EXHAUSTED_FLAG, coupon.mExhaustedFlag);
			return values;
		}
	}
	
	
	
	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link Store} dao table.
	 * 
	 * @author Rakesh Saytode { rakesh.saytode@xymob.com }
	 */
	public static final class StoreDaoHome extends DatabaseContent implements
			StoreDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_STORE_HOME";
		public static final Uri CONTENT_URI = Uri
				.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.store";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.store";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_STORE_ID_COLUMN = 1;
		public static final int CONTENT_STORE_ADDRESS1_COLUMN = 2;
		public static final int CONTENT_STORE_CITY_COLUMN = 3;
		public static final int CONTENT_STORE_STATE_COLUMN = 4;
		public static final int CONTENT_STORE_ZIP_COLUMN = 5;
		public static final int CONTENT_STORE_LAT_COLUMN = 6;
		public static final int CONTENT_STORE_LONG_COLUMN = 7;
		public static final int CONTENT_STORE_ADDRESS2_COLUMN = 8;
		public static final int CONTENT_STORE_PHONE_COLUMN = 9;
		public static final int CONTENT_STORE_NAME_COLUMN = 10;

		public static final String WHERE_CLAUSE_STORE_ID = STORE_ID + "=";
		public static final String WHERE_CLAUSE_STORE_IDS_IN = STORE_ID + " IN ";
		
		/** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + STORE_ID
				+ " text, " + STORE_ADDRESS1 + " text, " + STORE_CITY 
				+ " text, " + STORE_STATE + " text, " + STORE_ZIP 
				+ " text, " + STORE_LAT + " text, " + STORE_LONG
				+ " text, " + STORE_ADDRESS2 + " text, " + STORE_PHONE 
				+ " text, " + STORE_NAME + " text);";

			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil
					.getCreateIndexString(TABLE_NAME, STORE_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(STORE_ID);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_ADDRESS1);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_CITY);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_STATE);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_ZIP);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_LAT);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_LONG);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_ADDRESS2);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_PHONE);
			sqlRequest.append(", ");
			sqlRequest.append(STORE_NAME);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			String value = values.getAsString(STORE_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_ADDRESS1);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_CITY);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_STATE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_ZIP);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_LAT);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_LONG);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_ADDRESS2);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_PHONE);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(STORE_NAME);
			stmt.bindString(i++, value != null ? value : "");
		}

		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final HomeStore store) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(STORE_ID, store.mId)
				.withValue(STORE_ADDRESS1, store.mAddress1)
				.withValue(STORE_CITY, store.mCity)
				.withValue(STORE_STATE, store.mState)
				.withValue(STORE_ZIP, store.mZip)
				.withValue(STORE_LAT, store.mLat)
				.withValue(STORE_LONG, store.mLong)
				.withValue(STORE_ADDRESS2, store.mAddress2)
				.withValue(STORE_PHONE, store.mPhoneNumber)
				.withValue(STORE_NAME, store.mName);
			ops.add(builder.build());
		}
		
		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final HomeStore store,
				final byte storeChooser, final int couponCount,
				final String firstCouponTitle) {
			ContentValues values = new ContentValues();
			values.put(STORE_ID, store.mId);
			values.put(STORE_ADDRESS1, store.mAddress1);
			values.put(STORE_CITY, store.mCity);
			values.put(STORE_STATE, store.mState);
			values.put(STORE_ZIP, store.mZip);
			values.put(STORE_LAT, store.mLat);
			values.put(STORE_LONG, store.mLong);
			values.put(STORE_ADDRESS2, store.mAddress2);
			values.put(STORE_PHONE, store.mPhoneNumber);
			values.put(STORE_NAME, store.mName);
			return values;
		}
	}

	
	
	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link Category} dao table.
	 * 
	 * @author Gaurav Agrawal { gaurav.agrawal@xymob.com }
	 */
	public static final class CategoryDaoHome extends DatabaseContent implements
			CategoryDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_CATEGORY_HOME";
		public static final Uri CONTENT_URI = Uri
				.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.category";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.category";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_CATEGORY_ID_COLUMN = 1;
		public static final int CONTENT_CATEGORY_NAME_COLUMN = 2;
		public static final int CONTENT_CATEGORY_CHECK_FLAG_COLUMN = 3;
		public static final int CONTENT_CATEGORY_OWNER_ID_COLUMN = 4;
		public static final int CONTENT_IS_MAIN_CATEGORY_COLUMN = 5;
		
		public static final int FLAG_VALUE_MAIN_CATEGORY = 1;
		public static final int FLAG_VALUE_SUB_CATEGORY = 0;
		
		/** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + CATEGORY_ID
				+ " text, " + CATEGORY_NAME + " text, " + CATEGORY_CHECK_FLAG 
				+ " text, " + CATEGORY_OWNER_ID + " text, " + IS_MAIN_CATEGORY + " integer);";

			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil
					.getCreateIndexString(TABLE_NAME, CATEGORY_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(CATEGORY_ID);
			sqlRequest.append(", ");
			sqlRequest.append(CATEGORY_NAME);
			sqlRequest.append(", ");
			sqlRequest.append(CATEGORY_CHECK_FLAG);
			sqlRequest.append(", ");
			sqlRequest.append(CATEGORY_OWNER_ID);
			sqlRequest.append(", ");
			sqlRequest.append(IS_MAIN_CATEGORY);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			String value = values.getAsString(CATEGORY_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(CATEGORY_NAME);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(CATEGORY_CHECK_FLAG);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(CATEGORY_OWNER_ID);
			stmt.bindString(i++, value != null ? value : "");
			stmt.bindLong(i++, values.getAsInteger(IS_MAIN_CATEGORY));
		}

		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final Category category) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(CATEGORY_ID, category.mCategoryId)
				.withValue(CATEGORY_NAME, category.mCategoryName)
				.withValue(CATEGORY_CHECK_FLAG, category.mCategoryCheckFlag)
				.withValue(CATEGORY_OWNER_ID, category.mCategoryOwnerId)
				.withValue(IS_MAIN_CATEGORY, category.mIsCategory);
			ops.add(builder.build());
		}
		
		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final Category category) {
			ContentValues values = new ContentValues();
			values.put(CATEGORY_ID, category.mCategoryId);
			values.put(CATEGORY_NAME, category.mCategoryName);
			values.put(CATEGORY_CHECK_FLAG, category.mCategoryCheckFlag);
			values.put(CATEGORY_OWNER_ID, category.mCategoryOwnerId);
			values.put(IS_MAIN_CATEGORY, category.mIsCategory);
			return values;
		}
	}
	
	
	/**
	 * This class holds the database handling methods, column index and 
	 * various support methods to prepare and execute queries for {@link CategoryCountDao} dao table.
	 * 
	 * @author Gaurav Agrawal { gaurav.agrawal@xymob.com }
	 */
	public static final class CategoryCountDaoHome extends DatabaseContent implements
		CategoryCountDaoColumns, BaseColumns {
		public static final String TABLE_NAME = "TBL_CATEGORY_COUNT_HOME";
		public static final Uri CONTENT_URI = Uri
				.parse(DatabaseContent.CONTENT_URI + "/" + TABLE_NAME);
		public static final String TYPE_ELEM_TYPE = "vnd.android.cursor.item/com.manthansystems.loyalty.data.provider.categoryCount";
		public static final String TYPE_DIR_TYPE = "vnd.android.cursor.dir/com.manthansystems.loyalty.data.provider.categoryCount";

		public static final int CONTENT_ID_COLUMN = 0;
		public static final int CONTENT_CATEGORY_ID_COLUMN = 1;
		public static final int CONTENT_OFFER_ID_COLUMN = 2;
		public static final int CONTENT_OFFER_TYPE_COLUMN = 3;
		
		/** Method to create the table by executing the db query. */
		static void createTable(final SQLiteDatabase db) {
			final String s = " (" + _ID
				+ " integer primary key autoincrement, " + CATEGORY_ID
				+ " text, " + OFFER_ID + " text, " + OFFER_TYPE + " text);";

			db.execSQL("create table " + TABLE_NAME + s);

			db.execSQL(DatabaseUtil
					.getCreateIndexString(TABLE_NAME, CATEGORY_ID));
		}

		/** Method to upgrade the table by executing the db query. */
		static void upgradeTable(final SQLiteDatabase db, final int oldVersion,
				final int newVersion) {
			try {
				db.execSQL("drop table " + TABLE_NAME);
			} catch (final SQLException e) {
			}
			createTable(db);
		}

		/** Method to get the bulk insert string to make query. */
		public static String getBulkInsertString() {
			final StringBuffer sqlRequest = new StringBuffer("INSERT INTO ");
			sqlRequest.append(TABLE_NAME);
			sqlRequest.append(" ( ");
			sqlRequest.append(CATEGORY_ID);
			sqlRequest.append(", ");
			sqlRequest.append(OFFER_ID);
			sqlRequest.append(", ");
			sqlRequest.append(OFFER_TYPE);
			sqlRequest.append(" ) ");
			sqlRequest.append(" VALUES (?, ?, ?)");
			return sqlRequest.toString();
		}

		/** Method to bind the bulk insert string with values to make query. */
		public static void bindValuesInBulkInsert(final SQLiteStatement stmt,
				final ContentValues values) {
			int i = 1;
			String value = values.getAsString(CATEGORY_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(OFFER_ID);
			stmt.bindString(i++, value != null ? value : "");
			value = values.getAsString(OFFER_TYPE);
			stmt.bindString(i++, value != null ? value : "");
		}

		/** Method to create the {@link Builder} for {@link ContentProviderOperation} to make db query. */
		public static void addContentValues(final Uri content_uri,
				final ArrayList<ContentProviderOperation> ops, final HomeCategoryCount categoryCount) {
			Builder builder = ContentProviderOperation.newInsert(content_uri);
			builder.withValue(CATEGORY_ID, categoryCount.mCategoryId)
				.withValue(OFFER_ID, categoryCount.mOfferId)
				.withValue(OFFER_TYPE, categoryCount.mOfferType);
			ops.add(builder.build());
		}
		
		/** Method to get content values to make query. */
		public static ContentValues getContentValues(final HomeCategoryCount CategoryCount) {
			ContentValues values = new ContentValues();
			values.put(CATEGORY_ID, CategoryCount.mCategoryId);
			values.put(OFFER_ID, CategoryCount.mOfferId);
			values.put(OFFER_TYPE, CategoryCount.mOfferType);
			return values;
		}
		public static final String WHERE_CLAUSE_OFFER_TYPE = OFFER_TYPE + " = ";
	}
}
