/**
 * Copyright 2013 XYMOB Inc.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView.FindListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadMode;
import com.manthansystems.loyalty.worker.LoginWorker;
import com.manthansystems.loyalty.worker.SettingsWorker;

/**
 * A Fragment class that will manager user entered zip code. This class extends
 * {@link SherlockFragmentActivity}.
 * @author Gaurav Agrawal: gaurav.agrawal@xymob.com
 */
public class EnterHomeZipCodeFragment extends SherlockFragment  implements
		  OnRequestFinishedListener {

	private final String LOG_TAG = "EnterHomeZipCodeFragment";
	
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.EnterHomeZipCodeFragment#RequestId";
	
	private ViewGroup mView;
	private Handler mHandler;
    private RequestManager mRequestManager;
    private int mRequestId = -1;
    
    private String mErrorMessage;
    private String mErrorTitle;
    private Bundle mResponseBundle;
	
	private boolean mShowProgressBar = false;
	private Button mButtonOk;
	private Button mButtonCancel;
	private TextView mTextViewZipCodeMsg;
	private AutoCompleteTextView mEditTextZipCode;
	
	private Context mContext;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogConfig.logd(LOG_TAG, "onCreate()");
		if (savedInstanceState != null) {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
		}
		mHandler = new Handler();
    	mRequestManager = RequestManager.from(getActivity());
    	mContext = getActivity().getApplicationContext();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_homezip_code_screen, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;   
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		UIUtils.hideKeyboard(getActivity(), mEditTextZipCode);
		PreferenceConfig.setHomeZipScreenVisiblity(true, getActivity());
	}
	
	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logd(LOG_TAG, "onPause()");
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(EnterHomeZipCodeFragment.this);
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logd(LOG_TAG, "onResume()");
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(EnterHomeZipCodeFragment.this);
            } else {
                mRequestId = -1;
            }
        }
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
        outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		super.onSaveInstanceState(outState);
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.app_name, false, true, false, getSherlockActivity());
		mEditTextZipCode = (AutoCompleteTextView) mView.findViewById(R.id.editText_enter_id);
		mTextViewZipCodeMsg = ((TextView) mView.findViewById(R.id.textView_disclaimer_title));
		mTextViewZipCodeMsg.setVisibility(View.VISIBLE);
		
		
		String searchColumn = PreferenceConfig.getSearchColumn(getActivity());	
		mEditTextZipCode.setHint(R.string.enter_zip_code_hint);		
		String prevoiusHomeZip=PreferenceConfig.getHomeZipcodeFromServer(getActivity());
		if (UIUtils.getRetailId(getActivity()) == CommonConfig.RETAILTYPE_ROBINSON) {
			 mTextViewZipCodeMsg.setText(R.string.disclaimer_text);
			 if(prevoiusHomeZip.equalsIgnoreCase("zip")){			 
				    if (searchColumn.equalsIgnoreCase("city")) {			
					  mEditTextZipCode.setHint(R.string.enter_city_hint);			
				    }
				    else{
					 mEditTextZipCode.setHint(R.string.enter_zip_code_hint);	
					}
				}
				else{
					  mEditTextZipCode.setText(prevoiusHomeZip);
				}
		}
		else{
		
		  if (searchColumn.equalsIgnoreCase("city")) {	
		  mTextViewZipCodeMsg.setText(R.string.label_home_city_gps);
		   }
		  else{
		  mTextViewZipCodeMsg.setText(R.string.label_home_zip_gps);
		  }
		if(prevoiusHomeZip.equalsIgnoreCase("zip")){			 
		    if (searchColumn.equalsIgnoreCase("city")) {			
			mEditTextZipCode.setHint(R.string.enter_city_hint);			
		   }else{
			   mEditTextZipCode.setHint(R.string.enter_zip_code_hint);	
		   }
		}
		else{
			  mEditTextZipCode.setText(prevoiusHomeZip);
		}
		}
		String homeZipcode = PreferenceConfig.getHomeZipcode(getActivity());
		if (!TextUtils.isEmpty(homeZipcode)) {
			mEditTextZipCode.setText(homeZipcode);
		}
		
		final String[] city_names=getResources().getStringArray(R.array.city_names);
		
		mEditTextZipCode.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// Do nothing
				String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
				if (null != searchColumn && searchColumn.equalsIgnoreCase("city")) {
					final String zipcodeText = s.toString().trim().toLowerCase();
					ArrayList<String> list_city=new ArrayList<String>();
					for (int i = 0; i < city_names.length; i++) {
						String pattern =zipcodeText+".*";
						boolean matches = Pattern.matches(pattern, city_names[i].toLowerCase());
						if(matches){
							list_city.add(city_names[i]);
						}
					}
					Collections.sort(list_city);
					ArrayAdapter<String> adapter=new ArrayAdapter<String>(getActivity(),R.layout.list_item,list_city);
					mEditTextZipCode.setAdapter(adapter);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// Do nothing
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				
			}
		});
		
		mEditTextZipCode.setOnEditorActionListener(new EditText.OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_DONE 
			            || actionId == EditorInfo.IME_NULL
			            || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
					sendUserZipCode();
					return true;
				}
				return false;
			}
		});
		
		mButtonOk = (Button) mView.findViewById(R.id.Button_ok);
		if (UIUtils.getRetailId(getActivity())== CommonConfig.RETAILTYPE_ROBINSON) {
			((TextView) mView.findViewById(R.id.textView_enter_id)).setText(getResources().getString(searchColumn.equalsIgnoreCase("city") ? R.string.enter_city : R.string.enter_zip_code));	
		} 
		//mTextViewZipCodeMsg = ((TextView) mView.findViewById(R.id.textView_disclaimer_title));
		//mTextViewZipCodeMsg.setVisibility(View.VISIBLE);
		//mTextViewZipCodeMsg.setText(getResources().getString(R.string.disclaimer_text));
		mButtonOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				sendUserZipCode();
			}
		});
		mButtonCancel = (Button) mView.findViewById(R.id.Button_cancel);
		mButtonCancel.setText(getResources().getString(R.string.skip));
		mButtonCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (!PreferenceConfig.isHomeZipCodeScreenShown(getActivity())) {
					PreferenceConfig.setHomeZipCodeScreenShown(true, getActivity());
					launchHomeScreen();
				} else {
					getActivity().finish();
				}
			}
		});
		if(TextUtils.isEmpty(searchColumn) && null != searchColumn && !searchColumn.equalsIgnoreCase("city")) {			
			mEditTextZipCode.setFilters(new InputFilter[]{ mAlphaNumericFilter });
		}
	}
	
	/** Make server request to send user zip code to server. */
	private void callSendHomeZipCodeWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(EnterHomeZipCodeFragment.this);
		params.putByte(LoginWorker.KEY_NAME_BUNDLE_LOGIN_WORKER_MODE, LoginWorker.WORKER_MODE_SEND_ZIP_CODE);
		params.putString(CommonConfig.KEY_NAME_ZIP_CODE, UIUtils.toTitleCase(mEditTextZipCode.getText().toString().trim()));
		mRequestId = mRequestManager.sendZipCode(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			// must reset refreshing, if requested or not.
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(EnterHomeZipCodeFragment.this);
			ProgressBarHelper.dismissProgressBar(mHandler);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
 
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				zipCodeSentSuccessfullyDoSomething();
				
				byte downloadMode = DownloadMode.MODE_HOME_ZIPCODE;
				PreferenceConfig.setDownloadModeHome(downloadMode , getActivity());
				
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
		}
	};
	
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
			
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_ERROR_HOME_CITY:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.dialog_error_title)
			.setMessage(R.string.invalid_city)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
				//	mEditTextZipCode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
					dialog.dismiss();
				}
			});
			break;
		case DialogConfig.DIALOG_EXIT_APP:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(R.string.msg_app_exit_confirmation)
			.setCancelable(true)
			.setPositiveButton(R.string.label_yes,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						dialog.dismiss();
						getActivity().finish();
						
						// Show the GPS Settings if GPS was switched off
						// initially while launching
						if (PreferenceConfig.isDefaultGPSStatus(mContext) != PreferenceConfig.getCurrentGPSStatus(mContext)) {
							startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
						}
					}
				})
			.setNegativeButton(R.string.label_no,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						// Removing dialog box
						dialog.dismiss();
					}
				});
			break;
		}
		dlg.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logd(LOG_TAG, "onDestroy()");
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_login_screen));
		   System.gc();
	   }
	   PreferenceConfig.setHomeZipScreenVisiblity(false, getActivity());
	}
	
	/** A method to perform actions after successfully sent zip code to server*/
	private void zipCodeSentSuccessfullyDoSomething() {
		getLocationForHomeZipCode();
		PreferenceConfig.setPersonalOffersTimestamp(0L, getActivity());
		PreferenceConfig.setCommonOffersTimestamp(0L, getActivity());
		if (!PreferenceConfig.isHomeZipCodeScreenShown(getActivity())) {
			PreferenceConfig.setHomeZipCodeScreenShown(true, getActivity());
			launchHomeScreen();
		} else {
			getActivity().finish();
		}
	}
	
	/** A method to send and set user home zipcode. */
	private void sendUserZipCode() {
		UIUtils.hideKeyboard(getActivity(), mEditTextZipCode);
		
		String[] city_names=getResources().getStringArray(R.array.city_names);
		List<String> city_list=Arrays.asList(city_names);
		String homeZipcode = mEditTextZipCode.getText().toString().trim();
		String searchColumn = PreferenceConfig.getSearchColumn(getActivity());

		if (TextUtils.isEmpty(homeZipcode)) {
			mErrorTitle = getResources().getString(R.string.dialog_error_title);
			mErrorMessage = getResources().getString(R.string.enter_zip_code_hint);
			if (searchColumn.equalsIgnoreCase("city")) {
				mErrorMessage = getResources().getString(R.string.enter_city_hint);
			}
			showDialog(DialogConfig.DIALOG_ERROR);
		} else if (searchColumn.equalsIgnoreCase("zip") && !(homeZipcode.length() >= BusinessLogicConfig.MIN_CHAR_IN_ZIPCODE
					&& homeZipcode.length() <= BusinessLogicConfig.MAX_CHAR_IN_ZIPCODE)) {
			mErrorTitle = getResources().getString(R.string.dialog_error_title);
			mErrorMessage = getResources().getString(R.string.msg_enter_valid_zip_hint);
			if (searchColumn.equalsIgnoreCase("city")) {
				mErrorMessage = getResources().getString(R.string.msg_enter_valid_city_hint);
			}
			showDialog(DialogConfig.DIALOG_ERROR);
		} else if(searchColumn.equalsIgnoreCase("city") && !city_list.contains(homeZipcode)){
			showDialog(DialogConfig.DIALOG_ERROR_HOME_CITY);
			return;
		} else {
			String savedHomeZipcode = PreferenceConfig.getHomeZipcode(getActivity());
			if (!TextUtils.isEmpty(savedHomeZipcode)) {
				if (!mEditTextZipCode.getText().toString().equalsIgnoreCase(savedHomeZipcode)) {
					callSendHomeZipCodeWS();
				} else {
					if (!PreferenceConfig.isHomeZipCodeScreenShown(getActivity())) {
						PreferenceConfig.setHomeZipCodeScreenShown(true, getActivity());
						launchHomeScreen();
					} else {
						getActivity().finish();
					}
				}
			} else {
				callSendHomeZipCodeWS();
			}
		}
	}
	
	/** A method to launch home screen. */
	private void launchHomeScreen() {
		startActivity(new Intent(getActivity(), HomeActivity.class));
		getActivity().finish();
	}
	
	/** A method to get location for home Zip Code. */
	private void getLocationForHomeZipCode() {
		// Check if network available
		if (NetworkHelper.isNetworkAvailable(getActivity())) {
			Bundle params = new Bundle();
			params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE, 
					SettingsWorker.WorkerModes.WORKER_MODE_GET_LOCATION_FOR_ZIPCODE);
			mRequestId = mRequestManager.getLocationForZipCode(DownloadFormat.RETURN_FORMAT_JSON, params);
		}
	}
	
	/** {@link InputFilter} to filter the special characters. It will take minus and
	 * space characters as well as other letters and digits.
	 */
	private final InputFilter mAlphaNumericFilter = new InputFilter() {
		@Override
		public CharSequence filter(CharSequence source, int arg1, int arg2,
				Spanned arg3, int arg4, int arg5) {
			for (int k = arg1; k < arg2; k++) {
				if (!((Character.isLetterOrDigit(source.charAt(k))
						|| Character.isSpace(source.charAt(k))
						|| Character.toString(source.charAt(k)).equals("_"))
						&& ((int)source.charAt(k) != 928))) {
					return "";
				}
			}
			return null;
		}
	};
}
