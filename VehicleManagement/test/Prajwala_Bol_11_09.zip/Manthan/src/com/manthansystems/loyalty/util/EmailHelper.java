/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;


/**
 * A helper class that holds methods for email id verification and email sending.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class EmailHelper {/*
	
	*//** Method to send email to supplied recipients email ids. *//*
	public static void sendEmail(Context context, String to[], String cc[], String bcc[],
			String subject, CharSequence bodyText) {
		final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		emailIntent.setType("plain/text"); // For Emulator 
		emailIntent.setType("message/rfc822"); // For Device
		emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, to);
		emailIntent.putExtra(android.content.Intent.EXTRA_CC, cc);
		emailIntent.putExtra(android.content.Intent.EXTRA_BCC, bcc);
		emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);
		emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, bodyText);
		context.startActivity(Intent.createChooser(emailIntent, 
				context.getResources().getString(R.string.title_send_email)));
	}
	
	*//** Method to validate the email address given as parameter to this method. *//*
	public static boolean isValidEmail(String email){
		Pattern p = Pattern.compile(
				"^[a-z0-9,!#\\$%&'\\*\\+/=\\?\\^_`\\{\\|}~-]+(\\.[a-z0-9,!#\\$%&'\\*\\+/=\\?\\^_`\\{\\|}~-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*\\.([a-z]{2,})$");
		Matcher matcher = p.matcher(email);
		return matcher.matches();
	}
*/}

