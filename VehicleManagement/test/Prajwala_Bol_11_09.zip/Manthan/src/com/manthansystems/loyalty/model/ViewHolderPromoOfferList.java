/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

import android.database.Cursor;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.util.UIUtils;

/**
 * A view holder class that holds the row elements of Promotional Offers list item.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class ViewHolderPromoOfferList implements BaseViewHolder {

	@SuppressWarnings("unused")
	private int mPosition;
	@SuppressWarnings("unused")
	private int mSelectedPosition;
	
	private TextView mTextViewOfferTitle;
	public ImageView mImageViewFavoriteIcon;
	public ImageView mImageViewNewIcon;
	
	/** Paramterised constructor. */
	public ViewHolderPromoOfferList(final View view) {
		bindViews(view);
	}
	
	/** Method to bind the views from the row layout. */
	private void bindViews(View view) {
		mTextViewOfferTitle = (TextView) view.findViewById(R.id.TextView_offer_title);
		mImageViewFavoriteIcon = (ImageView) view.findViewById(R.id.ImageView_fav_icon);
		mImageViewNewIcon = (ImageView) view.findViewById(R.id.ImageView_new_offer_icon);
	}
	
	@Override
	public void populateView(Cursor inCursor, View view) {
		// set the title with decorations sent by server.
		mTextViewOfferTitle.setText(UIUtils.buildDecorativeSnippet(
				inCursor.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN),
				inCursor.getString(CouponDao.CONTENT_DECORATORS_COLUMN)));
		
		int couponNewStatus = inCursor.getInt(CouponDao.CONTENT_IS_NEW_COUPON);
		if (couponNewStatus == CouponDao.FLAG_VALUE_NEW_COUPON) {
			mImageViewNewIcon.setVisibility(View.VISIBLE);
		} else {
			mImageViewNewIcon.setVisibility(View.GONE);
		}
		view.setBackgroundColor(PreferenceConfig.getMarketingMsgBgColorCode(view.getContext()));
	}
	
	/** Set the row positions and current selected position. */
	public void setRowPosition(int position, int selectedPosition) {
		mPosition = position;
		mSelectedPosition = selectedPosition;
	}

	@Override
	public ImageView getFavoriteIconView() {
		return mImageViewFavoriteIcon;
	}

	@Override
	public ImageView getOfferIconView() {
		return null;
	}
}
