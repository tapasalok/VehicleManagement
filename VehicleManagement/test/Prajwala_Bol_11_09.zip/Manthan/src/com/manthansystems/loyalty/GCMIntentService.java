/*
 * Copyright 2013 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.manthansystems.loyalty;

import static com.manthansystems.loyalty.CommonUtilities.SENDER_ID;
import static com.manthansystems.loyalty.CommonUtilities.displayMessage;

import java.util.ArrayList;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;

import com.google.android.gcm.GCMBaseIntentService;
import com.google.android.gcm.GCMRegistrar;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.ui.HomeActivity;
import com.manthansystems.loyalty.ui.OffersFragment.OfferNotificationType;
import com.manthansystems.loyalty.ui.SplashActivity;
import com.manthansystems.loyalty.ui.UIApplication;
import com.manthansystems.loyalty.util.UIUtils;


/**
 * IntentService responsible for handling GCM messages.
 */
public class GCMIntentService extends GCMBaseIntentService {

    private static final String TAG = "GCMIntentService";

    public GCMIntentService() {
        super(SENDER_ID);
    }

    @Override
    protected void onRegistered(Context context, String registrationId) {
        LogConfig.logd(TAG, "Device registered: regId = " + registrationId);
        System.out.println("registrationId"+registrationId);
        
        System.out.println("--------------------Tapas Registation Id-------------------"+registrationId);
        
        displayMessage(context, getString(R.string.gcm_registered));
        ServerUtilities.register(context, registrationId);
    }

    @Override
    protected void onUnregistered(Context context, String registrationId) {
        LogConfig.logd(TAG, "Device unregistered");
        displayMessage(context, getString(R.string.gcm_unregistered));
        if (GCMRegistrar.isRegisteredOnServer(context)) {
            ServerUtilities.unregister(context, registrationId);
        } else {
            // This callback results from the call to unregister made on
            // ServerUtilities when the registration to the server failed.
            LogConfig.logd(TAG, "Ignoring unregister callback");
        }
    }

    @Override
    protected void onMessage(Context context, Intent intent) {
        LogConfig.logd(TAG, "Received message");
//        Resources resources = getResources();
//        String alertTitle = intent.getExtras().getString(resources.getString(R.string.gcm_alert_title));
//        LogConfig.logd(TAG, "Received message"+ alertTitle);
//        displayMessage(context, message);
        // notifies user
        generateNotification(context, intent);
    }

    @Override
    protected void onDeletedMessages(Context context, int total) {
        LogConfig.logd(TAG, "Received deleted messages notification");
//        String message = getString(R.string.gcm_deleted, total);
//        displayMessage(context, message);
//        // notifies user
//        generateNotification(context, message);
    }

    @Override
    public void onError(Context context, String errorId) {
        LogConfig.logd(TAG, "Received error: " + errorId);
        displayMessage(context, getString(R.string.gcm_error, errorId));
    }

    @Override
    protected boolean onRecoverableError(Context context, String errorId) {
        // log message
        LogConfig.logd(TAG, "Received recoverable error: " + errorId);
        displayMessage(context, getString(R.string.gcm_recoverable_error,
                errorId));
        return super.onRecoverableError(context, errorId);
    }

    /**
     * Issues a notification to inform the user that server has sent a message.
     */
	private static void generateNotification(Context context, Intent intent) {
    	LogConfig.logd(TAG, "generateNotification()");
        int icon = R.drawable.ic_launcher;
        long when = System.currentTimeMillis();
        // notifyID allows you to update the notification later on(if needed).
        Bundle bundle = intent.getExtras();
        int notifyID = 1;
        Resources resources = context.getResources();
        String alertContentText = bundle.getString(
        		resources.getString(R.string.gcm_alert_title));
        System.out.println("----------Tapas Message Bundle---------------"+bundle);
        
        String alertContentTitle = context.getString(R.string.app_name);
		String offerType = bundle.getString(JSONTagConstants.RESPONSE_TAG_TYPE);
		LogConfig.logd(TAG, "generateNotification(): offerType = " + offerType);
		String cid = bundle.getString(JSONTagConstants.RESPONSE_TAG_CID);
		String mcid = bundle.getString(JSONTagConstants.RESPONSE_TAG_MCID);
		ArrayList<String> couponIdArrayList = new ArrayList<String>();
		UIApplication uiApplication =  (UIApplication) context.getApplicationContext();
		if (!TextUtils.isEmpty(cid)) {
			couponIdArrayList.add(cid);
			uiApplication.setNoficationCouponIdList(couponIdArrayList);
		}
		if (!TextUtils.isEmpty(mcid)) {
			couponIdArrayList = UIUtils.stringToArrayList(mcid);
			uiApplication.setNoficationCouponIdList(couponIdArrayList);
		}
		if (offerType != null && offerType.equalsIgnoreCase(OfferNotificationType.PERSONAL_OFFER)) {
			LogConfig.logd(TAG, "generateNotification(): offerType type set personal");
			PreferenceConfig.setLaunchScreenFromNotification(
					OfferNotificationType.PERSONAL_OFFER, context);
		} else {
			LogConfig.logd(TAG, "generateNotification(): offerType type set category");
			PreferenceConfig.setLaunchScreenFromNotification(
					OfferNotificationType.COMMON_OFFER, context);
		}
        
        // Creates an explicit intent for an Activity in app.
        Intent notificationIntent = null;
        if (PreferenceConfig.getAppIsRunning(context)) {
        	notificationIntent = new Intent(context, HomeActivity.class);
        } else {
        	notificationIntent = new Intent(context, SplashActivity.class);
        }
        notificationIntent.putExtra(HomeActivity.KEY_EXTRA_STRING_NOTIFICATION_CLICKED, true);
        
        // set intent so it does not start a new activity
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK 
				| Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notificationIntent.putExtras(intent);
        PendingIntent pendingIntent =
                PendingIntent.getActivity(context, 0, notificationIntent, 0);
        
        // Instantiate a Builder object to prepare notification.
        NotificationCompat.Builder builder = new NotificationCompat.Builder(
        		context).setSmallIcon(icon)
                .setContentTitle(alertContentTitle)
                .setContentText(alertContentText)
                .setTicker(alertContentText)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setLights(resources.getColor(R.color.color_green), 500, 500)
                .setWhen(when)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);
        		
        // Notifications are issued by sending them to the
        // NotificationManager system service.
        NotificationManager notificationManager = (NotificationManager)
        		context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(notifyID, builder.build());
    }
}
