/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class ScreenOnOffReceiver extends BroadcastReceiver {
    
    public static boolean wasScreenOn = true;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
            // do whatever you need to do here
            wasScreenOn = false;
        } /*else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
        	// TODO - take action here.
        }*/
    }
}