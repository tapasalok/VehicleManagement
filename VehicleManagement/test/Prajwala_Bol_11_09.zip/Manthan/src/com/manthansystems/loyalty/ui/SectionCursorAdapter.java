/**
 * Copyright 2013 XYMOB Inc.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import android.content.Context;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.support.v4.widget.CursorAdapter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SectionIndexer;
import android.widget.TextView;


/**
 * A base {@link CursorAdapter}, Any cursor adapter that is going to render list with sections
 * should extend this class.
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 *
 */
public abstract class SectionCursorAdapter extends CursorAdapter implements SectionIndexer {

	@SuppressWarnings("unused")
	private static final String TAG = "SectionCursorAdapter";

	private static final int TYPE_NORMAL = 1;
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_COUNT = 2;

    private final int mHeaderRes;
    private int mGroupColumn;
    private final LayoutInflater mLayoutInflater;
    
    private LinkedHashMap<Integer, String> mSectionsIndexer;
//	private HashMap<String, Integer> mAlphabateIndexer;
	private String[] mSections;
	private ArrayList<String> mAlphabetValues;
    
	@SuppressWarnings("deprecation")
	public SectionCursorAdapter(Context context, Cursor c, int headerLayout, int groupColumn) {
		super(context, c);

		mSectionsIndexer = new LinkedHashMap<Integer, String>();

		mAlphabetValues = new ArrayList<String>();
		
		mHeaderRes = headerLayout;
		mGroupColumn = groupColumn;
		mLayoutInflater = LayoutInflater.from(context);

		if(c != null) {
			calculateSectionHeaders();
			prepareSectionsForSectionIndexer();
			c.registerDataSetObserver(mDataSetObserver);
		}
	}

	/** A data {@link DataSetObserver} to get the change notification of current data set. */
	private DataSetObserver mDataSetObserver = new DataSetObserver() {
		public void onChanged() {
			calculateSectionHeaders();
			prepareSectionsForSectionIndexer();
		};

		public void onInvalidated() {
			mSectionsIndexer.clear();
			mAlphabetValues.clear();
			calculateSectionHeaders();
		};
	}; 

	/** Method to calculate the section headers. */
	private void calculateSectionHeaders() {
		int i = 0;
		String previous = "";
		int count = 0;
		try {
			final Cursor c = getCursor();
			mSectionsIndexer.clear();
			
			mAlphabetValues.clear();
	
			c.moveToPosition(-1);
	
			while (c.moveToNext()) {
				final String group = c.getString(mGroupColumn);
	
				if (!group.equals(previous) ) {
					mSectionsIndexer.put(i + count, group);
					previous = group;
					count++;
				}
	//TODO - CHange it later
				final String sortColumnValue = ""/*c.getString(HistoryDao.CONTENT_HISTORY_TYPE_COLUMN)*/;
				if (!TextUtils.isEmpty(sortColumnValue)) {
					mAlphabetValues.add(sortColumnValue.substring(0, 1));
					//We store the first letter of the word, and its index.
			        //The Hashmap will replace the value for identical keys are putted in
				}
				i++;
			}
		} catch (Exception e) { }
	}
	
	/** Method to prepare the sections from data set. */
	private void prepareSectionsForSectionIndexer() {
		//Collections.sort(mAlphabetValues);
        mSections = new String[mAlphabetValues.size()]; // simple conversion to an
        // array of object
        mAlphabetValues.toArray(mSections);
	}
	
	/** Set customized header title. */
	public String getGroupCustomFormat(Object obj) {
		return null;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		int viewType = getItemViewType(position);

		if( viewType == TYPE_NORMAL) {
			Cursor c = (Cursor) getItem(position);

			if (c == null)
				return mLayoutInflater.inflate(mHeaderRes, null);

			final int mapCursorPos = getSectionForPosition(position);
			c.moveToPosition(mapCursorPos);

			return super.getView(mapCursorPos, convertView, parent);
		} else {				 
			TextView sectionText = (TextView) mLayoutInflater.inflate(mHeaderRes, null);

			final String group = mSectionsIndexer.get(position);
			final String customFormat = getGroupCustomFormat(group) ;

			sectionText.setText(customFormat == null ? group : customFormat);

			return sectionText;
		}
	}

	@Override
	public int getViewTypeCount() {
		return TYPE_COUNT;
	}

	@Override
	public int getCount() {
		return super.getCount() + mSectionsIndexer.size();
	}

	@Override
	public boolean isEnabled(int position) {
		return getItemViewType(position) == TYPE_NORMAL;
	}

	/** Get the position of section. */
	public int getPositionForSection(int section) {
		if(mSectionsIndexer.containsKey(section)) {
			return section + 1;
		}
		return section;
	}

	/** Get the section for the given position. */
	public int getSectionForPosition(int position) {
		int offset = 0;
		for(Integer key: mSectionsIndexer.keySet()) {
			if(position > key) {
				offset++;
			} else {
				break;
			}
		}

		return position - offset;
	}

	@Override
	public Object[] getSections() {
		return mSections; //use the indexer
	}
	
	@Override
	public Object getItem(int position) {
		if (getItemViewType(position) == TYPE_NORMAL){
            return super.getItem(getSectionForPosition(position));
        }
        return super.getItem(position);
	}

	@Override
	public int getItemViewType(int position) {
		if (position == getPositionForSection(position)) {
			return TYPE_NORMAL;
		}
		return TYPE_HEADER;
	}

	@Override
	public void changeCursor(Cursor cursor) {
		if(getCursor() != null) {
			try {
				getCursor().unregisterDataSetObserver(mDataSetObserver);
			} catch (Exception e) {}
		}

		super.changeCursor(cursor);
		calculateSectionHeaders();
		prepareSectionsForSectionIndexer();
		cursor.registerDataSetObserver(mDataSetObserver);
	}
	
	/** Set the database column index based on which the section will be created. The similar
	 * values of this column will be taken in groups and each groups will be shown in sections. 
	 */
	public void setGroupColumn(int groupColumn) {
		mGroupColumn = groupColumn;
	}
}


