package com.manthansystems.loyalty.ui;

import java.util.Map;
import java.util.StringTokenizer;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDaoHome;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDaoHome;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.model.HomeCoupon;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.OffersFragment.OffersType;
import com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity;
import com.manthansystems.loyalty.ui.phone.HomeOfferDetailActivity.HomeOfferDetailIntentKey;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadMode;
import com.manthansystems.loyalty.worker.HomeCouponWorker;

/**
 * An {@link SherlockFragment} class that will be working as a Home Page where
 * we will show all the offers or coupons set by admin
 * 
 */
public class HomeScreenFragment extends SherlockFragment implements
		LoaderManager.LoaderCallbacks<Cursor>, OnRequestFinishedListener {
	private final static String LOG_TAG = "HomeScreenFragment";

	public static final String KEY_NAME_CUSTOM_WEBVIEW_URL = "com.manthansystems.loyalty.ui.CustomWebviewFragment#web_url";
	public static final String KEY_NAME_CUSTOM_WEBVIEW_TITLE = "com.manthansystems.loyalty.ui.CustomWebviewFragment#title";
	public static final String SHOW_REFRESH_OPTION = "com.manthansystems.loyalty.ui.CustomWebviewFragment#show_refresh_option";
	public static final String KEY_NAME_SHOW_HEADER_TITLE = "com.manthansystems.loyalty.ui.CustomWebviewFragment#showHeaderTitle";
	public static final String KEY_NAME_CUSTOM_HTTP_HEADERS = "com.manthansystems.loyalty.ui.CustomWebviewFragment#customHttpHeader";
	public static final String KEY_NAME_HEADER_TITLE = "com.manthansystems.loyalty.ui.CustomWebviewFragment#headerTitle";
	private final String SAVED_STATE_REQUEST_TYPE = "com.manthansystems.loyalty.ui.HomeScreenFragment#RequestType";
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.HomeScreenFragment#RequestId";
	private WebView mWebView;
	private String mUrl;
	private String mLastUrl;
	private boolean mIsPageLoading;
	private String mActionBarTitle;
	private ViewGroup mView;
	private String mErrorMessage;
	private String mHeaderTitle;
	private SherlockFragmentActivity mActivity;
	private boolean mShowRefreshOption = false;
	private boolean mShowPreviousOption = false;
	private boolean mShowNextOption = false;
	private boolean mShowHeaderTitle = false;
	private boolean mAddCustomHeaders = false;
	private Map<String, String> mMapHeaders = null;
	private AlertDialog mAlertDialog;
	private ProgressDialog progDailog;

	private byte mDownloadMode;
	private RequestManager mRequestManager;
	private Handler mHandler;
	private int mRequestId = -1;
	private static byte mRequestType;
	private boolean mIsNoNetworkCaseOccurs = false;
	private String mDialogMessage;
	private String mErrorTitle;
	private Bundle mResponseBundle;
	private String couponHomeItemId = null;
	private SparseArray<HomeCoupon> mCouponArray = new SparseArray<HomeCoupon>();
	private int itemHomePosition = 0;
	public static int loadingCounter = 0;
	private RelativeLayout imageView;
	private static Bundle bundle;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		bundle = savedInstanceState;
		LogConfig.logv(LOG_TAG, "onCreate()");
		mActionBarTitle = "";
		mHeaderTitle = "";
		mActivity = (SherlockFragmentActivity) getActivity();

		if (savedInstanceState != null) {
			mUrl = savedInstanceState.getString(KEY_NAME_CUSTOM_WEBVIEW_URL);
			LogConfig.logv(LOG_TAG, "onCreate() : reload mUrl = " + mUrl);
			mActionBarTitle = savedInstanceState
					.getString(KEY_NAME_CUSTOM_WEBVIEW_TITLE);
			setShowRefreshOption(savedInstanceState
					.getBoolean(SHOW_REFRESH_OPTION));
			mShowHeaderTitle = savedInstanceState
					.getBoolean(KEY_NAME_SHOW_HEADER_TITLE);
			mAddCustomHeaders = savedInstanceState
					.getBoolean(KEY_NAME_CUSTOM_HTTP_HEADERS);
			mHeaderTitle = savedInstanceState.getString(KEY_NAME_HEADER_TITLE);
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
			mRequestType = savedInstanceState.getByte(SAVED_STATE_REQUEST_TYPE);
		} else {
			mUrl = WSConfig.HOME_URL;
		}
		mRequestManager = RequestManager.from(getActivity());

		mDownloadMode = PreferenceConfig.getDownloadModeHome(getActivity());
		mHandler = new Handler();
		if (mAddCustomHeaders) {
			mMapHeaders = ((UIApplication) getActivity().getApplication())
					.getCustomHttpHeaderForWebView();
			if (!(mMapHeaders != null && mMapHeaders.size() > 0)) {
				mAddCustomHeaders = false;
			}
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(
				R.layout.fragment_home_webview, null);

		// For some reason, if we omit this, NoSaveStateFrameLayout thinks we
		// are
		// FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top
		// of the activity.
		root.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT));
		mView = root;
		
		imageView = (RelativeLayout) root.findViewById(R.id.imageView);
		imageView.setVisibility(View.VISIBLE);
		// load animations
//		animFadeIn = AnimationUtils.loadAnimation(getActivity(),
//		                R.anim.translate_slide_right_out);
		
		// set animation listeners
//		animFadeIn.setAnimationListener(this);
		
		setActionBarTitle();
		bindViews();
		return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
//		imageView.setVisibility(View.VISIBLE);
		loadUrlOnWebView();
	}

	@Override
	public void onResume() {
		super.onResume();
		if (mActivity instanceof HomeActivity) {
			// register sliding menu open listener to update slide menu row
			// selection.
			((HomeActivity) getActivity()).getSlidingMenu().setOnOpenListener(
					onSlidingMenuOpenListener);
		}
		if (mRequestId != -1) {
			if (mRequestManager.isRequestInProgress(mRequestId)) {
				mRequestManager
						.addOnRequestFinishedListener(HomeScreenFragment.this);
			} else {
				mRequestId = -1;
			}
		}

		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			ProgressBarHelper.dismissProgressBar(mHandler);
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			// must reset refreshing, if requested or not.
			return;
		}
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(mErrorTitle)
					.setMessage(mDialogMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;
		}

		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
		mDialogMessage = "";
	}

	@Override
	public void onPause() {
		super.onPause();
		if (mActivity instanceof HomeActivity) {
			// un-register sliding menu open listener.
			((HomeActivity) getActivity()).getSlidingMenu().setOnOpenListener(
					null);
			mActivity.setSupportProgressBarIndeterminateVisibility(false);
		}
		dismissActiveDialog();
		mRequestManager
				.removeOnRequestFinishedListener(HomeScreenFragment.this);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		LogConfig.logv(LOG_TAG, "onDestroy()");
		PreferenceConfig.setAppConfigDownloadStatus(false, getActivity());
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putByte(SAVED_STATE_REQUEST_TYPE, mRequestType);
		outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		outState.putString(KEY_NAME_CUSTOM_WEBVIEW_URL, mUrl);
		outState.putString(KEY_NAME_CUSTOM_WEBVIEW_TITLE, mActionBarTitle);
		outState.putBoolean(SHOW_REFRESH_OPTION, isShowRefreshOption());
		outState.putBoolean(KEY_NAME_SHOW_HEADER_TITLE, mShowHeaderTitle);
		outState.putBoolean(KEY_NAME_CUSTOM_HTTP_HEADERS, mAddCustomHeaders);
		outState.putString(KEY_NAME_HEADER_TITLE, mHeaderTitle);
		super.onSaveInstanceState(outState);
	}

	/** Bind view elements to local view objects. */
	@SuppressLint("SetJavaScriptEnabled")
	private void bindViews() {
		progDailog = new ProgressDialog(getActivity());
		progDailog.setMessage(getString(R.string.loading));
		progDailog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		progDailog.setIndeterminate(true);
		progDailog.show();
		mWebView = (WebView) mView.findViewById(R.id.webview);
		mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
		mWebView.getSettings().setBuiltInZoomControls(true);
		mWebView.getSettings().setDomStorageEnabled(true);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setLoadWithOverviewMode(true);
		mWebView.getSettings().setUseWideViewPort(true);
		mWebView.setWebViewClient(new HomeScreenWebClient());
		mWebView.addJavascriptInterface(new JavaScriptHandler(),
				getString(R.string.app_name));

		if (mShowHeaderTitle) {
			final TextView textViewHeaderTitle = (TextView) mView
					.findViewById(R.id.TextView_header_title);
			textViewHeaderTitle.setText(mHeaderTitle);
			textViewHeaderTitle.setVisibility(View.VISIBLE);
			textViewHeaderTitle.setGravity(Gravity.CENTER);
		}
		if (mActivity instanceof HomeActivity) {

			UIUtils.setTitleView(R.string.label_tab_home, false, true, true,
					getSherlockActivity());

			View view = ((HomeActivity) mActivity).getSupportActionBar()
					.getCustomView();
			if (view != null) {
				view.findViewById(R.id.ImageView_Slide_Menu_more_icon)
						.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								((BaseSlidingActivity) getActivity())
										.getSlidingMenu().showMenu(true);
							}
						});

				view.findViewById(R.id.ImageView_Slide_Menu_icon)
						.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								if (!NetworkHelper
										.isNetworkAvailable(getActivity())) {
									mDialogMessage = getResources().getString(
											R.string.network_not_available_msg);
									mErrorTitle = getResources()
											.getString(
													R.string.network_not_available_title);
									showDialog(DialogConfig.DIALOG_ERROR);
									// must reset refreshing, if requested or
									// not.
									return;
								} else {
									Toast.makeText(getActivity(), getString(R.string.label_refreshing), Toast.LENGTH_SHORT).show();
									onCreate(bundle);
								}
							}
						});

			}
		}
	}

	/**
	 * @param isPageLoading
	 *            the Page Loading status to set
	 */
	public void setIsPageLoading(boolean isPageLoading) {
		mIsPageLoading = isPageLoading;
	}

	/**
	 * @return the Page loading status
	 */
	public boolean isPageLoading() {
		return mIsPageLoading;
	}

	/**
	 * It will be called when things happen that impact the rendering of the
	 * content, eg, errors or form submissions. We can also intercept URL
	 * loading here.
	 * 
	 */
	private final class HomeScreenWebClient extends WebViewClient {

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			super.onPageStarted(view, url, favicon);
			setIsPageLoading(true);
			setShowRefreshOption(false);
			imageView.setVisibility(View.VISIBLE);
		}

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			System.out.println("Ws Radius:" + WSConfig.WS_RADIUS);
			try {
				if (url != null && (url.toLowerCase().startsWith("mobile:"))) {
					loadingCounter = 1;
					StringTokenizer st = new StringTokenizer(url, ":");
					while (st.hasMoreTokens()) {
						couponHomeItemId = st.nextToken().toString();
					}
					if (PreferenceConfig
							.isHomelScreenClickVisible(getActivity())) {

						// TODO Hardcoding it into GPS for time being. We have
						// to change it according to the configuration
						// byte downloadMode = DownloadMode.MODE_ZIPCODE;
						mDownloadMode = PreferenceConfig
								.getDownloadModeHome(getActivity());
						System.out.println("DOWNLOAD_MODE---should Override"
								+ mDownloadMode);
						callHomeOffersListWS(mDownloadMode);
					} else {
						populateViews();
					}
				} else {
					if (!mAddCustomHeaders) {
						view.loadUrl(url);
					} else {
						view.loadUrl(url, mMapHeaders);
					}
				}
				return true;
			} catch (Exception e) {
				LogConfig.logd(LOG_TAG, "shouldOverrideUrlLoading()", e);
				return true;
			}
		}

		@SuppressLint("NewApi")
		@Override
		public void onPageFinished(WebView view, String url) {
			LogConfig.logv(LOG_TAG, "onPageFinished(): url = " + url);
			progDailog.dismiss();
			mActivity.setSupportProgressBarIndeterminateVisibility(false);
			setIsPageLoading(false);
			setShowRefreshOption(true);

			ProgressBarHelper.dismissProgressBar(mHandler);

			if (!TextUtils.isEmpty(url) && !url.equalsIgnoreCase("about:blank")) {
				mLastUrl = url;
			}
			if (mWebView.canGoBack()) {
				setShowPreviousOption(true);
			} else {
				setShowPreviousOption(false);
			}
			if (mWebView.canGoForward()) {
				setShowNextOption(true);
			} else {
				setShowNextOption(false);
			}
			mActivity.invalidateOptionsMenu();
		}

		@Override
		public void onReceivedError(WebView view, int errorCode,
				String description, String failingUrl) {
			LogConfig.logv(LOG_TAG, "onReceivedError(): failingUrl = "
					+ failingUrl);
			mActivity.setSupportProgressBarIndeterminateVisibility(false);
			mWebView.clearView();
			mWebView.loadDataWithBaseURL(null, "", "text/html", "utf-8",
					mLastUrl);
			mErrorMessage = getString(R.string.network_not_available_msg);
			imageView.setVisibility(View.VISIBLE);
			if (!mActivity.isFinishing()) {
				showCustomDialog(DialogConfig.DIALOG_ERROR);
			}
		}

	}

	@SuppressWarnings("unused")
	private void ShowWebBrowser(String url) {
		if (url != null && !url.startsWith("http://")
				&& !url.startsWith("https://")) {
			url = "http://" + url;
		}
		try {
			Intent browserIntent = new Intent(Intent.ACTION_VIEW,
					Uri.parse(url));
			startActivity(browserIntent);
		} catch (Exception e) {
			LogConfig.logd(LOG_TAG, "ShowWebBrowser()", e);
		}
	}

	/**
	 * @return the mShowRefreshOption
	 */
	public boolean isShowRefreshOption() {
		return mShowRefreshOption;
	}

	/**
	 * @param mShowRefreshOption
	 *            the mShowRefreshOption to set
	 */
	@SuppressLint("NewApi")
	public void setShowRefreshOption(boolean showRefreshOption) {
		mShowRefreshOption = showRefreshOption;
		if (showRefreshOption) {
			imageView.setVisibility(View.GONE);
		} else {
			imageView.setVisibility(View.VISIBLE);
		}
		mActivity.invalidateOptionsMenu();
	}

	/** A method to get boolean to show previous page option menu. **/
	public boolean isShowPreviousOption() {
		return mShowPreviousOption;
	}

	/** A method to set boolean to show previous page option menu. **/
	public void setShowPreviousOption(boolean showPreviousOption) {
		mShowPreviousOption = showPreviousOption;

	}

	/** A method to get boolean to show next page option menu. **/
	public boolean isShowNextOption() {
		return mShowNextOption;
	}

	/** A method to set boolean to show next page option menu. **/
	public void setShowNextOption(boolean showNextOption) {
		mShowNextOption = showNextOption;
	}

	/** A method to set action bar title of webview. **/
	private void setActionBarTitle() {
		String actionbarTitle = "";
		if (TextUtils.isEmpty(mActionBarTitle)) {
			actionbarTitle = getResources().getString(R.string.app_name);
		} else {
			actionbarTitle = mActionBarTitle.replaceAll("&amp;", "&");
		}
		// Set the screen title view.
		if (mActivity instanceof HomeActivity) {
			if (UIUtils.getRetailId(getActivity()) == CommonConfig.RETAILTYPE_ROBINSON) {
				UIUtils.setTitleView(R.string.label_tab_home, false, false,
						true, getSherlockActivity());
			} else {
				UIUtils.setTitleView(R.string.label_tab_home, false, true,
						true, getSherlockActivity());
			}
		} else {
			UIUtils.setTitleView(actionbarTitle, false, true, false, mActivity);
		}
	}

	/** A method to load webview with given url. **/
	private void loadUrlOnWebView() {
		if (mUrl != null) {
			if (!mUrl.startsWith("http://") && !mUrl.startsWith("https://")) {
				mUrl = "http://" + mUrl;
			}
			mLastUrl = mUrl;
			if (!mAddCustomHeaders) {
				mWebView.loadUrl(mUrl);
			} else {
				mWebView.loadUrl(mUrl, mMapHeaders);
			}
		}
	}

	/**
	 * A bridge class that holds the methods which will get called from
	 * Javascript from webpage.
	 * 
	 * 
	 */
	private final class JavaScriptHandler {

		/**
		 * Method should be called from Javascript of a web page on join
		 * success.
		 */
		@SuppressWarnings("unused")
		public void joinProgram(String statusCode, String msg) {
			LogConfig.logd(LOG_TAG, "JavaScriptHandler#joinProgram(): status="
					+ statusCode + ", msg = " + msg);
			if (!TextUtils.isEmpty(statusCode)
					&& statusCode
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_CODE_OK)) {
				getActivity().finish();
			} else if (!TextUtils.isEmpty(statusCode)
					&& statusCode
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_CODE_ERROR)) {
				mErrorMessage = TextUtils.isEmpty(msg) ? getResources()
						.getString(R.string.dialog_error_title) : msg;
				showCustomDialog(DialogConfig.DIALOG_ERROR);
			}
		}
	}

	/** Listener that invokes for Sliding menu open event. */
	private SlidingMenu.OnOpenListener onSlidingMenuOpenListener = new SlidingMenu.OnOpenListener() {
		@Override
		public void onOpen() {
			// Now update the sliding menu selected item position.
			SliderMenuFragment sliderMenuFragment = (SliderMenuFragment) getSherlockActivity()
					.getSupportFragmentManager().findFragmentById(
							R.id.menu_frame);
			if (sliderMenuFragment != null) {
				sliderMenuFragment
						.setRowSelected(HomeActivity.POSITION_TAB_HOME);
			}
		}
	};

	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}

	/** Make server request to get the Offers based on location mode. */
	private void callHomeOffersListWS(final byte downloadMode) {
		LogConfig.logv(LOG_TAG, "callOffersListWS(): downloadMode = "
				+ downloadMode);
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			ProgressBarHelper.dismissProgressBar(mHandler);
			prepareOffersListCursor();
			mDialogMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showCustomDialog(DialogConfig.DIALOG_ERROR);
			return;
		}

		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}

		// Set download mode again as this methods calls independently.
		mDownloadMode = downloadMode;
		Bundle params = new Bundle();
		params.putByte(HomeCouponWorker.DOWNLOAD_MODE, mDownloadMode);
		params.putByte(HomeCouponWorker.OFFERS_TYPE, getOffersType());
		params.putString(CommonConfig.STORE_ID, WSConfig.RETAILER_STORE_ID);
		mRequestManager.addOnRequestFinishedListener(HomeScreenFragment.this);
		mRequestType = REQUEST_TYPE.HOME_COUPON;
		mRequestId = mRequestManager.getHomeOfferList(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(HomeScreenFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE, -1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mDialogMessage = getResources().getString(
								R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mDialogMessage = getResources().getString(
								R.string.toast_server_connection_error);
					} else {
						mDialogMessage = getResources().getString(
								R.string.toast_response_error);
					}
				} else {
					mDialogMessage = getResources().getString(
							R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}

	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle
					.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			ProgressBarHelper.dismissProgressBar(mHandler);

			if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.HOME_COUPON) {
					offersDownloadedDoSomething();
				}

			} else if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				mDialogMessage = mResponseBundle
						.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mDialogMessage)
						&& (mRequestType != REQUEST_TYPE.GET_APP_CONFIG)
						&& (mRequestType != REQUEST_TYPE.GET_OFFER_COUNT)) {
					mErrorTitle = getResources().getString(
							R.string.dialog_error_title);
					showCustomDialog(DialogConfig.DIALOG_ERROR);
				}

			}
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {

		}
	};

	/** Method to call after successful download of offers list from server. */
	public void offersDownloadedDoSomething() {
		LogConfig.logv(LOG_TAG, "offersDownloadedDoSomething()");
		populateViews();
	}

	/** Method to populate the view on the screen. */
	private void populateViews() {
		LogConfig.logv(LOG_TAG, "populateViews()");
		prepareOffersListCursor();
	}

	/** Prepare offers list cursor by db query. */
	private void prepareOffersListCursor() {
		LogConfig.logv(LOG_TAG, "prepareOffersListCursor()");
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			getLoaderManager().destroyLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST);
			getLoaderManager().initLoader(
					DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST, null, this);
		}

	}

	@Override
	public Loader<Cursor> onCreateLoader(int token, Bundle bundle) {
		// TODO Auto-generated method stub
		int couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON; // default.
		if (getOffersType() == OffersType.COMMON_OFFERS) {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
		} else {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
		}
		if (token == DatabaseConfig.QUERY_TOKEN_COMMON_OFFER_LIST
				|| token == DatabaseConfig.QUERY_TOKEN_MYOFFER_LIST) {
			String selection = "";
			String categoryId = PreferenceConfig
					.getCategoryFilterId(getActivity());
			if (TextUtils.isEmpty(categoryId)) {
				return new CursorLoader(getActivity(),
						CouponDaoHome.CONTENT_URI, null,
						CouponDaoHome.WHERE_CLAUSE_COUPON_CHOOSER
								+ couponChooser, null, null);
			} else {
				categoryId = categoryId.replace("[", "").replace("]", "");
				if (categoryId.contains(UIApplication.NEW_CATEGORY_ID)) {
					// If all category filter is selected then also show
					// marketing messages
					// that don't have the category associated, or else hide
					// them.
					if (PreferenceConfig
							.getAllCategoryFiltersSelected(getActivity())) {
						selection = "SELECT * FROM TBL_COUPON_HOME WHERE "
								+ CouponDaoHome.COUPON_CHOOSER + " = "
								+ couponChooser + " AND ("
								+ CouponDaoHome.IS_NEW_COUPON + " = "
								+ CouponDaoHome.FLAG_VALUE_NEW_COUPON + " OR "
								+ CouponDaoHome.COUPON_ID + " IN (SELECT "
								+ CategoryCountDaoHome.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT_HOME WHERE "
								+ CategoryCountDaoHome.OFFER_TYPE + " = "
								+ couponChooser + " AND ("
								+ CategoryCountDaoHome.CATEGORY_ID + " IN ("
								+ categoryId + ") OR "
								+ CategoryCountDaoHome.CATEGORY_ID + "='"
								+ UIApplication.PROMO_CATEGORY_ID + "')))"
								+ " order by " + CouponDaoHome._ID;
					} else {
						selection = "SELECT * FROM TBL_COUPON_HOME WHERE "
								+ CouponDaoHome.COUPON_CHOOSER + " = "
								+ couponChooser + " AND ("
								+ CouponDaoHome.IS_NEW_COUPON + " = "
								+ CouponDaoHome.FLAG_VALUE_NEW_COUPON + " OR "
								+ CouponDaoHome.COUPON_ID + " IN (SELECT "
								+ CategoryCountDaoHome.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT_HOME WHERE "
								+ CategoryCountDaoHome.OFFER_TYPE + " = "
								+ couponChooser + " AND "
								+ CategoryCountDaoHome.CATEGORY_ID + " IN ("
								+ categoryId + ")))" + " order by "
								+ CouponDaoHome._ID;
					}
				} else {
					// If all category filter is selected then also show
					// marketing messages
					// that don't have the category associated, or else hide
					// them.
					if (PreferenceConfig
							.getAllCategoryFiltersSelected(getActivity())) {
						selection = "SELECT * FROM TBL_COUPON_HOME WHERE "
								+ CouponDaoHome.COUPON_CHOOSER + " = "
								+ couponChooser + " AND "
								+ CouponDaoHome.COUPON_ID + " IN (SELECT "
								+ CategoryCountDaoHome.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT_HOME WHERE "
								+ CategoryCountDaoHome.OFFER_TYPE + " = "
								+ couponChooser + " AND ("
								+ CategoryCountDaoHome.CATEGORY_ID + " IN ("
								+ categoryId + ") OR "
								+ CategoryCountDaoHome.CATEGORY_ID + "='"
								+ UIApplication.PROMO_CATEGORY_ID + "'))"
								+ " ORDER BY " + CouponDaoHome._ID;
					} else {
						selection = "SELECT * FROM TBL_COUPON_HOME WHERE "
								+ CouponDaoHome.COUPON_CHOOSER + " = "
								+ couponChooser + " AND "
								+ CouponDaoHome.COUPON_ID + " IN (SELECT "
								+ CategoryCountDaoHome.OFFER_ID
								+ " FROM TBL_CATEGORY_COUNT_HOME WHERE "
								+ CategoryCountDaoHome.OFFER_TYPE + " = "
								+ couponChooser + " AND "
								+ CategoryCountDaoHome.CATEGORY_ID + " IN ("
								+ categoryId + "))" + " ORDER BY "
								+ CouponDaoHome._ID;
					}
				}
				return new CursorLoader(getActivity(),
						CouponDaoHome.CONTENT_URI_FILTER_COUPON, null,
						selection, null, null);
			}
		}

		return null;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		// TODO Auto-generated method stub
		if (getActivity() == null) {
			return;
		}
		ProgressBarHelper.dismissProgressBar(mHandler);
		prepareOfferModelArray(cursor);
		if (loadingCounter == 1) {
			final Intent intent = new Intent(getActivity(),
					HomeOfferDetailActivity.class);
			intent.putExtra(HomeOfferDetailIntentKey.CURRENTLY_SELECTED_ITEM,
					itemHomePosition);
			intent.putExtra(HomeOfferDetailIntentKey.OFFER_COUNT,
					mCouponArray.size());
			startActivity(intent);
		}

	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		// TODO Auto-generated method stub

	}

	protected byte getOffersType() {
		// For Home page only Common Offers
		return OffersType.COMMON_OFFERS;

	}

	/** A method to prepare offer model array. **/
	private void prepareOfferModelArray(Cursor c) {
		LogConfig.logv(LOG_TAG, "prepareOfferModelArray()");
		if (mCouponArray != null) {
			mCouponArray.clear();
			mCouponArray = null;
		}
		mCouponArray = new SparseArray<HomeCoupon>();
		// If coming from notification then we have to load all offers in array
		// to show the
		// offers details screen.
		if (PreferenceConfig.getIsLaunchFromNotification(getActivity())) {
			int couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON; // default.
			if (getOffersType() == OffersType.COMMON_OFFERS) {
				couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
			} else {
				couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
			}
			CursorLoader loader = new CursorLoader(getActivity(),
					CouponDaoHome.CONTENT_URI, null,
					CouponDaoHome.WHERE_CLAUSE_COUPON_CHOOSER + couponChooser,
					null, null);
			c = loader.loadInBackground();
		}
		if (c != null) {
			c.moveToPosition(-1);
			while (c.moveToNext()) {
				try {
					HomeCoupon coupon = new HomeCoupon();
					coupon.mId = c
							.getInt(CouponDaoHome.CONTENT_COUPON_ID_COLUMN);
					coupon.mTitle = c
							.getString(CouponDaoHome.CONTENT_COUPON_NAME_COLUMN);
					coupon.mImageUrl = c
							.getString(CouponDaoHome.CONTENT_COUPON_IMAGE_URL_COLUMN);
					coupon.mDescription = c
							.getString(CouponDaoHome.CONTENT_COUPON_DESCRIPTION_COLUMN);
					coupon.mExpiryDate = c
							.getString(CouponDaoHome.CONTENT_EXPIRY_DATE_COLUMN);
					coupon.mCouponUrl = c
							.getString(CouponDaoHome.CONTENT_COUPON_URL_COLUMN);
					coupon.mCouponType = c
							.getString(CouponDaoHome.CONTENT_COUPON_TYPE_COLUMN);
					coupon.mDiscount = c
							.getString(CouponDaoHome.CONTENT_DISCOUNT_COLUMN);
					coupon.mFavoriteFlag = c
							.getInt(CouponDaoHome.CONTENT_COUPON_FAVORITE_FLAG_COLUMN);
					coupon.mCouponChooser = c
							.getInt(CouponDaoHome.CONTENT_COUPON_CHOOSER_COLUMN);
					coupon.mStoreIds = UIUtils.stringToArrayList(c
							.getString(CouponDaoHome.CONTENT_STORE_IDS_COLUMN));
					coupon.mExpires = c
							.getInt(CouponDaoHome.CONTENT_EXPIRES_COLUMN);
					coupon.mDecorators = UIUtils
							.stringToArrayList(c
									.getString(CouponDaoHome.CONTENT_DECORATORS_COLUMN));
					coupon.mBarcode = c
							.getString(CouponDaoHome.CONTENT_BARCODE_COLUMN);
					coupon.mBarcodeImageUrl = c
							.getString(CouponDaoHome.CONTENT_BARCODE_IMAGE_URL_COLUMN);
					coupon.mCouponCode = c
							.getString(CouponDaoHome.CONTENT_COUPON_CODE_COLUMN);
					coupon.mLargeImageUrl = c
							.getString(CouponDaoHome.CONTENT_COUPON_LARGE_IMAGE_URL_COLUMN);
					coupon.mLongDescription = c
							.getString(CouponDaoHome.CONTENT_COUPON_LONG_DESCRIPTION);
					coupon.mIsMarketingMessageFlag = c
							.getInt(CouponDaoHome.CONTENT_IS_MARKETING_MESSAGE_COLUMN);
					coupon.mRedeemableFlag = c
							.getInt(CouponDaoHome.CONTENT_REDEEMABLE_FLAG_COLUMN);
					coupon.mUsageType = c
							.getInt(CouponDaoHome.CONTENT_USAGE_TYPE_COLUMN);
					coupon.mThresholdLimit = c
							.getInt(CouponDaoHome.CONTENT_REDEEM_THRESHOLD_LIMIT_COLUMN);
					coupon.mExhaustedFlag = c
							.getInt(CouponDaoHome.CONTENT_EXHAUSTED_FLAG_COLUMN);
					if (couponHomeItemId.equalsIgnoreCase(c
							.getString(CouponDaoHome.CONTENT_COUPON_ID_COLUMN))) {
						itemHomePosition = c.getPosition();
					}
					mCouponArray.put(c.getPosition(), coupon);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			UIApplication app = (UIApplication) getActivity()
					.getApplicationContext();
			app.setCouponModelArrayHome(mCouponArray);
			// Close the locally created cursor.
			if (PreferenceConfig.getIsLaunchFromNotification(getActivity())) {
				c.close();
			}
		}
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showCustomDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(mActivity);
		dlg.setOnKeyListener(new OnKeyListener() {

			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(getResources().getString(R.string.app_name))
					.setMessage(mErrorMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									if (!(mActivity instanceof HomeActivity)) {
										mActivity.finish();
									}
								}
							});
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

}
