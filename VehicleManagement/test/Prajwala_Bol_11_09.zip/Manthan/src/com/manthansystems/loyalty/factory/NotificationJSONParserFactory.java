package com.manthansystems.loyalty.factory;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;

public class NotificationJSONParserFactory extends BaseJsonParser {
	/** Call to Parse notification response from JSON string. */
	public synchronized static HashMap<String, Object> parseNotificationResponse(String jsonData)
		throws JSONException {
		LogConfig.logd("Notification", "parseNotificationResponse");
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		ArrayList<Integer> couponIdArrayList = new ArrayList<Integer>();
		if (response.has(JSONTagConstants.RESPONSE_TAG_APS)) {
			JSONObject apsJSONObject = response.getJSONObject(JSONTagConstants.RESPONSE_TAG_APS);
			if (apsJSONObject.has(JSONTagConstants.RESPONSE_TAG_ALERT)) {
				map.put(CommonConfig.KEY_NAME_NOTIFICATION_OFFER_ALERT, 
						apsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_ALERT));
				LogConfig.logd("Notification", "parseNotificationResponse alert = "
						+ apsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_ALERT));
			}
		}
		if (response.has(JSONTagConstants.RESPONSE_TAG_TYPE) && 
				! response.isNull(JSONTagConstants.RESPONSE_TAG_TYPE)) {
			map.put(CommonConfig.KEY_NAME_NOTIFICATION_OFFER_TYPE, 
					response.getInt(JSONTagConstants.RESPONSE_TAG_TYPE));
			LogConfig.logd("Notification", "parseNotificationResponse tag = "
					+ response.getInt(JSONTagConstants.RESPONSE_TAG_TYPE));
		}
		if (response.has(JSONTagConstants.RESPONSE_TAG_MCID)) {
			JSONArray couponIdJSONArray = response.getJSONArray(JSONTagConstants.RESPONSE_TAG_MCID);
			int couponIdJSONArraySize = couponIdJSONArray.length();
			for (int i = 0; i < couponIdJSONArraySize; ++i) {
				couponIdArrayList.add(couponIdJSONArray.getInt(i));
				LogConfig.logd("Notification", "parseNotificationResponse multiple coupon id = "
						+ couponIdJSONArray.getInt(i));
			}
		}
		if (response.has(JSONTagConstants.RESPONSE_TAG_CID) && 
				!response.isNull(JSONTagConstants.RESPONSE_TAG_CID)) {
			couponIdArrayList.add(response.getInt(JSONTagConstants.RESPONSE_TAG_CID));
			LogConfig.logd("Notification", "parseNotificationResponse single coupon id = "
					+ response.getInt(JSONTagConstants.RESPONSE_TAG_CID));
		}
		map.put(CommonConfig.KEY_NAME_NOTIFICATION_OFFER_ARRAY_LIST, couponIdArrayList);
		return map;
	}
}
