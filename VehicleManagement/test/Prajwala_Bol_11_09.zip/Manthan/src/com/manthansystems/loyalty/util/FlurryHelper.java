/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.content.res.Resources;

import com.flurry.android.FlurryAgent;
import com.manthansystems.loyalty.R;

/** 
 * A helper class to manage flurry analytics.
 * @author Gaurav Agrawal {gaurav.agrawal@xymob.com}
 *
 */
public class FlurryHelper {
	
	private static String mFlurryUserId;
	
	/** A method to init flurry analytics **/
	public static void initFlurry(Context context) {
		initUserIdForFlurry(context);
		FlurryAgent.setLogEnabled(true);
		FlurryAgent.onStartSession(context, context.getResources().getString(R.string.flurry_key));
	}
	/** A method to init user id for flurry analytics **/
	private static void initUserIdForFlurry(Context context) {
		mFlurryUserId = UIUtils.getDeviceUniqueId(context);
	}
	
	/** A method to send analytics data to flurry analytics without parameters. **/
	public static void onEvent(Context context, int eventId) {
		String eventName = context.getResources().getString(eventId);
		FlurryAgent.onEvent(eventName, new HashMap<String, String>());
	}
	
	/** A method to send analytics data to flurry analytics with parameters in HashMap. **/
	public static void onEvent(Context context, int eventId, HashMap<String, String> hashMap) {
		Resources res = context.getResources();
		if (hashMap != null) {
			String eventName = res.getString(eventId);
			hashMap.put(res.getString(R.string.flurry_user_id), mFlurryUserId);
			FlurryAgent.onEvent(eventName, hashMap);
		} else {
			onEvent(context, eventId);
		}
	}
	
	/** A method to stop flurry sessions**/
	public static void stopFlurry(Context context) {
		FlurryAgent.onEndSession(context);
	}
	
	/** A method to track app launch analytics. **/
	public static void sendAppLaunchAnalytics(Context context) {
		onEvent(context,R.string.analytics_event_app_launched);
	}
	
	/** A method to track  in offer clicked analytics. **/
	public static void sendOfferClickedAnalytics(Context context, String offerTitle) {
		HashMap<String, String> map = new HashMap<String, String>();
		 map.put(context.getResources().getString(
				 R.string.analytics_event_offer_clicked), offerTitle);
		 onEvent(context, R.string.analytics_event_offer_clicked, map);
	}
	
	/** A method to track push notification clicked analytics. **/
	public static void sendPushNotificationClickedAnalytics(Context context, String status) {
		HashMap<String, String> map = new HashMap<String, String>();
		 map.put(context.getResources().getString(
				 R.string.analytics_event_push_notification_clicked), status);
		 onEvent(context, R.string.analytics_event_push_notification_clicked, map);
	}
	
	/** A method to track my category clicked analytics. **/
	public static void sendMyCategoryClickedAnalytics(Context context, ArrayList<String> categoryNameList) {
		HashMap<String, String> map = new HashMap<String, String>();
		int size = categoryNameList.size();
		for (int i = 0; i < size; i++) {
			map.put(context.getResources().getString(
					 R.string.analytics_event_my_category_clicked), categoryNameList.get(i));
		}
		onEvent(context, R.string.analytics_event_my_category_clicked, map);
	}
	
	/** A method to track favorite star clicked analytics. **/
	public static void sendFavoriteStarClickedAnalytics(Context context, String offerTitle, boolean isAddToFav) {
		HashMap<String, String> map = new HashMap<String, String>();
		String msg = "";
		if (isAddToFav) {
			msg = context.getResources().getString(R.string.add_to_favorite);
		} else {
			msg = context.getResources().getString(R.string.remove_from_favorite);
		}
		 map.put(msg + context.getResources().getString(
				 R.string.analytics_event_favorite_star_clicked_clicked), offerTitle);
		 onEvent(context, R.string.analytics_event_favorite_star_clicked_clicked, map);
	}
	
	/** A method to track my favorite tab clicked analytics. **/
	public static void sendMyFavoriteTabClickedAnalytics(Context context) {
		onEvent(context,R.string.analytics_event_my_favorite_tab_clicked);
	}
}
