/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

/**
 * A helper class that manages the call feature to any phone number given.
 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
 *
 */
public class CallHelper {
	private PhoneStateListener mListener;
	private TelephonyManager mTelMgr;
	
	public static CallHelper mCallHelper;

	/** Method to get the singleton of {@link CallHelper} */
	public static CallHelper getInstance() {
		if (mCallHelper != null) {
			return mCallHelper;
		} else {
			mCallHelper = new CallHelper();
			return mCallHelper;
		}
	}

	/** Method to initiate a call to given phone number. */
	public void makeCall(String phoneNumber, Context ctx) {
		mListener = new CallEndedListener();
		mTelMgr = (TelephonyManager) ctx
				.getSystemService(Context.TELEPHONY_SERVICE);

		// Register our listener to be notified of the beginning
		// and ending of calls
		mTelMgr.listen(mListener, PhoneStateListener.LISTEN_CALL_STATE);

		// Initiate the Call
		Intent intent = new Intent(Intent.ACTION_CALL,
				Uri.parse(new StringBuilder("tel:").append(phoneNumber)
						.toString()));
		ctx.startActivity(intent);
	}

	/** Method to unregister the call listener. */
	public void unregisterCallListener() {
		// Unregister the Listener
		if (mListener != null && mTelMgr != null) {
			mTelMgr.listen(mListener, PhoneStateListener.LISTEN_NONE);
		}
	}

	/**
	 * Override the methods for the state that you wish to receive updates for,
	 * and pass your PhoneStateListener object, along with bitwise-or of the
	 * LISTEN_ flags to TelephonyManager.listen().
	 * @see PhoneStateListener
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 * 
	 */
	private class CallEndedListener extends PhoneStateListener {
		private boolean called = false;

		@Override
		public void onCallStateChanged(int state, String incomingNumber) {
			super.onCallStateChanged(state, incomingNumber);

			// Don't fire before the call was made
			if (state == TelephonyManager.CALL_STATE_OFFHOOK)
				called = true;

			// Call has ended
			if (called && state == TelephonyManager.CALL_STATE_IDLE) {
				called = false;
				mTelMgr.listen(this, PhoneStateListener.LISTEN_NONE);
			}
		}
	}
}
