/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

import java.util.ArrayList;

/**
 * A model class that holds the offer data coming from server. 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class HomeCoupon {
	public int mId;
	public String mTitle;
	public String mImageUrl;
	public String mDescription;
	public String mExpiryDate;
	public String mCouponUrl;
	public String mCouponType;
	public String mDiscount;
	public int mFavoriteFlag;
	public int mCouponChooser;
	public ArrayList<String> mStoreIds;
	public int mExpires;
	public ArrayList<String> mDecorators;
	public String mLargeImageUrl;
	public String mBarcode;
	public String mBarcodeImageUrl;
	public String mCouponCode;
	public int mIsNewCouponFlag;
	public String mLongDescription;
	public int mIsMarketingMessageFlag;
	public int mRedeemableFlag;
	public int mUsageType;
	public int mThresholdLimit;
	public int mExhaustedFlag;
	
	/** Default constructor. */
	public HomeCoupon() {
		mStoreIds = new ArrayList<String>();
		mDecorators = new ArrayList<String>();		
	}
}
