/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.Timer;
import java.util.TimerTask;

import net.sourceforge.zbar.Config;
import net.sourceforge.zbar.Image;
import net.sourceforge.zbar.ImageScanner;
import net.sourceforge.zbar.Symbol;
import net.sourceforge.zbar.SymbolSet;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.Size;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.receiver.ScreenOnOffReceiver;
import com.manthansystems.loyalty.ui.phone.CustomWebViewActivity;
import com.manthansystems.loyalty.util.CameraPreview;
import com.manthansystems.loyalty.util.CameraPreviewRobinson;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.ToastHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.LoyaltyCardWorker.LoyaltyCardWorkerMode;

/**
 * A {@link SherlockFragment} class that do the scanning of Barcode and sends
 * the scanned barcode number to our server so to create and get the Loyalty
 * Card details.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class ScanBarcodeFragmentRobinson extends SherlockFragment {
	
	private final static String LOG_TAG = "ScanBarcodeFragment";
	
	static {
		System.loadLibrary("iconv");
	}
	
	private final byte SCAN_RESULT_QRCODE = 64;

	private Camera mCamera;
	private CameraPreviewRobinson mPreview;
	private ImageScanner mImageScanner;
	private BroadcastReceiver mReceiver = null;
	private Handler mAutoFocusHandler;
	private ViewGroup mViews = null;
	private TextView mTextViewFlashLightSwitch;

	private String mQRCodeResult;
	private String mQRCodeResultDialogTitle;
	private String mQRCodeResultDialogMessage;
	private String mErrorDialogTitle;
	private String mErrorDialogMessage;
	private boolean mPreviewing = true;
	private boolean mFlashLightToggleStatus = false;
	private boolean mShowProgressBar = false;
	private AlertDialog mAlertDialog;
	private Timer mScannerTimeoutTimer;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// initialize screen on/off receiver.
		mReceiver = new ScreenOnOffReceiver();
		IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
		getActivity().registerReceiver(mReceiver, filter);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(
				R.layout.fragment_scan_barcode, null);
		// For some reason, if we omit this, NoSaveStateFrameLayout thinks we
		// are
		// FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top
		// of the activity.
		root.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT));
		mViews = root;
		return root;
	}

	@Override
	public void onResume() {
		super.onResume();
		mFlashLightToggleStatus = false;
		mPreviewing = true;
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		}
		mShowProgressBar = true;
		new Handler().postDelayed(new Runnable() {
			public void run() { // ONLY WHEN SCREEN TURNS ON
				if (!ScreenOnOffReceiver.wasScreenOn) {
					// THIS IS WHEN ONRESUME() IS CALLED DUE TO A SCREEN STATE
					// CHANGE
					ScreenOnOffReceiver.wasScreenOn = true;
					getActivity().finish();
				} else {
					// THIS IS WHEN ONRESUME() IS CALLED WHEN THE SCREEN STATE
					// HAS NOT CHANGED
					bindViews();
				}
			}
		}, 50L);
	}

	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		UIUtils.setTitleView(R.string.label_tab_loyalty_card, false, true, false, getSherlockActivity());
		mAutoFocusHandler = new Handler();
		mCamera = getCameraInstance();
		mImageScanner = new ImageScanner();
		mImageScanner.setConfig(0, Config.X_DENSITY, 3);
		mImageScanner.setConfig(0, Config.Y_DENSITY, 3);
		mImageScanner.setConfig(Symbol.UPCA, Config.ENABLE, 1);
		mImageScanner.setConfig(Symbol.UPCE, Config.ENABLE, 1);
		mPreview = new CameraPreviewRobinson(getActivity(), mCamera, previewCb, autoFocusCB);
		final FrameLayout preview = (FrameLayout) mViews.findViewById(R.id.cameraPreview);
		preview.addView(mPreview, 0);
		startScanerTimeoutListener();
		// Hide the flash light On/Off switch if this feature is not supported on device.
		mTextViewFlashLightSwitch = (TextView) mViews.findViewById(R.id.TextView_flash_switch);
		boolean isFlashlightSupported = getSherlockActivity()
			.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
		if (!isFlashlightSupported) {
			mTextViewFlashLightSwitch.setVisibility(View.GONE);
		} else {
			mTextViewFlashLightSwitch.setVisibility(View.VISIBLE);
			mTextViewFlashLightSwitch.setBackgroundResource(R.drawable.ic_flash_disabled);
			mTextViewFlashLightSwitch.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Set the flash light ON or OFF as per users last decision.
					toggleFlashlight();
				}
			});
		}
	}

	@Override
	public void onPause() {
		super.onPause();
		getActivity().setRequestedOrientation(
				ActivityInfo.SCREEN_ORIENTATION_SENSOR);
		releaseCamera();
		stopScannerTimeoutListener();
		dismissActiveDialog();
	}

	/** A safe way to get an instance of the Camera object. */
	public static Camera getCameraInstance() {
		Camera c = null;
		try {
			if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.GINGERBREAD) {
				// only for android versions post gingerbread
				c = openCamera();
			} else {
				// only for android versions gingerbread and prior to it
				c = Camera.open();
			}
		} catch (Exception e) {
			LogConfig.logd(LOG_TAG, "getCameraInstance()", e);
		}
		return c;
	}

	/**
	 * The method shall return the camera only for the sdk version greater than
	 * Gingerbread since the devices(mainly tabs) having only the front camera
	 * and no back camera can be found only in versions greater than
	 * Gingerbread.
	 */
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	public static Camera openCamera() {
		int numCameras = Camera.getNumberOfCameras();
		if (numCameras == 0) {
			return null;
		}
		int index = 0;
		while (index < numCameras) {
			Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
			Camera.getCameraInfo(index, cameraInfo);
			if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
				break;
			}
			index++;
		}
		Camera camera;
		if (index < numCameras) {
			camera = Camera.open(index);
		} else {
			camera = Camera.open(0);
		}
		return camera;
	}

	/** Method to release the camera resources. */
	private void releaseCamera() {
		if (mCamera != null) {
			mPreviewing = false;
			mPreview.getHolder().removeCallback(mPreview);
			mCamera.setPreviewCallback(null);
			mCamera.cancelAutoFocus();
			mCamera.stopPreview();
			mCamera.release();
			mCamera = null;
		}
	}

	/** Set enable the camera auto focus. */
	private Runnable doAutoFocus = new Runnable() {
		public void run() {
			if (mPreviewing)
				if (mCamera != null) {
					mCamera.autoFocus(autoFocusCB);
				} else {
					ToastHelper.showToastMessage(R.string.msg_camera_not_init_msg,
							getActivity(), true);
					return;
				}
		}
	};

	/** A {@link PreviewCallback} that invokes when preview frames renders on screen. */
	private PreviewCallback previewCb = new PreviewCallback() {
		public void onPreviewFrame(byte[] data, Camera camera) {
			Camera.Parameters parameters = camera.getParameters();
			Size size = parameters.getPreviewSize();
			Image barcode = new Image(size.width, size.height, "Y800");
			barcode.setData(data);
			int result = mImageScanner.scanImage(barcode);
			if (result != 0) {
				SymbolSet syms = mImageScanner.getResults();
				for (Symbol sym : syms) {
					if (sym.getType() == SCAN_RESULT_QRCODE) {
						mPreviewing = false;
						mCamera.setPreviewCallback(null);
						mCamera.stopPreview();
						stopScannerTimeoutListener();
						showDialog(DialogConfig.DIALOG_QRCODE_NOT_SUPPORTED);
						return;
					}
				}
				mPreviewing = false;
				mCamera.setPreviewCallback(null);
				mCamera.stopPreview();
				stopScannerTimeoutListener();
//				SharedPreferences prefs = PreferenceConfig
//						.getInstance(getActivity());
//				boolean soundEnable = prefs.getBoolean(
//						PreferenceConfig.ENABLE_SOUND, true);
				for (Symbol sym : syms) {
//					if (soundEnable) 
					{
						@SuppressWarnings("static-access")
						final AudioManager mAudioManager = (AudioManager) getActivity()
								.getSystemService(getActivity().AUDIO_SERVICE);
						mAudioManager
								.setStreamVolume(
										AudioManager.STREAM_MUSIC,
										mAudioManager
												.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
										0);

						MediaPlayer mPlayer = MediaPlayer.create(getActivity(),
								R.raw.scan_beep);
						mPlayer.start();
					}
					if (sym.getType() == SCAN_RESULT_QRCODE) {
//						showQRCodeResult(sym.getData());
					} else {
						showBarcodeResult(sym.getData(), sym.getType());
					}
				}
			}
		}
	};

	/**
	 * Method to show QR code scan result. It opens the webview if result is a
	 * web url or else it does nothing.
	 */
	@SuppressWarnings("unused")
	private void showQRCodeResult(final String scanResult) {
		mQRCodeResult = scanResult;
		if (!TextUtils.isEmpty(mQRCodeResult) 
				&& (mQRCodeResult.contains("http") || mQRCodeResult.contains("www."))) {
			Resources resources = getResources();
			mQRCodeResultDialogTitle = resources
					.getString(R.string.title_dialog_scan_result_qrcode);
			mQRCodeResultDialogMessage = resources
					.getString(R.string.msg_dialog_scan_result_qrcode)
					+ "\n"
					+ scanResult;
			showDialog(DialogConfig.DIALOG_SCAN_RESULT_QRCODE);
		} else {
			LogConfig.logd(LOG_TAG, "showQRCodeResult(): SCAN SUCCESS");
			if (mAlertDialog != null) {
				mAlertDialog.dismiss();
			}
			PreferenceConfig.setLoyaltyCardWorkerMode(
					LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_SCAN, HomeActivity.getSlidingActivity());
			PreferenceConfig.setLoyaltyCardNumber(scanResult, HomeActivity.getSlidingActivity());
			PreferenceConfig.setLaunchLoyaltyCardDetailsScreen(true, HomeActivity.getSlidingActivity());
			getActivity().finish();
		}
	}

	/**
	 * Method to show the barcode scan result. If barcode is valid then will
	 * send the barcode to server to get the loyalty card details or else error
	 * dialog will be shown with appropriate message.
	 */
	private void showBarcodeResult(String scanResult, int type) {
//		final Resources resources = getResources();
		/*if (scanResult != null && scanResult.length() > 4
				&& scanResult.length() < 17) {*/
			//if (UIUtils.isValidBarcode(scanResult)) {
				LogConfig.logd(LOG_TAG, "SCAN SUCCESS");
				if (mAlertDialog != null) {
					mAlertDialog.dismiss();
				}
//				scanResult = scanResult.replace(" ", "");
				PreferenceConfig.setLoyaltyCardWorkerMode(
						LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_SCAN, HomeActivity.getSlidingActivity());
				PreferenceConfig.setLoyaltyCardNumber(scanResult, HomeActivity.getSlidingActivity());
				PreferenceConfig.setLaunchLoyaltyCardDetailsScreen(true, HomeActivity.getSlidingActivity());
				PreferenceConfig.setBarCodeType(type, getActivity());
				getActivity().finish();
			/*} else {
				mErrorDialogTitle = resources
						.getString(R.string.title_invalid_barcode);
				mErrorDialogTitle = mErrorDialogTitle + "\n" + scanResult;
				mErrorDialogMessage = resources
						.getString(R.string.msg_invalid_barcode);
				showDialog(DialogConfig.DIALOG_ERROR);
			}*/
		/*} else {
			mErrorDialogTitle = resources.getString(R.string.title_invalid_barcode);
			if (!TextUtils.isEmpty(scanResult)) {
				mErrorDialogTitle = mErrorDialogTitle + "\n" + scanResult;
			}
			mErrorDialogMessage = resources.getString(R.string.msg_invalid_upc);
			showDialog(DialogConfig.DIALOG_ERROR);
		}*/
	}

	/** Mimic continuous auto-focusing via {@link AutoFocusCallback}. */
	private AutoFocusCallback autoFocusCB = new AutoFocusCallback() {
		public void onAutoFocus(boolean success, Camera camera) {
			mAutoFocusHandler.postDelayed(doAutoFocus, 1000);
		}
	};

	/** Method to toggle the flash light ON/OFF switch. */
	private void toggleFlashlight() {
		Parameters p = mCamera.getParameters();
		if (!mFlashLightToggleStatus) {
			p.setFlashMode(Parameters.FLASH_MODE_TORCH);
			mTextViewFlashLightSwitch.setBackgroundResource(R.drawable.ic_flash_enabled);
		} else {
			p.setFlashMode(Parameters.FLASH_MODE_OFF);
			mTextViewFlashLightSwitch.setBackgroundResource(R.drawable.ic_flash_disabled);
		}
		mFlashLightToggleStatus = !mFlashLightToggleStatus;
		if (mCamera != null) {
			mCamera.setParameters(p);
		}
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {

			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorDialogTitle)
			.setMessage(mErrorDialogMessage)
			.setCancelable(true)
			.setPositiveButton(android.R.string.ok,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,
							int which) {
						dialog.dismiss();
						if (mCamera != null) {
							mCamera.setPreviewCallback(previewCb);
							mCamera.startPreview();
							mPreviewing = true;
							mCamera.autoFocus(autoFocusCB);
						} else {
							ToastHelper.showToastMessage(R.string.msg_camera_not_init_msg,
									getActivity(), true);
							return;
						}
					}
				});
			break;

		case DialogConfig.DIALOG_SCAN_RESULT_QRCODE:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mQRCodeResultDialogTitle)
			.setMessage(mQRCodeResultDialogMessage)
			.setCancelable(true)
			.setNegativeButton(android.R.string.cancel,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog,
							int which) {
						dialog.dismiss();
						if (mCamera != null) {
							mCamera.setPreviewCallback(previewCb);
							mCamera.startPreview();
							mPreviewing = true;
							mCamera.autoFocus(autoFocusCB);
						} else {
							ToastHelper.showToastMessage(R.string.msg_camera_not_init_msg,
									getActivity(), true);
							return;
						}
					}
				})
			.setPositiveButton(android.R.string.ok,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,
							int which) {
						if (!TextUtils.isEmpty(mQRCodeResult)) {
							dialog.dismiss();
							Intent intent = new Intent(getActivity(),
									CustomWebViewActivity.class);
							intent.putExtra(CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_URL,
									mQRCodeResult);
/*							intent.putExtra(CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_TITLE,
									getResources().getString(R.string.label_scan_result));
*/							startActivity(intent);
						}
					}
				});
			break;
			
		case DialogConfig.DIALOG_SCANNER_TIMEOUT:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(R.string.msg_scanner_timeout)
			.setCancelable(true)
			.setPositiveButton(android.R.string.ok,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,
							int which) {
						dialog.dismiss();
						getActivity().finish();
					}
				});
			break;
			
		case DialogConfig.DIALOG_QRCODE_NOT_SUPPORTED:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(R.string.msg_invalid_barcode)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,
							int which) {
						dialog.dismiss();
						getActivity().finish();
					}
				});
			break;
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		getActivity().unregisterReceiver(mReceiver);
		if (mViews != null) {
			UIUtils.unbindDrawables(mViews
					.findViewById(R.id.root_view_cameraPreview));
			System.gc();
		}
	}
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
	
	private String getBarCodeSymbolType(int type) {
		String symbolType;
		switch (type) {
		case Symbol.CODABAR:
			symbolType = "CODABAR";
			break;
			
		case Symbol.CODE128:
			symbolType = "CODE 128";
			break;
			
		case Symbol.CODE39:
			symbolType = "CODE 39";
			break;
			
		case Symbol.CODE93:
			symbolType = "CODE 93";
			break;
			
		case Symbol.DATABAR:
			symbolType = "GS1 DataBar (RSS)";
			break;
			
		case Symbol.DATABAR_EXP:
			symbolType = "GS1 DataBar Expanded";
			break;
			
		case Symbol.EAN13:
			symbolType = "EAN-13";
			break;
			
		case Symbol.EAN8:
			symbolType = "EAN-8";
			break;
			
		case Symbol.I25:
			symbolType = "Interleaved 2 of 5";
			break;
			
		case Symbol.ISBN10:
			symbolType = "ISBN-10";
			break;
			
		case Symbol.ISBN13:
			symbolType = "ISBN-13";
			break;
			
		case Symbol.PARTIAL:
			symbolType = "Intermediate status";
			break;
			
		case Symbol.PDF417:
			symbolType = "PDF417";
			break;
			
		case Symbol.QRCODE:
			symbolType = "QR Code";
			break;
			
		case Symbol.UPCA:
			symbolType = "UPC-A";
			break;
			
		case Symbol.UPCE:
			symbolType = "UPC-E";
			break;
				
		default:
			symbolType = "";
			break;
		}
		return symbolType;
	}
	
	private class ScannerTimeOutListner extends TimerTask {
		
		@Override
		public void run() {
			if (getActivity() != null) {
				getActivity().runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						showDialog(DialogConfig.DIALOG_SCANNER_TIMEOUT);
					}
				});
			}
		}
	}
	
	/** Method to Start the Scanner timeout listener. */
	private void startScanerTimeoutListener() {
		mScannerTimeoutTimer = new Timer();
		mScannerTimeoutTimer.schedule(new ScannerTimeOutListner(),
				BusinessLogicConfig.SCANNER_TIMEOUT_DELAY);
	}
	
	/** Method to Stop the Scanner timeout listener. */
	public void stopScannerTimeoutListener() {
		if (mScannerTimeoutTimer != null) {
			mScannerTimeoutTimer.cancel();
			mScannerTimeoutTimer = null;
		}
	}
}
