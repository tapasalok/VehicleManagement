/**
 * Copyright 2013 XYMOB Inc.
 */
package com.manthansystems.loyalty.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.ui.phone.EnterHomeZipCodeActivity;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.LoginWorker;

/**
 * A Fragment class that will take token id to activate user. This token sent to the
 * user's email id. This class extends {@link SherlockFragmentActivity}.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class EnterTokenFragment extends SherlockFragment implements OnRequestFinishedListener {

	private final String LOG_TAG = "EnterTokenFragment";
	
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.EnterTokenFragment#RequestId";
	
	private ViewGroup mView;
	private Handler mHandler;
    private RequestManager mRequestManager;
    private int mRequestId = -1;
    
    private String mErrorMessage;
    private String mErrorTitle;
    private Bundle mResponseBundle;
	
	private boolean mShowProgressBar = false;
	private Button mButtonOk;
	private Button mButtonCancel;
	private EditText mEditTextToken;
	private String mDialogMessage;
	private int mWrongTokenCounter = 0;
	private CustomSwipeDetector mCustomSwipeDetector;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogConfig.logd(LOG_TAG, "onCreate()");
		if (savedInstanceState == null) {
			// Do nothing.
		} else {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
		}
		mDialogMessage = getActivity().getIntent().getStringExtra(CommonConfig.KEY_NAME_RESULTS_MESSAGE);
		mHandler = new Handler();
    	mRequestManager = RequestManager.from(getActivity());
    	mCustomSwipeDetector = new CustomSwipeDetector(getActivity(), (OnSwipeListener) getActivity());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_login_screen, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;   
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		showDialog(DialogConfig.DIALOG_ACTIVATION_CODE_SENT);
		PreferenceConfig.setTokenScreenVisiblity(true, getActivity());
	}
	
	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logd(LOG_TAG, "onPause()");
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(EnterTokenFragment.this);
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logd(LOG_TAG, "onResume()");
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(EnterTokenFragment.this);
            } else {
                mRequestId = -1;
            }
        }
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
        outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		}
		return super.onOptionsItemSelected(item);
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.app_name, false, true, false, getSherlockActivity());
		mEditTextToken = (EditText) mView.findViewById(R.id.editText_enter_id);
		mEditTextToken.setHint(R.string.enter_token_hint);
		mEditTextToken.setInputType(InputType.TYPE_CLASS_NUMBER);
		InputFilter[] FilterArray = new InputFilter[1];
		FilterArray[0] = new InputFilter.LengthFilter(BusinessLogicConfig.TOKEN_DIGIT_THRESHOLD);
		mEditTextToken.setFilters(FilterArray);
		mEditTextToken.setOnEditorActionListener(new EditText.OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_DONE 
			            || actionId == EditorInfo.IME_NULL
			            || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
					verifyToken();
					return true;
				}
				return false;
			}
		});
		mButtonOk = (Button) mView.findViewById(R.id.Button_ok);
		((TextView) mView.findViewById(R.id.textView_enter_id)).setText(getResources().getString(R.string.enter_token));
		mButtonCancel = ((Button) mView.findViewById(R.id.Button_cancel));
		mButtonCancel.setVisibility(View.GONE);
		RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(mButtonOk.getLayoutParams());
		layoutParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
		layoutParams.addRule(RelativeLayout.BELOW, R.id.editText_enter_id);
		layoutParams.setMargins(10, 20, 10, 10);
		mButtonOk.setLayoutParams(layoutParams);
		mButtonOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				verifyToken();
			}
		});
		mView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return mCustomSwipeDetector.onTouchEvent(event);
            }
        });
	}
	
	/** Make server request to verify token from server. */
	private void callVerifyTokenWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		
		ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());

		Bundle params = new Bundle();
		params.putByte(LoginWorker.KEY_NAME_BUNDLE_LOGIN_WORKER_MODE, LoginWorker.WORKER_MODE_ACTIVATE_USER);
		params.putString(CommonConfig.KEY_NAME_TOKEN, mEditTextToken.getText().toString().trim());
		mRequestManager.addOnRequestFinishedListener(EnterTokenFragment.this);
		mRequestId = mRequestManager.activateUser(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			// must reset refreshing, if requested or not.
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(EnterTokenFragment.this);
			ProgressBarHelper.dismissProgressBar(mHandler);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
 
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				tokenVerifiedSuccessfullyDoSomething();
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				mWrongTokenCounter++;
				mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_INVALID_TOKEN);
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
		}
	};
	
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_INVALID_TOKEN:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.dialog_error_title)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int arg1) {
					dialog.dismiss();
					if (mWrongTokenCounter == BusinessLogicConfig.WRONG_TOKEN_THRESHOLD) {
						mWrongTokenCounter = 0;
						startActivity(new Intent(getActivity(), EnterEmailActivity.class));
						getActivity().finish();
					}
				}
			}) ;
			break;
			
		case DialogConfig.DIALOG_ACTIVATION_CODE_SENT:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.dialog_successfully_title)
			.setMessage(mDialogMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int arg1) {
					dialog.dismiss();
				}
			}) ;
			break;
		}
		dlg.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logd(LOG_TAG, "onDestroy()");
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_login_screen));
		   System.gc();
	   }
	   PreferenceConfig.setTokenScreenVisiblity(false, getActivity());
	}
	
	/** A method to perform required acton after successfully activating user. */
	private void tokenVerifiedSuccessfullyDoSomething() {
		Activity activity = getActivity();
		PreferenceConfig.setEmailScreenShown(true, activity);
		PreferenceConfig.setUserValidity(true, activity);
		// When user logged in refresh the offers.
		PreferenceConfig.setPersonalOffersTimestamp(0L, activity);
		PreferenceConfig.setCommonOffersTimestamp(0L, activity);
		startActivity(new Intent(activity, EnterHomeZipCodeActivity.class));
		activity.finish();
	}
	
	/** A method to verify token. if valid token is entered then it make network
	 * call to activate user. 
	**/
	private void verifyToken() {
		UIUtils.hideKeyboard(getActivity(), mEditTextToken);
		Resources resource = getResources();
		String token = mEditTextToken.getText().toString().trim();
		if (TextUtils.isEmpty(token)) {
			mErrorTitle = resource.getString(R.string.dialog_error_title);
			mErrorMessage = resource.getString(R.string.enter_token_hint);
			showDialog(DialogConfig.DIALOG_ERROR);
		} else {
			if (token.length() == BusinessLogicConfig.TOKEN_DIGIT_THRESHOLD) {
				callVerifyTokenWS();
			} else {
				mWrongTokenCounter ++;
				mErrorMessage = resource.getString(R.string.invalid_token);
				showDialog(DialogConfig.DIALOG_INVALID_TOKEN);
			}
		}
	}
}
