/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnKeyListener;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.phone.EnterCardNumberActivity;
import com.manthansystems.loyalty.ui.phone.ScanBarcodeActivity;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.LoyaltyCardWorker.LoyaltyCardWorkerMode;

/**
 * An {@link SherlockFragment} class that will give option to the user to join
 * loyalty program and scan barcode or manually enter barcode to create virtual
 * loyalty card on server.
 * 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 * 
 */
public class LoyaltyCardLoginFragment extends SherlockFragment implements OnRequestFinishedListener{

	private final String LOG_TAG = "LoyaltyCardLoginFragment";
	public static final String STRING_EXTRA_IS_COMING_FROM_LOYALTY_CARD_DETAILS_SCREEN 
		= "com.manthansystems.loyalty.ui.LoyaltyCardLoginFragment#isComingFromCardDetailsScreen";
	private ViewGroup mView;
	private boolean mShowProgressBar = false;
	private Handler mHandler;
    private RequestManager mRequestManager;
    private int mRequestId = -1;
    private Bundle mResponseBundle;
    private static byte mRequestType;
    private boolean mIsComingFromLoyaltyCardDetailScreen = false;
    private String mDialogMessage;
	private String mErrorTitle;
	private AlertDialog mAlertDialog;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogConfig.logd(LOG_TAG, "onCreate()");
		mHandler = new Handler();
    	mRequestManager = RequestManager.from(getActivity());
    	Bundle args = getArguments();
    	if (args != null) {
    		mIsComingFromLoyaltyCardDetailScreen = args.getBoolean(
    				STRING_EXTRA_IS_COMING_FROM_LOYALTY_CARD_DETAILS_SCREEN, false);
    	}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_loyalty_card_login, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;   
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		if (PreferenceConfig.getFirstLaunchLoyaltyCardStatus(getActivity())
				&& !mIsComingFromLoyaltyCardDetailScreen) {
			LogConfig.logd(LOG_TAG, "onActivityCreated(): call callGetLoyaltyCardDetailsWS()");
			callGetLoyaltyCardDetailsWS();
		}
		mIsComingFromLoyaltyCardDetailScreen = false;
	}
	
	@Override
	public void onPause() {
		super.onPause();
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(LoyaltyCardLoginFragment.this);
		}
		// un-register sliding menu open listener.
		((HomeActivity)getActivity()).getSlidingMenu().setOnOpenListener(null);
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logd(LOG_TAG, "onResume()");
		// register sliding menu open listener to update slide menu row selection.
		((HomeActivity)getActivity()).getSlidingMenu().setOnOpenListener(onSlidingMenuOpenListener);
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(LoyaltyCardLoginFragment.this);
            } else {
                mRequestId = -1;
            }
        }
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		menu.clear();
//		inflater.inflate(R.menu.information_menu_item, menu);
		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.menu_information) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		
		UIUtils.setTitleView(R.string.label_tab_loyalty_card, false, true, true, getSherlockActivity());
		
		View view = ((SherlockFragmentActivity) getActivity())
				.getSupportActionBar().getCustomView();
		if (view != null) {
			view.findViewById(R.id.ImageView_Slide_Menu_more_icon)
					.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							((BaseSlidingActivity) getActivity())
									.getSlidingMenu().showMenu(true);
						}
					});

			view.findViewById(R.id.ImageView_Slide_Menu_icon)
					.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							if (PreferenceConfig
									.getHomeTabEnabled(getActivity()) == 0) {
								Toast.makeText(
										getActivity(),
										getString(R.string.label_no_home_page),
										Toast.LENGTH_SHORT).show();

							} else if (!NetworkHelper.isNetworkAvailable(getActivity())) {
								mDialogMessage = getResources().getString(
										R.string.network_not_available_msg);
								mErrorTitle = getResources().getString(
										R.string.network_not_available_title);
								showDialog(DialogConfig.DIALOG_ERROR);
								// must reset refreshing, if requested or not.
								return;
							}else {
								PreferenceConfig.putComingFromHomeIcon(
										getActivity(), true);
								startActivity(new Intent(getActivity(),
										HomeActivity.class));
							}

						}
					});
		}
//		final Button buttonJoinNow = (Button) mView.findViewById(R.id.button_join_now);
		final Button buttonScanCard = (Button) mView.findViewById(R.id.button_scan_card);
		final Button buttonEnterCardNo = (Button) mView.findViewById(R.id.button_enter_card_no);
		
		/*buttonJoinNow.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), CustomWebViewActivity.class);
				intent.putExtra(CustomWebViewActivity.KEY_NAME_CUSTOM_WEBVIEW_TITLE,
						getActivity().getResources().getString(R.string.label_tab_loyalty_card));
				intent.putExtra(CustomWebViewActivity.KEY_NAME_CUSTOM_HTTP_HEADERS, true);
				intent.putExtra(CustomWebViewActivity.KEY_NAME_SHOW_HEADER_TITLE, true);
				intent.putExtra(CustomWebViewActivity.KEY_NAME_HEADER_TITLE,
						getActivity().getResources().getString(R.string.title_join_program));
				intent.putExtra(CustomWebViewActivity.KEY_NAME_CUSTOM_WEBVIEW_URL, WSConfig.URL_LOYALTY_CARD_JOIN);
				// Set the custom http header to be set on webview.
				Map<String, String> headerMap = new HashMap<String, String>();
				ArrayList<Header> headers = BaseWorker.getBasicHeaders(getActivity());
				for (Header h : headers) {
					headerMap.put(h.getName(), h.getValue());
				}
				((UIApplication) getActivity().getApplication()).setCustomHttpHeaderToWebView(
						headerMap);
				getActivity().startActivity(intent);
			}
		});*/
		
		buttonScanCard.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), ScanBarcodeActivity.class);
				getActivity().startActivity(intent);
			}
		});
		
		buttonEnterCardNo.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), EnterCardNumberActivity.class);
				getActivity().startActivity(intent);
			}
		});
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(mErrorTitle)
					.setMessage(mDialogMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;
		}

		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
		mDialogMessage = "";
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logd(LOG_TAG, "onDestroy()");
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_loyalty_card_login));
		   System.gc();
	   }
	}
	
	/** Listener that invokes for Sliding menu open event. */
	private SlidingMenu.OnOpenListener onSlidingMenuOpenListener = new SlidingMenu.OnOpenListener() {
		@Override
		public void onOpen() {
			// Now update the sliding menu selected item position.
			SliderMenuFragment sliderMenuFragment = (SliderMenuFragment) getSherlockActivity()
					.getSupportFragmentManager().findFragmentById(
							R.id.menu_frame);
			if (sliderMenuFragment != null) {
				sliderMenuFragment.setRowSelected(HomeActivity.POSITION_TAB_LOYALTY_CARD);
			}
		}
	};
	
	/** Make server request to get the Loyalty Card details from server. */
	private void callGetLoyaltyCardDetailsWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());
		}
		Bundle params = new Bundle();
		params.putByte(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_LOYALTY_CARD_WORKER_MODE,
				LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY);
		mRequestManager.addOnRequestFinishedListener(LoyaltyCardLoginFragment.this);
		mRequestType = REQUEST_TYPE.VIEW_LOYALTY_CARD;
		mRequestId = mRequestManager.loyaltyCard(DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			// must reset refreshing, if requested or not.
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(LoyaltyCardLoginFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
	
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.VIEW_LOYALTY_CARD ) {
					loyaltyCardDetailDownloaded();
				} 
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
		}
	};
	
	/** Method to perform action after successful download of loyalty card detail. */
	private void loyaltyCardDetailDownloaded() {
		ProgressBarHelper.dismissProgressBar(mHandler);
		PreferenceConfig.setFirstLaunchLoyaltyCardStatus(false, getActivity());
		// set the mode to NONE so that on subsequent fragment resume will not go for
		// loyalty card details download on first go.
		PreferenceConfig.setLoyaltyCardWorkerMode(
				LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_NONE, getActivity());
		// Close the detail screen and show the loyalty card creation screen.
		((HomeActivity) getActivity()).removeTabFragment(HomeActivity.TAB_LOYALTY_CARD_VIEW);
		((HomeActivity) getActivity()).switchContent(
						HomeActivity.TAB_LOYALTY_CARD_VIEW, LoyaltyCardDetailFragment.class, null);
	}
}
