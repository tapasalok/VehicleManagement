/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

/**
 * A model class that holds the store data coming from server. 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class HomeStore {
	public String mId;
	public String mAddress1;
	public String mAddress2;
	public String mCity;
	public String mState;
	public String mZip;
	public String mLat;
	public String mLong;
	public String mPhoneNumber;
	public String mName;

	/** Default Constructor. */
	public HomeStore() {
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			// Do nothing.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.finalize();
		}
	}
}
