/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.data.provider;

import java.util.ArrayList;

import android.content.ContentProvider;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.provider.BaseColumns;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDaoHome;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDaoHome;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDaoHome;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDaoHome;

/**
 *	A {@link ContentProvider} class to handle the database with respect to this application.
 *	@author Rakesh Saytode {rakesh.saytode@xymob.com}
 */
public class DatabaseProvider extends ContentProvider {

    private static final String LOG_TAG = DatabaseProvider.class.getSimpleName();

    protected static final String DATABASE_NAME = "CouponVaultDB.db";

    // Any changes to the database format *must* include update-in-place code.
    // Original version: 1
    public static final int DATABASE_VERSION = 7;

    public static String AUTHORITY = "com.manthansystems.loyalty.data.provider.DatabaseProvider";

    public static final Uri INTEGRITY_CHECK_URI = Uri.parse("content://" + AUTHORITY + "/integrityCheck");

    private static final int BASE_INDEX_OFFER = 0;
    private static final int OFFER = BASE_INDEX_OFFER + 1;
    private static final int OFFER_ID = BASE_INDEX_OFFER + 2;
    private static final int FAVORITE = BASE_INDEX_OFFER + 3;
    private static final int FILTER_COUPON = BASE_INDEX_OFFER + 4;
    
    private static final int BASE_INDEX_STORE = 7;
    private static final int STORE = BASE_INDEX_STORE + 1;
    private static final int STORE_ID = BASE_INDEX_STORE + 2;
    
    private static final int BASE_INDEX_CATEGORY = 15;
    private static final int CATEGORY = BASE_INDEX_CATEGORY + 1;
    private static final int CATEGORY_ID = BASE_INDEX_CATEGORY + 2;
    
    private static final int BASE_INDEX_CATEGORY_COUNT = 23;
    private static final int CATEGORY_COUNT = BASE_INDEX_CATEGORY_COUNT + 1;
    private static final int CATEGORY_COUNT_ID = BASE_INDEX_CATEGORY_COUNT + 2;
    
    private static final int BASE_SHIFT = 3; // DO NOT TOUCH!
    //  for example:- expression: (val>>3) gives 0 where [val=0,1..7]
	//  and 1 where [val=8,9,..15] and so on.
	// Next base index will be = [7(y) + (y-1)], where y = 1..n
    private static final int BASE_INDEX_OFFER_HOME= 31;
    private static final int OFFER_HOME = BASE_INDEX_OFFER_HOME+ 1;
    private static final int OFFER_ID_HOME = BASE_INDEX_OFFER_HOME + 2;
    private static final int FAVORITE_HOME = BASE_INDEX_OFFER_HOME + 3;
    private static final int FILTER_COUPON_HOME = BASE_INDEX_OFFER_HOME + 4;
    
    private static final int BASE_INDEX_STORE_HOME = 39;
    private static final int STORE_HOME = BASE_INDEX_STORE_HOME + 1;
    private static final int STORE_ID_HOME = BASE_INDEX_STORE_HOME + 2;
    
    private static final int BASE_INDEX_CATEGORY_HOME = 47;
    private static final int CATEGORY_HOME = BASE_INDEX_CATEGORY_HOME + 1;
    private static final int CATEGORY_ID_HOME = BASE_INDEX_CATEGORY_HOME + 2;
    
    private static final int BASE_INDEX_CATEGORY_COUNT_HOME = 55;
    private static final int CATEGORY_COUNT_HOME = BASE_INDEX_CATEGORY_COUNT_HOME + 1;
    private static final int CATEGORY_COUNT_ID_HOME = BASE_INDEX_CATEGORY_COUNT_HOME + 2;
    
    
    

    private static final String[] TABLE_NAMES = {
    	CouponDao.TABLE_NAME, StoreDao.TABLE_NAME, CategoryDao.TABLE_NAME, CategoryCountDao.TABLE_NAME, CouponDaoHome.TABLE_NAME, StoreDaoHome.TABLE_NAME, CategoryDaoHome.TABLE_NAME, CategoryCountDaoHome.TABLE_NAME
    };

    private static final UriMatcher sURIMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        addUriMatchers();
    }

	private static void addUriMatchers() {
		final UriMatcher matcher = sURIMatcher;

        // All Offer row
        matcher.addURI(AUTHORITY, CouponDao.TABLE_NAME, OFFER);
        // A specific Offer row
        matcher.addURI(AUTHORITY, CouponDao.TABLE_NAME + "/#", OFFER_ID);
        // A unique favorite offer row
        matcher.addURI(AUTHORITY, CouponDao.TABLE_NAME_FAVORITE, FAVORITE);
        // filter coupon
        matcher.addURI(AUTHORITY, CouponDao.TABLE_NAME_FILTER_COUPON, FILTER_COUPON);
        // All Store row
        matcher.addURI(AUTHORITY, StoreDao.TABLE_NAME, STORE);
        // A specific Store row
        matcher.addURI(AUTHORITY, StoreDao.TABLE_NAME + "/#", STORE_ID);
        
        // All Category
        matcher.addURI(AUTHORITY, CategoryDao.TABLE_NAME, CATEGORY);
        // A Sepecefic Category
        matcher.addURI(AUTHORITY, CategoryDao.TABLE_NAME + "/#", CATEGORY_ID);
        
        // All Category
        matcher.addURI(AUTHORITY, CategoryCountDao.TABLE_NAME, CATEGORY_COUNT);
        // A sepecefic category.
        matcher.addURI(AUTHORITY, CategoryCountDao.TABLE_NAME + "/#", CATEGORY_COUNT_ID);
        // All Offer row
        matcher.addURI(AUTHORITY, CouponDaoHome.TABLE_NAME, OFFER_HOME);
        // A specific Offer row
        matcher.addURI(AUTHORITY, CouponDaoHome.TABLE_NAME + "/#", OFFER_ID_HOME);
        // A unique favorite offer row
        matcher.addURI(AUTHORITY, CouponDaoHome.TABLE_NAME_FAVORITE, FAVORITE_HOME);
        // filter coupon
        matcher.addURI(AUTHORITY, CouponDaoHome.TABLE_NAME_FILTER_COUPON, FILTER_COUPON_HOME);
        // All Store row
        matcher.addURI(AUTHORITY, StoreDaoHome.TABLE_NAME, STORE_HOME);
        // A specific Store row
        matcher.addURI(AUTHORITY, StoreDaoHome.TABLE_NAME + "/#", STORE_ID_HOME);
        
        // All Category
        matcher.addURI(AUTHORITY, CategoryDaoHome.TABLE_NAME, CATEGORY_HOME);
        // A Sepecefic Category
        matcher.addURI(AUTHORITY, CategoryDaoHome.TABLE_NAME + "/#", CATEGORY_ID_HOME);
     // All Category
        matcher.addURI(AUTHORITY, CategoryCountDaoHome.TABLE_NAME, CATEGORY_COUNT_HOME);
        // A sepecefic category.
        matcher.addURI(AUTHORITY, CategoryCountDaoHome.TABLE_NAME + "/#", CATEGORY_COUNT_ID_HOME);
        
	}

    private SQLiteDatabase mDatabase;
    
    public static final String KEY_SQL_INJECT = "sql_inject";

    public synchronized SQLiteDatabase getDatabase(final Context context) {
        // Always return the cached database, if we've got one
        if (mDatabase != null) {
            return mDatabase;
        }

        final DatabaseHelper helper = new DatabaseHelper(context, DATABASE_NAME);
        mDatabase = helper.getWritableDatabase();
        if (mDatabase != null) {
            mDatabase.setLockingEnabled(true);
        }

        return mDatabase;
    }

    static SQLiteDatabase getReadableDatabase(final Context context) {
        final DatabaseHelper helper = new DatabaseProvider().new DatabaseHelper(context, DATABASE_NAME);
        return helper.getReadableDatabase();
    }

    private class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(final Context context, final String name) {
            super(context, name, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(final SQLiteDatabase db) {
            LogConfig.logd(LOG_TAG, "Creating database");

            // Creates all tables here; each class has its own method
//            LogConfig.logd(LOG_TAG, "DatabaseProvider | CouponDao start");
            CouponDao.createTable(db);
//            LogConfig.logd(LOG_TAG, "DatabaseProvider | CouponDao end");
//            LogConfig.logd(LOG_TAG, "DatabaseProvider | StoreDao start");
            StoreDao.createTable(db);
//            LogConfig.logd(LOG_TAG, "DatabaseProvider | StoreDao end");
//            LogConfig.logd(LOG_TAG, "DatabaseProvider | CategoryDao start");
            CategoryDao.createTable(db);
//            LogConfig.logd(LOG_TAG, "DatabaseProvider | CategoryDao end");
//         	  LogConfig.logd(LOG_TAG, "DatabaseProvider | CategoryCountDao start");
            CategoryCountDao.createTable(db);
//            LogConfig.logd(LOG_TAG, "DatabaseProvider | CategoryCountDao end");
            
            
            // Creates all tables here; each class has its own method

           CouponDaoHome.createTable(db);
           StoreDaoHome.createTable(db);
           CategoryDaoHome.createTable(db);    
           CategoryCountDaoHome.createTable(db);

            
            
        }

        @Override
        public void onUpgrade(final SQLiteDatabase db, final int oldVersion, final int newVersion) {
        	CouponDao.upgradeTable(db, oldVersion, newVersion);
        	StoreDao.upgradeTable(db, oldVersion, newVersion);
        	CategoryDao.upgradeTable(db, oldVersion, newVersion);
        	CategoryCountDao.upgradeTable(db, oldVersion, newVersion);
        	
        	
        	CouponDaoHome.upgradeTable(db, oldVersion, newVersion);
        	StoreDaoHome.upgradeTable(db, oldVersion, newVersion);
        	CategoryDaoHome.upgradeTable(db, oldVersion, newVersion);
        	CategoryCountDaoHome.upgradeTable(db, oldVersion, newVersion);
        }

        @Override
        public void onOpen(final SQLiteDatabase db) {
        }
    }

    @Override
    public int delete(final Uri uri, final String selection, final String[] selectionArgs) {

        final int match = sURIMatcher.match(uri);
        final Context context = getContext();

        // Pick the correct database for this operation
        final SQLiteDatabase db = getDatabase(context);
        final int table = match >> BASE_SHIFT;
        String id = "0";

//        LogConfig.logd(LOG_TAG, "delete: uri=" + uri + ", match is " + match + ", " + table);

        int result = -1;

        switch (match) {
            case OFFER_ID_HOME:
            case STORE_ID_HOME:
            case CATEGORY_ID_HOME:
            case CATEGORY_COUNT_ID_HOME:
            	 id = uri.getPathSegments().get(1);
                 result = db.delete(TABLE_NAMES[table], whereWithId(id, selection), selectionArgs);
                 break;
				 
            case OFFER_ID:
            case STORE_ID:
            case CATEGORY_ID:
            case CATEGORY_COUNT_ID:
                id = uri.getPathSegments().get(1);
                result = db.delete(TABLE_NAMES[table], whereWithId(id, selection), selectionArgs);
                break;   
				     
            case OFFER_HOME:
            case STORE_HOME:
            case CATEGORY_HOME:
            case CATEGORY_COUNT_HOME:  
            	 result = db.delete(TABLE_NAMES[table], selection, selectionArgs);
                 break;
            case OFFER:
            case STORE:
            case CATEGORY:
            case CATEGORY_COUNT:
                result = db.delete(TABLE_NAMES[table], selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

//        getContext().getContentResolver().notifyChange(uri, null);
        return result;
    }

    @Override
    public String getType(final Uri uri) {
        final int match = sURIMatcher.match(uri);
        switch (match) {
            case OFFER_ID:
                return CouponDao.TYPE_ELEM_TYPE;
            case OFFER:
            case FAVORITE:
            case FILTER_COUPON:
            	return CouponDao.TYPE_DIR_TYPE;
            case STORE_ID:
                return StoreDao.TYPE_ELEM_TYPE;
            case STORE:
            	return StoreDao.TYPE_DIR_TYPE;
            case CATEGORY_ID:
            	return CategoryDao.TYPE_ELEM_TYPE;
            case CATEGORY:
            	return CategoryDao.TYPE_DIR_TYPE;
            case CATEGORY_COUNT:
            	return CategoryCountDao.TYPE_DIR_TYPE;
            case CATEGORY_COUNT_ID:
            	return CategoryCountDao.TYPE_ELEM_TYPE;
            	
            case OFFER_ID_HOME:
                return CouponDaoHome.TYPE_ELEM_TYPE;
            case OFFER_HOME:
            case FAVORITE_HOME:
            case FILTER_COUPON_HOME:
            	return CouponDaoHome.TYPE_DIR_TYPE;
            case STORE_ID_HOME:
                return StoreDaoHome.TYPE_ELEM_TYPE;
            case STORE_HOME:
            	return StoreDaoHome.TYPE_DIR_TYPE;
            case CATEGORY_ID_HOME:
            	return CategoryDaoHome.TYPE_ELEM_TYPE;
            case CATEGORY_HOME:
            	return CategoryDaoHome.TYPE_DIR_TYPE;
            case CATEGORY_COUNT_HOME:
            	return CategoryCountDaoHome.TYPE_DIR_TYPE;
            case CATEGORY_COUNT_ID_HOME:
            	return CategoryCountDaoHome.TYPE_ELEM_TYPE;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
    }

    @Override
    public Uri insert(final Uri uri, final ContentValues values) {

        final int match = sURIMatcher.match(uri);
        final Context context = getContext();

        // Pick the correct database for this operation
        final SQLiteDatabase db = getDatabase(context);
        final int table = match >> BASE_SHIFT;
        long id;

//        LogConfig.logd(LOG_TAG, "insert: uri=" + uri + ", match is " + match + ", " + table);

        Uri resultUri = null;

        switch (match) {
            case OFFER_HOME:
            case STORE_HOME:
            case CATEGORY_HOME:
            case CATEGORY_COUNT_HOME:
            	  id = db.insert(TABLE_NAMES[table], "foo", values);
                  resultUri = ContentUris.withAppendedId(uri, id);
                  break;
	        case OFFER:
	        case STORE:
	        case CATEGORY:
	        case CATEGORY_COUNT:
                id = db.insert(TABLE_NAMES[table], "foo", values);
                resultUri = ContentUris.withAppendedId(uri, id);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

        // Notify with the base uri, not the new uri (nobody is watching a new
        // record)
//        getContext().getContentResolver().notifyChange(uri, null);
        return resultUri;
    }

    @Override
    public int bulkInsert(final Uri uri, final ContentValues[] values) {

        final int match = sURIMatcher.match(uri);
        final Context context = getContext();

        // Pick the correct database for this operation
        final SQLiteDatabase db = getDatabase(context);

//        LogConfig.logd(LOG_TAG, "bulkInsert: uri=" + uri + ", match is " + match);

        int numberInserted = 0;
        SQLiteStatement insertStmt;

        db.beginTransaction();
        try {
            switch (match) {
	            case OFFER:
	            	insertStmt = db.compileStatement(CouponDao.getBulkInsertString());
                    for (final ContentValues value : values) {
                    	CouponDao.bindValuesInBulkInsert(insertStmt, value);
                        insertStmt.execute();
                        insertStmt.clearBindings();
                    }
                    insertStmt.close();
                    db.setTransactionSuccessful();
                    numberInserted = values.length;
                    break;
                    
	            case STORE:
	            	insertStmt = db.compileStatement(StoreDao.getBulkInsertString());
                    for (final ContentValues value : values) {
                    	StoreDao.bindValuesInBulkInsert(insertStmt, value);
                        insertStmt.execute();
                        insertStmt.clearBindings();
                    }
                    insertStmt.close();
                    db.setTransactionSuccessful();
                    numberInserted = values.length;
                    break;
                    
	            case CATEGORY:
	            	insertStmt = db.compileStatement(CategoryDao.getBulkInsertString());
	            	for (final ContentValues value : values) {
	            		CategoryDao.bindValuesInBulkInsert(insertStmt, value);
	            		insertStmt.execute();
	            		insertStmt.clearBindings();
	            	}
                    insertStmt.close();
                    db.setTransactionSuccessful();
                    numberInserted = values.length;
                    break;
                    
	            case CATEGORY_COUNT:
	            	insertStmt = db.compileStatement(CategoryCountDao.getBulkInsertString());
	            	for (final ContentValues value : values) {
	            		CategoryCountDao.bindValuesInBulkInsert(insertStmt, value);
	            		insertStmt.execute();
	            		insertStmt.clearBindings();
	            	}
	            	insertStmt.close();
	            	db.setTransactionSuccessful();
	            	numberInserted = values.length;
	            	break;
	            case OFFER_HOME:
	            	insertStmt = db.compileStatement(CouponDaoHome.getBulkInsertString());
                    for (final ContentValues value : values) {
                    	CouponDaoHome.bindValuesInBulkInsert(insertStmt, value);
                        insertStmt.execute();
                        insertStmt.clearBindings();
                    }
                    insertStmt.close();
                    db.setTransactionSuccessful();
                    numberInserted = values.length;
                    break;
                    
	            case STORE_HOME:
	            	insertStmt = db.compileStatement(StoreDaoHome.getBulkInsertString());
                    for (final ContentValues value : values) {
                    	StoreDaoHome.bindValuesInBulkInsert(insertStmt, value);
                        insertStmt.execute();
                        insertStmt.clearBindings();
                    }
                    insertStmt.close();
                    db.setTransactionSuccessful();
                    numberInserted = values.length;
                    break;
                    
	            case CATEGORY_HOME:
	            	insertStmt = db.compileStatement(CategoryDaoHome.getBulkInsertString());
	            	for (final ContentValues value : values) {
	            		CategoryDaoHome.bindValuesInBulkInsert(insertStmt, value);
	            		insertStmt.execute();
	            		insertStmt.clearBindings();
	            	}
                    insertStmt.close();
                    db.setTransactionSuccessful();
                    numberInserted = values.length;
                    break;
                    
	            case CATEGORY_COUNT_HOME:
	            	insertStmt = db.compileStatement(CategoryCountDaoHome.getBulkInsertString());
	            	for (final ContentValues value : values) {
	            		CategoryCountDaoHome.bindValuesInBulkInsert(insertStmt, value);
	            		insertStmt.execute();
	            		insertStmt.clearBindings();
	            	}
	            	insertStmt.close();
	            	db.setTransactionSuccessful();
	            	numberInserted = values.length;
	            	break;
                default:
                    throw new IllegalArgumentException("Unknown URI " + uri);
            }
        } finally {
            db.endTransaction();
        }

        // Notify with the base uri, not the new uri (nobody is watching a new
        // record)
//        context.getContentResolver().notifyChange(uri, null);
        return numberInserted;
    }

    @Override
    public Cursor query(final Uri uri, final String[] projection, final String selection, final String[] selectionArgs,
    		final String sortOrder) {

        Cursor c = null;
        final Uri notificationUri = DatabaseContent.CONTENT_URI;
        final int match = sURIMatcher.match(uri);
        final Context context = getContext();
        // Pick the correct database for this operation
        final SQLiteDatabase db = getDatabase(context);
        final int table = match >> BASE_SHIFT;
        String id;

//        LogConfig.logd(LOG_TAG, "query: uri=" + uri + ", match is " + match + ", " + table);

        switch (match) {
        
            case OFFER_ID_HOME:
            case STORE_ID_HOME:
            case CATEGORY_ID_HOME:
            	 id = uri.getPathSegments().get(1);
                 c = db.query(TABLE_NAMES[table], projection, whereWithId(id, selection), selectionArgs, null, null,
                         sortOrder);
                 break;
	        case OFFER_ID:
	        case STORE_ID:
	        case CATEGORY_ID:
                id = uri.getPathSegments().get(1);
                c = db.query(TABLE_NAMES[table], projection, whereWithId(id, selection), selectionArgs, null, null,
                        sortOrder);
                break;
				
	        case OFFER_HOME:
	        case STORE_HOME:
	        case CATEGORY_HOME:
	        	  c = db.query(TABLE_NAMES[table], projection, selection, selectionArgs, null, null, sortOrder);
	                break;
	        case OFFER:
	        case STORE:
	        case CATEGORY:
                c = db.query(TABLE_NAMES[table], projection, selection, selectionArgs, null, null, sortOrder);
                break;
                
            /** Special case for showing distinct favorite offers. */
	        case FAVORITE_HOME:
	        	c = db.query(true, TABLE_NAMES[table], projection, selection, selectionArgs, CouponDaoHome.COUPON_ID, null, CouponDaoHome._ID + " ASC", null);
	        	break;
				
	        case FAVORITE:
	        	c = db.query(true, TABLE_NAMES[table], projection, selection, selectionArgs, CouponDao.COUPON_ID, null, CouponDao._ID + " ASC", null);
	        	break;
	        
	        /** case for raw query to get filter coupons. */
	        case FILTER_COUPON_HOME:
	        	c = db.rawQuery(selection, null);
	        	break;

	        case FILTER_COUPON:
	        	c = db.rawQuery(selection, null);
	        	break;
	        	
	        /** Row query for getting category count**/
	        case CATEGORY_COUNT_HOME:
	        	c= db.rawQuery(selection, null);
	        	break;
				
	        case CATEGORY_COUNT:
	        	c= db.rawQuery(selection, null);
	        	break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

        if ((c != null) && !isTemporary()) {
            c.setNotificationUri(getContext().getContentResolver(), notificationUri);
        }
        return c;
    }

    private String whereWithId(final String id, final String selection) {
        final StringBuilder sb = new StringBuilder(256);
        sb.append(BaseColumns._ID);
        sb.append(" = ");
        sb.append(id);
        if (selection != null) {
            sb.append(" AND (");
            sb.append(selection);
            sb.append(')');
        }
        return sb.toString();
    }

    @Override
    public int update(final Uri uri, final ContentValues values, final String selection, final String[] selectionArgs) {

        final int match = sURIMatcher.match(uri);
        final Context context = getContext();
        // Pick the correct database for this operation
        final SQLiteDatabase db = getDatabase(context);
        final int table = match >> BASE_SHIFT;
        int result;
        Boolean bSqlInject = values.getAsBoolean(KEY_SQL_INJECT);
        boolean sqlInject = (bSqlInject == null)? true : bSqlInject.booleanValue();
        values.remove(KEY_SQL_INJECT);

//        LogConfig.logd(LOG_TAG, "update: uri=" + uri + ", match is " + match + ", " + table);

        switch (match) {
            case OFFER_ID_HOME:
            case STORE_ID_HOME:
            case CATEGORY_ID_HOME:
            	final String id1 = uri.getPathSegments().get(1);
                result = db.update(TABLE_NAMES[table], values, whereWithId(id1, selection), selectionArgs);
                break;
				
	        case OFFER_ID:
	        case STORE_ID:
	        case CATEGORY_ID:
                final String id = uri.getPathSegments().get(1);
                result = db.update(TABLE_NAMES[table], values, whereWithId(id, selection), selectionArgs);
                break;
				
	        case OFFER_HOME:
	        case STORE_HOME:
	        case CATEGORY_HOME:
	        	 result = db.update(TABLE_NAMES[table], values, selection, selectionArgs);
	                break;
					
	        case OFFER:
	        case STORE:
	        case CATEGORY:
                result = db.update(TABLE_NAMES[table], values, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

        if (sqlInject) {
        	getContext().getContentResolver().notifyChange(uri, null);
        }
        return result;
    }

    @Override
    public boolean onCreate() {
    	AUTHORITY = getContext().getString(R.string.authority_uri);
        addUriMatchers();
        return true;
    }
    
    @Override
    public ContentProviderResult[] applyBatch(ArrayList<ContentProviderOperation> operations)
            throws OperationApplicationException {
    	final Context context = getContext();
//		LogConfig.logd(LOG_TAG, "Inside apply batch");
        // Pick the correct database for this operation
        final SQLiteDatabase db = getDatabase(context);
        db.beginTransaction();
        try {
            final int numOperations = operations.size();
            final ContentProviderResult[] results = new ContentProviderResult[numOperations];
            for (int i = 0; i < numOperations; i++) {
                results[i] = operations.get(i).apply(this, results, i);
            }
            db.setTransactionSuccessful();
            return results;
        } finally {
            db.endTransaction();
        }
    }
}
