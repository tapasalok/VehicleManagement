package com.manthansystems.loyalty.crashinvocation;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.PreferenceConfig;

/**
 * @author tapas Builds the report and sends the attachment to the given email
 *         id Note: Check the AndroidManifest as this is started in a new
 *         process which also must be where the ContentProvider is hosted!
 */

public class CrashInvocationActivity extends Activity {
	private static final String EXTRA_THROWABLE = "extraThrowable";
	private static final String TAG = "CrashReportActivity";

	public static Intent createIntent(Context context, Throwable throwable) {
		Log.i(TAG, "---createIntent---");
		return new Intent(context.getApplicationContext(),
				CrashInvocationActivity.class).addFlags(
				Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(EXTRA_THROWABLE,
				throwable);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(TAG, "---onCreate Entry---");
		showAlertDialog();
		Log.i(TAG, "---onCreate Exit---");
	}

	/*
	 * This alert will be shown to user when there would be any crash
	 */
	private void showAlertDialog() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(
				CrashInvocationActivity.this);
		alertDialog.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});
		alertDialog
				.setIcon(R.drawable.icon)
				.setTitle(R.string.app_name)
				.setMessage(R.string.dialog_crash_report_message)
				.setCancelable(false)
				.setPositiveButton(android.R.string.cancel,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								sendCrashEmail();

								// Show the GPS Settings if GPS was switched off
								// initially

								if (PreferenceConfig
										.isDefaultGPSStatus(getApplicationContext()) != PreferenceConfig
										.getCurrentGPSStatus(getApplicationContext())) {
									startActivity(new Intent(
											android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
								}
							}
						})
				.setNegativeButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								sendCrashEmail();

								// Show the GPS Settings if GPS was switched off
								// initially while launching
								if (PreferenceConfig
										.isDefaultGPSStatus(getApplicationContext()) != PreferenceConfig
										.getCurrentGPSStatus(getApplicationContext())) {
									startActivity(new Intent(
											android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
								}
							}
						});

		alertDialog.create();
		alertDialog.show();
	}

	/*
	 * This method is used to send crash email
	 */
	private void sendCrashEmail() {
		Log.i(TAG, "---sendCrashEmail Entered---");
		// List<Uri> attachments = addAttachments();

		// Send mail automatically
		// sendMailAutomatically();

		// Show user how to send the crash report
		// showOptionsToSendMail(attachments);

		finish();
		Log.i(TAG, "---sendCrashEmail Exited---");
	}

}
