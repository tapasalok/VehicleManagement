/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.Map;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.LoyaltyCardWorker.LoyaltyCardWorkerMode;

/**
 * A class that extends {@link SherlockFragment} which shows the custom {@link WebView}.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class CustomWebviewFragment extends SherlockFragment {
	
	private final static String LOG_TAG = "CustomWebviewFragment";
	
	public static final String KEY_NAME_CUSTOM_WEBVIEW_URL =
		"com.manthansystems.loyalty.ui.CustomWebviewFragment#web_url";
	public static final String KEY_NAME_CUSTOM_WEBVIEW_TITLE =
		"com.manthansystems.loyalty.ui.CustomWebviewFragment#title";
	public static final String SHOW_REFRESH_OPTION =
		"com.manthansystems.loyalty.ui.CustomWebviewFragment#show_refresh_option";
	public static final String KEY_NAME_SHOW_HEADER_TITLE = 
		"com.manthansystems.loyalty.ui.CustomWebviewFragment#showHeaderTitle";
	public static final String KEY_NAME_CUSTOM_HTTP_HEADERS = 
		"com.manthansystems.loyalty.ui.CustomWebviewFragment#customHttpHeader";
	public static final String KEY_NAME_HEADER_TITLE = 
		"com.manthansystems.loyalty.ui.CustomWebviewFragment#headerTitle";
	
	private WebView mWebView;
	private String mUrl;
	private String mLastUrl;
	private boolean mIsPageLoading;
	private String mActionBarTitle;
	private ViewGroup mView;
	private String mErrorMessage;
	private String mHeaderTitle;
	private SherlockFragmentActivity mActivity;
	private boolean mShowRefreshOption = false;
	private boolean mShowPreviousOption = false;
	private boolean mShowNextOption = false;
	private boolean mShowHeaderTitle = false;
	private boolean mAddCustomHeaders = false;
	private Map<String, String> mMapHeaders = null;
	private AlertDialog mAlertDialog;
	private String mDialogMessage;
	private String mErrorTitle;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogConfig.logv(LOG_TAG, "onCreate()");
		mActionBarTitle = "";
		mHeaderTitle = "";
		mActivity = (SherlockFragmentActivity) getActivity();
		if (savedInstanceState != null) {
			mUrl = savedInstanceState.getString(KEY_NAME_CUSTOM_WEBVIEW_URL);
			LogConfig.logv(LOG_TAG, "onCreate() : reload mUrl = " + mUrl);
	    	mActionBarTitle = savedInstanceState.getString(KEY_NAME_CUSTOM_WEBVIEW_TITLE);
	    	setShowRefreshOption(savedInstanceState.getBoolean(SHOW_REFRESH_OPTION));
	    	mShowHeaderTitle = savedInstanceState.getBoolean(KEY_NAME_SHOW_HEADER_TITLE);
	    	mAddCustomHeaders = savedInstanceState.getBoolean(KEY_NAME_CUSTOM_HTTP_HEADERS);
	    	mHeaderTitle = savedInstanceState.getString(KEY_NAME_HEADER_TITLE);
        } else {
        	Bundle args = getArguments();
        	if (args == null) {
        		final Intent intent = mActivity.getIntent();
        		if (intent != null && intent.getExtras() != null) {
            		args = intent.getExtras();
            	}
        	}
        	if (args.containsKey(KEY_NAME_CUSTOM_WEBVIEW_URL)) {
        		mUrl = args.getString(KEY_NAME_CUSTOM_WEBVIEW_URL);
        	} else {
        		mUrl = "";
        	}
        	if (args.containsKey(KEY_NAME_CUSTOM_WEBVIEW_TITLE)) {
        		mActionBarTitle = args.getString(KEY_NAME_CUSTOM_WEBVIEW_TITLE);
        	}
        	if (args.containsKey(KEY_NAME_SHOW_HEADER_TITLE)) {
        		mShowHeaderTitle = args.getBoolean(KEY_NAME_SHOW_HEADER_TITLE);
        	}
        	if (args.containsKey(KEY_NAME_CUSTOM_HTTP_HEADERS)) {
        		mAddCustomHeaders = args.getBoolean(KEY_NAME_CUSTOM_HTTP_HEADERS);
        	}
        	if (args.containsKey(KEY_NAME_HEADER_TITLE)) {
        		mHeaderTitle = args.getString(KEY_NAME_HEADER_TITLE);
        	}
        }
		if (mAddCustomHeaders) {
			mMapHeaders = ((UIApplication) getActivity().getApplication()).getCustomHttpHeaderForWebView();
			if (!(mMapHeaders != null && mMapHeaders.size() > 0)) {
				mAddCustomHeaders = false;
			}
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_custom_webview, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;
        setActionBarTitle();
        bindViews();
        return root;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		loadUrlOnWebView();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (mActivity instanceof HomeActivity) {
			// register sliding menu open listener to update slide menu row selection.
			((HomeActivity) getActivity()).getSlidingMenu().setOnOpenListener(onSlidingMenuOpenListener);
		}
	}
	
	@Override
	public void onPause() {
		super.onPause();
		if (mActivity instanceof HomeActivity) {
			// un-register sliding menu open listener.
			((HomeActivity)getActivity()).getSlidingMenu().setOnOpenListener(null);
			mActivity.setSupportProgressBarIndeterminateVisibility(false);
		}
		dismissActiveDialog();
	}
	
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		menu.clear();
		if (isShowRefreshOption()) {
			inflater.inflate(R.menu.refresh_menu_items, menu);
		} else {
			inflater.inflate(R.menu.stop_page_menu_items, menu);
		}
		if (isShowNextOption()) {
			inflater.inflate(R.menu.next_page_menu_items, menu);
		}
		if (isShowPreviousOption()) {
			inflater.inflate(R.menu.previous_page_menu_items, menu);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.menu_refresh) {
			setShowRefreshOption(false);
        	if (!TextUtils.isEmpty(mLastUrl)) {
        		mActivity.setSupportProgressBarIndeterminateVisibility(true);
        		if (!mAddCustomHeaders) {
    				mWebView.loadUrl(mLastUrl);
    			} else {
    				mWebView.loadUrl(mLastUrl, mMapHeaders);
    			}
        	}
            return true;
        } else if (item.getItemId() == R.id.menu_next_page_item) {
        	if (mWebView.canGoForward()) {
				mWebView.goForward();
			}
        	return true;
        } else if (item.getItemId() == R.id.menu_previous_page_item) {
        	if (mWebView.canGoBack()) {
				mWebView.goBack();
			}
        	return true;
        } else if (item.getItemId() == R.id.menu_stop_page_item) {
        	setShowRefreshOption(true);
			mWebView.stopLoading();
			return true;
        }
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putString(KEY_NAME_CUSTOM_WEBVIEW_URL, mUrl);
		outState.putString(KEY_NAME_CUSTOM_WEBVIEW_TITLE, mActionBarTitle);
		outState.putBoolean(SHOW_REFRESH_OPTION, isShowRefreshOption());
		outState.putBoolean(KEY_NAME_SHOW_HEADER_TITLE, mShowHeaderTitle);
		outState.putBoolean(KEY_NAME_CUSTOM_HTTP_HEADERS, mAddCustomHeaders);
		outState.putString(KEY_NAME_HEADER_TITLE, mHeaderTitle);
		super.onSaveInstanceState(outState);
	}
    
    /** Bind view elements to local view objects. */
	@SuppressLint("SetJavaScriptEnabled")
	private void bindViews() {
		mWebView = (WebView) mView.findViewById(R.id.webview);
		mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        mWebView.getSettings().setBuiltInZoomControls(true);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.getSettings().setJavaScriptEnabled(true); 
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.setWebViewClient(new CustomWebViewClient());
        mWebView.addJavascriptInterface(new JavaScriptHandler(), "Loyalty247");
        
        if (mShowHeaderTitle) {
        	final TextView textViewHeaderTitle = (TextView) mView.findViewById(R.id.TextView_header_title);
        	textViewHeaderTitle.setText(mHeaderTitle);
        	textViewHeaderTitle.setVisibility(View.VISIBLE);
        }
        if (mActivity instanceof HomeActivity) {
        	
        	View view = ((SherlockFragmentActivity) getActivity())
					.getSupportActionBar().getCustomView();
			if (view != null) {
				view.findViewById(R.id.ImageView_Slide_Menu_more_icon)
						.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								((BaseSlidingActivity) getActivity())
										.getSlidingMenu().showMenu(true);
							}
						});

				view.findViewById(R.id.ImageView_Slide_Menu_icon)
						.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								if (PreferenceConfig
										.getHomeTabEnabled(getActivity()) == 0) {
									Toast.makeText(
											getActivity(),
											getString(R.string.label_no_home_page),
											Toast.LENGTH_SHORT).show();

								} else if (!NetworkHelper.isNetworkAvailable(getActivity())) {
									mDialogMessage = getResources().getString(
											R.string.network_not_available_msg);
									mErrorTitle = getResources().getString(
											R.string.network_not_available_title);
									showDialog(DialogConfig.DIALOG_ERROR);
									// must reset refreshing, if requested or not.
									return;
								}else {
									PreferenceConfig.putComingFromHomeIcon(
											getActivity(), true);
									startActivity(new Intent(getActivity(),
											HomeActivity.class));
								}

							}
						});
			}
        }
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(mErrorTitle)
					.setMessage(mDialogMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;
		}

		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
		mDialogMessage = "";
	}
	/**
	 * @param isPageLoading the Page Loading status to set
	 */
	public void setIsPageLoading(boolean isPageLoading) {
		mIsPageLoading = isPageLoading;
	}

	/**
	 * @return the Page loading status
	 */
	public boolean isPageLoading() {
		return mIsPageLoading;
	}

	/**
	 * It will be called when things happen that impact the rendering of the content,
	 *  eg, errors or form submissions. We can also intercept URL loading here.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	private final class CustomWebViewClient extends WebViewClient {
		
		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			super.onPageStarted(view, url, favicon);
			mActivity.setSupportProgressBarIndeterminateVisibility(true);
			setIsPageLoading(true);
			setShowRefreshOption(false);
		}

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			
			try {
				if (url != null && (url.toLowerCase().startsWith("tel:")
						|| url.toLowerCase().startsWith("mailto")
						|| url.toLowerCase().startsWith("market:")
						|| url.toLowerCase().startsWith("geo:"))) {
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
		            startActivity(intent);
		            if (url.toLowerCase().startsWith("market:")) {
		            	mActivity.finish();
		            }
				} else {
					if (!mAddCustomHeaders) {
						view.loadUrl(url);
	    			} else {
	    				view.loadUrl(url, mMapHeaders);
	    			}
				}
	            return true;
			} catch (Exception e) {
				LogConfig.logd(LOG_TAG, "shouldOverrideUrlLoading()", e);
				return true;
			}
        }
		
		@Override
        public void onPageFinished(WebView view, String url) {
			LogConfig.logv(LOG_TAG, "onPageFinished(): url = " + url);
			mActivity.setSupportProgressBarIndeterminateVisibility(false);
			setIsPageLoading(false);
			setShowRefreshOption(true);
			if (!TextUtils.isEmpty(url) && !url.equalsIgnoreCase("about:blank")) {
				mLastUrl = url;
			}
			if (mWebView.canGoBack()) {
				setShowPreviousOption(true);
			} else {
				setShowPreviousOption(false);
			}
			if (mWebView.canGoForward()) {
				setShowNextOption(true);
			} else {
				setShowNextOption(false);
			}
			mActivity.invalidateOptionsMenu();
        }
		
		@Override
		public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
			LogConfig.logv(LOG_TAG, "onReceivedError(): failingUrl = " + failingUrl);
			mActivity.setSupportProgressBarIndeterminateVisibility(false);
			mWebView.clearView();
			mWebView.loadDataWithBaseURL(null, "", "text/html", "utf-8", mLastUrl);
			mErrorMessage = getString(R.string.network_not_available_msg);
			if (!mActivity.isFinishing()) {
				showCustomDialog(DialogConfig.DIALOG_ERROR);
			}
			
        }
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showCustomDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(mActivity);
		dlg.setOnKeyListener(new OnKeyListener() {

			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(getResources().getString(R.string.app_name))
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						if (!(mActivity instanceof HomeActivity)) {
							mActivity.finish();
						}
					}
			});
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logv(LOG_TAG, "onDestroy()");
	   /*UIUtils.unbindDrawables(findViewById(R.id.root_view_custom_webview));
	   System.gc();*/
	}
	
	@SuppressWarnings("unused")
	private void ShowWebBrowser(String url) {
		if (url != null && !url.startsWith("http://") && !url.startsWith("https://")) {
			url = "http://" + url;
		}
		try {
			Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
			startActivity(browserIntent);
		} catch (Exception e) {
			LogConfig.logd(LOG_TAG, "ShowWebBrowser()", e);
		}
	}
	
	/**
	 * @return the mShowRefreshOption
	 */
	public boolean isShowRefreshOption() {
		return mShowRefreshOption;
	}

	/**
	 * @param mShowRefreshOption the mShowRefreshOption to set
	 */
	public void setShowRefreshOption(boolean showRefreshOption) {
		mShowRefreshOption = showRefreshOption;
		mActivity.invalidateOptionsMenu();
	}
	
	/** A method to get boolean to show previous page option menu. **/
	public boolean isShowPreviousOption() {
		return mShowPreviousOption;
	}
	
	/** A method to set boolean to show previous page option menu. **/
	public void setShowPreviousOption(boolean showPreviousOption) {
		mShowPreviousOption = showPreviousOption;
		
	}
	
	/** A method to get boolean to show next page option menu. **/
	public boolean isShowNextOption() {
		return mShowNextOption;
	}
	
	/** A method to set boolean to show next page option menu. **/
	public void setShowNextOption(boolean showNextOption) {
		mShowNextOption = showNextOption;
	}
	
	/** A method to set action bar title of webview. **/
	private void setActionBarTitle() {
		String actionbarTitle = "";
		if (TextUtils.isEmpty(mActionBarTitle)) {
			if (UIUtils.getRetailId(getActivity()) == CommonConfig.RETAILTYPE_ROBINSON) {
				actionbarTitle = getResources().getString(R.string.client_app_name);
			}else{
				actionbarTitle = getResources().getString(R.string.app_name);
			}
		
		} else {
			actionbarTitle = mActionBarTitle.replaceAll("&amp;", "&");
		}
		// Set the screen title view.
		if (mActivity instanceof HomeActivity) {
			UIUtils.setTitleView(actionbarTitle, false, true, true,
					mActivity);
		} else {
			UIUtils.setTitleView(actionbarTitle, false, true, false, mActivity);
		}
	}
	
	/** A method to load webview with given url. **/
	private void loadUrlOnWebView() {
		if (mUrl != null) {
			if (!mUrl.startsWith("http://") && !mUrl.startsWith("https://")) {
				mUrl = "http://" + mUrl;
			}
			mLastUrl = mUrl;
			if (!mAddCustomHeaders) {
				mWebView.loadUrl(mUrl);
			} else {
				mWebView.loadUrl(mUrl, mMapHeaders);
			}
		}
	}
	
	/**
	 * A bridge class that holds the methods which will get called from Javascript from
	 * webpage.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	private final class JavaScriptHandler {
		
		/** Method should be called from Javascript of a web page on loyalty card join success. */
		@SuppressWarnings("unused")
		public void joinProgram(String statusCode, String msg){
			LogConfig.logd(LOG_TAG, "JavaScriptHandler#joinProgram(): status=" + statusCode + ", msg = " + msg);
			if (!TextUtils.isEmpty(statusCode) && 
					statusCode.equalsIgnoreCase(JSONTagConstants.RESPONSE_CODE_OK)) {
				PreferenceConfig.setLoyaltyCardWorkerMode(
						LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY, getActivity());
				PreferenceConfig.setLaunchLoyaltyCardDetailsScreen(true, getActivity());
				getActivity().finish();
			} else if (!TextUtils.isEmpty(statusCode) 
					&& statusCode.equalsIgnoreCase(JSONTagConstants.RESPONSE_CODE_ERROR)) {
				mErrorMessage = TextUtils.isEmpty(msg) ? getResources().getString(R.string.dialog_error_title) : msg;
				showCustomDialog(DialogConfig.DIALOG_ERROR);
			}
	    }
	}
	
	/** Listener that invokes for Sliding menu open event. */
	private SlidingMenu.OnOpenListener onSlidingMenuOpenListener = new SlidingMenu.OnOpenListener() {
		@Override
		public void onOpen() {
			// Now update the sliding menu selected item position.
			SliderMenuFragment sliderMenuFragment = (SliderMenuFragment) getSherlockActivity()
					.getSupportFragmentManager().findFragmentById(
							R.id.menu_frame);
			if (sliderMenuFragment != null) {
				sliderMenuFragment.setRowSelected(HomeActivity.POSITION_TAB_ABOUT_US);
			}
		}
	};
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
}
