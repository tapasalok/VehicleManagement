password                         : loyalty

key store name                   : Manthan


Alias name: manthan
Creation date: 23 Apr, 2013
Entry type: PrivateKeyEntry
Certificate chain length: 1
Certificate[1]:
Owner: CN=Manthan, O=Manthan Systems, L=Bangalore, ST=KA, C=IN
Issuer: CN=Manthan, O=Manthan Systems, L=Bangalore, ST=KA, C=IN
Serial number: 5a917608
Valid from: Tue Apr 23 12:05:21 IST 2013 until: Mon Apr 02 12:05:21 IST 2103
Certificate fingerprints:
         MD5:  35:33:DA:CC:9F:10:2C:63:21:00:A3:9C:C3:78:0A:0A
         SHA1: 60:CD:72:00:33:05:33:A0:E6:30:00:BD:A3:15:37:EB:11:13:9C:DE
         Signature algorithm name: SHA256withRSA
         Version: 3
