/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

/**
 * A model class that holds the Category data coming from server. 
 * @author Gaurav Agrawal: gaurav.agrawal@xymob.com
 *
 */
public class LoyaltyCardHistory {
	public String mTransactionId;
	public String mDate;
	public String mRewards;
	
	/** Default Constructor. */
	public LoyaltyCardHistory() {
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			// Do nothing.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.finalize();
		}
	}
}
