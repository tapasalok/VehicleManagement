/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui.phone;

import android.os.Bundle;
import android.view.KeyEvent;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;

/**
 * An activity class that will show store list. This class extends
 * {@link SherlockFragmentActivity}.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class StoreListActivity extends SherlockFragmentActivity {

	@SuppressWarnings("unused")
	private final String TAG = "StoreListActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_store_list);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	public void finish() {
	    super.finish();
	    overridePendingTransition(0, R.anim.translate_slide_right_out);
	}
}