/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import com.crashlytics.android.Crashlytics;
import java.security.NoSuchAlgorithmException;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.util.Log;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.ui.phone.EnterHomeZipCodeActivity;
import com.manthansystems.loyalty.ui.phone.EnterTokenActivity;
import com.manthansystems.loyalty.util.EDUtils;

/**
 * A launcher activity that extends SherlockFragmentActivity which is the
 * entry-point of the application.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class LauncherActivity extends SherlockFragmentActivity {
	
	private final String LOG_TAG = "LauncherActivity";
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
//        Crashlytics api to start checking occurance of crash
        Crashlytics.start(this);
        
		// Initialise the app version that will be used to append with logger.
        LogConfig.APP_VER = getResources().getString(R.string.version_name);
        
        // If app is upgraded then reset some flags
		try {
			PackageInfo packageInfo = this.getPackageManager()
					.getPackageInfo(this.getPackageName(), 0);
			int verCode = PreferenceConfig.getAppVersionCode(this);
			if (packageInfo.versionCode != verCode) {
				LogConfig.logv(LOG_TAG, "onCreate(): APP UPDATED or first launch");
				PreferenceConfig.setIsAppUpdateAvailable(false, this);
			}
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
        
        Intent intent = null;
        if (PreferenceConfig.isEmailScreenVisible(this)) {
        	LogConfig.logd(LOG_TAG, "onCreate(): Show Email Screen");
        	intent = new Intent(this, EnterEmailActivity.class);
        	intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        } else if (PreferenceConfig.isTokenScreenVisible(this)) {
        	LogConfig.logd(LOG_TAG, "onCreate(): Show Token Screen");
        	intent = new Intent(this, EnterTokenActivity.class);
        	intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        } else if (PreferenceConfig.isHomeZipScreenVisible(this)) {
        	LogConfig.logd(LOG_TAG, "onCreate(): Show HomeZip Screen");
        	intent = new Intent(this, EnterHomeZipCodeActivity.class);
        	intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        } else if (PreferenceConfig.getAppIsRunning(this)) {
        	LogConfig.logd(LOG_TAG, "onCreate(): Show Home Tab Screen");
        	intent = new Intent(this, HomeActivity.class);
        	intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        } else {
        	LogConfig.logd(LOG_TAG, "onCreate(): Show Splash Screen");
        	intent = new Intent(this, SplashActivity.class);
        }
        startActivity(intent);
        try {
        	if (PreferenceConfig.getCodeRedKey(this) == null) {
        		PreferenceConfig.setCodeRedKey(EDUtils.generateSalt().getEncoded(), this);
        	}
        	if (PreferenceConfig.getCodeRedPass(this) == null) {
        		PreferenceConfig.setCodeRedPass("CodeRedPass", this);
        	}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			Log.e(LOG_TAG, "onCreate(): Exception: " + e);
		}
        finish();
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logd(LOG_TAG, "onDestroy()");
	}
}
