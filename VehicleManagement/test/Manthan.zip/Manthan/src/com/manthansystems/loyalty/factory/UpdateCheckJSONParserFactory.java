/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */

package com.manthansystems.loyalty.factory;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;

/**
 * A JSON parser class that will parse the app update response
 *  json string coming from server.
 * @author Rakesh Saytode: rakesh.saytode@xymob.com
 */
public class UpdateCheckJSONParserFactory extends BaseJsonParser {
	
	@SuppressWarnings("unused")
	private final static String LOG_TAG = "UpdateCheckJSONParserFactory";
	
	/** Call to Parse category response from JSON string. */
	public synchronized static HashMap<String, Object> parseResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
				JSONObject updateResponse = response.getJSONObject(JSONTagConstants.RESPONSE_RESULTS);
				if (updateResponse.has(JSONTagConstants.APP_UPDATE_AVAILABLE_TAG)) {
					map.put(CommonConfig.KEY_NAME_UPDATE_AVAILABLE,
							updateResponse.getString(JSONTagConstants.APP_UPDATE_AVAILABLE_TAG));
				}
				if (updateResponse.has(JSONTagConstants.APP_UPDATE_MESSAGE_TAG)) {
					map.put(CommonConfig.KEY_NAME_UPDATE_MESSAGE,
							updateResponse.getString(JSONTagConstants.APP_UPDATE_MESSAGE_TAG));
				}
				if (updateResponse.has(JSONTagConstants.APP_UPDATE_OBSOLETE_TAG)) {
					map.put(CommonConfig.KEY_NAME_UPDATE_OBSOLETE,
							updateResponse.getString(JSONTagConstants.APP_UPDATE_OBSOLETE_TAG));
				}
				if (updateResponse.has(JSONTagConstants.APP_UPDATE_TYPE_TAG)) {
					map.put(CommonConfig.KEY_NAME_UPDATE_TYPE,
							updateResponse.getString(JSONTagConstants.APP_UPDATE_TYPE_TAG));
				}
				if (updateResponse.has(JSONTagConstants.APP_UPDATE_VERSION_TAG)) {
					map.put(CommonConfig.KEY_NAME_UPDATE_VERSION,
							updateResponse.getString(JSONTagConstants.APP_UPDATE_VERSION_TAG));
				}
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_RESULTS_MESSAGE, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
}
