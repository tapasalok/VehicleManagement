/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui.phone;

import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Window;
import com.manthansystems.loyalty.R;

/**
 * A class that extends {@link SherlockFragmentActivity} which shows the custom {@link WebView}.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class CustomWebViewActivity extends SherlockFragmentActivity {

	@SuppressWarnings("unused")
	private final String TAG = "CustomWebViewActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
		setContentView(R.layout.activity_custom_webview);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	public void finish() {
	    super.finish();
	    overridePendingTransition(0, R.anim.translate_slide_right_out);
	}
}