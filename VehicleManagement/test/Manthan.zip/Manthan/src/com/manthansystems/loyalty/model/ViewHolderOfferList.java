/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

import android.content.res.Resources;
import android.database.Cursor;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.util.UIUtils;

/**
 * A view holder class that holds the row elements of Offers list item.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class ViewHolderOfferList implements BaseViewHolder {

	private int mPosition;
	private int mSelectedPosition;
	
	public ImageView mImageViewOfferIcon;
	private TextView mTextViewOfferTitle;
	private TextView mTextViewExpiresOn;
	private TextView mTextViewCouponType;
	public ImageView mImageViewFavoriteIcon;
	public ImageView mImageViewNewIcon;
	private ImageView mImageViewExhaustedIcon;
	
	/** Paramterised constructor. */
	public ViewHolderOfferList(final View view) {
		bindViews(view);
	}
	
	/** Method to bind the views from the row layout. */
	private void bindViews(View view) {
		mImageViewOfferIcon = (ImageView) view.findViewById(R.id.ImageView_offer_logo);
		mTextViewOfferTitle = (TextView) view.findViewById(R.id.TextView_offer_title);
		mTextViewExpiresOn = (TextView) view.findViewById(R.id.TextView_expires_on);
		mImageViewFavoriteIcon = (ImageView) view.findViewById(R.id.ImageView_fav_icon);
		mTextViewCouponType = (TextView) view.findViewById(R.id.TextView_coupon_type);
		mImageViewNewIcon = (ImageView) view.findViewById(R.id.ImageView_new_offer_icon);
		mImageViewExhaustedIcon = (ImageView) view.findViewById(R.id.ImageView_exhausted_icon);
	}
	
	@Override
	public void populateView(Cursor inCursor, View view) {
		Resources res = view.getResources();
		// set the title with decorations sent by server.
		mTextViewOfferTitle.setText(UIUtils.buildDecorativeSnippet(
				inCursor.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN),
				inCursor.getString(CouponDao.CONTENT_DECORATORS_COLUMN)));
		
		// set coupon expire days
		int expiresInDays = inCursor.getInt(CouponDao.CONTENT_EXPIRES_COLUMN);
		String label = String.format(res.getString(R.string.label_expires_in), expiresInDays,
			(expiresInDays > 1? res.getString(R.string.label_days) : res.getString(R.string.label_day)));
		if (expiresInDays <= 1) {
			mTextViewExpiresOn.setTextColor(res.getColor(R.color.color_red));
			if (expiresInDays == 0) {
				label = res.getString(R.string.expires_today);
			}
		} else {
			mTextViewExpiresOn.setTextColor(res.getColor(android.R.color.black));
		}
		mTextViewExpiresOn.setText(label);
		// Set the coupon type
		mTextViewCouponType.setText(inCursor.getString(CouponDao.CONTENT_COUPON_TYPE_COLUMN));
		// Show Offer is exhausted if really it is exhausted.
		int exhaustedFlag = inCursor.getInt(CouponDao.CONTENT_EXHAUSTED_FLAG_COLUMN);
		if (exhaustedFlag == CommonConfig.FLAG_TRUE) {
			mImageViewNewIcon.setVisibility(View.GONE);
			mImageViewExhaustedIcon.setVisibility(View.VISIBLE);
		} else {
			mImageViewExhaustedIcon.setVisibility(View.GONE);
			// Offer new status flag if its new offer.
			int couponNewStatus = inCursor.getInt(CouponDao.CONTENT_IS_NEW_COUPON);
			if (couponNewStatus == CouponDao.FLAG_VALUE_NEW_COUPON) {
				mImageViewNewIcon.setVisibility(View.VISIBLE);
			} else {
				mImageViewNewIcon.setVisibility(View.GONE);
			}
		}
		// Set list row background graient color.
        if (mPosition == mSelectedPosition) {
        	view.setBackgroundDrawable(UIUtils.getListSelectedRowBgGradientDrawable(view));
		} else {
			view.setBackgroundColor(view.getResources().getColor(android.R.color.white));
		}
	}
	
	@Override
	public void setRowPosition(int position, int selectedPosition) {
		mPosition = position;
		mSelectedPosition = selectedPosition;
	}

	@Override
	public ImageView getFavoriteIconView() {
		return mImageViewFavoriteIcon;
	}

	@Override
	public ImageView getOfferIconView() {
		return mImageViewOfferIcon;
	}
}
