/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;

import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.location.LocationHandler;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 * make the network request to send trigger events to the server.<br><BR>
 * Trigger Event type could be one of following:<ul> 
 * <li>AI � On opening of the application</li>
 * <li>CS � On sharing of the coupon</li>
 * <li>GL � On getting the location of the device</li>
 * <li>CD � On viewing the details page of the coupon.</li></ul>
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 * 
 */
public class TriggerWorker extends BaseWorker {

	private final static String LOG_TAG = "TriggerWorker";
	
	/** Start processing the trigger related network requests. */
	public static void start(final Context inContext, final int inReturnFormat,
			final Bundle inBundleData) throws IllegalStateException,
			IOException, URISyntaxException, RestClientException,
			ParserConfigurationException, SAXException, JSONException,
			Exception, OperationApplicationException, ConnectionException {

		final byte workerMode = inBundleData
				.getByte(TriggerConstants.KEY_NAME_BUNDLE_TRIGGER_WORKER_MODE);
		LogConfig.logd(LOG_TAG, "workerMode = " + workerMode);
		
		String serverRequestUrl = prepareRequestUrl(workerMode, inBundleData, inContext);
		ArrayList<Header> headerList = getBasicHeaders(inContext);
		LogConfig.logv(LOG_TAG, "Trigger serverRequestUrl = " + serverRequestUrl);
		NetworkConnectionResult result = NetworkConnection.retrieveResponseFromService(serverRequestUrl,
				Method.POST, null, headerList, false, inContext);
		LogConfig.logv(LOG_TAG, "Trigger result = " + result.wsResponse);
	}
	
	/** Method to prepare the appropriate server request url based on the worker mode. */
    private static String prepareRequestUrl(final byte workerMode,
    		Bundle bundle, Context inContext) throws URISyntaxException,
    		UnsupportedEncodingException {
    	StringBuilder url = new StringBuilder();
    	int valuePosition = 0;
    	
    	switch (workerMode) {
		case TriggerConstants.WORKER_MODE_TRIGGER_GEO_LOCATION:
			url.append(WSConfig.URL_TRIGGER_GL);
	    	double[] locationData = LocationHandler.getSavedLocation(true, inContext);
    		valuePosition = url.indexOf(WSConfig.WS_TRIGGER_LAT);
    		url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_LAT.length()),
    				locationData[LocationHandler.LATTITUDE] + "");
    		valuePosition = url.indexOf(WSConfig.WS_TRIGGER_LON);
    		url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_LON.length()), 
    				locationData[LocationHandler.LONGITUDE] + "");
    		valuePosition = url.indexOf(WSConfig.WS_TRIGGER_EVENT_TYPE);
    		url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_EVENT_TYPE.length()),
    				TriggerConstants.TRIGGER_TYPE_GEO_LOCATION);
			return url.toString();
			
		case TriggerConstants.WORKER_MODE_TRIGGER_SHARE_COUPON:
			url.append(WSConfig.URL_TRIGGER_CS);
			valuePosition = url.indexOf(WSConfig.WS_TRIGGER_COUPON_ID);
			url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_COUPON_ID.length()),
    				bundle.getString(TriggerConstants.KEY_NAME_BUNDLE_COUPON_ID));
			valuePosition = url.indexOf(WSConfig.WS_TRIGGER_EVENT_TYPE);
			url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_EVENT_TYPE.length()),
    				TriggerConstants.TRIGGER_TYPE_COUPON_SHARE);
			valuePosition = url.indexOf(WSConfig.WS_TRIGGER_SHARE_CHANNEL_NAME);
			url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_SHARE_CHANNEL_NAME.length()),
    				bundle.getString(TriggerConstants.KEY_NAME_BUNDLE_SHARE_CHANNEL));
			return url.toString();
			
		case TriggerConstants.WORKER_MODE_TRIGGER_OPEN_APP:
			url.append(WSConfig.URL_TRIGGER);
			valuePosition = url.indexOf(WSConfig.WS_TRIGGER_EVENT_TYPE);
			url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_EVENT_TYPE.length()),
    				TriggerConstants.TRIGGER_TYPE_OPEN_APP);
			return url.toString();
			
		case TriggerConstants.WORKER_MODE_TRIGGER_VIEW_COUPON_DETAIL:
			url.append(WSConfig.URL_TRIGGER_CD);
			valuePosition = url.indexOf(WSConfig.WS_TRIGGER_COUPON_ID);
			url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_COUPON_ID.length()),
    				bundle.getString(TriggerConstants.KEY_NAME_BUNDLE_COUPON_ID));
			valuePosition = url.indexOf(WSConfig.WS_TRIGGER_EVENT_TYPE);
			url.replace(valuePosition, (valuePosition + WSConfig.WS_TRIGGER_EVENT_TYPE.length()),
    				TriggerConstants.TRIGGER_TYPE_COUPON_DETAIL);
			return url.toString();
		default:
			throw new URISyntaxException("TriggerWorker mode not set.",
					"The caller for method prepareRequestUrl() has not set the" +
					"worker mode.");
		}
    }
	
	/** An interface to hold trigger constants. */
	public interface TriggerConstants {
		public final String KEY_NAME_BUNDLE_TRIGGER_WORKER_MODE = "com.manthansystems.loyalty.worker.TriggerWorker#WorkerMode";
		public final String KEY_NAME_BUNDLE_TRIGGER_EVENT_TYPE = "com.manthansystems.loyalty.worker.TriggerWorker#TRIGGER_EVENT_TYPE";
		public final String KEY_NAME_BUNDLE_COUPON_ID = "com.manthansystems.loyalty.worker.TriggerWorker#COUPON_ID";
		public final String KEY_NAME_BUNDLE_SHARE_CHANNEL = "com.manthansystems.loyalty.worker.TriggerWorker#SHARE_CHANNEL";
		
		public final byte WORKER_MODE_TRIGGER_OPEN_APP = 1;
		public final byte WORKER_MODE_TRIGGER_VIEW_COUPON_DETAIL = 2;
		public final byte WORKER_MODE_TRIGGER_SHARE_COUPON = 3;
		public final byte WORKER_MODE_TRIGGER_GEO_LOCATION = 4;
		
		public final String TRIGGER_TYPE_OPEN_APP = "AI";
		public final String TRIGGER_TYPE_COUPON_DETAIL = "CD";
		public final String TRIGGER_TYPE_COUPON_SHARE = "CS";
		public final String TRIGGER_TYPE_GEO_LOCATION = "GL";
		
		public final String TRIGGER_SHARE_CHANNEL_FACEBOOK = "Facebook";
		public final String TRIGGER_SHARE_CHANNEL_EMAIL = "Email";
	}
}
