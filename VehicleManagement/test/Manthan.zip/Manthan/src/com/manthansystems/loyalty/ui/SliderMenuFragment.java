/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.CursorLoader;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockListFragment;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.util.UIUtils;

/**
 * A {@link Fragment} class that extends {@link SherlockListFragment}. It
 * represents the left side view of Sliding Menu screen. It holds various items
 * like Offers, My Offers, Favorites etc.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class SliderMenuFragment extends SherlockListFragment {

	private final static String LOG_TAG = "SliderMenuFragment";

	private CustomAdapter mCustomAdapter;
	private static int mSelectedPosition;
	private AlertDialog mAlertDialog;
	private static int mDlgResId;
	private Context mContext;
	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mContext = getActivity().getApplicationContext();
		return inflater.inflate(R.layout.fragment_slider_menu_list, null);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		LogConfig.logd(LOG_TAG, "onActivityCreated()");
		boolean lmsFlag = PreferenceConfig.isloyaltyCardEnabled(getActivity());
		if (lmsFlag) {
			String[] tabItems = { HomeActivity.TAB_OFFERS,
					HomeActivity.TAB_MYOFFERS, HomeActivity.TAB_FAVORITE,
					HomeActivity.TAB_PREFERENCES,
					HomeActivity.TAB_LOYALTY_CARD, HomeActivity.TAB_ABOUT_US };
			int[] itemCounts = {
					PreferenceConfig.getCommonOfferCount(getActivity()),
					PreferenceConfig.getPersonalOfferCount(getActivity()),
					PreferenceConfig.getFavoriteOfferCount(getActivity()) };
			mCustomAdapter = new CustomAdapter(getActivity(), tabItems,
					itemCounts);
			setListAdapter(mCustomAdapter);
		} else {
			String[] tabItems = { HomeActivity.TAB_OFFERS,
					HomeActivity.TAB_MYOFFERS, HomeActivity.TAB_FAVORITE,
					HomeActivity.TAB_PREFERENCES, HomeActivity.TAB_ABOUT_US };
			int[] itemCounts = {
					PreferenceConfig.getCommonOfferCount(getActivity()),
					PreferenceConfig.getPersonalOfferCount(getActivity()),
					PreferenceConfig.getFavoriteOfferCount(getActivity()) };
			mCustomAdapter = new CustomAdapter(getActivity(), tabItems,
					itemCounts);
			setListAdapter(mCustomAdapter);
		}
	}

	@Override
	public void onListItemClick(ListView lv, View v, int position, long id) {
		String tag = null;
		Class<?> clss = null;
		Bundle args = null;
		mSelectedPosition = position;
		boolean sliderOpenFlag=true;
		switch (position) {
		case HomeActivity.POSITION_TAB_OFFERS:		
			tag = HomeActivity.TAB_OFFERS;
			clss = OffersFragment.class;			
			break;
		case HomeActivity.POSITION_TAB_MYOFFERS:
			if (!PreferenceConfig.isValidUser(getActivity())) {
				mDlgResId = R.string.dialog_signup_user_message_myoffer_tab;
				showCustomDialog(DialogConfig.DIALOG_SIGN_UP);				
				sliderOpenFlag=false;
			}
			else{
			tag = HomeActivity.TAB_MYOFFERS;
			clss = MyOffersFragment.class;
			}
			break;
		case HomeActivity.POSITION_TAB_FAVORITE:
			
			if (!PreferenceConfig.isValidUser(getActivity())) {
				mDlgResId = R.string.dialog_signup_user_message_fav_tab;
				showCustomDialog(DialogConfig.DIALOG_SIGN_UP);				
				sliderOpenFlag=false;
			}
			
			else{
				CursorLoader loader = new CursorLoader(getActivity(), CouponDao.CONTENT_URI,
						new String[] { CouponDao.COUPON_ID },
						CouponDao.WHERE_CLAUSE_COUPON_CHOOSER + DatabaseConfig.DB_OFFER_TYPE_FAVORITE,
						null, null);
				Cursor c = loader.loadInBackground();
				if(c.getCount()==0){
					mDlgResId=R.string.msg_no_favorite_offers;
					showCustomDialog(DialogConfig.DIALOG_NO_FAVORITE_OFFERS);				
					sliderOpenFlag=false;
				}
				else{
				tag = HomeActivity.TAB_FAVORITE;
				clss = FavoriteOffersFragment.class;
				}
			}

			break;
		case HomeActivity.POSITION_TAB_PREFERENCES:
			if (!PreferenceConfig.isValidUser(getActivity())) {
				mDlgResId = R.string.msg_sign_up_in_preferences;
				showCustomDialog(DialogConfig.DIALOG_SIGN_UP);				
				sliderOpenFlag=false;
			}
			else{
			tag = HomeActivity.TAB_PREFERENCES;
			clss = SettingsFragment.class;
			}
			break;
		case HomeActivity.POSITION_TAB_LOYALTY_CARD:
			boolean lmsFlag = PreferenceConfig.isloyaltyCardEnabled(getActivity());
			if (!PreferenceConfig.isValidUser(getActivity())) {
				mDlgResId = R.string.dialog_signup_user_message_loyalty_tab;
				showCustomDialog(DialogConfig.DIALOG_SIGN_UP);				
				sliderOpenFlag=false;
			}
			
			else if (!lmsFlag) {
				tag = HomeActivity.TAB_ABOUT_US;
				clss = CustomWebviewFragment.class;
				args = new Bundle();
				args.putString(
						CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_TITLE,
						getResources().getString(R.string.label_tab_about_us));
				String appVersion = getActivity().getResources().getString(
						R.string.client_version);
				args.putString(
						CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_URL,
						WSConfig.ABOUT_US_URL + appVersion);
			} else if (PreferenceConfig.getIsLoyaltyCardCreated(getActivity())) {
				tag = HomeActivity.TAB_LOYALTY_CARD_VIEW;
				clss = LoyaltyCardDetailFragment.class;
			} else {
				tag = HomeActivity.TAB_LOYALTY_CARD;
				clss = LoyaltyCardLoginFragment.class;
			}
			break;
		case HomeActivity.POSITION_TAB_ABOUT_US:
			tag = HomeActivity.TAB_ABOUT_US;
			clss = CustomWebviewFragment.class;
			args = new Bundle();
			args.putString(CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_TITLE,
					getResources().getString(R.string.label_tab_about_us));
			String appVersion = getActivity().getResources().getString(
					R.string.client_version);
			args.putString(CustomWebviewFragment.KEY_NAME_CUSTOM_WEBVIEW_URL,
					WSConfig.ABOUT_US_URL + appVersion);
			break;
		}
		if(sliderOpenFlag){
		switchFragment(tag, clss, args);
		}
	}
	
	
	
	

	/**
	 * Method to change/set fragment on selected tab item in Slider menu view.
	 * 
	 * @param tag
	 *            Tag name of the selected tab item.
	 * @param clss
	 *            Class name for selected tab's fragment attached or to be
	 *            attached.
	 */
	private void switchFragment(String tag, Class<?> clss, Bundle args) {
		if (getActivity() == null)
			return;

		if (getActivity() instanceof HomeActivity) {
			HomeActivity fca = (HomeActivity) getActivity();
			fca.switchContent(tag, clss, args);
		}
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showCustomDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_SIGN_UP:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(mDlgResId )
					.setCancelable(false)
					.setNegativeButton(android.R.string.cancel,
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();

								}
							})
					.setPositiveButton(R.string.label_sign_up,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									getActivity().startActivity(new Intent(
											getActivity(),
											EnterEmailActivity.class));
								}
							});
			break;

		case DialogConfig.DIALOG_EXIT_APP:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(R.string.msg_app_exit_confirmation)
					.setCancelable(true)
					.setPositiveButton(R.string.label_yes,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									dialog.dismiss();
									getActivity().finish();
									
									// Show the GPS Settings if GPS was switched off
									// initially while launching
									if (PreferenceConfig.isDefaultGPSStatus(mContext) != PreferenceConfig.getCurrentGPSStatus(mContext)) {
										startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
									}
								}
							})
					.setNegativeButton(R.string.label_no,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									// Removing dialog box
									dialog.dismiss();
								}
							});
			break;
			
			
			
		case DialogConfig.DIALOG_NO_FAVORITE_OFFERS:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.title_sorry)
			.setMessage(mDlgResId)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					
				}
			});
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
	/**
	 * An adapter class of type {@link BaseAdapter} that holds the menu screen
	 * of Slider View.
	 * 
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	private static class CustomAdapter extends ArrayAdapter<String> {

		/**
		 * List row iew holder class for faster list row rendering.
		 * 
		 * @author Rakesh Saytode : rakesh.saytode@xymob.com
		 *
		 */
		static class ViewHolder {
			public TextView mTextViewTabName;
			public TextView mTextViewTabItemCount;
			public ImageView mImageViewTabIcon;
		}

		private LayoutInflater mInflater = null;
		private String[] mTabNames;
		private int[] mTabItemCounts;

		/** Constructor Method */
		public CustomAdapter(Activity activity, String[] tabNames,
				int[] tabItemCounts) {
			super(activity, R.layout.row_for_slider_menu, tabNames);
			mTabNames = tabNames;
			mTabItemCounts = tabItemCounts;
			mInflater = (LayoutInflater) activity
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View vi = convertView;
			ViewHolder viewHolder = null;
			if (convertView == null) {
				vi = mInflater.inflate(R.layout.row_for_slider_menu, null);
				viewHolder = new ViewHolder();
				viewHolder.mImageViewTabIcon = (ImageView) vi
						.findViewById(R.id.ImageView_tab_icon);
				viewHolder.mTextViewTabItemCount = (TextView) vi
						.findViewById(R.id.TextView_tab_item_count);
				viewHolder.mTextViewTabName = (TextView) vi
						.findViewById(R.id.TextView_tab_name);
				vi.setTag(viewHolder);
			}
			viewHolder = (ViewHolder) vi.getTag();
			viewHolder.mImageViewTabIcon.setImageDrawable(null);
			viewHolder.mImageViewTabIcon.setBackgroundResource(0);
			// Set list row background gradient color.
			if (position == mSelectedPosition) {
				vi.setBackgroundDrawable(UIUtils
						.getListSelectedRowBgGradientDrawable(vi));
				viewHolder.mTextViewTabItemCount.setTypeface(null,
						Typeface.BOLD);
				viewHolder.mTextViewTabName.setTypeface(null, Typeface.BOLD);
			} else {
				vi.setBackgroundDrawable(UIUtils
						.getListRowBgGradientDrawable(vi));
				viewHolder.mTextViewTabItemCount.setTypeface(null,
						Typeface.NORMAL);
				viewHolder.mTextViewTabName.setTypeface(null, Typeface.NORMAL);
			}
			Resources res = vi.getResources();
			if (mTabNames != null && mTabNames.length > 0
					&& (mTabNames.length - 1) >= position) {
				String tabName = mTabNames[position];
				viewHolder.mTextViewTabName.setText(tabName);
				Drawable tabIconDrawable = null;
				if (tabName.equalsIgnoreCase(HomeActivity.TAB_OFFERS)) {
					tabIconDrawable = res
							.getDrawable(R.drawable.ic_tab_offers_selected);
				} else if (tabName.equalsIgnoreCase(HomeActivity.TAB_MYOFFERS)) {
					tabIconDrawable = res
							.getDrawable(R.drawable.ic_tab_myoffers_selected);
				} else if (tabName.equalsIgnoreCase(HomeActivity.TAB_FAVORITE)) {
					tabIconDrawable = res
							.getDrawable(R.drawable.ic_tab_fav_selected);
				} else if (tabName
						.equalsIgnoreCase(HomeActivity.TAB_PREFERENCES)) {
					tabIconDrawable = res
							.getDrawable(R.drawable.ic_tab_settings_selected);
				} else if (tabName
						.equalsIgnoreCase(HomeActivity.TAB_LOYALTY_CARD)) {
					tabIconDrawable = res
							.getDrawable(R.drawable.ic_tab_loyalty_selected);
				} else if (tabName
						.equalsIgnoreCase(HomeActivity.TAB_MY_ACCOUNT)) {
					tabIconDrawable = res
							.getDrawable(R.drawable.ic_tab_myaccount_selected);
				} else if (tabName.equalsIgnoreCase(HomeActivity.TAB_ABOUT_US)) {
					tabIconDrawable = res
							.getDrawable(R.drawable.ic_tab_about_us_selected);
				}
				viewHolder.mImageViewTabIcon.setImageDrawable(tabIconDrawable);
			} else {
				viewHolder.mTextViewTabName.setText("");
				viewHolder.mImageViewTabIcon.setImageDrawable(null);
			}

			if (mTabItemCounts != null && mTabItemCounts.length > 0
					&& (mTabItemCounts.length - 1) >= position) {
				int itemCount = mTabItemCounts[position];
				if (itemCount > 0) {
					viewHolder.mTextViewTabItemCount.setText("(" + itemCount
							+ ")");
				} else {
					viewHolder.mTextViewTabItemCount.setText("");
				}
			} else {
				viewHolder.mTextViewTabItemCount.setText("");
			}
			return vi;
		}

		/**
		 * Set the tab item counts i.e. count of offers, My Offers, Favorites
		 * etc.
		 */
		public void setTabItemCounts(int[] tabItemCounts) {
			mTabItemCounts = tabItemCounts;
		}
	}

	/** Method to redraw the list to update the offers count. */
	public void redrawView() {
		LogConfig.logd(LOG_TAG, "redrawView()");
		if (mCustomAdapter != null) {
			int[] itemCounts = {
					PreferenceConfig.getCommonOfferCount(getActivity()),
					PreferenceConfig.getPersonalOfferCount(getActivity()),
					PreferenceConfig.getFavoriteOfferCount(getActivity()), 0 };
			mCustomAdapter.setTabItemCounts(itemCounts);
			mCustomAdapter.notifyDataSetChanged();
		}
	}

	/** Method to make any Slide Menu row item selected. */
	public void setRowSelected(final int rowIndex) {
		mSelectedPosition = rowIndex;
		mCustomAdapter.notifyDataSetChanged();
	}
}
