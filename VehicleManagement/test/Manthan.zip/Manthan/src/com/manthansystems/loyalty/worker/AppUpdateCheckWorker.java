/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.UpdateCheckJSONParserFactory;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 * make the network request related to app update check. It handles the
 * parsing, caching and error states while of these processes.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class AppUpdateCheckWorker extends BaseWorker {

	private final static String LOG_TAG = "AppUpdateCheckWorker";
	
	/** Start processing the request. */
	public static Bundle start(final Context inContext, final int inReturnFormat,
    		final Bundle inBudleData) throws IllegalStateException,
    		IOException,URISyntaxException, RestClientException, ParserConfigurationException,
    		SAXException, JSONException, Exception, OperationApplicationException, ConnectionException {
    	
    	Bundle bundle = new Bundle();
    	String responseStatus = null;
    	ArrayList<Header> headerList = getBasicHeaders(inContext);
    	HashMap<String, Object> hashMap = new HashMap<String, Object>(1);
    	NetworkConnectionResult wsResult = NetworkConnection.retrieveResponseFromService(
    			WSConfig.URL_CHECK_APP_UPDATE, Method.GET,
    			null, headerList, true, false, inContext);
    	
    	LogConfig.logv(LOG_TAG, "wsResult = " + wsResult.wsResponse);
    	hashMap = UpdateCheckJSONParserFactory.parseResponse(wsResult.wsResponse);
    	
    	responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        	PreferenceConfig.setIsAppUpdateChecked(false, inContext);
        } else {
        	bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
        	bundle.putString(CommonConfig.KEY_NAME_UPDATE_AVAILABLE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_AVAILABLE));
        	bundle.putString(CommonConfig.KEY_NAME_UPDATE_MESSAGE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_MESSAGE));
        	bundle.putString(CommonConfig.KEY_NAME_UPDATE_OBSOLETE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_OBSOLETE));
        	bundle.putString(CommonConfig.KEY_NAME_UPDATE_TYPE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_TYPE));
        	bundle.putString(CommonConfig.KEY_NAME_UPDATE_VERSION, 
					(String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_VERSION));
        	if (((String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_AVAILABLE)).equalsIgnoreCase("true")) {
        		PreferenceConfig.setIsAppUpdateAvailable(true, inContext);
        	} else {
        		PreferenceConfig.setIsAppUpdateAvailable(false, inContext);
        	}
        	PreferenceConfig.setAppUpdateMessage((String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_MESSAGE),
        			inContext);
        	PreferenceConfig.setIsAppUpdateChecked(true, inContext);
        	PreferenceConfig.setAppUpdateType((String)hashMap.get(CommonConfig.KEY_NAME_UPDATE_TYPE),
        			inContext);
        }
        return bundle;
    }
}
