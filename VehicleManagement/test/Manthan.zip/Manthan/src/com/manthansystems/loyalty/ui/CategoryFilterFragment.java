/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ListView;

import com.actionbarsherlock.app.SherlockListFragment;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDao;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.model.BaseViewHolder;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.ViewHolderCategoryFilter;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.SettingsWorker;

/**
 * A class to provide user to filter category. It extends {@link SherlockListFragment}.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class CategoryFilterFragment extends SherlockListFragment  implements
		LoaderManager.LoaderCallbacks<Cursor>, OnRequestFinishedListener, OnSwipeListener {

	private static final String LOG_TAG = "CategoryFilterFragment";
	
	private final String SAVED_STATE_REQUEST_TYPE = "com.manthansystems.loyalty.ui.CategoryFilterFragment#RequestType";
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.CategoryFilterFragment#RequestId";
	
	private ViewGroup mView;
	
	private SectionAdapter mSectionAdapter;
	private int mSectionGroupColumn;
	
	private Handler mHandler;
    private RequestManager mRequestManager;
    private int mRequestId = -1;
    private static byte mRequestType;
    
    private String mErrorMessage;
    private String mErrorTitle;
    private Bundle mResponseBundle;
	
	private boolean mShowProgressBar = false;
	
	private boolean mIsNoNetworkCaseOccurs = false;
	
	private AlertDialog mAlertDialog;
	
	private ArrayList<String> mCategoryIdList;
	private ArrayList<String> mSelectedCategoryIdList;
	public static String OFFER_TYPE = "OFFER_TYPE";
	private int mOfferType;
	private CustomSwipeDetector mCustomSwipeDetector;
	private SparseArray<String> mSerialCategoryIds = new SparseArray<String>();
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState == null) {
			mOfferType = getActivity().getIntent().getIntExtra(OFFER_TYPE, DatabaseConfig.DB_OFFER_TYPE_COMMON);
		} else {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
			mRequestType = savedInstanceState.getByte(SAVED_STATE_REQUEST_TYPE);
			mOfferType = savedInstanceState.getInt(OFFER_TYPE);
		}
		mHandler = new Handler();
    	mRequestManager = RequestManager.from(getActivity());
    	mCategoryIdList = new ArrayList<String>();
    	mSelectedCategoryIdList = new ArrayList<String>();
    	mCustomSwipeDetector = new CustomSwipeDetector(getActivity(), this);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_category_filter, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        mView = root;   
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		LogConfig.logv(LOG_TAG, "onActivityCreated()");
		mSelectedCategoryIdList = UIUtils.stringToArrayList(PreferenceConfig.getCategoryFilterId(getActivity()));
		mSectionAdapter = new SectionAdapter(getActivity(), null,
				R.layout.list_header, getSectionGroupColumn());
		final ListView listView = getListView();
		listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		listView.setAdapter(mSectionAdapter);
		listView.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return mCustomSwipeDetector.onTouchEvent(event);
			}
		});
		if (PreferenceConfig.isAllCategoryTimestampExpired(getActivity())) {
			LogConfig.logv(LOG_TAG, "onResume(): Timestamp expired: downloaded categories");
			callGetCategoryWS();
		} else {
			LogConfig.logv(LOG_TAG, "onResume(): Timestamp Valid");
			callGetCategoryWS();
			populateCategoryList();
		}
	}
	
	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logv(LOG_TAG, "onPause() ");
		// un-register sliding menu open listener.
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(CategoryFilterFragment.this);
		}
		dismissActiveDialog();
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logv(LOG_TAG, "onResume()");
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(CategoryFilterFragment.this);
            } else {
                mRequestId = -1;
            }
        }
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
        outState.putByte(SAVED_STATE_REQUEST_TYPE, mRequestType);
        outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
        outState.putInt(OFFER_TYPE, mOfferType);
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		menu.clear();
		if (isAllCategorySelected()) {
			inflater.inflate(R.menu.category_all_deselect_menu_items, menu);
		} else {
			inflater.inflate(R.menu.category_all_select_menu_items, menu);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.menu_category_select_all
				|| item.getItemId() == R.id.menu_category_deselect_all) {
			if (isAllCategorySelected()) {
				mSelectedCategoryIdList.clear();
				PreferenceConfig.setAllCategoryFiltersSelected(false, getActivity());
			} else {
				mSelectedCategoryIdList.clear();
				int size = mCategoryIdList.size();
				for (int i = 0; i < size; ++ i) {
					mSelectedCategoryIdList.add(mCategoryIdList.get(i));
				}
				PreferenceConfig.setAllCategoryFiltersSelected(true, getActivity());
			}
			mSectionAdapter.notifyDataSetChanged();
			getSherlockActivity().invalidateOptionsMenu();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.label_filter, false, true, false, getSherlockActivity());
	}
	
	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(CategoryFilterFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
 
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.GET_ALL_CATEGORIES) {
					allCategoriesDownloadedDoSomething();
				} 
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
				if (mRequestType == REQUEST_TYPE.GET_ALL_CATEGORIES) {
					populateCategoryList();
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
			if (mRequestType == REQUEST_TYPE.GET_ALL_CATEGORIES) {
				populateCategoryList();
			}
		}
	 };
	
	/**
	 * A custom {@link CursorAdapter} class to render the product list.
	 * @author Gaurav Agrawal {gaurav.agrawal@xymob.com}
	 *
	 */
	private class SectionAdapter extends SectionCursorAdapter {

		private Activity mActivity;
		private int mPosition;
		private int mSelectedPosition = -1;
		private HashMap<String , String> hashMap;
		
		/** Parameterized constructor.*/
		public SectionAdapter(Context context, Cursor c, int headerLayout,
				int groupColumn) {
			super(context, c, headerLayout, groupColumn);
			mActivity = (Activity) context;
		}

		/** {@inheritDoc} */
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			mPosition = position;
			if (convertView == null || (convertView != null && convertView.getTag() == null)) {
				convertView = mActivity.getLayoutInflater().inflate(
						R.layout.row_for_categories_filter, null);
				final CategoryFilterViewHolder viewHolder = new CategoryFilterViewHolder(convertView);
				convertView.setTag(viewHolder);
			}
			return super.getView(position, convertView, parent);
		}

		/** {@inheritDoc} */
		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {
			return null;
		}

		/** {@inheritDoc} */
		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			if (view != null) {
				final Cursor c = cursor;
				final int mapCursorPos = getSectionForPosition(mPosition);
				c.moveToPosition(mapCursorPos);
				final CategoryFilterViewHolder holder = (CategoryFilterViewHolder) view.getTag();
				holder.setRowPosition(mPosition, mSelectedPosition);
				final String categoryId = cursor.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN);
				holder.mCheckBoxCategory.setTag(categoryId);
				holder.mCheckBoxCategory.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						handleCategoryClicking(v.getTag().toString());
					}
				});
				if (mSelectedCategoryIdList.contains(categoryId)) {
					holder.mCheckBoxCategory.setChecked(true);
				} else {
					holder.mCheckBoxCategory.setChecked(false);
				}
				String categoryCount = hashMap.get(categoryId);
				if (TextUtils.isEmpty(categoryCount)) {
					holder.mTextViewCategoryCount.setText("(0)");
				} else {
					holder.mTextViewCategoryCount.setText("(" + categoryCount + ")");
				}
				holder.populateView(c, view);
			}
		}

		/** {@inheritDoc} */
		public String getGroupCustomFormat(Object obj) {
			return (String) obj;
		}
		
		/** A method to set coupon counts for all category items in hashmap. */
		private void setCouponCount(HashMap<String, String> inHashMap) {
			hashMap = inHashMap;
		}
	}
	
	/** Method to handle category clicking. */
	private void handleCategoryClicking(String categoryId) {
		if (!TextUtils.isEmpty(categoryId)) {
			if (isAllCategorySelected()) {
				mSelectedCategoryIdList.clear();
				mSelectedCategoryIdList.add(categoryId);
				PreferenceConfig.setAllCategoryFiltersSelected(true, getActivity());
			} else {
				if (mSelectedCategoryIdList.contains(categoryId)) {
					mSelectedCategoryIdList.remove(categoryId);
				} else {
					mSelectedCategoryIdList.add(categoryId);
				}
				PreferenceConfig.setAllCategoryFiltersSelected(isAllCategorySelected(), getActivity());
			}
			mSectionAdapter.notifyDataSetChanged();
			getSherlockActivity().invalidateOptionsMenu();
		}	
	}
	
	/**
	 * Get the section group column name for list, the groups will be
	 * created based on this column name.
	 */
	private int getSectionGroupColumn() {
		return mSectionGroupColumn;
	}
	
	/**
	 * A view holder class that extends {@link BaseViewHolder} which holds the view of
	 * {@link Coupon} list row layout.
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 *
	 */
	private static class CategoryFilterViewHolder extends ViewHolderCategoryFilter{
		public CategoryFilterViewHolder(View view) {
			super(view);
		}
	}

	@Override
	public Loader<Cursor> onCreateLoader(int token, Bundle bundle) {
		if (token == DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST) {
			return new CursorLoader(getActivity(), CategoryDao.CONTENT_URI, null, 
					CategoryDao.IS_MAIN_CATEGORY + " = " + CategoryDao.FLAG_VALUE_MAIN_CATEGORY 
					+ " AND " + CategoryDao.CATEGORY_ID + " != " + UIApplication.All_CATEGORY_ID ,
					null, null);
		} 
		return null;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		final int token = loader.getId();
		LogConfig.logd(LOG_TAG, "onloadFinished");
		if (token == DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST) {
			if (cursor != null) {
				LogConfig.logd(LOG_TAG, "count is " + cursor.getCount());
			}
			mSerialCategoryIds.clear();
			mSectionAdapter.swapCursor(cursor);
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					cursor.moveToPosition(-1);
					int position = 0;
					while (cursor.moveToNext()) {
						mSerialCategoryIds.put(position, cursor.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
						position ++;
					}
					cursor.moveToPosition(-1);
					if (mSelectedCategoryIdList.size() == 0) {
						while (cursor.moveToNext()) {
							mCategoryIdList.add(cursor.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
							mSelectedCategoryIdList.add(cursor.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
						}
						PreferenceConfig.setAllCategoryFiltersSelected(true, getActivity());
					} else {
						while (cursor.moveToNext()) {
							mCategoryIdList.add(cursor.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN));
						}
						PreferenceConfig.setAllCategoryFiltersSelected(isAllCategorySelected(), getActivity());
					}
				} else if (cursor.getCount() <= 0 && !mIsNoNetworkCaseOccurs) {
					mHandler.post(new Runnable() {
						
						@Override
						public void run() {
							if (mResponseBundle != null) {
								mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_RESULTS_MESSAGE);
								if (!TextUtils.isEmpty(mErrorMessage)) {
									mErrorTitle = getResources().getString(R.string.app_name);
									showDialog(DialogConfig.DIALOG_ERROR);
								}
							}
						}
					});
				}
				mIsNoNetworkCaseOccurs = false;
				getSherlockActivity().invalidateOptionsMenu();
			}
		} 
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		// This is called when the last Cursor provided to onLoadFinished()
        // above is about to be closed.  We need to make sure we are no
        // longer using it.
		mSectionAdapter.swapCursor(null);
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;

		case DialogConfig.DIALOG_SELECT_ATLEAST_ONE_CATEGORY:
			dlg.setIcon(R.drawable.icon)
			.setTitle(getResources().getString(R.string.app_name))
			.setMessage(getResources().getString(R.string.label_select_at_least_one_category))
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_fragment_cateegory_filter));
		   System.gc();
	   }
	}
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
	
	/** Make server request to get category from server. */
	private void callGetCategoryWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			populateCategoryList();
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		
		ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
				false, mHandler, getSherlockActivity());
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(CategoryFilterFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.GET_ALL_CATEGORIES;
		params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
				SettingsWorker.WorkerModes.WORKER_MODE_GET_ALL_CATEGORY);
		mRequestId = mRequestManager.getAllCategories(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	/** A method to perform action after successfully downloading of all category. **/
	private void allCategoriesDownloadedDoSomething() {
		ProgressBarHelper.dismissProgressBar(mHandler);
		populateCategoryList();
	}
	
	/** A method to populate category list from DataBase. */
	private void populateCategoryList() {
		mSectionAdapter.setCouponCount(prepareCategoryCount(mOfferType));
		getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST);
		getLoaderManager().initLoader(DatabaseConfig.QUERY_TOKEN_CATEGORIES_LIST, null, this);
	}
	
	/** A method to prepare category count from DB. */
	private HashMap<String,String> prepareCategoryCount (int couponChooser) {
		HashMap<String, String> map = new HashMap<String, String>();
		final int COLUMN_CATEGORY_ID = 0;
		final int COLUMN_CATEGORY_COUNT = 1;
		String where = "select TBL_CATEGORY_COUNT.CATEGORY_ID, COUNT(TBL_CATEGORY_COUNT.CATEGORY_ID) " +
				"from TBL_CATEGORY_COUNT WHERE TBL_CATEGORY_COUNT.OFFER_TYPE = " + couponChooser +
				" GROUP BY TBL_CATEGORY_COUNT.CATEGORY_ID";
		CursorLoader cursorLoader = new CursorLoader(getActivity(), CategoryCountDao.CONTENT_URI, null,
				where, null, null);
		Cursor c = cursorLoader.loadInBackground();
		if (c != null && c.getCount() > 0) {
			c.moveToPosition(-1);
			while(c.moveToNext()) {
				String categoryId = c.getString(COLUMN_CATEGORY_ID);
				String categoryCount = c.getString(COLUMN_CATEGORY_COUNT);
				map.put(categoryId, categoryCount);
			}
		}
		if (c != null) {
			c.close();
		}
		return map;
	}
	
	/**
	 * A method to check whether all category is selected or not. Return true if
	 * all category is selected.
	 **/
	private boolean isAllCategorySelected() {
		if (mSelectedCategoryIdList.size() == mCategoryIdList.size()) {
			return true;
		}
		return false;
	}
	
	/** Method to handle back key press. */
	public boolean handleBackKeyPress() {
		if (mSelectedCategoryIdList.size() == 0 && mCategoryIdList.size() > 0) {
			showDialog(DialogConfig.DIALOG_SELECT_ATLEAST_ONE_CATEGORY);
			return true;
		} else {
			PreferenceConfig.setCategoryFilterId(mSelectedCategoryIdList.toString(), getActivity());
			return false;
		}
	}

	@Override
	public void onLeftToRightSwipeDetected() {
		if(handleBackKeyPress()) {
			return;
		}
		getActivity().finish();
	}

	@Override
	public void onRightToLeftSwipeDetected() {
		// Do nothing
	}

	@Override
	public void onListItemClicked(int position) {
		if (position > -1) {
			handleCategoryClicking(mSerialCategoryIds.get(position));
		}
	}
}
