/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

/**
 * A model class that holds the Category data coming from server. 
 * @author Gaurav Agrawal: gaurav.agrawal@xymob.com
 *
 */
public class Category {
	public String mCategoryId;
	public String mCategoryName;
	public String mCategoryCheckFlag;
	public String mCategoryOwnerId;
	public byte mIsCategory;
	
	/** Default Constructor. */
	public Category() {
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			// Do nothing.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.finalize();
		}
	}
}
