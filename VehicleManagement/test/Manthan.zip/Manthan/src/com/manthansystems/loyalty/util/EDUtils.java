/**
 * Copyright XYMOB Inc 2014. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import android.content.Context;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;

import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;

/**
 * An utility class that provides encryption and decryption upon the data.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class EDUtils {
	
	public static final String LOG_TAG = "EDUtils";
	
	private static String mLoginToken;
	private static String mEmailId;
	
	/**
	 * Method to generate a truly random AES key which used as encryption salt.
	 * @return random AES key.
	 * @throws NoSuchAlgorithmException
	 */
	public static SecretKey generateSalt() throws NoSuchAlgorithmException {
	    // Generate a 256-bit key
	    final int outputKeyLength = BusinessLogicConfig.CODE_RED_OUTPUT_LENGTH;

	    SecureRandom secureRandom = new SecureRandom();
	    // Do *not* seed secureRandom! Automatically seeded from system entropy.
	    KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
	    keyGenerator.init(outputKeyLength, secureRandom);
	    SecretKey key = keyGenerator.generateKey();
	    return key;
	}

	/**
	 * If your app needs additional encryption, a recommended approach is to
	 * require a passphrase or PIN to access your application. This passphrase
	 * could be fed into PBKDF2 to generate the encryption key. (PBKDF2 is a
	 * commonly used algorithm for deriving key material from a passphrase,
	 * using a technique known as "key stretching".) Android provides an
	 * implementation of this algorithm inside SecretKeyFactory as
	 * <code>PBKDF2WithHmacSHA1</code>
	 * 
	 * @param passphraseOrPin
	 * @param salt
	 * @return the encryption key
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 */
	public static SecretKey generateKey(char[] passphraseOrPin, byte[] salt)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		// Number of PBKDF2 hardening rounds to use. Larger values increase
		// computation time. You should select a value that causes computation
		// to take >100ms.
		final int iterations = BusinessLogicConfig.CODE_RED_ITERATION_COUNT;

		// Generate a 256-bit key
		final int outputKeyLength = BusinessLogicConfig.CODE_RED_OUTPUT_LENGTH;

		SecretKeyFactory secretKeyFactory = SecretKeyFactory
				.getInstance("PBKDF2WithHmacSHA1");
		KeySpec keySpec = new PBEKeySpec(passphraseOrPin, salt, iterations,
				outputKeyLength);
		SecretKey secretKey = secretKeyFactory.generateSecret(keySpec);
		SecretKey encriptionKey = new SecretKeySpec(secretKey.getEncoded(), "AES");
		return encriptionKey;
	}
	
	/**
	 * Method to encrypt data.
	 * @param inContext
	 * @param plainText
	 * @param passphraseOrPin
	 * @return encrypted data
	 * @throws Exception
	 */
	public static byte[] encrypt(Context inContext, final String plainText,
			final String passphraseOrPin) throws Exception {
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] iv = PreferenceConfig.getCodeRedIVKey(inContext);
		if (iv == null) {
			iv = new byte[cipher.getBlockSize()];
			SecureRandom secureRandom = new SecureRandom();
			secureRandom.nextBytes(iv);
			PreferenceConfig.setCodeRedIVKey(iv, inContext);
		}
		IvParameterSpec ivParams = new IvParameterSpec(iv);
		SecretKey secretKey = generateKey(passphraseOrPin.toCharArray(),
				PreferenceConfig.getCodeRedKey(inContext));
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParams);
		byte[] ciphertext = cipher.doFinal(plainText.getBytes());
		return ciphertext;
	}
	
	/**
	 * Method to decrypt the data.
	 * @param inContext
	 * @param encryptedText
	 * @param passphraseOrPin
	 * @return decrypted data
	 * @throws Exception
	 */
	public static byte[] decrypt(Context inContext, final byte[] encryptedText,
			final String passphraseOrPin) throws Exception {
		byte[] salt = PreferenceConfig.getCodeRedKey(inContext);
		if (salt == null) {
			throw new Exception("Crypto salt should not be null");
		}
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] iv = PreferenceConfig.getCodeRedIVKey(inContext);
		if (iv == null) {
			throw new Exception("Crypto iv should not be null");
		}
		SecretKey key = generateKey(passphraseOrPin.toCharArray(), salt);
		IvParameterSpec ivParams = new IvParameterSpec(iv);
		cipher.init(Cipher.DECRYPT_MODE, key, ivParams);
		byte[] plaintext = cipher.doFinal(encryptedText);
		return plaintext;
    }
	
	/**
	 * Method to get the passphrase of pin for encryption.
	 * @return passphrase of pin for encryption.
	 */
	public static String getPassPhrase(Context inContext) {
		String pass = PreferenceConfig.getCodeRedPass(inContext) + "PIN";
		byte[] passByte = pass.getBytes();
		int length = passByte.length;
		for (int i = 0; i < length; ++i) {
			passByte[i] = (byte) (passByte[i] & 0xFF);
		}
		return Base64.encodeToString(passByte, Base64.NO_WRAP);
	}
	
	/**
	 * Method to encrypt the data.
	 * @param inContext
	 * @param data plain text
	 * @return encrypted data
	 */
	public static byte[] encrypt(Context inContext, final String data) {
		if (TextUtils.isEmpty(data)) {
    		return null;
    	}
    	try {
			final byte[] encryptBytes = encrypt(inContext, data,
					getPassPhrase(inContext));
			return encryptBytes;
		} catch (Exception e) {
			Log.e(LOG_TAG, "encrypt() : Exception: " + e);
			e.printStackTrace();
			return null;
		}
    }
	
	/**
	 * Method to decrypt the data.
	 * @param inContext
	 * @param data encrypted data
	 * @return decrypted data
	 */
	public static byte[] decrypt(Context inContext, final String data) {
    	if (TextUtils.isEmpty(data)) {
    		return null;
    	}
    	try {
			final byte[] decryptBytes = decrypt(inContext,
					Base64.decode(data, Base64.NO_WRAP),
					getPassPhrase(inContext));
			return decryptBytes;
		} catch (Exception e) {
			Log.e(LOG_TAG, "decrypt() : Exception: " + e);
			e.printStackTrace();
			return null;
		}
    }
	
	/**
	 * Get the login token.
	 * @return login token.
	 */
	public static String getLoginToken(Context context) {
		LogConfig.logv(LOG_TAG, "getLoginToken()");
		if (TextUtils.isEmpty(mLoginToken)) {
			LogConfig.logv(LOG_TAG, "getLoginToken(): load token in-memory");
			String loginToken = PreferenceConfig.getLoginToken(context);
			if (TextUtils.isEmpty(loginToken)) {
				LogConfig.logv(LOG_TAG, "getLoginToken(): No token yet");
				return null;
			}
			LogConfig.logv(LOG_TAG, "getLoginToken(): decrypt token");
			final byte[] loginTokenBytes = EDUtils.decrypt(context, loginToken);
			if (loginTokenBytes != null) {
				mLoginToken = new String(loginTokenBytes);
				LogConfig.logv(LOG_TAG, "getLoginToken(): token decrypt success: " + mLoginToken);
				return mLoginToken;
			} else {
				LogConfig.logv(LOG_TAG, "getLoginToken(): Unable to decrypt token");
				PreferenceConfig.setUserValidity(false, context);
				EDUtils.setLoginToken(context, "");
				EDUtils.setEmailId(context, "");
				PreferenceConfig.setSessionId("", context);
			}
		}
		return mLoginToken;
	}

	/**
	 * Set the login token.
	 * @param loginToken
	 */
	public static void setLoginToken(Context inContext, String loginToken) {
		mLoginToken = loginToken;
		LogConfig.logv(LOG_TAG, "setLoginToken(): " + mLoginToken);
		if (TextUtils.isEmpty(loginToken)) {
			LogConfig.logv(LOG_TAG, "setLoginToken(): Save NULL token");
			PreferenceConfig.setLoginToken("", inContext);
			return;
		}
		LogConfig.logv(LOG_TAG, "setLoginToken(): Encrypt given token");
		final byte[] newLoginToken = EDUtils.encrypt(inContext, loginToken);
		if (newLoginToken != null) {
			LogConfig.logv(LOG_TAG, "setLoginToken(): Save encrypted token");
			PreferenceConfig.setLoginToken(
				Base64.encodeToString(newLoginToken, Base64.NO_WRAP),
				inContext);
		} else {
			LogConfig.logv(LOG_TAG, "setLoginToken(): Unable to encrypt token");
		}
	}
	
	/**
	 * Get the email id from in memory.
	 * @return email id.
	 */
	public static String getEmailID(Context context) {
		LogConfig.logv(LOG_TAG, "getEmailID()");
		if (TextUtils.isEmpty(mEmailId)) {
			String emailId = PreferenceConfig.getUserEmailAddress(context);
			if (TextUtils.isEmpty(emailId)) {
				LogConfig.logv(LOG_TAG, "getEmailID(): No email Id yet");
				return null;
			}
			LogConfig.logv(LOG_TAG, "getEmailID(): decrypt email id");
			final byte[] emailIdBytes = EDUtils.decrypt(context, emailId);
			if (emailIdBytes != null) {
				mEmailId = new String(emailIdBytes);
				LogConfig.logv(LOG_TAG, "getEmailID(): Save decrypted email id: " + mEmailId);
				return mEmailId;
			} else {
				LogConfig.logv(LOG_TAG, "getEmailID(): Unable to decrypt email Id");
			}
		}
		return mEmailId;
	}

	/**
	 * Set the email id in memory.
	 * @param emailId
	 */
	public static void setEmailId(Context inContext, String emailId) {
		LogConfig.logv(LOG_TAG, "setEmailId()");
		mEmailId = emailId;
		if (TextUtils.isEmpty(emailId)) {
			LogConfig.logv(LOG_TAG, "setEmailId(): Save NULL email Id");
			PreferenceConfig.setUserEmailAddress("", inContext);
			return;
		}
		LogConfig.logv(LOG_TAG, "setEmailId(): Encrypt given email id");
		final byte[] newEmailId = EDUtils.encrypt(inContext, emailId);
		if (newEmailId != null) {
			LogConfig.logv(LOG_TAG, "setEmailId(): Save encrypted email id");
			PreferenceConfig.setUserEmailAddress(
				Base64.encodeToString(newEmailId, Base64.NO_WRAP),
				inContext);
		} else {
			LogConfig.logv(LOG_TAG, "setEmailId(): Unable to encrypt token");
		}
	}
}
