/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

/**
 * An interface that holds the different Coupon usage types. The values can be
 * 1 - Normal, 2- Single Use, 3 - Multiple Use, 4 - Multiple with threshold.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public interface CouponUsageType {
	public final byte TYPE_NORMAL = 1;
	public final byte TYPE_SINGLE = 2;
	public final byte TYPE_MULTIPLE = 3;
	public final byte TYPE_MULTIPLE_WITH_THRESHOLD = 4;
}
