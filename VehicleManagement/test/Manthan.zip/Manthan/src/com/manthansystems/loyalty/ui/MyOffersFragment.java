/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import com.manthansystems.loyalty.R;

/**
 * A class to display the My offers listing. It extends {@link OffersFragment}.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class MyOffersFragment extends OffersFragment {

	@Override
	protected void updateLogTag() {
		LOG_TAG = "MyOffersFragment";
	}
	
	@Override
	protected byte getOffersType() {
		return OffersType.PERSONAL_OFFERS;
	}
	
	/** Method to get the resource id for screen title. */
	public int getTitleResId() {
		return R.string.label_tab_myoffers;
	}
}
