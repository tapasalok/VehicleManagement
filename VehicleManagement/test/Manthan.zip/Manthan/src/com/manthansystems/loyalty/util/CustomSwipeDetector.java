/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import android.app.Activity;
import android.support.v4.app.ListFragment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.widget.ListView;

import com.manthansystems.loyalty.config.LogConfig;

/**
 * A custom screen swipe detector that invokes the callback method on left or right swipe.
 * The listeners have to implement the {@link OnSwipeListener} interface.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * @see OnSwipeListener
 */
public class CustomSwipeDetector implements OnGestureListener {

	private final String LOG_TAG = "CustomSwipeDetector";
	
	//swipe gesture constants
	private static int SWIPE_MIN_DISTANCE = 120;
	private static int SWIPE_MAX_OFF_PATH = 250;
	private static int SWIPE_THRESHOLD_VELOCITY = 200;
	
	private OnSwipeListener mOnSwipeListener;
	private GestureDetector mGestureDetector;
	
	/**
	 * Constructor Method.
	 * @param onSwipeListener Callback listener.
	 * @See {@link OnSwipeListener}
	 */
	public CustomSwipeDetector(Activity activity, OnSwipeListener onSwipeListener) {
		mOnSwipeListener = onSwipeListener;
		mGestureDetector = new GestureDetector(activity, (OnGestureListener) this);
		DisplayMetrics dm = activity.getResources().getDisplayMetrics();
	    SWIPE_MIN_DISTANCE = (int)(120.0f * dm.densityDpi / 160.0f + 0.5); 
	    SWIPE_MAX_OFF_PATH = (int)(250.0f * dm.densityDpi / 160.0f + 0.5);
	    SWIPE_THRESHOLD_VELOCITY = (int)(200.0f * dm.densityDpi / 160.0f + 0.5);
	}
	
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		LogConfig.logv(LOG_TAG, "onFling()");
		try {
			if (e1 != null && e2 != null) {
				if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH) {
					return false;
				}
				if(e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					LogConfig.logv(LOG_TAG, "onFling() to left");
					//right to left swipe
					mOnSwipeListener.onRightToLeftSwipeDetected();
				} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					LogConfig.logv(LOG_TAG, "onFling() to right");
					//left to right swipe
					mOnSwipeListener.onLeftToRightSwipeDetected();
				}
			}
		} catch (Exception e) {
			Log.e(LOG_TAG, "onFling(): " + e);
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean onDown(MotionEvent e) {
		// Do Nothing
		return false;
	}
	
	@Override
	public void onLongPress(MotionEvent e) {
		// Do Nothing
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		// Do Nothing
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		// Do Nothing
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		if (mOnSwipeListener instanceof ListFragment) {
			ListView listView = ((ListFragment) mOnSwipeListener).getListView();
	        int pos = listView.pointToPosition((int)e.getX(), (int)e.getY());
	        if (pos > -1) {
	        	mOnSwipeListener.onListItemClicked(pos);
	        }
		}
		return false;
	}
	
	/**
	 * Analyses the given motion event and if applicable triggers the
	 * appropriate callbacks on the GestureDetector.OnGestureListener supplied.
	 */
	public boolean onTouchEvent(MotionEvent me) {
		return mGestureDetector.onTouchEvent(me);
	}
	
	/**
	 * An interface that holds the callback methods of Swipe detection.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 */
	public static interface OnSwipeListener {
		/** Method that invokes when screen swiped from left to right. */
		public void onLeftToRightSwipeDetected();
		
		/** Method that invokes when screen swiped from right to left. */
		public void onRightToLeftSwipeDetected();
		
		/** Method that only will invoke for {@link ListFragment} type listeners
		 * when their list row is clicked. */
		public void onListItemClicked(int position);
	}
}
