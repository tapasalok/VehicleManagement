/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.service;

import org.json.JSONException;

import android.content.Intent;
import android.os.Bundle;

import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.AppUpdateCheckWorker;
import com.manthansystems.loyalty.worker.CouponRedemptionWorker;
import com.manthansystems.loyalty.worker.FavoriteOffersWorker;
import com.manthansystems.loyalty.worker.LoginWorker;
import com.manthansystems.loyalty.worker.LoyaltyCardWorker;
import com.manthansystems.loyalty.worker.OffersWorker;
import com.manthansystems.loyalty.worker.SettingsWorker;
import com.manthansystems.loyalty.worker.TriggerWorker;

/**
 * This class is called by the {@link RequestManager} through the
 * {@link Intent} system. Get the parameters stored in the {@link Intent} and
 * call the right Worker.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 */
public class WorkerService extends BaseWorkerService {

    private static final String LOG_TAG = WorkerService.class.getSimpleName();

    // TODO : Set the number of thread
    // Max number of parallel threads used
    private static final int MAX_THREADS = 3;
    
    // TODO : Set a numeric constant for each worker (to distinguish them).
    // These constants will be sent in the Intent in order to see which worker
    // to call
    // Worker types
    public static final int WORKER_TYPE_OFFER_LIST = 1;
    public static final int WORKER_TYPE_SEARCH_STORE = 2;
    public static final int WORKER_TYPE_USER_LOGIN = 3;
    public static final int WORKER_TYPE_FAVORITE_OFFER = 4;
    public static final int WORKER_TYPE_SETTINGS = 5;
    public static final int WORKER_TYPE_OFFER_COUNT = 6;
    public static final int WORKER_TYPE_TRIGGER_EVENT = 7;
    public static final int WORKER_TYPE_LOYALTY_CARD = 8;
    public static final int WORKER_TYPE_OFFER_REDEMPTION = 9;
    public static final int WORKER_TYPE_CHECK_APP_UPDATE = 10;
	
    // TODO : Set a string constants for each param to send to the worker. You
    // should use these constants in the Intent as extra name
    public static final String INTENT_EXTRA_RETURN_FORMAT = "com.manthansystems.loyalty.extras.ReturnFormat";
    public static final String INTENT_EXTRA_BUNDLE_DATA = "com.manthansystems.loyalty.extras.BundleData";
    
    private Bundle mBundle = new Bundle();

    public WorkerService() {
        super(MAX_THREADS);
    }

    @Override
    protected void onHandleIntent(final Intent intent) {
        final int workerType = intent.getIntExtra(INTENT_EXTRA_WORKER_TYPE, -1);
        mBundle.clear();
        try {
            switch (workerType) {
			case  WORKER_TYPE_OFFER_LIST:
        		mBundle = OffersWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
        				DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
        		sendSuccess(intent, mBundle);
            	break;
            
			case  WORKER_TYPE_USER_LOGIN:
        		mBundle = LoginWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
        				DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
        		sendSuccess(intent, mBundle);
            	break;
            	
			case  WORKER_TYPE_FAVORITE_OFFER:
        		mBundle = FavoriteOffersWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
        				DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
        		sendSuccess(intent, mBundle);
            	break;
            	
			case  WORKER_TYPE_SETTINGS:
        		mBundle = SettingsWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
        				DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
        		sendSuccess(intent, mBundle);
            	break;
            	
			case  WORKER_TYPE_OFFER_COUNT:
        		mBundle = OffersWorker.getOffersCount(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
        				DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
        		sendSuccess(intent, mBundle);
            	break;
            	
			case WORKER_TYPE_TRIGGER_EVENT:
				TriggerWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT, 
						DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
				
			case WORKER_TYPE_LOYALTY_CARD:
				mBundle = LoyaltyCardWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT, 
						DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;

			case  WORKER_TYPE_OFFER_REDEMPTION:
        		mBundle = CouponRedemptionWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
        				DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
        		sendSuccess(intent, mBundle);
            	break;
	            	
			case  WORKER_TYPE_CHECK_APP_UPDATE:
        		mBundle = AppUpdateCheckWorker.start(this, intent.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
        				DownloadFormat.RETURN_FORMAT_JSON), intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
        		sendSuccess(intent, mBundle);
            	break;
				
            default:
            	LogConfig.logd(LOG_TAG, "This worker type is not implemented");
                sendFailure(intent, null);
                break;
            }
            // This block (which should be the last one in your implementation)
            // will catch all the RuntimeException and send you back an error
            // that you can manage. If you remove this catch, the
            // RuntimeException will still crash the Service but you will not be
            // informed (as it is in 'background') so you should never remove
            // this catch
        } catch (final JSONException e) {
        	LogConfig.logd(LOG_TAG, "JSONException", e);
            sendDataFailure(intent, null);
        } catch (final ConnectionException e) {
        	LogConfig.logd(LOG_TAG, "ConnectionException", e);
            sendConnexionFailure(intent, null);
        } catch (final Exception e) {
        	LogConfig.logd(LOG_TAG, "Error", e);
            sendFailure(intent, null);
        }
    }
}
