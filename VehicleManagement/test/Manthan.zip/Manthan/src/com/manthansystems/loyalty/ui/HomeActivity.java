/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.KeyEvent;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.service.LocationUpdateService;
import com.manthansystems.loyalty.ui.OffersFragment.OfferNotificationType;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.util.AnalyticsHelper;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.TriggerWorker.TriggerConstants;

/**
 * An {@link Activity} class that extends {@link BaseSlidingActivity}. It will
 * manage sliding screen for the application.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class HomeActivity extends BaseSlidingActivity {

	private final String LOG_TAG = "HomeActivity";

	private Fragment mContent;
	public static String TAB_OFFERS = "Offers";
	public static String TAB_MYOFFERS = "My Offers";
	public static String TAB_FAVORITE = "Favourites";
	public static String TAB_PREFERENCES = "Preferences";
	public static String TAB_LOYALTY_CARD = "Loyalty Card";
	public static String TAB_LOYALTY_CARD_VIEW = "Loyalty Card View";
	public static String TAB_MY_ACCOUNT = "My Account";
	public static String TAB_ABOUT_US = "About Us";

	public static String KEY_EXTRA_STRING_NOTIFICATION_CLICKED = "com.manthansystems.loyalty.ui#NOTIFICATION_CLICKED";

	public static final int POSITION_TAB_OFFERS = 0;
	public static final int POSITION_TAB_MYOFFERS = 1;
	public static final int POSITION_TAB_FAVORITE = 2;
	public static final int POSITION_TAB_PREFERENCES = 3;
	public static final int POSITION_TAB_LOYALTY_CARD = 4;
	// public static final int POSITION_TAB_MY_ACCOUNT = 5;
	public static final int POSITION_TAB_ABOUT_US = 5;

	private static HomeActivity mHomeActivity;
	private final HashMap<String, TabInfo> mTabs = new HashMap<String, TabInfo>();
	private TabInfo mCurrentTab;
	private static int mDlgMessageResId;
	private AlertDialog mAlertDialog;

	/** Constructor method. */
	public HomeActivity() {
		super(R.string.app_name);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Initialise the app version for logging.
		LogConfig.APP_VER = getResources().getString(R.string.version_name);
		LogConfig.logd(LOG_TAG, "onCreate()");
		// set the Above View
		if (savedInstanceState != null) {
			mContent = getSupportFragmentManager().getFragment(
					savedInstanceState, "mContent");
		}

		// set the Above View
		setContentView(R.layout.content_frame);
		mHomeActivity = this;

		Resources res = getResources();
		TAB_OFFERS = res.getString(R.string.label_tab_offers);
		TAB_MYOFFERS = res.getString(R.string.label_tab_myoffers);
		TAB_FAVORITE = res.getString(R.string.label_tab_favorite);
		TAB_PREFERENCES = res.getString(R.string.label_tab_preferences);
		TAB_LOYALTY_CARD = res.getString(R.string.label_tab_loyalty_card);
		TAB_MY_ACCOUNT = res.getString(R.string.label_tab_my_account);
		TAB_ABOUT_US = res.getString(R.string.label_tab_about_us);

		if (mContent == null) {
			switchContent(TAB_OFFERS, OffersFragment.class, null);
		} else {
			// set the Behind View
			setBehindContentView(R.layout.menu_frame);
			getSupportFragmentManager().beginTransaction()
					.replace(R.id.content_frame, mContent).commit();
		}

		// set the Behind View
		setBehindContentView(R.layout.menu_frame);
		getSupportFragmentManager().beginTransaction()
				.replace(R.id.menu_frame, new SliderMenuFragment()).commit();

		// customize the SlidingMenu
		getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);

		AnalyticsHelper.initAnalytics(this);
		AnalyticsHelper.sendAppLaunchAnalytics(this);
		callAppLaunchTriggerWS();
		PreferenceConfig.setAppIsRunning(true, this);

		// If app is upgraded then set the flag to do initial favorite sync.
		try {
			PackageInfo packageInfo = this.getPackageManager().getPackageInfo(
					this.getPackageName(), 0);
			if (packageInfo.versionCode != PreferenceConfig
					.getAppVersionCode(this)) {
				LogConfig.logv(LOG_TAG,
						"onCreate(): APP UPDATED or First Launch");
				PreferenceConfig.setFavoriteOffersFirstSyncStatus(false, this);
				PreferenceConfig.setAllCategoryFiltersSelected(false, this);
				PreferenceConfig.setAllCategoryTimestamp(0L, this);
				PreferenceConfig.setCommonOffersTimestamp(0L, this);
				PreferenceConfig.setPersonalOffersTimestamp(0L, this);
				PreferenceConfig.setAppConfigDownloadStatus(false, this);
				PreferenceConfig.setAppVersionCode(packageInfo.versionCode,
						this);
			}
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}

		// Start location trigger service.
		startService(new Intent(this, LocationUpdateService.class));
		setSupportProgressBarIndeterminateVisibility(false);

		// Handle push notification clicks by user.
		handleNotificationClick(getIntent());
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		getSupportFragmentManager().putFragment(outState, "mContent", mContent);
	}

	@Override
	protected void onPause() {
		LogConfig.logd(LOG_TAG, "onPause()");
		super.onPause();
		if (getSlidingMenu().isMenuShowing()) {
			getSlidingMenu().showContent();
		}
		dismissActiveDialog();
	}

	@Override
	protected void onResume() {
		super.onResume();
		LogConfig.logd(LOG_TAG, "onResume(): Is launched from Notification = "
				+ PreferenceConfig.getIsLaunchFromNotification(this));
		if (PreferenceConfig.getIsLaunchFromNotification(this)) {
			if (PreferenceConfig.getLaunchScreenFromNotification(this)
					.equalsIgnoreCase(OfferNotificationType.PERSONAL_OFFER)) {
				switchContent(TAB_MYOFFERS, MyOffersFragment.class, null);
			} else {
				switchContent(TAB_OFFERS, OffersFragment.class, null);
			}
			ArrayList<String> filterCategoryIdList = UIUtils
					.stringToArrayList(PreferenceConfig
							.getCategoryFilterId(this));
			if (filterCategoryIdList.size() > 0
					&& !filterCategoryIdList
							.contains(UIApplication.NEW_CATEGORY_ID)) {
				filterCategoryIdList.add(UIApplication.NEW_CATEGORY_ID);
				PreferenceConfig.setCategoryFilterId(
						filterCategoryIdList.toString(), this);
			}
		} else if (PreferenceConfig.getLaunchLoyaltyCardDetailsScreen(this)) {
			LogConfig.logd(LOG_TAG, "onResume(): destroy details screen ");
			// Destroy loyalty details screen if exists.
			removeTabFragment(TAB_LOYALTY_CARD_VIEW);
			LogConfig.logd(LOG_TAG, "onResume(): details screen destoryed");
			// Launch the Loyalty card details screen after successful
			// barcode/Qr code scan.
			switchContent(TAB_LOYALTY_CARD_VIEW,
					LoyaltyCardDetailFragment.class, null);
			PreferenceConfig.setLaunchLoyaltyCardDetailsScreen(false, this);
		}
	}

	/**
	 * Method to switch to the selected screen via replacing the existing
	 * content view. If the requested screen(fragment) is not in memory it will
	 * be instantiated new and added as view content.
	 * 
	 * @param tag
	 *            Tag name of requested fragment view.
	 * @param clss
	 *            Requested fragment class name to be shown.
	 * @param args
	 *            Bundle data to be send with fragment.
	 */
	public void switchContent(String tag, Class<?> clss, Bundle args) {
		// pre-condition.
		// check if favorite or My Offers tab clicked. If so and user is not
		// sign in then
		// ask for sign up.
		if (tag.equalsIgnoreCase(TAB_FAVORITE)
				|| tag.equalsIgnoreCase(TAB_MYOFFERS)
				|| tag.equalsIgnoreCase(TAB_LOYALTY_CARD)
				|| tag.equalsIgnoreCase(TAB_LOYALTY_CARD_VIEW)
				|| tag.equalsIgnoreCase(TAB_PREFERENCES)) {
			if (!PreferenceConfig.isValidUser(HomeActivity.this)) {
				getSlidingMenu().showContent();
				if (tag.equalsIgnoreCase(TAB_FAVORITE)) {
					mDlgMessageResId = R.string.dialog_signup_user_message_fav_tab;
				} else if (tag.equalsIgnoreCase(TAB_MYOFFERS)) {
					mDlgMessageResId = R.string.dialog_signup_user_message_myoffer_tab;
				} else if (tag.equalsIgnoreCase(TAB_LOYALTY_CARD)
						|| tag.equalsIgnoreCase(TAB_LOYALTY_CARD_VIEW)) {
					mDlgMessageResId = R.string.dialog_signup_user_message_loyalty_tab;
				} else if (tag.equalsIgnoreCase(TAB_PREFERENCES)
						|| tag.equalsIgnoreCase(TAB_PREFERENCES)) {
					mDlgMessageResId = R.string.msg_sign_up_in_preferences;
				}
				showCustomDialog(DialogConfig.DIALOG_SIGN_UP);
				return;
			}
		}

		TabInfo newTab = null;
		if (mTabs != null && mTabs.containsKey(tag)) {
			LogConfig.logv(LOG_TAG, "switchContent(): existing tab: " + tag);
			newTab = mTabs.get(tag);
			newTab.fragment = getSupportFragmentManager()
					.findFragmentByTag(tag);
			if (newTab.args == null && args != null) {
				newTab.args = args;
			}
		} else {
			LogConfig.logv(LOG_TAG, "switchContent(): new tab: " + tag);
			newTab = new TabInfo(tag, clss, args);
			mTabs.put(tag, newTab);
		}

		FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
		if (mCurrentTab != newTab) {
			if (mCurrentTab != null) {
				if (mCurrentTab.fragment != null) {
					LogConfig.logv(LOG_TAG,
							"switchContent(): detach old fragment");
					ft.detach(mCurrentTab.fragment);
				}
			}
			if (newTab.fragment == null) {
				LogConfig.logv(LOG_TAG,
						"switchContent(): instantiate new fragment");
				newTab.fragment = Fragment.instantiate(HomeActivity.this,
						newTab.clss.getName(), newTab.args);
				ft.add(R.id.content_frame, newTab.fragment, newTab.tag);
			} else {
				LogConfig.logv(LOG_TAG,
						"switchContent(): attach existing fragment");
				ft.attach(newTab.fragment);
			}
			mCurrentTab = newTab;
			ft.commit();
		}
		mContent = newTab.fragment;
		getSlidingMenu().showContent();
	}

	/**
	 * A model class that holds meta data related to the screen navigation tabs
	 * like Offers, My Offers etc.
	 * 
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 * 
	 */
	static final class TabInfo {
		private final String tag;
		private final Class<?> clss;
		private Bundle args;
		private Fragment fragment;

		TabInfo(String _tag, Class<?> _class, Bundle _args) {
			tag = _tag;
			clss = _class;
			args = _args;
		}
	}

	/**
	 * Method to set a fragment as current visible view based on its tag name.
	 * 
	 * @param tabTag
	 *            - Tag name of the tab item.
	 * 
	 * @see {@link HomeActivity#TAB_OFFERS}, {@link HomeActivity#TAB_MYOFFERS},
	 *      {@link HomeActivity#TAB_FAVORITE}, {@link HomeActivity#TAB_LOCATION}
	 *      , {@link HomeActivity#TAB_PREFERENCES} etc.
	 */
	public void setCurrentTab(final String tabTag) {
		if (mTabs != null && mTabs.containsKey(tabTag)) {
			TabInfo tabInfo = mTabs.get(tabTag);
			switchContent(tabInfo.tag, tabInfo.clss, tabInfo.args);
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			if (mCurrentTab != null && mCurrentTab.tag != null) {
				if (mCurrentTab.tag == TAB_OFFERS
						&& ((OffersFragment) mCurrentTab.fragment)
								.onBackKeyPressEvent()) {
					return true;
				} else if (mCurrentTab.tag == TAB_FAVORITE
						&& ((FavoriteOffersFragment) mCurrentTab.fragment)
								.onBackKeyPressEvent()) {
					return true;
				} else {
					if (getSlidingMenu().isMenuShowing()) {
						getSlidingMenu().showContent();
					} else {
						// Show app exit confirmation dialog.
						showCustomDialog(DialogConfig.DIALOG_EXIT_APP);
					}
					return true;
				}
			} else {
				if (getSlidingMenu().isMenuShowing()) {
					getSlidingMenu().showContent();
				} else {
					// Show app exit confirmation dialog.
					showCustomDialog(DialogConfig.DIALOG_EXIT_APP);
				}
				return true;
			}
		} else if (keyCode == KeyEvent.KEYCODE_SEARCH
				&& event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		LogConfig.logd(LOG_TAG, "onDestroy()");
		PreferenceConfig.setAppIsRunning(false, this);
		AnalyticsHelper.stopAnalytics(this);
		PreferenceConfig.setIsAppUpdateChecked(false, this);
		UIUtils.unbindDrawables(findViewById(R.id.content_frame));
		System.gc();
	}

	/** Method to show dialog on the basis of different dialog ids. */
	private void showCustomDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(mHomeActivity);
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_SIGN_UP:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(mDlgMessageResId)
					.setCancelable(false)
					.setNegativeButton(android.R.string.cancel,
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();

								}
							})
					.setPositiveButton(R.string.label_sign_up,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									mHomeActivity.startActivity(new Intent(
											mHomeActivity,
											EnterEmailActivity.class));
								}
							});
			break;

		case DialogConfig.DIALOG_EXIT_APP:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(R.string.msg_app_exit_confirmation)
					.setCancelable(true)
					.setPositiveButton(R.string.label_yes,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									dialog.dismiss();
									mHomeActivity.finish();
									
									// Show the GPS Settings if GPS was switched off
									// initially while launching
									if (PreferenceConfig.isDefaultGPSStatus(getApplicationContext()) != PreferenceConfig.getCurrentGPSStatus(getApplicationContext())) {
										startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
									}
								}
							})
					.setNegativeButton(R.string.label_no,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									// Removing dialog box
									dialog.dismiss();
								}
							});
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		getSlidingMenu().setBehindOffsetRes(R.dimen.slidingmenu_offset);
	}

	/** Method to call app launch trigger network request. */
	private void callAppLaunchTriggerWS() {
		LogConfig.logv(LOG_TAG, "callAppLaunchTriggerWS()");
		String activeTriggerList = PreferenceConfig.getActiveTriggersList(this);
		if (TextUtils.isEmpty(activeTriggerList)) {
			return;
		}
		if (NetworkHelper.isNetworkAvailable(this)
				&& PreferenceConfig.isValidUser(this)
				&& activeTriggerList
						.contains(TriggerConstants.TRIGGER_TYPE_OPEN_APP)) {
			Bundle params = new Bundle();
			params.putByte(
					TriggerConstants.KEY_NAME_BUNDLE_TRIGGER_WORKER_MODE,
					TriggerConstants.WORKER_MODE_TRIGGER_OPEN_APP);
			RequestManager requestManager = RequestManager.from(this);
			requestManager.triggerEvent(DownloadFormat.RETURN_FORMAT_JSON,
					params);
		}
	}

	/**
	 * Method to get the current tab's fragment instance. It can be get globally
	 * in app and we are using it to get the slide activity's context.
	 * 
	 * @return Current tab's Fragment instance.
	 */
	public static Activity getSlidingActivity() {
		return mHomeActivity;
	}

	/**
	 * Method to remove the fragment from {@link FragmentManager} by its tag
	 * name.
	 * 
	 * @param tagName
	 *            Tag name for fragment to remove.
	 */
	public void removeTabFragment(final String tagName) {
		// Destroy loyalty details screen if exists.
		FragmentManager fm = mHomeActivity.getSupportFragmentManager();
		Fragment loyaltyDetailFrag = fm.findFragmentByTag(tagName);
		if (loyaltyDetailFrag != null) {
			FragmentTransaction ft = fm.beginTransaction();
			ft.remove(loyaltyDetailFrag);
			ft.commit();
		}
		if (mTabs != null && mTabs.containsKey(tagName)) {
			mTabs.remove(mTabs.get(tagName));
		}
		mHomeActivity.getSupportFragmentManager().executePendingTransactions();
	}

	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		LogConfig.logv(LOG_TAG, "onNewIntent()");
		handleNotificationClick(intent);
	}

	/** Method to handle push notification clicks. */
	private void handleNotificationClick(final Intent intent) {
		Bundle extras = intent.getExtras();
		if (extras != null) {
			if (extras.containsKey(KEY_EXTRA_STRING_NOTIFICATION_CLICKED)) {
				LogConfig.logv(LOG_TAG,
						"handleNotificationClick(): Notification clicked");
				PreferenceConfig.setIsLaunchFromNotification(true,
						HomeActivity.this);
				PreferenceConfig.setPersonalOffersTimestamp(0L,
						HomeActivity.this); // Mentis:�0021507
				PreferenceConfig
						.setCommonOffersTimestamp(0L, HomeActivity.this); // Mentis:�0021507
				/*
				 * Mentis:�0021507: if
				 * (PreferenceConfig.getLaunchScreenFromNotification
				 * (HomeActivity.this)
				 * .equalsIgnoreCase(OfferNotificationType.PERSONAL_OFFER)) {
				 * PreferenceConfig.setPersonalOffersTimestamp(0L,
				 * HomeActivity.this); } else {
				 * PreferenceConfig.setCommonOffersTimestamp(0L,
				 * HomeActivity.this); }
				 */
			} else {
				LogConfig.logv(LOG_TAG,
						"handleNotificationClick(): Notification Not clicked");
			}
		}
	}
}
