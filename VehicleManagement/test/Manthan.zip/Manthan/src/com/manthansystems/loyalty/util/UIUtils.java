/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import java.lang.ref.SoftReference;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.ui.HomeActivity;

/**
 * An assortment of UI helpers.
 */
public class UIUtils {

	private static StyleSpan sBoldSpan = new StyleSpan(Typeface.BOLD);

	/**
	 * Populate the given {@link TextView} with the requested text, formatting
	 * through {@link Html#fromHtml(String)} when applicable. Also sets
	 * {@link TextView#setMovementMethod} so inline links are handled.
	 */
	public static void setTextMaybeHtml(TextView view, String text) {
		if (TextUtils.isEmpty(text)) {
			view.setText("");
			return;
		}
		if (text.contains("<") && text.contains(">")) {
			view.setText(Html.fromHtml(text));
			view.setMovementMethod(LinkMovementMethod.getInstance());
		} else {
			view.setText(text);
		}
	}

	/**
	 * Given a snippet string with matching segments surrounded by curly braces,
	 * turn those areas into bold spans, removing the curly braces.
	 */
	public static Spannable buildStyledSnippet(String snippet) {
		final SpannableStringBuilder builder = new SpannableStringBuilder(
				snippet);

		// Walk through string, inserting bold snippet spans
		int startIndex = -1, endIndex = -1, delta = 0;
		while ((startIndex = snippet.indexOf('{', endIndex)) != -1) {
			endIndex = snippet.indexOf('}', startIndex);

			// Remove braces from both sides
			builder.delete(startIndex - delta, startIndex - delta + 1);
			builder.delete(endIndex - delta - 1, endIndex - delta);

			// Insert bold style
			builder.setSpan(sBoldSpan, startIndex - delta,
					endIndex - delta - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

			delta += 2;
		}

		return builder;
	}

	private static final int BRIGHTNESS_THRESHOLD = 130;

	/**
	 * Calculate whether a color is light or dark, based on a commonly known
	 * brightness formula.
	 *
	 * @see {@literal http://en.wikipedia.org/wiki/HSV_color_space%23Lightness}
	 */
	public static boolean isColorDark(int color) {
		return ((30 * Color.red(color) + 59 * Color.green(color) + 11 * Color
				.blue(color)) / 100) <= BRIGHTNESS_THRESHOLD;
	}

	public static boolean isHoneycomb() {
		// Can use static final constants like HONEYCOMB, declared in later
		// versions
		// of the OS since they are inlined at compile time. This is guaranteed
		// behavior.
		return Build.VERSION.SDK_INT >= 11;// Build.VERSION_CODES.HONEYCOMB;
	}

	public static boolean isTablet(Context context) {
		return (context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE;
	}

	public static boolean isHoneycombTablet(Context context) {
		return isHoneycomb() && isTablet(context);
	}

	public static boolean isAmazonDevice() {
		return android.os.Build.MANUFACTURER.equalsIgnoreCase("Amazon");
	}

	public static long getCurrentTime(final Context context) {
		return System.currentTimeMillis();
	}

	public static Drawable getIconForIntent(final Context context, Intent i) {
		PackageManager pm = context.getPackageManager();
		List<ResolveInfo> infos = pm.queryIntentActivities(i,
				PackageManager.MATCH_DEFAULT_ONLY);
		if (infos.size() > 0) {
			return infos.get(0).loadIcon(pm);
		}
		return null;
	}

	/**
	 * Method to set the custom font to supplied {@link View} with appropriate
	 * attribute set.
	 */
	public static void setCustomFont(View textViewOrButton, Context ctx,
			AttributeSet attrs, int[] attributeSet, int fontId) {
		TypedArray a = ctx.obtainStyledAttributes(attrs, attributeSet);
		String customFont = a.getString(fontId);
		setCustomFont(textViewOrButton, ctx, customFont);
		a.recycle();
	}

	/**
	 * Method to set the custom font to supplied {@link View} with appropriate
	 * attribute set.
	 */
	public static boolean setCustomFont(View textViewOrButton, Context ctx,
			String asset) {
		if (TextUtils.isEmpty(asset)) {
			return false;
		}
		Typeface tf = null;
		try {
			tf = getFont(ctx, asset);
			if (textViewOrButton instanceof TextView) {
				((TextView) textViewOrButton).setTypeface(tf);
			} else if (textViewOrButton instanceof Button) {
				((Button) textViewOrButton).setTypeface(tf);
			} else if (textViewOrButton instanceof EditText) {
				((EditText) textViewOrButton).setTypeface(tf);
			}
		} catch (Exception e) {
			Log.e("UiUtils", "Could not get typeface: " + asset, e);
			return false;
		}

		return true;
	}

	private static final Hashtable<String, SoftReference<Typeface>> fontCache = new Hashtable<String, SoftReference<Typeface>>();

	/**
	 * Method to get the custom font from cache if exists or create new instance
	 * and cache the newly created font to future use.
	 */
	public static Typeface getFont(Context c, String name) {
		synchronized (fontCache) {
			if (fontCache.get(name) != null) {
				SoftReference<Typeface> ref = fontCache.get(name);
				if (ref.get() != null) {
					return ref.get();
				}
			}

			Typeface typeface = Typeface.createFromAsset(c.getAssets(),
					"fonts/" + name);
			fontCache.put(name, new SoftReference<Typeface>(typeface));

			return typeface;
		}
	}

	/**
	 * Convert the price value to $##.## format.
	 * 
	 * @param originalValue
	 *            actual price value that needs to converted in above mentioned
	 *            format.
	 * @param roundChars
	 *            digits after decimal.
	 * @return formatted price string.
	 */
	public static String getPreetyPrice(String originalValue,
			final int roundChars) {
		if (TextUtils.isEmpty(originalValue)) {
			return "$0.00";
		} else {
			try {
				originalValue = originalValue.replace('$', ' ').trim();
				originalValue = originalValue.replace(",", "").trim();
				DecimalFormat twoDForm = new DecimalFormat("#.00");
				twoDForm.setMinimumIntegerDigits(1);
				String doubleVal = twoDForm.format(Double
						.parseDouble(originalValue));
				double val = Double.valueOf(doubleVal);
				if (val <= 0) {
					originalValue = "$0.00";
				} else {
					return "$" + doubleVal;
				}
			} catch (Exception e) {
				originalValue = "$0.00";
			}
		}
		return originalValue;
	}

	/**
	 * Method to hide the virtual keyboard with respect to the {@link EditText}.
	 */
	public static void hideKeyboard(final Context context,
			final EditText editText) {
		InputMethodManager imm = (InputMethodManager) context
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
		((Activity) context).getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
	}

	/** Call this method to unbind the drawable attached with the given View. */
	public static void unbindDrawables(View view) {
		if (view != null) {
			if (view.getBackground() != null) {
				view.getBackground().setCallback(null);
			}
			if (view instanceof ViewGroup && !(view instanceof AdapterView)) {
				for (int i = 0; i < ((ViewGroup) view).getChildCount(); ++i) {
					unbindDrawables(((ViewGroup) view).getChildAt(i));
				}
				((ViewGroup) view).removeAllViews();
			}
		}
	}

	/**
	 * Method to set the title of current screen and also set the custom home
	 * icon if needed or the default app icon will be shown. <br>
	 * <b>Note:</b>
	 * <ul>
	 * <li>Case 1: Setting TRUE to both <code>showStandardHomeIcon</code> and
	 * <code>showCustomHomeIcon</code> params will also show the standard home
	 * icon.<br>
	 * <li>Case 2: Setting both params to FALSE will show the Sliding Menu icon
	 * on action bar.
	 * </ul>
	 * 
	 * @param titleResId
	 *            Resource id for Actionbar title.
	 * @param showStandardHomeIcon
	 *            True to show standard home icon on actionbar.
	 * @param showCustomHomeIcon
	 *            True to show custom home icon on actionbar.
	 * @param activity
	 *            Activity instance.
	 */
	public static void setTitleView(final int titleResId,
			final boolean showStandardHomeIcon,
			final boolean showCustomHomeIcon,
			final boolean showCustomHomeMoreIcon,
			SherlockFragmentActivity activity) {
		String title = activity.getResources().getString(titleResId);
		setTitleView(title, showStandardHomeIcon, showCustomHomeIcon,
				showCustomHomeMoreIcon, activity);
	}

	/**
	 * Method to set the title of current screen and also set the custom home
	 * icon if needed or the default app icon will be shown. <br>
	 * <b>Note:</b>
	 * <ul>
	 * <li>Case 1: Setting TRUE to both <code>showStandardHomeIcon</code> and
	 * <code>showCustomHomeIcon</code> params will also show the standard home
	 * icon.<br>
	 * <li>Case 2: Setting both params to FALSE will show the Sliding Menu icon
	 * on action bar.
	 * </ul>
	 * 
	 * @param title
	 *            Actionbar title.
	 * @param showStandardHomeIcon
	 *            True to show standard home icon on actionbar.
	 * @param showCustomHomeIcon
	 *            True to show custom home icon on actionbar.
	 * @param activity
	 *            Activity instance.
	 */
	public static void setTitleView(final String title,
			final boolean showStandardHomeIcon,
			final boolean showCustomHomeIcon,
			final boolean showCustomHomeMoreIcon,
			SherlockFragmentActivity activity) {
		activity.getSupportActionBar().setDisplayShowTitleEnabled(false);
		activity.getSupportActionBar().setDisplayShowHomeEnabled(
				showStandardHomeIcon);
		activity.getSupportActionBar().setDisplayShowCustomEnabled(true);
		LayoutInflater inflater = (LayoutInflater) activity
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		View titleView = inflater.inflate(R.layout.actionbar_title, null);
		final TextView textView = (TextView) titleView
				.findViewById(R.id.textView_actionbar_title);
		final ImageView dummyView = (ImageView) titleView
				.findViewById(R.id.dummy_view);
		textView.setText(title);
		textView.setGravity(Gravity.CENTER);
       
		if (title.equalsIgnoreCase(HomeActivity.TAB_OFFERS)
				|| title.equalsIgnoreCase(HomeActivity.TAB_MYOFFERS)
				|| title.equalsIgnoreCase(HomeActivity.TAB_LOYALTY_CARD)
				|| title.equalsIgnoreCase(HomeActivity.TAB_ABOUT_US)
				|| title.equalsIgnoreCase(activity.getResources().getString(
						R.string.coupon_description))
				|| title.equalsIgnoreCase(activity.getResources().getString(
						R.string.promo_coupon_description))
				|| title.equalsIgnoreCase(activity.getResources().getString(
						R.string.label_filter))) {

			dummyView.setVisibility(View.GONE);

		} else {
			dummyView.setVisibility(View.INVISIBLE);
		}

		if (showStandardHomeIcon) {
			titleView.findViewById(R.id.ImageView_Slide_Menu_icon)
					.setVisibility(View.GONE);
		} else {
			if (showCustomHomeIcon) {
				activity.getSupportActionBar().setDisplayShowHomeEnabled(false);
				((ImageView) titleView
						.findViewById(R.id.ImageView_Slide_Menu_icon))
						.setImageDrawable(activity.getResources().getDrawable(
								R.drawable.ic_home_custom));

			} else {
				titleView.findViewById(R.id.ImageView_Slide_Menu_icon)
						.setVisibility(View.GONE);
				dummyView.setVisibility(View.INVISIBLE);
			}
			if (showCustomHomeMoreIcon) {		
				activity.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
				((ImageView) titleView
						.findViewById(R.id.ImageView_Slide_Menu_more_icon))
						.setVisibility(View.VISIBLE);
				
			}
		}

		activity.getSupportActionBar().setCustomView(titleView);

	}

	/** Method to get the screen orientation. */
	public static int getScreenOrientation(Activity activity) {
		Display getOrient = activity.getWindowManager().getDefaultDisplay();
		int orientation = Configuration.ORIENTATION_UNDEFINED;
		if (getOrient.getWidth() == getOrient.getHeight()) {
			orientation = Configuration.ORIENTATION_SQUARE;
		} else {
			if (getOrient.getWidth() < getOrient.getHeight()) {
				orientation = Configuration.ORIENTATION_PORTRAIT;
			} else {
				orientation = Configuration.ORIENTATION_LANDSCAPE;
			}
		}
		return orientation;
	}

	/** A method to check Token is of four digits or not. **/
	public static boolean isValidTokenCode(String zipCode) {
		return zipCode.matches("\\d{4}?");
	}

	/**
	 * Given a snippet string with matching segments surrounded by angle braces,
	 * turn those areas into bold spans, removing the angle braces.
	 */
	public static Spanned buildDecorativeSnippet(String snippet,
			String decorations) {
		final SpannableStringBuilder builder = new SpannableStringBuilder(
				snippet);
		if (TextUtils.isEmpty(snippet)) {
			return builder;
		}
		if (!TextUtils.isEmpty(decorations)) {
			decorations = decorations.replace("[", "").replace("]", "");
			if (!TextUtils.isEmpty(decorations)) {
				List<String> array = Arrays.asList(decorations.split(","));
				int size = array.size();
				for (int i = 0; i < size; ++i) {
					String str = array.get(i);
					// take following special approach to make $ sign bold.
					if (str.contains("$")) {
						// Check for dollar sign presence.
						int dollarIndex = str.indexOf('$');
						if (dollarIndex != -1) {
							StringBuilder stringBuilder = new StringBuilder(str);
							stringBuilder.insert(dollarIndex, "\\");
							str = stringBuilder.toString();
						}
					}
					snippet = snippet.replaceAll(str, "<b>" + str + "</b>");
				}
			}
		}
		return Html.fromHtml(snippet);
	}

	/** A method to convert String in to String ArrayList. **/
	public static ArrayList<String> stringToArrayList(String data) {
		List<String> array = new ArrayList<String>();
		if (!TextUtils.isEmpty(data)) {
			data = data.replace("[", "").replace("]", "");
			if (!TextUtils.isEmpty(data)) {
				array = Arrays.asList(data.split(", "));
			}
		}
		return new ArrayList<String>(array);
	}

	/**
	 * So if you want something unique to the device itself, TM.getDeviceId()
	 * should be sufficient. But it might be useful to hash 1 or more of these
	 * identifiers, so that the string is still virtually unique to the device,
	 * but does not explicitly identify the user's actual device. For example,
	 * using String.hashCode(), combined with a UUID.
	 * 
	 * @param context
	 * @return String.hashCode() combined with a UUID.
	 */
	public static String getDeviceUniqueId(Context context) {
		final TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);

		final String tmDevice, tmSerial, androidId;
		tmDevice = "" + tm.getDeviceId();
		tmSerial = "" + tm.getSimSerialNumber();
		androidId = ""
				+ android.provider.Settings.Secure.getString(
						context.getContentResolver(),
						android.provider.Settings.Secure.ANDROID_ID);
		UUID deviceUuid = new UUID(androidId.hashCode(),
				((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
		return deviceUuid.toString();
	}

	/**
	 * To check if device is having large screen.
	 */
	public static boolean isLargeScreenDevice(Resources resource) {
		int screenSize = resource.getConfiguration().screenLayout
				& Configuration.SCREENLAYOUT_SIZE_MASK;
		if (screenSize == Configuration.SCREENLAYOUT_SIZE_XLARGE
				|| screenSize == Configuration.SCREENLAYOUT_SIZE_LARGE) {
			return true;
		} else {
			return false;
		}
	}

	/** Method to calculate the {@link TimeZone} offset. */
	public static double getUTCTimeOffset() {
		TimeZone tz = TimeZone.getDefault();
		Date now = new Date();
		double offsetFromUtc = tz.getOffset(now.getTime()) / 1000;
		offsetFromUtc = (double) offsetFromUtc / (double) 60;
		offsetFromUtc = (double) offsetFromUtc / (double) 60;
		return offsetFromUtc;
	}

	/**
	 * Method to get the {@link Drawable} instance to set as list row background
	 * gradient color.
	 */
	public static Drawable getListRowBgGradientDrawable(final View view) {
		ShapeDrawable.ShaderFactory sf = new ShapeDrawable.ShaderFactory() {
			@Override
			public Shader resize(int width, int height) {
				LinearGradient lg = new LinearGradient(0, 0, 0,
						view.getHeight(), new int[] {
								Color.parseColor("#F4F5F5"),
								Color.parseColor("#F1F1F2"),
								Color.parseColor("#EDEEEF"),
								Color.parseColor("#EBECED") }, new float[] { 0,
								0.35f, 0.75f, 1 }, Shader.TileMode.REPEAT);
				return lg;
			}
		};
		PaintDrawable p = new PaintDrawable();
		p.setShape(new RectShape());
		p.setShaderFactory(sf);
		p.setCornerRadius(1.0f);
		return p;
	}

	/**
	 * Method to get the {@link Drawable} instance to set as list selected row
	 * background gradient color.
	 */
	public static Drawable getListSelectedRowBgGradientDrawable(final View view) {
		ShapeDrawable.ShaderFactory sf = new ShapeDrawable.ShaderFactory() {
			@Override
			public Shader resize(int width, int height) {
				LinearGradient lg = new LinearGradient(0, 0, 0,
						view.getHeight(), new int[] {
								Color.parseColor("#E3E4E5"),
								Color.parseColor("#DADBDD"),
								Color.parseColor("#D0D1D3"),
								Color.parseColor("#CBCCCE") }, new float[] { 0,
								0.35f, 0.75f, 1 }, Shader.TileMode.REPEAT);
				return lg;
			}
		};
		PaintDrawable p = new PaintDrawable();
		p.setShape(new RectShape());
		p.setShaderFactory(sf);
		p.setCornerRadius(1.0f);
		return p;
	}

	/**
	 * What is checksum or check digit or barcode validation? Ans: A check digit
	 * is a form of redundancy check used for error detection, the decimal
	 * equivalent of a binary checksum. It consists of a single digit computed
	 * from the other digits in the message. With a check digit, one can detect
	 * simple errors in the input of a series of digits, such as a single
	 * mistyped digit or some permutations of two successive digits. for more
	 * details: http://en.wikipedia.org/wiki/Check_digit
	 */
	public static boolean isValidBarcode(String barcode) {
		// size of the barcode digits (possiblly 12 or 13)
		int size = barcode.length();
		// integer array creation, it will hold the individual barcode digits
		int barcodeDigits[] = new int[size];
		// loop index variable
		int i;
		// placing each barcode character from barcode string to this newly
		// allocated integer array
		for (i = 0; i < size; i++) {
			barcodeDigits[i] = barcode.charAt(i) - 48; // - 48 means; ascii to
														// integer conversion
		}
		// few required variables
		int evenSum = 0;
		int oddSum = 0;
		int totalSum = 0;
		int reminder = 0;
		int checkDigit = 0;

		// adding even digits after multiplying by 3
		for (i = size - 2; i >= 0; i -= 2) {
			evenSum = evenSum + barcodeDigits[i] * 3;
		}
		// adding odd digits
		for (i = size - 3; i >= 0; i -= 2) {
			oddSum = oddSum + barcodeDigits[i];
		}
		// further calculation for getting check digit
		totalSum = evenSum + oddSum;
		reminder = totalSum % 10;
		checkDigit = reminder != 0 ? (10 - reminder) : reminder;
		// return true if valid barcode
		if (checkDigit == barcodeDigits[size - 1]) {
			return true;
		}
		// return false if invalid barcode
		return false;
	}

	public static String toTitleCase(String givenString) {
		givenString = givenString.toLowerCase();
		String[] arr = givenString.split(" ");
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < arr.length; i++) {
			sb.append(Character.toUpperCase(arr[i].charAt(0)))
					.append(arr[i].substring(1)).append(" ");
		}
		return sb.toString().trim();
	}
}
