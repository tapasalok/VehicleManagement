/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.app.SherlockListFragment;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.data.provider.DatabaseProvider;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.model.BaseViewHolder;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.ViewHolderOfferList;
import com.manthansystems.loyalty.model.ViewHolderPromoOfferList;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.phone.OfferDetailActivity;
import com.manthansystems.loyalty.ui.phone.OfferDetailActivity.OfferDetailIntentKey;
import com.manthansystems.loyalty.ui.widget.RefreshableListView;
import com.manthansystems.loyalty.ui.widget.RefreshableListView.OnUpdateTask;
import com.manthansystems.loyalty.util.AnalyticsHelper;
import com.manthansystems.loyalty.util.BitmapManager;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.FavoriteOffersWorker;

/**
 * A class to display the favorite offers listing. It extends {@link SherlockListFragment}.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class FavoriteOffersFragment extends SherlockListFragment  implements
		LoaderManager.LoaderCallbacks<Cursor>, OnRequestFinishedListener {

	private final String LOG_TAG = "FavoriteOffersFragment";
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.FavoriteOffersFragment#RequestId";
	
	private ViewGroup mView;
	private SectionAdapter mSectionAdapter;
	private Handler mHandler;
    private BitmapManager mBitmapManager;
    private Bundle mResponseBundle;
    private RequestManager mRequestManager;
    
	private int mRequestId = -1;
	private int mSectionGroupColumn;
	private boolean mShowProgressBar = false;
    private String mErrorMessage;
    private String mDialogTitle;
    private SparseArray<Coupon> mFavoriteCouponArray = new SparseArray<Coupon>();
    /** To check if app control is coming from offer details screen or not.*/
    private boolean mIsComingFromOfferDetailsScreen;
    /** To check if no network case occurs or not.*/
    private boolean mIsNoNetworkCaseOccurs = false;
    /** To check if favorite icon is clicked or not.*/
    private boolean mIsFavoriteClicked = false;
    
    private AlertDialog mAlertDialog;
    
    private RefreshableListView mListView;
	private TextView mTextViewTapToRefresh;
	
	private EditText mEditTextSearch;
	private boolean mSearchResultShowing = false;
	/** Get the status TURE if search result is showing by keypress search event or else
	 * get FALSE. <br><br>Note: The basic intent of using this method is to avoid showing the
	 * <code>"No Offers Found"</code> message while offer search via keypress event
	 * of search text box.
	 */
	private boolean mKeyPressSearchResultShowing = false;
    
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mRequestManager = RequestManager.from(getActivity());
		mHandler = new Handler();
		UIApplication app = (UIApplication) getActivity().getApplication();
    	mBitmapManager = app.getBitmapManagerInstance(getActivity());
		if (savedInstanceState != null) {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
		}
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_pulldown_list, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
        mSectionAdapter = new SectionAdapter(getActivity(), null,
        		R.layout.list_header, getSectionGroupColumn());
        mListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		mListView.setAdapter(mSectionAdapter);	
		mListView.setOnUpdateTask(new OnUpdateTask() {
			@Override
			public void onUpdateStart() {
				callSyncFavoriteOffersWS();
			}
			
			@Override
			public void updateBackground() {
			}
			
			@Override
			public void updateUI() {
			}
		});
		AnalyticsHelper.sendMyFavoriteTabClickedAnalytics(getActivity());
	}
	
	@Override
	public void onSaveInstanceState(final Bundle outState) {
		outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		super.onSaveInstanceState(outState);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		// un-register sliding menu open listener.
		((HomeActivity)getActivity()).getSlidingMenu().setOnOpenListener(null);
		
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(FavoriteOffersFragment.this);
		}
		if (!mIsComingFromOfferDetailsScreen) {
			getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST);
			getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST);
			
			// reset the search status once again, though it is also resetting from
			// onLoadFinished() method of search result query completion.
			mSearchResultShowing = false;
			// set empty text at search text box
			mEditTextSearch.setText("");
		}
		dismissActiveDialog();
		// Call to hide list refresh animation, though refresh would done.
		listRefreshed();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		// register sliding menu open listener to hide the vkeyboard if open.
		((HomeActivity)getActivity()).getSlidingMenu().setOnOpenListener(onSlidingMenuOpenListener);
		
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(FavoriteOffersFragment.this);
            } else {
                mRequestId = -1;
            }
        }
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
		if (!mIsComingFromOfferDetailsScreen || PreferenceConfig.isOffersTimestampExpired(getActivity())) {
			LogConfig.logv(LOG_TAG, "onResume(): call callSyncFavoriteOffersWS()");
	        callSyncFavoriteOffersWS();
		}
		mIsComingFromOfferDetailsScreen = false;
	}
	
    @Override
	public void onDestroy() {
	    super.onDestroy();
	    if (mView != null) {
	    	UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_pulldown_list));
	    	System.gc();
	    }
    }

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		int itemPosition = position - getListView().getHeaderViewsCount();
		LogConfig.logv(LOG_TAG, "onListItemClick() " + itemPosition);
		final Object obj = mSectionAdapter.getItem(itemPosition);
    	if (obj instanceof Cursor) { // Normal row is clicked.
    		mIsComingFromOfferDetailsScreen = true;
    		mSectionAdapter.setSelectedPosition(itemPosition);
			mSectionAdapter.notifyDataSetChanged();
			Cursor c = (Cursor) obj;
    		final Intent intent = new Intent(getActivity(), OfferDetailActivity.class);
			intent.putExtra(OfferDetailIntentKey.CURRENTLY_SELECTED_ITEM, itemPosition);
			intent.putExtra(OfferDetailIntentKey.OFFER_COUNT, c.getCount());
			startActivity(intent);
			AnalyticsHelper.sendOfferClickedAnalytics(getActivity(), 
					c.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN));
			
    	}
	}

	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title.
		UIUtils.setTitleView(R.string.label_tab_favorite, false, true, true, getSherlockActivity());
		View view = ((SherlockFragmentActivity) getActivity()).getSupportActionBar().getCustomView();
		if (view != null) {
			view.findViewById(R.id.ImageView_Slide_Menu_icon).setOnClickListener(
					new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					((BaseSlidingActivity) getActivity()).getSlidingMenu().showMenu(true);
				}
			});
		}
		mListView = (RefreshableListView) mView.findViewById(android.R.id.list);
		mTextViewTapToRefresh = (TextView) mView.findViewById(R.id.TextView_tap_to_refresh);
		mTextViewTapToRefresh.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				callSyncFavoriteOffersWS();
			}
		});
		
		// Hide the location button. Not needed in this screen.
		mView.findViewById(R.id.imageButton_location).setVisibility(View.GONE);
		
		mEditTextSearch = (EditText) mView.findViewById(R.id.editText_search_text);
		mEditTextSearch.setOnEditorActionListener(new EditText.OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (event != null && event.getAction() != KeyEvent.ACTION_DOWN) {
			        return false;
			    } else if (actionId == EditorInfo.IME_ACTION_SEARCH
		    		|| actionId == EditorInfo.IME_ACTION_DONE 
		            || actionId == EditorInfo.IME_NULL
			        || event == null
			        || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
			    	mKeyPressSearchResultShowing = false;
			    	UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
					if (TextUtils.isEmpty(mEditTextSearch.getText().toString().trim())) {
						mDialogTitle = getResources().getString(R.string.app_name);
						mErrorMessage = getResources().getString(R.string.dialog_msg_enter_search_text);
						showDialog(DialogConfig.DIALOG_ERROR);
						return true;
					} else if(mEditTextSearch.getText().toString().trim().length() > 40) {
						mDialogTitle = getResources().getString(R.string.app_name);
						mErrorMessage = getResources().getString(R.string.dialog_msg_search_text_limit);
						showDialog(DialogConfig.DIALOG_ERROR);
						return true;
					}
					return true;
			    }
				return false;
			}
		});
		mEditTextSearch.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// Do nothing
			}
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// Do nothing
			}
			@Override
			public void afterTextChanged(Editable s) {
				final String searchText = s.toString().trim();
				if (TextUtils.isEmpty(searchText)) {
					mKeyPressSearchResultShowing = false;
					// reset search
					if (mSearchResultShowing) {
						// reset the search status once again, though it is also resetting from
						// onLoadFinished() method.
						mSearchResultShowing = false;
						
						// re-query the favorite offers list from cache.
						queryFavoriteOffersFromDB();
					}
				} else {
					searchOffersOnKeyPress(mEditTextSearch.getText().toString().trim());
				}
			}
		});
		
		final LinearLayout searchIcon = (LinearLayout) mView.findViewById(R.id.search_ic_container);
		searchIcon.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mKeyPressSearchResultShowing = false;
				UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
				if (TextUtils.isEmpty(mEditTextSearch.getText().toString().trim())) {
					mDialogTitle = getResources().getString(R.string.app_name);
					mErrorMessage = getResources().getString(R.string.dialog_msg_enter_search_text);
					showDialog(DialogConfig.DIALOG_ERROR);
					return;
				} else if(mEditTextSearch.getText().toString().trim().length() > 40) {
					mDialogTitle = getResources().getString(R.string.app_name);
					mErrorMessage = getResources().getString(R.string.dialog_msg_search_text_limit);
					showDialog(DialogConfig.DIALOG_ERROR);
					return;
				}
			}
		});
		
		final RelativeLayout rootView = (RelativeLayout) mView.findViewById(R.id.root_view_pulldown_list);
		rootView.setOnTouchListener(mOnTouchListenerScreen);
	}
	
	/**
	 * A list adapter class for favorite offers listing that extends {@link CursorAdapter}
	 *  via {@link SectionCursorAdapter}.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	private class SectionAdapter extends SectionCursorAdapter {

		private Activity mActivity;
		private int mPosition;
		private int mSelectedPosition = -1;
		private int mImageWidth;
		private int mImageHeight;

		/** Parameterized constructor. */
		public SectionAdapter(Context context, Cursor c, int headerLayout,
				int groupColumn) {
			super(context, c, headerLayout, groupColumn);
			mActivity = (Activity) context;
			mBitmapManager.setPlaceholder(BitmapFactory.decodeResource(
					context.getResources(), R.drawable.background_trans));
			mImageWidth = context.getResources().getInteger(
					R.integer.image_width);
			mImageHeight = context.getResources().getInteger(
					R.integer.image_height);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			mPosition = position;
			final Cursor c = (Cursor) getItem(position);
			final int cursorPos = getSectionForPosition(position);
			c.moveToPosition(cursorPos);
			final int isMarketingMessage = c.getInt(CouponDao.CONTENT_IS_MARKETING_MESSAGE_COLUMN);
			if (isMarketingMessage == CouponDao.FLAG_VALUE_MARKETING_MESSAGE) {
				if ((convertView == null) || !(convertView.getTag() instanceof PromoOfferListViewHolder)) {
					convertView = mActivity.getLayoutInflater().inflate(
							R.layout.row_for_promo_offers, null);
					final PromoOfferListViewHolder viewHolder = new PromoOfferListViewHolder(convertView);
					convertView.setTag(viewHolder);
				}
			} else {
				if ((convertView == null) || !(convertView.getTag() instanceof OfferListViewHolder)) {
					convertView = mActivity.getLayoutInflater().inflate(
							R.layout.row_for_offers, null);
					final OfferListViewHolder viewHolder = new OfferListViewHolder(convertView);
					convertView.setTag(viewHolder);
				}
			}
			return super.getView(position, convertView, parent);
		}

		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {
			return null;
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			if (view != null) {
				final Cursor c = cursor;
				final int mapCursorPos = getSectionForPosition(mPosition);
				c.moveToPosition(mapCursorPos);
				final int offerId = c.getInt(CouponDao.CONTENT_COUPON_ID_COLUMN);
				final String offerTitle = c.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN);
				final String couponImageUrl = c.getString(CouponDao.CONTENT_COUPON_IMAGE_URL_COLUMN);
				
				final BaseViewHolder holder = (BaseViewHolder) view.getTag();
				holder.setRowPosition(mPosition, mSelectedPosition);
				holder.populateView(c, view);
				holder.getFavoriteIconView().setBackgroundResource(R.drawable.ic_star_selected);
				holder.getFavoriteIconView().setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						mIsFavoriteClicked = true;
						PreferenceConfig.setFavoriteOfferCount(
								PreferenceConfig.getFavoriteOfferCount(getActivity()) - 1, getActivity());
						final String whereClause = CouponDao.WHERE_CLAUSE_COUPON_ID + offerId;
						final ContentValues contentValues = new ContentValues();
						contentValues.put(CouponDao.COUPON_FAVORITE_FLAG, CouponDao.FLAG_VALUE_FAVOURITE_DISABLE);
						contentValues.put(DatabaseProvider.KEY_SQL_INJECT, true);
						// Update favourite flag in Coupon table.
						getActivity().getContentResolver().update(CouponDao.CONTENT_URI, 
							contentValues, whereClause, null);
						// following task is independent from list rendering so we can do it inside non-ui thread.
						new Thread(new Runnable() {
							@Override
							public void run() {
								// Delete this coupon from table with Favorite coupon chooser.
								getActivity().getContentResolver().delete(CouponDao.CONTENT_URI,
										CouponDao.WHERE_CLAUSE_COUPON_CHOOSER + 
										DatabaseConfig.DB_OFFER_TYPE_FAVORITE + " AND " +
										CouponDao.WHERE_CLAUSE_COUPON_ID + offerId, null);
								AnalyticsHelper.sendFavoriteStarClickedAnalytics(getActivity(), offerTitle, false);
							}
						}).start();
					}
				});
				
				if (holder.getOfferIconView() != null) {
					mBitmapManager.loadBitmap(couponImageUrl,
							holder.getOfferIconView(), mImageWidth, mImageHeight);
				}
			}
		}

		/** {@inheritDoc} */
		public String getGroupCustomFormat(Object obj) {
			return (String) obj;
		}
		

		/** Setter method to set the current selected position in list. */
		public void setSelectedPosition(final int inPosition) {
			mSelectedPosition = inPosition;
		}
	}
	
	/**
	 * Get the section group column name for list, the groups will be
	 * created based on this column name.
	 */
	private int getSectionGroupColumn() {
		return mSectionGroupColumn;
	}
	
	/**
	 * A view holder class that extends {@link BaseViewHolder} which holds the view of
	 * {@link Coupon} list row layout.
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 *
	 */
	private static class OfferListViewHolder extends ViewHolderOfferList {
		public OfferListViewHolder(View view) {
			super(view);
		}
	}
	
	/**
	 * A view holder class that extends {@link BaseViewHolder} which holds the view of
	 * {@link Coupon} list row layout for Promotioal type coupons.
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 *
	 */
	private static class PromoOfferListViewHolder extends ViewHolderPromoOfferList {
		public PromoOfferListViewHolder(View view) {
			super(view);
		}
	}

	@Override
	public Loader<Cursor> onCreateLoader(int token, Bundle arg1) {
		if (token == DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST) {
			return new CursorLoader(getActivity(),
				CouponDao.CONTENT_URI_FAVORITE, null, CouponDao.WHERE_CLAUSE_COUPON_CHOOSER +
				DatabaseConfig.DB_OFFER_TYPE_FAVORITE,
        		null, CouponDao._ID + " ASC");
		} else if (token == DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST) {
			String searchText = mEditTextSearch.getText().toString().trim();
			searchText = searchText.replace("'", "''").replace("\"", "''");
			return new CursorLoader(getActivity(), CouponDao.CONTENT_URI, null,
				"(" + CouponDao.COUPON_NAME + " like '%" + searchText + "%' OR "
				+ CouponDao.COUPON_TYPE + " like '%" + searchText + "%' OR "
				+ CouponDao.COUPON_DESCRIPTION + " like '%" + searchText + "%') AND "
				+ CouponDao.WHERE_CLAUSE_COUPON_CHOOSER + DatabaseConfig.DB_OFFER_TYPE_FAVORITE,
				null, null);
		}
		return null;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		// Swap the new cursor in.  (The framework will take care of closing the
        // old cursor once we return.)
		if (getActivity() == null) {
            return;
        }
		final int token = loader.getId();
		ProgressBarHelper.dismissProgressBar(mHandler);
		prepareFavoriteOfferModelArray(cursor);
		mSectionAdapter.swapCursor(cursor);
		if (cursor != null) {
			LogConfig.logd(LOG_TAG, "  onLoadFinished() " + cursor.getCount());
			if (token == DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST) {
				getListView().setVisibility(View.VISIBLE);
				if (cursor.getCount() > 0) {
					getListView().setSelectionAfterHeaderView();
				} else if (cursor.getCount() == 0 && !mIsNoNetworkCaseOccurs && !mIsFavoriteClicked) {
					mHandler.post(new Runnable() {
	
						@Override
						public void run() {
							showDialog(DialogConfig.DIALOG_NO_FAVORITE_OFFERS);
						}
					});
				}
				mIsNoNetworkCaseOccurs = false;
				mIsFavoriteClicked = false;
				// Show tap to refresh option instead of list if no data.
				if (mTextViewTapToRefresh != null) {
					if (cursor.getCount() <= 0) {
						mTextViewTapToRefresh.setVisibility(View.VISIBLE);
					} else {
						mTextViewTapToRefresh.setVisibility(View.GONE);
					}
				}
			} else if (token == DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST) {
				if (cursor != null) {
					LogConfig.logd(LOG_TAG, "count is " + cursor.getCount());
					if (cursor.getCount() <= 0 && !mKeyPressSearchResultShowing) {
						mHandler.post(new Runnable() {
							
							@Override
							public void run() {
								mDialogTitle = getResources().getString(R.string.app_name);
								mErrorMessage = getResources().getString(R.string.msg_no_result_found);
								showDialog(DialogConfig.DIALOG_ERROR);
							}
						});
					}
				}
				mSectionAdapter.swapCursor(cursor);
				if (cursor != null && cursor.getCount() > 0) {
					getListView().setSelectionAfterHeaderView();
				}
				getListView().setVisibility(View.VISIBLE);
				ProgressBarHelper.dismissProgressBar(mHandler);
				// set if search result is showing.
				mSearchResultShowing = true;
			}
        } else {
        	// Show tap to refresh option instead of list if no data.
			if (mTextViewTapToRefresh != null) {
				mTextViewTapToRefresh.setVisibility(View.VISIBLE);
			}
        }
		
		// Call to notify that list is refreshed via list pull down event.
		listRefreshed();
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		// This is called when the last Cursor provided to onLoadFinished()
        // above is about to be closed.  We need to make sure we are no
        // longer using it.
		mSectionAdapter.swapCursor(null);
	}
	
	/** Make server request to sync favorite Offers. */
	private void callSyncFavoriteOffersWS() {
		LogConfig.logv(LOG_TAG, "callSyncFavoriteOffersWS() ");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mIsNoNetworkCaseOccurs = true;
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mDialogTitle = getResources().getString(R.string.network_not_available_title);
			queryFavoriteOffersFromDB();
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		
		// prepare the favorite offer ids.
		prepareFavoriteOfferIds();
		
		mRequestManager.addOnRequestFinishedListener(FavoriteOffersFragment.this);
		ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
				false, mHandler, getActivity());
		Bundle params = new Bundle();
		params.putByte(FavoriteOffersWorker.DOWNLOAD_MODE,
				PreferenceConfig.getDownloadMode(getActivity()));
		params.putBoolean(FavoriteOffersWorker.FLAG_FAVORITE_OFFER_SYNC_REQUEST, true);
		mRequestId = mRequestManager.getFavoriteOffers(DownloadFormat.RETURN_FORMAT_JSON,
				params);
		
		// reset the search status once again, though it is also resetting from
		// onLoadFinished() method of search result query completion.
		mSearchResultShowing = false;
		
		// set empty text at search text box
		mEditTextSearch.setText("");
		
		// hide virtual keyboard if visible.
		UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
	}
	
	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(FavoriteOffersFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
	
	/**
	 * This runnable will invoke to handle the success state when request
	 * finished.
	 */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				favoriteOffersSyncedDoSomething();
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				queryFavoriteOffersFromDB();
				mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mDialogTitle = getResources().getString(R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
				queryFavoriteOffersFromDB();
			}
		}
	};

	/**
	 * This runnable will invoke to handle the error state when request
	 * finished.
	 */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {

		@Override
		public void run() {
			getListView().setVisibility(View.INVISIBLE);
			queryFavoriteOffersFromDB();
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mDialogTitle = getResources().getString(R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
		}
	};
	
	/** Method to call after favorite offers sync with server process completion. */
	private void favoriteOffersSyncedDoSomething() {
		queryFavoriteOffersFromDB();
	}
	
	/** Method to prepare query to fetch favorite offers from database. */
	private void queryFavoriteOffersFromDB() {
		ProgressBarHelper.dismissProgressBar(mHandler);
		getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST);
		getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST);
		// Load store offers from database
        getLoaderManager().initLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST, null, this);
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			        return true;
				}
				return false;
			}
		});
		
		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mDialogTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_NO_FAVORITE_OFFERS:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.title_sorry)
			.setMessage(R.string.msg_no_favorite_offers)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					((HomeActivity)getActivity()).setCurrentTab(HomeActivity.TAB_OFFERS);
				}
			});
			break;
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
	
	/** Method to prepare favorite offer ids from database. This method must be
	 * called before going for favorite sync. */
	private void prepareFavoriteOfferIds() {
		CursorLoader loader = new CursorLoader(getActivity(), CouponDao.CONTENT_URI,
				new String[] { CouponDao.COUPON_ID },
				CouponDao.WHERE_CLAUSE_COUPON_CHOOSER + DatabaseConfig.DB_OFFER_TYPE_FAVORITE,
				null, null);
		Cursor c = loader.loadInBackground();
		UIApplication app = (UIApplication) getActivity().getApplication();
		ArrayList<Integer> favoriteOfferIds = new ArrayList<Integer>();
		if (c != null && c.getCount() > 0) {
			c.moveToPosition(-1);
			while (c.moveToNext()) {
				favoriteOfferIds.add(c.getInt(0));
			}
		}
		app.setFavoriteOffersIds(favoriteOfferIds);
		if (c != null) {
			c.close();
		}
	}
	
	/** A method to prepare offer model array. **/
	private void prepareFavoriteOfferModelArray(Cursor c) {
		if (mFavoriteCouponArray != null) {
			mFavoriteCouponArray.clear();
			mFavoriteCouponArray = null;
		}
		mFavoriteCouponArray = new SparseArray<Coupon>();
		if (c != null) {
			c.moveToPosition(-1);
			while (c.moveToNext()) {
				try {
					final Coupon coupon = new Coupon();
					coupon.mId = c.getInt(CouponDao.CONTENT_COUPON_ID_COLUMN);
					coupon.mTitle = c.getString(CouponDao.CONTENT_COUPON_NAME_COLUMN);
					coupon.mImageUrl = c.getString(CouponDao.CONTENT_COUPON_IMAGE_URL_COLUMN);
					coupon.mLongDescription = c.getString(CouponDao.CONTENT_COUPON_LONG_DESCRIPTION);
					coupon.mExpiryDate = c.getString(CouponDao.CONTENT_EXPIRY_DATE_COLUMN);
					coupon.mCouponUrl = c.getString(CouponDao.CONTENT_COUPON_URL_COLUMN);
					coupon.mCouponType= c.getString(CouponDao.CONTENT_COUPON_TYPE_COLUMN);
					coupon.mDiscount = c.getString(CouponDao.CONTENT_DISCOUNT_COLUMN);
					coupon.mFavoriteFlag = c.getInt(CouponDao.CONTENT_COUPON_FAVORITE_FLAG_COLUMN);
					coupon.mCouponChooser = c.getInt(CouponDao.CONTENT_COUPON_CHOOSER_COLUMN);
					coupon.mStoreIds = UIUtils.stringToArrayList(c.getString(CouponDao.CONTENT_STORE_IDS_COLUMN));
					coupon.mExpires = c.getInt(CouponDao.CONTENT_EXPIRES_COLUMN);
					coupon.mDecorators = UIUtils.stringToArrayList(c.getString(CouponDao.CONTENT_DECORATORS_COLUMN));
					coupon.mBarcode = c.getString(CouponDao.CONTENT_BARCODE_COLUMN);
					coupon.mBarcodeImageUrl = c.getString(CouponDao.CONTENT_BARCODE_IMAGE_URL_COLUMN);
					coupon.mCouponCode = c.getString(CouponDao.CONTENT_COUPON_CODE_COLUMN);
					coupon.mLargeImageUrl = c.getString(CouponDao.CONTENT_COUPON_LARGE_IMAGE_URL_COLUMN);
					coupon.mIsMarketingMessageFlag = c.getInt(CouponDao.CONTENT_IS_MARKETING_MESSAGE_COLUMN);
					coupon.mDescription = c.getString(CouponDao.CONTENT_COUPON_DESCRIPTION_COLUMN);
					coupon.mRedeemableFlag = c.getInt(CouponDao.CONTENT_REDEEMABLE_FLAG_COLUMN);
					coupon.mUsageType = c.getInt(CouponDao.CONTENT_USAGE_TYPE_COLUMN);
					coupon.mThresholdLimit = c.getInt(CouponDao.CONTENT_REDEEM_THRESHOLD_LIMIT_COLUMN);
					coupon.mExhaustedFlag = c.getInt(CouponDao.CONTENT_EXHAUSTED_FLAG_COLUMN);
					mFavoriteCouponArray.put(c.getPosition(), coupon);
				} catch (Exception e) { e.printStackTrace(); }
			}
			UIApplication app = (UIApplication) getActivity().getApplicationContext();
		    app.setCouponModelArray(mFavoriteCouponArray);
		}
	}
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
	
	/** Method to called after the list refresh completion. */
	private void listRefreshed() {
		mListView.post(new Runnable() {
			@Override
			public void run() {
				mListView.listRefreshed();
			}
		});
	}
	
	/** Method to search offers locally on key press to enter search text 
	 * and render the result in a list. */
	private void searchOffersOnKeyPress(String searchText) {
		mSectionAdapter.setSelectedPosition(-1);
		LogConfig.logv(LOG_TAG, "searchOffersOnKeyPress(): " + searchText);
		if(searchText.length() > 40) {
			mDialogTitle = getResources().getString(R.string.app_name);
			mErrorMessage = getResources().getString(R.string.dialog_msg_search_text_limit);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		getLoaderManager().destroyLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_LIST);
		if (getLoaderManager().getLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST) == null) {
			getLoaderManager().initLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST, null, this);
		} else {
			getLoaderManager().restartLoader(DatabaseConfig.QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST, null, this);
		}
		mKeyPressSearchResultShowing = true;
	}
	
	/** This method should to be called when user is on search result screen
	 * and pressing back key to come to the offers list screen.
	 */
	public boolean onBackKeyPressEvent() {
		mKeyPressSearchResultShowing = false;
		if (mSearchResultShowing) {
			// reset the search status once again, though it is also resetting from
			// onLoadFinished() method.
			mSearchResultShowing = false;
			
			// set empty text at search text box
			mEditTextSearch.setText("");
			
			// re-query the favorite offers list from cache.
			queryFavoriteOffersFromDB();
			return true;
		}
		return false;
	}
	
	/** {@link OnTouchListener} to hide the virtual keyboard if visible while searching. */
	private final OnTouchListener mOnTouchListenerScreen = new OnTouchListener() {
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// hide virtual keyboard if visible.
			UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
			return false;
		}
	};
	
	/** Listener that invokes for Sliging menu open event. */
	private SlidingMenu.OnOpenListener onSlidingMenuOpenListener = new SlidingMenu.OnOpenListener() {
		@Override
		public void onOpen() {
			// Hide the virtual keyboard if opened.
			if (mEditTextSearch != null) {
				UIUtils.hideKeyboard(getActivity(), mEditTextSearch);
			}
			// Now update the offers count.
			SliderMenuFragment sliderMenuFragment = (SliderMenuFragment) getSherlockActivity()
					.getSupportFragmentManager().findFragmentById(
							R.id.menu_frame);
			if (sliderMenuFragment != null) {
				sliderMenuFragment.redrawView();
				sliderMenuFragment.setRowSelected(HomeActivity.POSITION_TAB_FAVORITE);
			}
		}
	};
}
