/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */

package com.manthansystems.loyalty.factory;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.model.LoyaltyCardHistory;
import com.manthansystems.loyalty.worker.LoyaltyCardWorker.LoyaltyCardWorkerMode;

/**
 * A parser factory to parse the server response of various Loyalty card related operations.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class LoyaltyCardJsonParserFactory extends BaseJsonParser {
	
	/** Call to Parse various Loyalty card related response from JSON string. */
	public synchronized static HashMap<String, Object> parseLoyaltyCardResponse(final String jsonData,
			final byte workerMode) throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_RESULTS_MESSAGE, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
			if (workerMode == LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_SCAN
					|| workerMode == LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_MANUAL_ADD
					|| workerMode == LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY) {
				map = parseLoyaltyCardDetails(response, map);
			}
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	@SuppressWarnings("deprecation")
	private static HashMap<String, Object> parseLoyaltyCardDetails(JSONObject response,
			HashMap<String, Object> map) throws JSONException {
		if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
			final ArrayList<LoyaltyCardHistory> loyaltyCardHistoryArrayList = new ArrayList<LoyaltyCardHistory>();
			JSONObject resultsJSONObject = response.getJSONObject(JSONTagConstants.RESPONSE_RESULTS);
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_EMAIL)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_EMAIL, 
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_EMAIL));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_FIRST_NAME)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_FIRST_NAME, 
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_FIRST_NAME));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_IMAGE_URL)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_IMAGE_URL,
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_IMAGE_URL));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_TOTAL_REWARDS_DAY)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_TOTAL_REWARDS_DAY, 
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_TOTAL_REWARDS_DAY));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_TOTAL_REWARDS)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_TOTAL_REWARDS, 
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_TOTAL_REWARDS));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_EXPIRY_DAYS)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_EXPIRY_DAYS, 
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_EXPIRY_DAYS));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_EXPIRY_REWARDS)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_EXPIRY_REWARDS, 
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_EXPIRY_REWARDS));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_CARD_NUM)) {
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_NUMBER, 
						resultsJSONObject.getString(JSONTagConstants.RESPONSE_TAG_CARD_NUM));
			}
			if (resultsJSONObject.has(JSONTagConstants.RESPONSE_TAG_HISTORY)) {
				JSONArray historyJSONArray = resultsJSONObject.getJSONArray(JSONTagConstants.RESPONSE_TAG_HISTORY);
				int historyJSONArraySize = historyJSONArray.length();
				for (int i = 0; i < historyJSONArraySize; ++i) {
					JSONObject historyItemJSONObject = historyJSONArray.getJSONObject(i);
					final LoyaltyCardHistory loyaltyCardHistory = new LoyaltyCardHistory();
					if (historyItemJSONObject.has(JSONTagConstants.RESPONSE_TAG_TRANSACTION_ID)) {
						loyaltyCardHistory.mTransactionId = historyItemJSONObject.getString(
								JSONTagConstants.RESPONSE_TAG_TRANSACTION_ID);
					}
					if (historyItemJSONObject.has(JSONTagConstants.RESPONSE_TAG_DATE)) {
						loyaltyCardHistory.mDate =  historyItemJSONObject.getString(
								JSONTagConstants.RESPONSE_TAG_DATE);
					}
					if (historyItemJSONObject.has(JSONTagConstants.RESPONSE_TAG_REWARDS)) {
						loyaltyCardHistory.mRewards = historyItemJSONObject.getString(
								JSONTagConstants.RESPONSE_TAG_REWARDS);
					}
					loyaltyCardHistoryArrayList.add(loyaltyCardHistory);
				}
				map.put(CommonConfig.KEY_NAME_LOYALTY_CARD_HISTORY_LIST, loyaltyCardHistoryArrayList);
			}
		}
		return map;
	}
}
