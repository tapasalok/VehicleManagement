/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui.phone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.ui.LocationSettingsFragment;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;

/**
 * An activity class that will manage location settings. User can select 
 * location mode to GPS, Home zipcode or else can enter their own zipcode
 * based on which offers will be fetch. Once selected location mode offers 
 * will be downloaded for current selected location mode. This class extends
 * {@link SherlockFragmentActivity}.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class LocationSettingsAcitivity extends SherlockFragmentActivity
	implements OnSwipeListener  {

	@SuppressWarnings("unused")
	private final String TAG = "LocationSettingsAcitivity";
	private LocationSettingsFragment mLocationSettingsFragment;
	private CustomSwipeDetector mCustomSwipeDetector;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_location_settings);
		mCustomSwipeDetector = new CustomSwipeDetector(this, this);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    } else if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	FragmentManager fm = getSupportFragmentManager();
	    	mLocationSettingsFragment = (LocationSettingsFragment) fm.findFragmentById(
	    			R.id.fragment_location_settings);
	    	if (mLocationSettingsFragment != null) {
	    		mLocationSettingsFragment.getActivity().setResult(Activity.RESULT_CANCELED, new Intent());
	    		mLocationSettingsFragment.getActivity().finish();
	    	}
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	public void finish() {
	    super.finish();
	    overridePendingTransition(0, R.anim.translate_slide_right_out);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent me) {
		return mCustomSwipeDetector.onTouchEvent(me);
	}

	@Override
	public void onLeftToRightSwipeDetected() {
		FragmentManager fm = getSupportFragmentManager();
    	mLocationSettingsFragment = (LocationSettingsFragment) fm.findFragmentById(
    			R.id.fragment_location_settings);
    	if (mLocationSettingsFragment != null) {
    		mLocationSettingsFragment.getActivity().setResult(Activity.RESULT_CANCELED, new Intent());
    		mLocationSettingsFragment.getActivity().finish();
    	}
	}

	@Override
	public void onRightToLeftSwipeDetected() {
		// Do Nothing
	}

	@Override
	public void onListItemClicked(int position) {
		// Do Nothing
	}
}
