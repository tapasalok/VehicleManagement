/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.factory;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;

/**
 * A JSON parser class that will parse the user email registration response,
 * user activation response and home zip code validation response from json string coming from server.
 * 
 * @author Gaurav Agrawal: gaurav.agrawal@xymob.com
 */
public class LoginJSONParserFactory extends BaseJsonParser {

	/** Call to Parse user email address response from JSON string. */
	public synchronized static HashMap<String, Object> parseEmailRegistrationResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
				JSONObject resultResponseJsonObject = response.getJSONObject(JSONTagConstants.RESPONSE_RESULTS);
				if (resultResponseJsonObject.has(JSONTagConstants.RESPONSE_RESULTS_MESSAGE)) {
					map.put(CommonConfig.KEY_NAME_RESULTS_MESSAGE, resultResponseJsonObject.getString(JSONTagConstants.RESPONSE_RESULTS_MESSAGE));
				}
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	/** Call to Parse authenticate token response from JSON string. */
	public synchronized static HashMap<String, Object> parseActivateUserResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
				JSONObject resultResponseJsonObject = response.getJSONObject(JSONTagConstants.RESPONSE_RESULTS);
				if (resultResponseJsonObject.has(JSONTagConstants.RESPONSE_RESULTS_MESSAGE)) {
					map.put(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
							resultResponseJsonObject.getString(JSONTagConstants.RESPONSE_RESULTS_MESSAGE));
				}
				if (resultResponseJsonObject.has(JSONTagConstants.RESPONSE_LOGIN_TOKEN)) {
					map.put(CommonConfig.KEY_NAME_LOGIN_TOKEN, 
							resultResponseJsonObject.getString(JSONTagConstants.RESPONSE_LOGIN_TOKEN));
				}
				
				if (resultResponseJsonObject.has(JSONTagConstants.RESPONSE_SESSION_ID)) {
					map.put(CommonConfig.KEY_NAME_SESSION_ID, 
							resultResponseJsonObject.getString(JSONTagConstants.RESPONSE_SESSION_ID));
				}
				
				if (resultResponseJsonObject.has(JSONTagConstants.ZIP)) {
					map.put(CommonConfig.ZIP, 
							resultResponseJsonObject.getString(JSONTagConstants.ZIP));
					
				}
				
				
				
				
				
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	/** Call to Parse ZipCode response from JSON string. */
	public synchronized static HashMap<String, Object> parseZipCodeResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
}
