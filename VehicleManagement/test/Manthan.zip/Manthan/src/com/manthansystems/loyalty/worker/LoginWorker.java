/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.LoginJSONParserFactory;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;
import com.manthansystems.loyalty.util.EDUtils;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 *  make the network request to user login. It handles the parsing,
 *  db caching and error states while of these processes. 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class LoginWorker extends BaseWorker {

	@SuppressWarnings("unused")
	private final static String LOG_TAG = "LoginWorker";
	
	public static String KEY_NAME_BUNDLE_LOGIN_WORKER_MODE = "com.manthansystems.loyalty.worker.LoginWorker#WorkerMode";
	public final static byte WORKER_MODE_REGISTER_EMAIL_ADDRESS	= 1;
	public final static byte WORKER_MODE_ACTIVATE_USER = 2;
	public final static byte WORKER_MODE_SEND_ZIP_CODE = 3;
	public final static byte WORKER_MODE_VALIDATE_USER_ZIP_CODE = 4;
	public final static byte WORKER_MODE_LOGIN_USER = 5;
	
	/** Start processing the request. */
	public static Bundle start(final Context inContext, final int inReturnFormat,
    		final Bundle inBundleData) throws IllegalStateException,
    		IOException,URISyntaxException, RestClientException, ParserConfigurationException,
    		SAXException, JSONException, Exception, OperationApplicationException, ConnectionException {
    	
		Bundle bundle = new Bundle();
		HashMap<String, Object> hashMap = null;
		NetworkConnectionResult wsResult = null;
    	String responseStatus = null;
    	
		byte workerMode = inBundleData.getByte(KEY_NAME_BUNDLE_LOGIN_WORKER_MODE);
    	
    	String serverRequestUrl = prepareRequestUrl(workerMode);
    	ArrayList<Header> headerList = getBasicHeaders(inContext);

    	switch (workerMode) {
		case WORKER_MODE_ACTIVATE_USER:
			resetPostBuffer();
			final String emailId = EDUtils.getEmailID(inContext);
			addToPostBuffer(JSONTagConstants.EMAIL_ID_TAG, emailId);
			addToPostBuffer(JSONTagConstants.TOKEN_TAG, inBundleData.getString(CommonConfig.KEY_NAME_TOKEN));
			
			wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.POST, mParameters, headerList, false, inContext);
			
			hashMap = LoginJSONParserFactory.parseActivateUserResponse(wsResult.wsResponse);
			
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				EDUtils.setLoginToken(inContext, (String) hashMap.get(CommonConfig.KEY_NAME_LOGIN_TOKEN));
	        	PreferenceConfig.setSessionId(
	        			(String) hashMap.get(CommonConfig.KEY_NAME_SESSION_ID), inContext);
	        	
	        	PreferenceConfig.setHomeZipcodeFromServer((String) hashMap.get(CommonConfig.ZIP), inContext);
	        }
			break;
		
		case WORKER_MODE_REGISTER_EMAIL_ADDRESS:
			resetPostBuffer();
			final String emailIdStr = inBundleData.getString(CommonConfig.KEY_NAME_EMAIL_ADDRESS);
			addToPostBuffer(JSONTagConstants.EMAIL_ID_TAG, emailIdStr);
			
			wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.POST, mParameters, headerList, false, inContext);
			
			hashMap = LoginJSONParserFactory.parseEmailRegistrationResponse(wsResult.wsResponse);
			
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				EDUtils.setEmailId(inContext, emailIdStr);
				bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
						(String)hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
	        }
			break;
		
		case WORKER_MODE_SEND_ZIP_CODE:
			String zipCode = inBundleData.getString(CommonConfig.KEY_NAME_ZIP_CODE);
			resetPostBuffer();
			addToPostBuffer(JSONTagConstants.ZIP_CODE, URLEncoder.encode(zipCode, "UTF-8"));
			
			wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.POST, mParameters, headerList, false, inContext);
			hashMap = LoginJSONParserFactory.parseZipCodeResponse(wsResult.wsResponse);
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				PreferenceConfig.setHomeZipcode(zipCode, inContext);
	        }
			break;
		
		case WORKER_MODE_VALIDATE_USER_ZIP_CODE:
			StringBuilder urlBuilder = new StringBuilder(serverRequestUrl);
			int valuePosition = 0;
	    	String zip = inBundleData.getString(CommonConfig.KEY_NAME_ZIP_CODE);
    		valuePosition = urlBuilder.indexOf(WSConfig.WS_ZIP_CODE);
    		urlBuilder.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()),
    				URLEncoder.encode(zip, "UTF-8"));
			wsResult = NetworkConnection.retrieveResponseFromService(
					urlBuilder.toString(), Method.GET, null, headerList, false, inContext);
			hashMap = LoginJSONParserFactory.parseZipCodeResponse(wsResult.wsResponse);
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			break;
			
		case WORKER_MODE_LOGIN_USER:
			resetPostBuffer();
			final String loginTokenStr = EDUtils.getLoginToken(inContext);
			addToPostBuffer(WSConfig.LOGIN_TOKEN, loginTokenStr);
			wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.POST, mParameters, headerList, false, inContext);
			hashMap = LoginJSONParserFactory.parseActivateUserResponse(wsResult.wsResponse);
			
			responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				EDUtils.setLoginToken(inContext, (String) hashMap.get(CommonConfig.KEY_NAME_LOGIN_TOKEN));
	        	PreferenceConfig.setSessionId(
	        			(String) hashMap.get(CommonConfig.KEY_NAME_SESSION_ID), inContext);
	        	PreferenceConfig.setAppBackgroundTrackTimestamp(System.currentTimeMillis(), inContext);
	        }
			break;
			
		default:
			throw new URISyntaxException("LoginWorker mode not set.", 
					"The caller for method start() has not set the" +
					"worker mode.");
		}
        responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        }
        return bundle;
    }
    
	/** Method to prepare the appropriate server request url based on the worker mode. */
    private static String prepareRequestUrl(final byte workerMode) throws URISyntaxException,
    		UnsupportedEncodingException {
    	switch (workerMode) {
		case WORKER_MODE_ACTIVATE_USER:
			return WSConfig.URL_ACTIVATE_USER;
		case WORKER_MODE_REGISTER_EMAIL_ADDRESS:
			return WSConfig.URL_REGISTER_EMAIL_ADDRESS;
		case WORKER_MODE_SEND_ZIP_CODE:
			return WSConfig.URL_UPDATE_USER_PROFILE;
		case WORKER_MODE_VALIDATE_USER_ZIP_CODE:
			return WSConfig.URL_VALIDATE_ZIPCODE;
		case WORKER_MODE_LOGIN_USER:
			return WSConfig.URL_LOGIN_USER;
		default:
			throw new URISyntaxException("LoginWorker mode not set.",
					"The caller for method prepareRequestUrl() has not set the" +
					"worker mode.");
		}
    }
}
