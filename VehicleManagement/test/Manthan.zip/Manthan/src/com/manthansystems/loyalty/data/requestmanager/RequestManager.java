/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.data.requestmanager;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.Random;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.util.SparseArray;

import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.service.WorkerService;

/**
 * This class is used as a proxy to call the Service. It provides easy-to-use
 * methods to call the service and manages the Intent creation. It also assures
 * that a request will not be sent again if an exactly identical one is already
 * in progress
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 */
public class RequestManager extends BaseRequestManager {
	
	private static final String LOG_TAG = RequestManager.class.getSimpleName();
	
    // TODO : This constant will be used in your special methods
    private static final int MAX_RANDOM_REQUEST_ID = 1000000;

    // Singleton management
    private static RequestManager sInstance;
    private static Random sRandom = new Random();
    public static RequestManager from(final Context context) {
        if (sInstance == null) {
            sInstance = new RequestManager(context);
        }

        return sInstance;
    }

    private SparseArray<Intent> mRequestSparseArray;
    // TODO : This variable will be used in your special methods
    private Context mContext;
    private ArrayList<WeakReference<OnRequestFinishedListener>> mListenerList;
    private Handler mHandler = new Handler();
    // TODO : This variable will be used in your special methods
    private EvalReceiver mEvalReceiver = new EvalReceiver(mHandler);

    private RequestManager(final Context context) {
        mContext = context.getApplicationContext();
        mRequestSparseArray = new SparseArray<Intent>();
        mListenerList = new ArrayList<WeakReference<OnRequestFinishedListener>>();
    }

    /**
     * The ResultReceiver that will receive the result from the Service
     */
    private class EvalReceiver extends ResultReceiver {
        EvalReceiver(final Handler h) {
            super(h);
        }

        @Override
        public void onReceiveResult(final int resultCode, final Bundle resultData) {
            handleResult(resultCode, resultData);
        }
    }

    /**
     * Clients may implements this interface to be notified when a request is
     * finished
     * 
     */
    public static interface OnRequestFinishedListener extends EventListener {

        /**
         * Event fired when a request is finished.
         * 
         * @param requestId The request Id (to see if this is the right request)
         * @param resultCode The result code (0 if there was no error)
         * @param payload The result of the service execution.
         */
        public void onRequestFinished(int requestId, int resultCode, Bundle payload);
    }

    /**
     * Add a {@link OnRequestFinishedListener} to this
     * {@link RequestManager}. Clients may use it in order to listen to
     * events fired when a request is finished.
     * <p>
     * <b>Warning !! </b> If it's an {@link Activity} that is used as a
     * Listener, it must be detached when {@link Activity#onPause} is called in
     * an {@link Activity}.
     * </p>
     * 
     * @param listener The listener to add to this
     *            {@link RequestManager} .
     */
    public void addOnRequestFinishedListener(final OnRequestFinishedListener listener) {
        synchronized (mListenerList) {
            // Check if the listener is not already in the list
            if (!mListenerList.isEmpty()) {
                for (WeakReference<OnRequestFinishedListener> weakRef : mListenerList) {
                    if (weakRef != null && weakRef.get() != null && listener != null && weakRef.get().equals(listener)) {
                        return;
                    }
                }
            }
            if (listener != null) {
            	mListenerList.add(new WeakReference<OnRequestFinishedListener>(listener));
            }
        }
    }

    /**
     * Remove a {@link OnRequestFinishedListener} to this
     * {@link RequestManager}.
     * 
     * @param listenerThe listener to remove to this
     *            {@link RequestManager}.
     */
    public void removeOnRequestFinishedListener(final OnRequestFinishedListener listener) {
        synchronized (mListenerList) {
            final int listenerListSize = mListenerList.size();
            for (int i = 0; i < listenerListSize; i++) {
                if (mListenerList.get(i).get().equals(listener)) {
                    mListenerList.remove(i);
                    return;
                }
            }
        }
    }

    /**
     * Return whether a request (specified by its id) is still in progress or
     * not
     * 
     * @param requestId The request id
     * @return whether the request is still in progress or not.
     */
    public boolean isRequestInProgress(final int requestId) {
        return (mRequestSparseArray.indexOfKey(requestId) >= 0);
    }

    /**
     * This method is call whenever a request is finished. Call all the
     * available listeners to let them know about the finished request
     * 
     * @param resultCode The result code of the request
     * @param resultData The bundle sent back by the service
     */
    protected void handleResult(final int resultCode, final Bundle resultData) {

        // Get the request Id
        final int requestId = resultData.getInt(RECEIVER_EXTRA_REQUEST_ID);

        // Remove the request Id from the "in progress" request list
        mRequestSparseArray.remove(requestId);

        // Call the available listeners
        synchronized (mListenerList) {
            for (int i = 0; i < mListenerList.size(); i++) {
                final WeakReference<OnRequestFinishedListener> weakRef = mListenerList.get(i);
                final OnRequestFinishedListener listener = weakRef.get();
                if (listener != null) {
                    listener.onRequestFinished(requestId, resultCode, resultData);
                } else {
                    mListenerList.remove(i);
                    i--;
                }
            }
        }
    }

    /**
     * Here begin the special methods
     */

    // TODO : This is where you will add your methods which will call the
    // service
     
    /** Method to get the offer list from the server. */
    public int getOfferList(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_OFFER_LIST, inReturnFormat, inBundleData);
    }
    
    /** Method to get favorite offers from the server. */
    public int getFavoriteOffers(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_FAVORITE_OFFER, inReturnFormat, inBundleData);
    }
    
    /** Method to register user's email address. */
    public int registerEmailAddress(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_USER_LOGIN, inReturnFormat, inBundleData);
    }
    
    /** Method to activate user. */
    public int activateUser(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_USER_LOGIN, inReturnFormat, inBundleData);
    }
    
    /** Method to send zipcode. */
    public int sendZipCode(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_USER_LOGIN, inReturnFormat, inBundleData);
    }
    
    /** Method to validate user zipcode. */
    public int validateUserZipCode(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_USER_LOGIN, inReturnFormat, inBundleData);
    }
    
    /** Method to get all categories. */
    public int getAllCategories(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_SETTINGS, inReturnFormat, inBundleData);
    }
    
    /** Method to send user category. */
    public int sendUserCategory(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_SETTINGS, inReturnFormat, inBundleData);
    }
    
    /** Method to get user category. */
    public int getUserCategory(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_SETTINGS, inReturnFormat, inBundleData);
    }
    
	/** Method to set status of push notification. S**/
    public int setPushNotification(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_SETTINGS, inReturnFormat, inBundleData);
    }
    
    /** Method to get app config. **/
    public int getAppConfig(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_SETTINGS, inReturnFormat, inBundleData);
    }
    
    /** Method to get location for zipcode. */
    public int getLocationForZipCode(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_SETTINGS, inReturnFormat, inBundleData);
    }
    
    /** Method to login user. */
    public int loginUser(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_USER_LOGIN, inReturnFormat, inBundleData);
    }
    
    /** Method to get the count offer from the server. */
    public int getOfferCount(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_OFFER_COUNT, inReturnFormat, inBundleData);
    }
    
    /** Method to trigger user event. */
    public int triggerEvent(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_TRIGGER_EVENT, inReturnFormat, inBundleData);
    }
    
    /** Method for various loyalty card related network request. */
    public int loyaltyCard(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_LOYALTY_CARD, inReturnFormat, inBundleData);
    }

	/** Method to get the coupon redemption lock from server. If redemption is valid
	 * for selected coupon then server says success response or else it sends
	 * appropriate error message. */
    public int handleCouponRedemption(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_OFFER_REDEMPTION, inReturnFormat, inBundleData);
    }
    
    /** Method to check app update availability on server. **/
    public int checkAppUpdate(final int inReturnFormat, final Bundle inBundleData) {
    	return startServiceToHandleRequest(WorkerService.WORKER_TYPE_CHECK_APP_UPDATE, inReturnFormat, inBundleData);
    }
    
    /** It avoids duplicate request, starts service for new request. */
    private int startServiceToHandleRequest(final int inWorkerType, final int inReturnFormat, Bundle inBundleData) {
    	LogConfig.logd(LOG_TAG, "inside startServiceToHandleRequest()");
    	// Check if a match to this request is already launched
        final int requestSparseArrayLength = mRequestSparseArray.size();
        if(inBundleData == null) {
        	inBundleData = new Bundle();
        }
        for (int i = 0; i < requestSparseArrayLength; i++) {
            final Intent savedIntent = mRequestSparseArray.valueAt(i);

            if (savedIntent.getIntExtra(WorkerService.INTENT_EXTRA_WORKER_TYPE, -1) != inWorkerType) {
                continue;
            }
            if (savedIntent.getIntExtra(WorkerService.INTENT_EXTRA_RETURN_FORMAT, -1) != inReturnFormat) {
                continue;
            }
            if (!savedIntent.getBundleExtra(WorkerService.INTENT_EXTRA_BUNDLE_DATA).equals(inBundleData)) {
                continue;
            }
            return mRequestSparseArray.keyAt(i);
        }

        final int requestId = sRandom.nextInt(MAX_RANDOM_REQUEST_ID);
        
        final Intent intent = new Intent(mContext, WorkerService.class);
        intent.putExtra(WorkerService.INTENT_EXTRA_WORKER_TYPE, inWorkerType);
        intent.putExtra(WorkerService.INTENT_EXTRA_RECEIVER, mEvalReceiver);
        intent.putExtra(WorkerService.INTENT_EXTRA_REQUEST_ID, requestId);
        intent.putExtra(WorkerService.INTENT_EXTRA_RETURN_FORMAT, inReturnFormat);
        intent.putExtra(WorkerService.INTENT_EXTRA_BUNDLE_DATA, inBundleData);
        		
        LogConfig.logd(LOG_TAG, "before SkeletonService start service");
        mContext.startService(intent);

        mRequestSparseArray.append(requestId, intent);

        return requestId;
    }
}
