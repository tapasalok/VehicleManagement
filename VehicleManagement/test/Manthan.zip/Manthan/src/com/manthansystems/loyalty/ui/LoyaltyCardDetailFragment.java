/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.io.File;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.app.SherlockListFragment;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuInflater;
import com.actionbarsherlock.view.MenuItem;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.widget.RefreshableListView;
import com.manthansystems.loyalty.ui.widget.RefreshableListView.OnUpdateTask;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.LoyaltyCardWorker.LoyaltyCardWorkerMode;

/**
 * A {@link SherlockFragment} class that shows the Loyalty Card details of user
 * which contains Card number, barcode image of card, Retailer logo, rewards
 * points, and rewards history etc. After by joining in loyalty program or
 * scanning, manual card entry the card details will be fetched from server and
 * shown to there user here.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class LoyaltyCardDetailFragment extends SherlockListFragment implements
	OnRequestFinishedListener {

	private final String LOG_TAG = "LoyaltyCardDetailFragment";
	
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.LoyaltyCardDetailFragment#RequestId";
	private final String SAVED_STATE_WORKER_MODE = 
		"com.manthansystems.loyalty.ui.LoyaltyCardDetailFragment#SaveStateWorkerMode";
	private final String SAVED_STATE_LOYALTY_CARD_NUMBER = 
		"com.manthansystems.loyalty.ui.LoyaltyCardDetailFragment#SaveStateCardNumber";
	private final String SAVED_STATE_BARCODE_TYPE = 
		"com.manthansystems.loyalty.ui.LoyaltyCardDetailFragment#SaveStateBarcodeType";
	
	private ViewGroup mView;
	private Handler mHandler;
    private RequestManager mRequestManager;
    private int mRequestId = -1;
    private String mErrorMessage;
    private String mErrorTitle;
    private Bundle mResponseBundle;
	private boolean mShowProgressBar = false;
	private byte mLoyaltyCardWorkerMode;
	private RelativeLayout relativeLayout_balance_reward; 
	private RelativeLayout relativeLayout_point_expiry;
	private String mLoyaltyCardNumber;
	private TextView textView_label_balance_reward;
	private TextView mTextViewValueBalanceReward;
	private TextView mTextViewExpiryPoint;
	private TextView mTextViewCardNumber; 
	private TextView mTextViewExpiryDays;
	private ImageView mImageViewBarCode;
	private static byte mRequestType;
	private boolean mDeleteRequested = false;
	private AlertDialog mAlertDialog;
	private int mBarCodeType;
	private RefreshableListView mListView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogConfig.logd(LOG_TAG, "onCreate()");
		if (savedInstanceState != null) {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
			mLoyaltyCardWorkerMode = savedInstanceState.getByte(SAVED_STATE_WORKER_MODE);
			mLoyaltyCardNumber = savedInstanceState.getString(SAVED_STATE_LOYALTY_CARD_NUMBER);
			mBarCodeType = savedInstanceState.getInt(SAVED_STATE_BARCODE_TYPE);
		}
		mHandler = new Handler();
    	mRequestManager = RequestManager.from(getActivity());
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_pulldown_list, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;   
        bindViews();
        return root;
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.label_tab_loyalty_card, false, true, true, getSherlockActivity());
		// search bar is not needed for this screen so hide it.
		mView.findViewById(R.id.search_bar_layout).setVisibility(View.GONE);
		mView.findViewById(R.id.TextView_tap_to_refresh).setVisibility(View.GONE);
		mListView = (RefreshableListView) mView.findViewById(android.R.id.list);
		// list divider is not required.
		mListView.setDividerHeight(0);
		mListView.setOnUpdateTask(new OnUpdateTask() {
			@Override
			public void onUpdateStart() {
				LogConfig.logv(LOG_TAG, "onUpdateStart()");
				mLoyaltyCardWorkerMode = LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY;
				PreferenceConfig.setLoyaltyCardWorkerMode(mLoyaltyCardWorkerMode, getActivity());
				callGetLoyaltyCardDetailsWS();
			}
			
			@Override
			public void updateBackground() {
				mListView.listRefreshed();
			}
			
			@Override
			public void updateUI() {
				LogConfig.logv(LOG_TAG, "updateUI()");
			}
		});
		
		View view = ((SherlockFragmentActivity) getActivity()).getSupportActionBar().getCustomView();
		if (view != null) {
			view.findViewById(R.id.ImageView_Slide_Menu_icon).setOnClickListener(
					new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					((BaseSlidingActivity) getActivity()).getSlidingMenu().showMenu(true);
				}
			});
		}
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		addViewToListHeader(getActivity());
		mLoyaltyCardWorkerMode = PreferenceConfig.getLoyaltyCardWorkerMode(getActivity());
		mLoyaltyCardNumber = PreferenceConfig.getLoyaltyCardNumber(getActivity());
		mBarCodeType = PreferenceConfig.getBarCodeType(getActivity());
		if (PreferenceConfig.getIsLoyaltyCardCreated(getActivity())) {
			populateView();
		}
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
		if (mLoyaltyCardWorkerMode != LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_NONE) {
			callGetLoyaltyCardDetailsWS();
		} else {
			// set the mode to display so that on subsequent fragment resume it always go for
			// loyalty card details download in display mode.
			mLoyaltyCardWorkerMode = LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY;
			PreferenceConfig.setLoyaltyCardWorkerMode(mLoyaltyCardWorkerMode, getActivity());
			if (!PreferenceConfig.getIsLoyaltyCardCreated(getActivity())) {
				// This case will only occurs if loyalty login screen launches this screen
				// even if the card is not yet created on server, So will
				// close the detail screen and show the loyalty card creation screen again.
				((HomeActivity) getActivity()).removeTabFragment(HomeActivity.TAB_LOYALTY_CARD);
				((HomeActivity) getActivity()).switchContent(
						HomeActivity.TAB_LOYALTY_CARD, LoyaltyCardLoginFragment.class, null);
			}
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logd(LOG_TAG, "onResume()");
		// register sliding menu open listener to update slide menu row selection.
		((HomeActivity)getActivity()).getSlidingMenu().setOnOpenListener(onSlidingMenuOpenListener);
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(LoyaltyCardDetailFragment.this);
            } else {
                mRequestId = -1;
            }
        }
	}

	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logd(LOG_TAG, "onPause()");
		// un-register sliding menu open listener.
		((HomeActivity)getActivity()).getSlidingMenu().setOnOpenListener(null);
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(LoyaltyCardDetailFragment.this);
		}
		//dismissActiveDialog();
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
        outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
        outState.putString(SAVED_STATE_LOYALTY_CARD_NUMBER, mLoyaltyCardNumber);
        outState.putInt(SAVED_STATE_WORKER_MODE, mLoyaltyCardWorkerMode);
        outState.putInt(SAVED_STATE_BARCODE_TYPE, mBarCodeType);
		super.onSaveInstanceState(outState);
	}

	/** Make server request to get the Loyalty Card details from server. */
	private void callGetLoyaltyCardDetailsWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			populateView();
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());
		}
		Bundle params = new Bundle();
		// Add loyalty card number in case of scan or manual barcode entry.
		if (mLoyaltyCardWorkerMode == LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_SCAN
				|| mLoyaltyCardWorkerMode == LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_MANUAL_ADD) {
			params.putString(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_LOYALTY_CARD_NUMBER,
					mLoyaltyCardNumber);
			params.putInt(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_BARCODE_TYPE, mBarCodeType);
		}
		params.putByte(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_LOYALTY_CARD_WORKER_MODE,
				mLoyaltyCardWorkerMode);
		mRequestManager.addOnRequestFinishedListener(LoyaltyCardDetailFragment.this);
		mRequestType = REQUEST_TYPE.VIEW_LOYALTY_CARD;
		mRequestId = mRequestManager.loyaltyCard(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			// must reset refreshing, if requested or not.
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(LoyaltyCardDetailFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
	
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.VIEW_LOYALTY_CARD ) {
					loyaltyCardDetailsDownloadedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.DELETE_LOYALTY_CARD) {
					loyaltyCardDeletedDoSomething();
				}
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				if (mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_CODE).equals(
						CommonConfig.ERROR_CODE_NO_LOYALTY_CARD_REGISTERED)) {
					// No Loyalty card is registered.
					// Reset loyalty card data as if card is deleted from other device with
					// same user email id.
					PreferenceConfig.setIsLoyaltyCardCreated(false, getActivity());
					PreferenceConfig.setFirstLaunchLoyaltyCardStatus(true, getActivity());
				}
				mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
					
					// set the mode to display so that on subsequent fragment resume it always go for
					// loyalty card details download in display mode.
					mLoyaltyCardWorkerMode = LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY;
					PreferenceConfig.setLoyaltyCardWorkerMode(mLoyaltyCardWorkerMode, getActivity());
					
					if (PreferenceConfig.getIsLoyaltyCardCreated(getActivity())) {
						populateView();
					} else {
						// Close the detail screen and show the loyalty card creation screen.
						Bundle args = new Bundle();
						args.putBoolean(LoyaltyCardLoginFragment.STRING_EXTRA_IS_COMING_FROM_LOYALTY_CARD_DETAILS_SCREEN,
								true);
						((HomeActivity) getActivity()).removeTabFragment(HomeActivity.TAB_LOYALTY_CARD);
						((HomeActivity) getActivity()).switchContent(
										HomeActivity.TAB_LOYALTY_CARD, LoyaltyCardLoginFragment.class, args);
					}
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
			// set the mode to display so that on subsequent fragment resume it always go for
			// loyalty card details download in display mode.
			mLoyaltyCardWorkerMode = LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY;
			PreferenceConfig.setLoyaltyCardWorkerMode(mLoyaltyCardWorkerMode, getActivity());
			
			if (PreferenceConfig.getIsLoyaltyCardCreated(getActivity())) {
				populateView();
			} else {
				// Close the detail screen and show the loyalty card creation screen.
				((HomeActivity) getActivity()).removeTabFragment(HomeActivity.TAB_LOYALTY_CARD);
				((HomeActivity) getActivity()).switchContent(
								HomeActivity.TAB_LOYALTY_CARD, LoyaltyCardLoginFragment.class, null);
			}
		}
	};
	
	/**
	 * Method should invoke after successful download completion of Loyalty Card
	 * Details from server.
	 */
	private void loyaltyCardDetailsDownloadedDoSomething() {
		LogConfig.logd(LOG_TAG, "loyaltyCardDetailsDownloadedDoSomething()");
		ProgressBarHelper.dismissProgressBar(mHandler);
		// set the mode to display so that on subsequent fragment resume it always go for
		// loyalty card details download in display mode.
		mLoyaltyCardWorkerMode = LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY;
		PreferenceConfig.setLoyaltyCardWorkerMode(mLoyaltyCardWorkerMode, getActivity());
		// Prepare to show the loyalty card details.
		populateView();
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_DELETE_LOYALTY_CARD_CONFIRMATION:
			dlg.setIcon(R.drawable.icon)
			.setTitle(getResources().getString(R.string.app_name))
			.setMessage(getResources().getString(R.string.msg_delete_confirmation))
			.setCancelable(false)
			.setPositiveButton(R.string.label_delete, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					callDeleteLoyaltyCardWS();
					mDeleteRequested = false;
				}
			})
			.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					mDeleteRequested = false;
				}
			});
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		LogConfig.logd(LOG_TAG, "onDestroy()");
		if (mView != null) {
			UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_pulldown_list));
			System.gc();
		}
	}
	
	/** Make server request to delete the Loyalty Card from server. */
	private void callDeleteLoyaltyCardWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());
		}
		mLoyaltyCardWorkerMode = LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DELETE;
		PreferenceConfig.setLoyaltyCardWorkerMode(mLoyaltyCardWorkerMode, getActivity());
		Bundle params = new Bundle();
		params.putByte(LoyaltyCardWorkerMode.KEY_NAME_BUNDLE_LOYALTY_CARD_WORKER_MODE,
				mLoyaltyCardWorkerMode);
		mRequestManager.addOnRequestFinishedListener(LoyaltyCardDetailFragment.this);
		mRequestType = REQUEST_TYPE.DELETE_LOYALTY_CARD;
		mRequestId = mRequestManager.loyaltyCard(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	/** method to populate data on view. */
	private void populateView() {
		File imgFile = new  File(PreferenceConfig.getLoyaltyCardImagePath(getActivity()));
		if (imgFile.exists()) {
			Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
		    mImageViewBarCode.setImageBitmap(myBitmap);
		    DisplayMetrics displaymetrics = new DisplayMetrics();
		    getActivity().getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		    int height = displaymetrics.heightPixels;
		    LayoutParams params = mImageViewBarCode.getLayoutParams();
			params.height = (int) (height * 0.3);
		    mImageViewBarCode.setLayoutParams(params);
		}
	    Resources resources = getResources();
	    
	    if(PreferenceConfig.getLoyaltyCardTotalRewards(getActivity()).length()>0&&PreferenceConfig.getLoyaltyCardTotalRewardsDay(getActivity()).length()>0){
	    	relativeLayout_balance_reward.setVisibility(View.VISIBLE);
	    	mTextViewValueBalanceReward.setText(Html.fromHtml(PreferenceConfig.getLoyaltyCardTotalRewards(getActivity())));
	    	textView_label_balance_reward.setText(Html.fromHtml(PreferenceConfig.getLoyaltyCardTotalRewardsDay(getActivity())));
	    }else{
	    	relativeLayout_balance_reward.setVisibility(View.INVISIBLE);
	    }
	    
		if(PreferenceConfig.getLoyaltyCardExpiryRewards(getActivity()).length()>0){
			relativeLayout_point_expiry.setVisibility(View.VISIBLE);
			//mTextViewExpiryPoint.setText(Html.fromHtml(PreferenceConfig.getLoyaltyCardExpiryRewards(getActivity())));
			mTextViewExpiryDays.setText(Html.fromHtml(PreferenceConfig.getLoyaltyCardExpiryDays(getActivity())));
		}else{
			relativeLayout_point_expiry.setVisibility(View.INVISIBLE);
		}
	  
		/*StringBuilder expiryDays = new StringBuilder();
		expiryDays.append(resources.getString(R.string.label_expiring_in))
		.append(" <b>" )
		.append(PreferenceConfig.getLoyaltyCardExpiryDays(getActivity()))
		.append("</b> ")
		.append(resources.getString(R.string.label_days));
		mTextViewExpiryDays.setText(Html.fromHtml(expiryDays.toString()));*/
		if (!TextUtils.isEmpty(mLoyaltyCardNumber)) {
			StringBuilder cardNoStringBuilder = new StringBuilder(resources.getString(R.string.label_card_no));
			cardNoStringBuilder.append(" ").append(mLoyaltyCardNumber);
			mTextViewCardNumber.setText(cardNoStringBuilder.toString());
		} else {
			mTextViewCardNumber.setVisibility(View.INVISIBLE);
		}
		final LinearLayout linearLayout = (LinearLayout) mView.findViewById(R.id.linearLayout_reward_history);
		int childCount = linearLayout.getChildCount();
		if (childCount > 1) {
			linearLayout.removeViews(1, childCount - 1);
		}
		LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);
		int count = PreferenceConfig.getLoyaltyCardHistoryCount(getActivity());
		for (int i = 0; i < count; ++i ) {
			final View rowView = inflater.inflate(R.layout.row_for_reward_history, null);
			TextView textViewRewardDate = (TextView) rowView.findViewById(R.id.textView_reward_date);
			TextView textViewRewardPoint = (TextView) rowView.findViewById(R.id.textView_reward_point);
			textViewRewardDate.setText(PreferenceConfig.getLoyaltyCardDate(getActivity(), i));
			textViewRewardPoint.setText(PreferenceConfig.getLoyaltyCardRewards(getActivity(), i));
			if (i % 2 == 0) {
				rowView.setBackgroundColor(resources.getColor(R.color.color_dark_grey));
			} else {
				rowView.setBackgroundColor(resources.getColor(R.color.color_light_grey));
			}
			linearLayout.addView(rowView);
		}
	}
	
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		menu.clear();
		inflater.inflate(R.menu.delete_menu_item, menu);
		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == R.id.menu_delete) {
			if (!mDeleteRequested) {
				mDeleteRequested = true;
				showDialog(DialogConfig.DIALOG_DELETE_LOYALTY_CARD_CONFIRMATION);
			}
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	/** method to perform action after deletion of loyalty card. */
	private void loyaltyCardDeletedDoSomething() {
		LogConfig.logd(LOG_TAG, "loyaltyCardDeletedDoSomething()");
		ProgressBarHelper.dismissProgressBar(mHandler);
		PreferenceConfig.setFirstLaunchLoyaltyCardStatus(true, getActivity());
		// set the mode to display so that on subsequent fragment resume it always go for
		// loyalty card details download in display mode.
		mLoyaltyCardWorkerMode = LoyaltyCardWorkerMode.WORKER_MODE_LOYALTY_CARD_DISPLAY;
		PreferenceConfig.setLoyaltyCardWorkerMode(mLoyaltyCardWorkerMode, getActivity());
		((HomeActivity) getActivity()).removeTabFragment(HomeActivity.TAB_LOYALTY_CARD);
		((HomeActivity) getActivity()).switchContent(
						HomeActivity.TAB_LOYALTY_CARD, LoyaltyCardLoginFragment.class, null);
	}
	
	/** Listener that invokes for Sliding menu open event. */
	private SlidingMenu.OnOpenListener onSlidingMenuOpenListener = new SlidingMenu.OnOpenListener() {
		@Override
		public void onOpen() {
			// Now update the sliding menu selected item position.
			SliderMenuFragment sliderMenuFragment = (SliderMenuFragment) getSherlockActivity()
					.getSupportFragmentManager().findFragmentById(
							R.id.menu_frame);
			if (sliderMenuFragment != null) {
				sliderMenuFragment.setRowSelected(HomeActivity.POSITION_TAB_LOYALTY_CARD);
			}
		}
	};
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if (mImageViewBarCode != null && getActivity() != null) {
			DisplayMetrics displaymetrics = new DisplayMetrics();
		    getActivity().getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		    int height = displaymetrics.heightPixels;
		    LayoutParams params = mImageViewBarCode.getLayoutParams();
			params.height = (int) (height * 0.3);
		    mImageViewBarCode.setLayoutParams(params);
		}
	}
	
	/**
	 * Call this method from inside of onActiityCreated() (before setting the
	 * values to UI elements) to set the screen UI as list header view. By
	 * adding the view to list header we are providing the pull-down refresh
	 * feature to this screen.
	 * 
	 * @param context
	 *            Context
	 */
	private void addViewToListHeader(Context context) {
		if (mView == null) {
			return;
		}
		LogConfig.logv(LOG_TAG, "addViewToListHeader()");
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		final View headerView = inflater.inflate(R.layout.fragment_display_loyalty_card_detail, null);
		relativeLayout_balance_reward=(RelativeLayout)headerView.findViewById(R.id.relativeLayout_balance_reward);
		relativeLayout_point_expiry=(RelativeLayout)headerView.findViewById(R.id.relativeLayout_point_expiry);
		textView_label_balance_reward= (TextView) headerView.findViewById(R.id.textView_label_balance_reward);
		mTextViewValueBalanceReward = (TextView) headerView.findViewById(R.id.textView_value_balance_reward);
		mTextViewExpiryPoint = (TextView) headerView.findViewById(R.id.textView_value_point_expiry);
		mTextViewCardNumber = (TextView) headerView.findViewById(R.id.textView_label_card_number);
		mImageViewBarCode = (ImageView)	headerView.findViewById(R.id.imageView_barcode_image);
		mTextViewExpiryDays =  (TextView) headerView.findViewById(R.id.textView_label_point_expiry);
		mListView.addHeaderView(headerView);
		mListView.setAdapter(new ArrayAdapter<String>(getActivity(),
				android.R.layout.simple_list_item_1));
	}
}
