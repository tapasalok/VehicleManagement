package com.manthansystems.loyalty.crashinvocation;

import java.lang.Thread.UncaughtExceptionHandler;

import android.content.Context;
import android.os.Debug;
import android.util.Log;

/**
 * @author tapas This class will save log file in the temp folder after
 *         capturing from logcat and deletes it when mail is sent to the email
 *         id
 */
public class CrashInvocationHandler {
	private static final String TAG = CrashInvocationHandler.class
			.getSimpleName();
	private static Context applicationContext;
	private static String emailIdForCrash;

	private static volatile boolean alreadyCrashed = false;

	public static void registerCrashListener(final Context context,
			final String emailId) {
		applicationContext = context.getApplicationContext();
		emailIdForCrash = emailId;
		// NOTE: It does not generate crash reports when you are debugging your
		// app.

		if (!Debug.waitingForDebugger() && !Debug.isDebuggerConnected()) {
			Thread.setDefaultUncaughtExceptionHandler(new UncaughtHandler());
		}
	}

	public static String getEmailAddress() {
		return emailIdForCrash;
	}

	private static class UncaughtHandler implements UncaughtExceptionHandler {
		public void uncaughtException(Thread thread, Throwable ex) {
			try {
				// Avoid infinite loops if crash-reporting
				// crashes.
				if (alreadyCrashed) {
					return;
				}
				alreadyCrashed = true;
				Log.e(TAG, "FATAL EXCEPTION: " + thread.getName(), ex);
				applicationContext.startActivity(CrashInvocationActivity
						.createIntent(applicationContext, ex));

				// Bring up Google feedback
				// showDefaultReportActivity(sAppContext, ex);
			} catch (Throwable t2) {
				try {
					Log.e(TAG, "Error reporting crash", t2);
				} catch (Throwable t3) {
				}
			} finally {
				// Trying everything to make sure this process goes away.
				android.os.Process.killProcess(android.os.Process.myPid());
				System.exit(10);
			}
		}
	}
}
