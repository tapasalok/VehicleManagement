/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.service;

import java.util.Calendar;
import java.util.Observable;
import java.util.Observer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.text.TextUtils;

import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.location.GeoUtils;
import com.manthansystems.loyalty.location.LocationHandler;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.TriggerWorker.TriggerConstants;

/**
 * A {@link Service} class that handles the {@link Location} trigger event flow.
 * Last known location is first checked for its validation in terms of time 
 * and accuracy, if valid then service is reschedule to restart later on and no location
 * trigger takes place, else if its not valid then fresh location update is requested.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class LocationUpdateService extends Service {
	public final String LOG_TAG = "LocationUpdateService";
	
	private LocationHandler mLocationHandler;
	private LocationManager mLocationManager;
	private LocationUpdateListener mLocationUpdateListener;
	private Location mLastKnowLocation;
	private AlarmManager mAlarmManager;
	private PendingIntent mPendingIntentRequestLocationUpdate;
	private Handler mHandler;
	private RequestManager mRequestManager;
	
	@Override
	public void onCreate() {
		LogConfig.logv(LOG_TAG, "onCreate()");
		super.onCreate();
		mLocationHandler = new LocationHandler();
		mLocationUpdateListener = new LocationUpdateListener();
		mLocationManager = (LocationManager) this.getSystemService(
				Context.LOCATION_SERVICE);
		mAlarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
		mHandler = new Handler();
		mRequestManager = RequestManager.from(this);
		
		Intent locationUpdateIntent = new Intent(this, LocationUpdateService.class);
		mPendingIntentRequestLocationUpdate = PendingIntent.getService(this, 0, 
	    		locationUpdateIntent, 0);
		
		// Start logic for location trigger invocation.
		locationUpdateTriggerFlow();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onDestroy() {
		LogConfig.logv(LOG_TAG, "onDestroy()");
		super.onDestroy();
	}
	
	/**
	 * Method to prepare logic for location update trigger. Location update will
	 * only be requested if Location access is permitted by user and the
	 * location provider is set ON. <br><br>Before going for fresh location it checks
	 * for the accuracy of last known location to use the last known location if
	 * is accurate and valid based on time. <br><br>If distance of new location is more
	 * than the last know location then we send a location trigger to our
	 * server.
	 */
	private void locationUpdateTriggerFlow() {
		LogConfig.logv(LOG_TAG, "locationUpdateTriggerFlow()");
		// PRE-CHECK
		// If trigger is disable then do not send trigger event.
		String activeTriggerList = PreferenceConfig.getActiveTriggersList(this);
		if (TextUtils.isEmpty(activeTriggerList)) {
			return;
		}
		// Check if location access is allowed by user and Location provider is ON.
		// If not then there is no need to go for location trigger flow.
		if (!mLocationHandler.getGpsLocationPermissionStatus(this) 
				|| !GeoUtils.isGpsLocationProviderEnabled(this)
				|| !PreferenceConfig.isValidUser(this) 
				|| !activeTriggerList.contains(TriggerConstants.TRIGGER_TYPE_GEO_LOCATION) ) {
			rescheduleServiceStarterAlarm();
			return;
		}
		
		// Check if last known location is valid in terms of time and accuracy.
		// If not valid then request for fresh location or else just reschedule
		// the location updater service to restart later.
		final float oneMile = 1609.344f;
		String geoSignificantDistanceStr = PreferenceConfig.getGeoSignificantDistance(this);
		float minDistance = TextUtils.isEmpty(geoSignificantDistanceStr)?
				BusinessLogicConfig.GPS_SIGNIFICANT_DISTANCE_MILES_THRESHOLD 
				: Integer.parseInt(geoSignificantDistanceStr); // in miles
		minDistance = minDistance * oneMile;  // in meters
		mLastKnowLocation = GeoUtils.getLastBestLocation(this, (int) minDistance, 
				System.currentTimeMillis() - AlarmManager.INTERVAL_FIFTEEN_MINUTES);
		// Request for fresh location update.
		requestLocationUpdate();
	}
	
	/** Request the location updates and if location provider is OFF then it will
	 * removes the location updates, schedules the alarm to restart the location update
	 * service later and stops the current service. */
	private void requestLocationUpdate() {
		LogConfig.logd(LOG_TAG, "requestLocationUpdate()");
		mLocationHandler.addObserver(mLocationUpdateListener);
		int providerStatus = mLocationHandler.register(this.getApplicationContext(),
				mLocationManager);
		if (providerStatus == LocationHandler.LOCATION_PROVIDER_DISABLED) {
			LogConfig.logv(LOG_TAG, "Location update() : Provider Disabled");
			removeLocationUpdate();
			rescheduleServiceStarterAlarm();
		}
	}
	
	/** Remove the location updates. */
	private void removeLocationUpdate() {
		LogConfig.logd(LOG_TAG, "removeLocationUpdate()");
		mLocationHandler.deleteObserver(mLocationUpdateListener);
		mLocationHandler.unregister(mLocationManager);
	}
	
	/**
	 * A location update listener class which implements {@link Observer}, which
	 * listen for location updates. New location will be saved with timestamp.
	 * If distance of old location is more then the new location location
	 * trigger will be sent to our server.
	 * 
	 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
	 * 
	 */
	private class LocationUpdateListener implements Observer {

		@Override
		public void update(final Observable observable, final Object data) {
			removeLocationUpdate();
			if (data instanceof Location) {
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						LogConfig.logv(LOG_TAG, "Location update() : Success");
						locationUpdated((Location) data);
					}
				});
			} else if (data instanceof String) {
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						LogConfig.logv(LOG_TAG, "Location update() : Fails");
						rescheduleServiceStarterAlarm();
					}
				});
				
				// Show location status log for debugging.
				if (LogConfig.DDP_DEBUG_LOGS_ENABLED) {
					final String locationMessage = (String) data;
					if (locationMessage
							.equalsIgnoreCase(LocationHandler.LOCATION_RESULT_INVALID)) {
						LogConfig.logd(LOG_TAG + ": LocationUpdateListener",
								"  location update(): "
										+ LocationHandler.LOCATION_RESULT_INVALID);
					} else if (locationMessage
							.equalsIgnoreCase(LocationHandler.LOCATION_RESULT_TIMEOUT)) {
						LogConfig.logd(LOG_TAG + ": LocationUpdateListener",
								"  location update(): "
										+ LocationHandler.LOCATION_RESULT_TIMEOUT);
					}
				}
			}
		}
	}
	
	/** Method to reschedule the alarm manager to restart the location updater service later
	 * and stops the current service. */
	private void rescheduleServiceStarterAlarm() {
		LogConfig.logv(LOG_TAG, "rescheduleServiceStarterAlarm()");
		// Re-schedule the alarm to start service later.
		Calendar cal = Calendar.getInstance();
		String geoSignificantFrequencyStr = PreferenceConfig.getGeoSignificantFrequency(LocationUpdateService.this);
		int geoSignificantFrequency = !TextUtils.isEmpty(geoSignificantFrequencyStr)?
				 Integer.parseInt(geoSignificantFrequencyStr): (int) AlarmManager.INTERVAL_FIFTEEN_MINUTES; // in Mins.
		long alarmScheduleTime = geoSignificantFrequency * 60 * 1000;  // in Secs.
		// Start service after every defined geo significant frequency.
		mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(),
				alarmScheduleTime, mPendingIntentRequestLocationUpdate);
		stopSelf();
	}

	/**
	 * Method to get called when location update received. If there is no valid
	 * last know location then directly call location trigger or else check the
	 * distance criteria between old and new location. If distance is more than
	 * the criteria then call a location trigger.
	 * @param location New location received from {@link LocationManager}.
	 */
	private void locationUpdated(Location location) {
		LogConfig.logv(LOG_TAG, "locationUpdated()");
		if (mLastKnowLocation == null) {
			LogConfig.logv(LOG_TAG, "locationUpdated(): First Location");
			// call location trigger.
			triggerLocationUpdateWS();
		} else {
			// check the distance criteria between old and new location.
			// If distance is more than the criteria then call a location trigger.
			final float oneMile = 1609.344f;
			String geoSignificantDistanceStr = PreferenceConfig.getGeoSignificantDistance(this);
			float minDistance = TextUtils.isEmpty(geoSignificantDistanceStr)?
					BusinessLogicConfig.GPS_SIGNIFICANT_DISTANCE_MILES_THRESHOLD 
					: Integer.parseInt(geoSignificantDistanceStr); // in miles
			minDistance = minDistance * oneMile;  // in meters
			if (!GeoUtils.isLocationDistanceCriteriaIsValid(location, mLastKnowLocation, minDistance)) {
				LogConfig.logv(LOG_TAG, "locationUpdated(): Distance criteria voilated");
				// call location trigger.
				triggerLocationUpdateWS();
			} else {
				// location distance is under the criteria, no need to generate location trigger.
				// DO NOTHING
				LogConfig.logv(LOG_TAG, "locationUpdated(): location is under distance criteria");
			}
		}
		// Finally reschedule the alarm to restart location update service later.
		rescheduleServiceStarterAlarm();
	}
	
	/** Method to call location trigger network request. */
	private void triggerLocationUpdateWS() {
		LogConfig.logv(LOG_TAG, "triggerLocationUpdateWS()");
		Bundle params = new Bundle();
		params.putByte(TriggerConstants.KEY_NAME_BUNDLE_TRIGGER_WORKER_MODE,
				TriggerConstants.WORKER_MODE_TRIGGER_GEO_LOCATION);
		mRequestManager.triggerEvent(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
}
