/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui.phone;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;

/**
 * An {@link SherlockFragmentActivity} class that will manage bar code scanning.
 * It scans the loyalty card bar code to create virtual loyalty card by sending
 * the card number to our server that intern returns the loyalty card details
 * once successfully created on server.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class ScanBarcodeActivity extends SherlockFragmentActivity
	implements OnSwipeListener {
	
	private CustomSwipeDetector mCustomSwipeDetector;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_scan_barcode);
		mCustomSwipeDetector = new CustomSwipeDetector(this, this);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	public void finish() {
	    super.finish();
	    overridePendingTransition(0, R.anim.translate_slide_right_out);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent me) {
		return mCustomSwipeDetector.onTouchEvent(me);
	}

	@Override
	public void onLeftToRightSwipeDetected() {
		ScanBarcodeActivity.this.finish();
	}

	@Override
	public void onRightToLeftSwipeDetected() {
		// Do Nothing
	}

	@Override
	public void onListItemClicked(int position) {
		// Do Nothing
	}
}
