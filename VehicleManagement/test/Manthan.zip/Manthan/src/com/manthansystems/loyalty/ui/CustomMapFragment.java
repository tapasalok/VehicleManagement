/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import android.os.Bundle;

import com.google.android.gms.maps.SupportMapFragment;

/**
 * A {@link SupportMapFragment} class that is customize to retain the map
 * instance.
 * 
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 * 
 */
public class CustomMapFragment extends SupportMapFragment {

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setRetainInstance(true);
	}
}