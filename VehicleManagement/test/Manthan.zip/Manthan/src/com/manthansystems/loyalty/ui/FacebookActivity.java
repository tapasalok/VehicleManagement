/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;

/**
 * A {@link SherlockFragmentActivity} class that shows the facebook feed sharing screen.
 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
 *
 */
public class FacebookActivity extends SherlockFragmentActivity implements OnSwipeListener {
	
	private CustomSwipeDetector mCustomSwipeDetector;
	
	/**
	 * An interface to holds the key name constants.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	public interface KEY_CONSTANTS {
		public final String FEED_MESSAGE = "com.manthansystems.loyalty.ui.FacebookActivity.feedMessage";
		public final String FEED_NAME = "com.manthansystems.loyalty.ui.FacebookActivity.feedName";
		public final String FEED_CAPTION = "com.manthansystems.loyalty.ui.FacebookActivity.feedCaption";
		public final String FEED_DESCRIPTION = "com.manthansystems.loyalty.ui.FacebookActivity.feedDesc";
		public final String FEED_LINK = "com.manthansystems.loyalty.ui.FacebookActivity.feedLink";
		public final String FEED_PICTURE = "com.manthansystems.loyalty.ui.FacebookActivity.feedPicture";
		public final String COUPON_ID = "com.manthansystems.loyalty.ui.FacebookActivity.couponId";
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facebook);
        mCustomSwipeDetector = new CustomSwipeDetector(this, this);
    }
    
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	public void finish() {
	    super.finish();
	    overridePendingTransition(0, R.anim.translate_slide_right_out);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent me) {
		return mCustomSwipeDetector.onTouchEvent(me);
	}

	@Override
	public void onLeftToRightSwipeDetected() {
		FacebookActivity.this.finish();
	}

	@Override
	public void onRightToLeftSwipeDetected() {
		// Do Nothing
	}

	@Override
	public void onListItemClicked(int position) {
		// Do Nothing
	}
}