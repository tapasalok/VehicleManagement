/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.facebook.FacebookRequestError;
import com.facebook.Request;
import com.facebook.Request.GraphUserCallback;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionLoginBehavior;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphObject;
import com.facebook.model.GraphUser;
import com.facebook.widget.LoginButton;
import com.facebook.widget.ProfilePictureView;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.ui.FacebookActivity.KEY_CONSTANTS;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.TriggerWorker.TriggerConstants;

/**
 * A fragment class to show the facebook feed post screen.
 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
 *
 */
public class FacebookFeedFragment extends SherlockFragment {
	
	@SuppressWarnings("unused")
	private final String TAG = "FacebookFeedFragment" + LogConfig.APP_VER;
	
	private Handler mHandler;
	private UiLifecycleHelper mUiHelper;
    private Session.StatusCallback mCallback = new Session.StatusCallback() {
        @Override
        public void call(final Session session, final SessionState state, final Exception exception) {
//        	Log.v(TAG, "[ Loyalty247 ] mCallback:Call(): session state = " + session.isOpened());
            onSessionStateChange(session, state, exception);
        }
    };
    
	private Button mButtonPublishFeed;
	private EditText mEditTextFeedMessage;
	private TextView mTextViewProfileName;
	private ProfilePictureView mProfilePictureView;
	
	private static final List<String> PERMISSIONS = Arrays.asList("publish_actions");
	
	private String mMessage;
	private String mFeedName;
	private String mFeedCaption;
	private String mFeedDescription;
	private String mFeedLink;
	private String mFeedPicture;
	private String mCouponId;
	private CustomSwipeDetector mCustomSwipeDetector;
	private AlertDialog mAlertDialog;
	
	@Override
	public View onCreateView(LayoutInflater inflater,  ViewGroup container, 
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_facebook, container, false);
        
		mTextViewProfileName = (TextView) view.findViewById(R.id.TextView_greeting);
		mProfilePictureView = (ProfilePictureView) view.findViewById(R.id.profile_pic);
		mProfilePictureView.setCropped(true);
        
		LoginButton authButton = (LoginButton) view.findViewById(R.id.authButton);
		authButton.setFragment(this);
		authButton.setPublishPermissions(PERMISSIONS);
		authButton.setLoginBehavior(SessionLoginBehavior.SUPPRESS_SSO);
		
		mEditTextFeedMessage = (EditText) view.findViewById(R.id.EditText_feedMessage);
		mButtonPublishFeed = (Button) view.findViewById(R.id.shareButton);
		mButtonPublishFeed.setOnClickListener(new View.OnClickListener() {
		    @Override
		    public void onClick(View v) {
		    	UIUtils.hideKeyboard(getActivity(), mEditTextFeedMessage);
		    	publishFeedStatus();       
		    }
		});
		
		if (savedInstanceState != null) {
			mMessage = savedInstanceState.getString(KEY_CONSTANTS.FEED_MESSAGE);
			mFeedName = savedInstanceState.getString(KEY_CONSTANTS.FEED_NAME);
			mFeedCaption = savedInstanceState.getString(KEY_CONSTANTS.FEED_CAPTION);
			mFeedDescription = savedInstanceState.getString(KEY_CONSTANTS.FEED_DESCRIPTION);
			mFeedLink = savedInstanceState.getString(KEY_CONSTANTS.FEED_LINK);
			mFeedPicture = savedInstanceState.getString(KEY_CONSTANTS.FEED_PICTURE);
			mCouponId = savedInstanceState.getString(KEY_CONSTANTS.COUPON_ID);
		} else {
			Bundle bundle = getActivity().getIntent().getExtras();
			if (bundle != null) {
				mMessage = bundle.getString(KEY_CONSTANTS.FEED_MESSAGE);
				mFeedName = bundle.getString(KEY_CONSTANTS.FEED_NAME);
				mFeedCaption = bundle.getString(KEY_CONSTANTS.FEED_CAPTION);
				mFeedDescription = bundle.getString(KEY_CONSTANTS.FEED_DESCRIPTION);
				mFeedLink = bundle.getString(KEY_CONSTANTS.FEED_LINK);
				mFeedPicture = bundle.getString(KEY_CONSTANTS.FEED_PICTURE);
				mCouponId = bundle.getString(KEY_CONSTANTS.COUPON_ID);
			}
		}
		
		mEditTextFeedMessage.setText(mMessage);
		UIUtils.setTitleView(R.string.label_facebook, false, true, false, getSherlockActivity());
		view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return mCustomSwipeDetector.onTouchEvent(event);
            }
        });
		return view;
	}
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mUiHelper = new UiLifecycleHelper(getActivity(), mCallback);
        mUiHelper.onCreate(savedInstanceState);
        mHandler = new Handler();
        mCustomSwipeDetector = new CustomSwipeDetector(getActivity(), (OnSwipeListener) getActivity());
    }

    @Override
    public void onResume() {
        super.onResume();
        
        // For scenarios where the main activity is launched and user
		// session is not null, the session state change notification
		// may not be triggered. Trigger it if it's open/closed.
		Session session = Session.getActiveSession();
		if (session != null &&
				(session.isOpened() || session.isClosed()) ) {
//			Log.v(TAG, "[ Loyalty247 ] onResume(): FB session session.isOpened() = " + session.isOpened());
			onSessionStateChange(session, session.getState(), null);
		} else {
//			Log.v(TAG, "[ Loyalty247 ] onResume(): FB session NULL");
		}
		
        mUiHelper.onResume();
    }
    
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mUiHelper.onActivityResult(requestCode, resultCode, data);
    }
    
    @Override
    public void onPause() {
        super.onPause();
        mUiHelper.onPause();
        ProgressBarHelper.dismissProgressBar(mHandler);
        dismissActiveDialog();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        mUiHelper.onDestroy();
    }
    
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mUiHelper.onSaveInstanceState(outState);
        outState.putString(KEY_CONSTANTS.FEED_MESSAGE, mMessage);
		outState.putString(KEY_CONSTANTS.FEED_NAME, mFeedName);
		outState.putString(KEY_CONSTANTS.FEED_CAPTION, mFeedCaption);
		outState.putString(KEY_CONSTANTS.FEED_DESCRIPTION, mFeedDescription);
		outState.putString(KEY_CONSTANTS.FEED_LINK, mFeedLink);
		outState.putString(KEY_CONSTANTS.FEED_PICTURE, mFeedPicture);
		outState.putString(KEY_CONSTANTS.COUPON_ID, mCouponId);
    }
	
	private void onSessionStateChange(Session session, SessionState state, Exception exception) {
//		Log.v(TAG, "[ Loyalty247 ] onSessionStateChange(): session.isOpened() = " + session.isOpened());
        if (state.isOpened()) {
            mButtonPublishFeed.setVisibility(View.VISIBLE);
            mEditTextFeedMessage.setVisibility(View.VISIBLE);
            if (TextUtils.isEmpty(mTextViewProfileName.getText().toString())) {
            	getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {
						mProfilePictureView.setVisibility(View.VISIBLE);
		            	mTextViewProfileName.setText(
		            			getActivity().getResources().getString(R.string.msg_fb_profile_loading));
					}
				});
            	Request.executeMeRequestAsync(session, new GraphUserCallback() {
					@Override
					public void onCompleted(GraphUser user, Response response) {
						if (user != null) {
							Activity activity = getActivity();
							if (activity != null && mButtonPublishFeed.getVisibility() == View.VISIBLE) {
								mTextViewProfileName.setVisibility(View.VISIBLE);
								String name = String.format(
										activity.getResources().getString(
												R.string.msg_fb_welcome_user), user.getName());
								mTextViewProfileName.setText(name);
								mProfilePictureView.setProfileId(user.getId());
							}
						} else {
							mTextViewProfileName.setText("");
							mTextViewProfileName.setVisibility(View.GONE);
							mProfilePictureView.setProfileId(null);
						}
					}
				});
            }
        } else if (state.isClosed()) {
        	UIUtils.hideKeyboard(getActivity(), mEditTextFeedMessage);
            mButtonPublishFeed.setVisibility(View.GONE);
            mEditTextFeedMessage.setVisibility(View.INVISIBLE);
            mProfilePictureView.setVisibility(View.INVISIBLE);
            mTextViewProfileName.setText("");
        }
    }
	
	/** Method to publish the feed status to user's facebook wall. */
	private void publishFeedStatus() {
		ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
				false, mHandler, getActivity());
		String message = mEditTextFeedMessage.getText().toString().trim();
		Bundle params = new Bundle();
		params.putString("message", message);
        params.putString("name", mFeedName);
        params.putString("caption", mFeedCaption);
        params.putString("description", mFeedDescription);
        params.putString("link", mFeedLink);
        params.putString("picture", mFeedPicture);
        params.putString("actions", "[{\"name\":\"" + getResources().getString(R.string.app_name) + "\",\"link\":\"http://www.manthansystems.com\"}]");
        Request request = Request
        	.newStatusUpdateRequest(Session.getActiveSession(), params, new Request.Callback() {
                @Override
                public void onCompleted(Response response) {
                    showPublishResult(response.getGraphObject(), response.getError());
                }
            });
        request.executeAsync();
	}
	
	private void showPublishResult(GraphObject result, final FacebookRequestError error) {
		ProgressBarHelper.dismissProgressBar(mHandler);
        String title = null;
        String alertMessage = null;
        if (error == null) {
            title = getResources().getString(R.string.dialog_successfully_title);
            alertMessage = getResources().getString(R.string.msg_fb_feed_post_success);
            callShareCouponTriggerWS();
        } else {
            title = getResources().getString(R.string.dialog_error_title);
            alertMessage = error.getErrorMessage();
        }

        if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = new AlertDialog.Builder(getActivity())
        .setTitle(title)
        .setMessage(alertMessage)
        .setPositiveButton(android.R.string.ok, new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (error == null) {
					getActivity().finish();
				}
			}
		}).create();
		mAlertDialog.show();
    }
	
	/** Method to call share coupon trigger network request. */
	private void callShareCouponTriggerWS() {
		String activeTriggerList = PreferenceConfig.getActiveTriggersList(getActivity());
		if (TextUtils.isEmpty(activeTriggerList)) {
			return;
		}
		if (NetworkHelper.isNetworkAvailable(getActivity())
				&& PreferenceConfig.isValidUser(getActivity()) && 
				activeTriggerList.contains(TriggerConstants.TRIGGER_TYPE_COUPON_SHARE)) {
			Bundle params = new Bundle();
			params.putByte(TriggerConstants.KEY_NAME_BUNDLE_TRIGGER_WORKER_MODE,
					TriggerConstants.WORKER_MODE_TRIGGER_SHARE_COUPON);
			params.putString(TriggerConstants.KEY_NAME_BUNDLE_COUPON_ID, 
					mCouponId+"");
			params.putString(TriggerConstants.KEY_NAME_BUNDLE_SHARE_CHANNEL, 
					TriggerConstants.TRIGGER_SHARE_CHANNEL_FACEBOOK);
			RequestManager requestManager = RequestManager.from(getActivity());
			requestManager.triggerEvent(DownloadFormat.RETURN_FORMAT_JSON, params);
		}
	}
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
}
