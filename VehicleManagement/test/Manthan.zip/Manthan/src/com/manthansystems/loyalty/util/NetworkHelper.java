/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */

package com.manthansystems.loyalty.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;

import com.manthansystems.loyalty.ui.OffersFragment;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;

/**
 * A helper class for network operations.
 * @author Rakesh Saytode - rakesh.saytode@xymob.com
 *
 */
public class NetworkHelper {
	
	/**
	 * An interface that holds the various network request type constants.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	public interface REQUEST_TYPE {
		public byte FETCH_OFFERS = 1;
		public byte INITIAL_SYNC_FAVORITE_OFFERS = 2;
		public byte SEND_HOME_ZIP_CODE = 3;
		public byte GET_ALL_CATEGORIES = 4;
		public byte GET_USER_CATEGORIES = 5;
		public byte SEND_USER_CATEGORIES = 6;
		public byte ENABLE_PUSH_NOTIFICATION = 7;
		public byte DISABLE_PUSH_NOTIFICATION = 8;
		public byte GET_APP_CONFIG = 9;
		public byte VALIDATE_USER_ZIP_CODE = 10;
		public byte GET_SESSION_ID = 11;
		public byte GET_OFFER_COUNT = 12;
		public byte DELETE_LOYALTY_CARD = 13;
		public byte ADD_LOYALTY_CARD = 14;
		public byte VIEW_LOYALTY_CARD = 15;
		public byte CHECK_COUPON_REDEMPTION_AVAILABILITY = 16;
		public byte CONFIRM_COUPON_REDEMPTION = 17;
		public byte CHECK_APP_UPDATE = 18;
	}
	
	/**
	 * Invokes to check network availability on device.
	 * @param context Application context
	 * @return True - Yes network is available. <br>False - Network not available.
	 */
	public static boolean isNetworkAvailable(Context context) {
		ConnectivityManager manager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo info = manager.getActiveNetworkInfo();

		// Network is available then return true
		if (info != null && info.isConnectedOrConnecting()) {
			return true;
		}

		// network is not available then return false
		return false;
	}
	
	/**
	 * This will makes http request to the Pontiflex server to check whether it it
	 * up or not.
	 * @return server up status.
	 */
	public static boolean isConnectedtoInternet() {
		try {
			URL url = new URL("http://www.pontiflex.com");
			HttpURLConnection urlConnection = (HttpURLConnection) url
					.openConnection();
			urlConnection.setRequestProperty("User-Agent", "Mozilla 1.0");
			urlConnection.setRequestProperty("Connection", "close");
			urlConnection.setConnectTimeout(1000 * 10); // mTimeout is in
			urlConnection.setReadTimeout(1000 * 5);
			// seconds
			urlConnection.connect();
			if (urlConnection.getResponseCode() == 200) {
				return true;
			}
		} catch (MalformedURLException e1) {
		} catch (IOException e) {
		}
		return false;
	}
	
	/** Method to encode the last part of url which may contains the file name with space
	 * or character encoded. */
	public static String getEncodedUrl(final String url) {
		if (TextUtils.isEmpty(url)) {
			return url;
		}
		int index = url.lastIndexOf("/");
		if (index == -1) {
			return url;
		}
		String lastPart = url.substring(index + 1, url.length());
		String urlPart = url.substring(0, index + 1);
		try {
			lastPart = URLDecoder.decode(lastPart, "UTF-8");
			return urlPart + URLEncoder.encode(lastPart, "UTF-8");
		} catch (UnsupportedEncodingException e) {
		}
		return url;
	}
}

