package com.manthansystems.loyalty.util;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

public class ToastHelper {
	public static void showToastMessage(int messageResId, Context context, boolean alignCenter) {
		Toast toast = Toast.makeText(context,
				context.getResources().getString(messageResId),
				Toast.LENGTH_SHORT);
		if (alignCenter) {
			toast.setGravity(Gravity.CENTER, 0, 0);
		}
		toast.show();
	}

	public static void showToastMessage(String message, Context context, boolean alignCenter) {
		Toast toast = Toast.makeText(context, message, Toast.LENGTH_SHORT);
		if (alignCenter) {
			toast.setGravity(Gravity.CENTER, 0, 0);
		}
		toast.show();
	}
}


