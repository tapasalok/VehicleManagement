/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.ui.FacebookActivity;

/**
 * A helper class for social sharing operations.
 * @author Rakesh Saytode - rakesh.saytode@xymob.com
 *
 */
public class ShareHelper {

	/** Method to publish the facebook feed on user's wall. */
	public static void publishFacebookFeed(Context context, Bundle params) {
		Intent intent = new Intent(context, FacebookActivity.class);
		intent.putExtras(params);
		context.startActivity(intent);
	}
	
	/** Method to send email to supplied recipients email ids. */
	public static void sendEmail(Context context, String to[], String cc[], String bcc[],
			String subject, CharSequence bodyText) {
		final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		emailIntent.setType("plain/text"); // For Emulator 
		emailIntent.setType("message/rfc822"); // For Device
		emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, to);
		emailIntent.putExtra(android.content.Intent.EXTRA_CC, cc);
		emailIntent.putExtra(android.content.Intent.EXTRA_BCC, bcc);
		emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);
		emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, bodyText);
		context.startActivity(Intent.createChooser(emailIntent, 
				context.getResources().getString(R.string.title_send_email)));
	}
	
	/** Method to validate the email address given as parameter to this method. */
	public static boolean isValidEmail(String email) {
		Pattern p = Pattern.compile(
				"^[a-z0-9,!#\\$%&'\\*\\+/=\\?\\^_`\\{\\|}~-]+(\\.[a-z0-9,!#\\$%&'\\*\\+/=\\?\\^_`\\{\\|}~-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*\\.([a-z]{2,})$");
		Matcher matcher = p.matcher(email);
		return matcher.matches();
	}
}
