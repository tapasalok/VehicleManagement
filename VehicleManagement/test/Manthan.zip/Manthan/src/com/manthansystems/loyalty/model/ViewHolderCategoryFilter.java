/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

import android.database.Cursor;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDao;
import com.manthansystems.loyalty.util.UIUtils;

/**
 * A view holder class that holds the row elements of store list item.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class ViewHolderCategoryFilter implements BaseViewHolder {

	@SuppressWarnings("unused")
	private int mPosition;
	@SuppressWarnings("unused")
	private int mSelectedPosition;
	
	private TextView mTextViewCategoryName;
	public TextView mTextViewCategoryCount;
	public CheckBox mCheckBoxCategory;
	
	/** Paramterised constructor. */
	public ViewHolderCategoryFilter(final View view) {
		bindViews(view);
	}
	
	/** Method to bind the views from the row layout. */
	private void bindViews(View view) {
		mTextViewCategoryName = (TextView) view.findViewById(R.id.textView_category_name);
		mTextViewCategoryCount = (TextView) view.findViewById(R.id.textView_category_item_count);
		mCheckBoxCategory = (CheckBox) view.findViewById(R.id.checkBox_select_category);
	}
	
	@Override
	public void populateView(Cursor inCursor, View view) {
		view.setBackgroundDrawable(UIUtils.getListRowBgGradientDrawable(view));
		String categoryName = inCursor.getString(CategoryDao.CONTENT_CATEGORY_NAME_COLUMN);
		if (TextUtils.isEmpty(categoryName)) {
			mTextViewCategoryName.setText("");
		} else {
			mTextViewCategoryName.setText(categoryName);
		}
	}
	
	@Override
	public void setRowPosition(int position, int selectedPosition) {
		mPosition = position;
		mSelectedPosition = selectedPosition;
	}

	@Override
	public ImageView getFavoriteIconView() {
		return null;
	}

	@Override
	public ImageView getOfferIconView() {
		return null;
	}
}
