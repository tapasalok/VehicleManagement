/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.config;

/**
 * A configuration interface that holds constants that used for database data chooser types
 * and to hold the query tokens.
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 *
 */
public interface DatabaseConfig {
	public final int QUERY_TOKEN_COMMON_OFFER_LIST = 1;
	public final int QUERY_TOKEN_COMMON_OFFER_SEARCH_LIST = 2;
	public final int QUERY_TOKEN_FAVORITE_OFFER_LIST = 3;
	public final int QUERY_TOKEN_CATEGORIES_LIST = 4;
	public final int QUERY_TOKEN_STORE_LIST = 5;
	public final int QUERY_TOKEN_MYOFFER_LIST = 6;
	public final int QUERY_TOKEN_MYOFFER_SEARCH_LIST = 7;
	public final int QUERY_TOKEN_FAVORITE_OFFER_SEARCH_LIST = 8;
	
	public final int DB_OFFER_TYPE_FAVORITE = 1;
	public final int DB_OFFER_TYPE_COMMON = 2;
	public final int DB_OFFER_TYPE_PERSONAL = 3;
}
