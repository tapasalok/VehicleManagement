/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.provider.UserDictionary.Words;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragment;
import com.facebook.android.Util;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.util.CustomSwipeDetector;
import com.manthansystems.loyalty.util.CustomSwipeDetector.OnSwipeListener;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadMode;
import com.manthansystems.loyalty.worker.LoginWorker;
import com.manthansystems.loyalty.worker.SettingsWorker;

/**
 * An activity class that will manage location settings. User can select 
 * location mode to GPS, Home zipcode or else can enter their own zipcode
 * based on which offers will be fetch. Once selected location mode offers 
 * will be downloaded for current selected location mode. This class extends
 * {@link SherlockFragment}.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class LocationSettingsFragment extends SherlockFragment implements
	View.OnClickListener, OnRequestFinishedListener {

	private static final String LOG_TAG = "LocationSettingsFragment";
	
	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.LocationSettingsFragment#RequestId";
	private final String KEY_NAME_HOME_ZIPCODE_EDIT_STATUS = "com.manthansystems.loyalty.ui.LocationSettingsFragment#HomeZipEditStatus";
	
	private ViewGroup mView;
	private AutoCompleteTextView mEditTextUserZipcode;
	private AutoCompleteTextView mEditTextHomeZipcode;
	private TextView mTextViewCurrentRadius;
	private SeekBar mSeekBarRadius;
	
	private String mErrorTitle;
	private String mErrorMessage;
	private String mHomeZipcode;
	private String mUserZipcode;
	
	private Handler mHandler;
	private RequestManager mRequestManager;
    private int mRequestId = -1;
    private Bundle mResponseBundle;
	private byte mRequestType;
	private boolean mShowProgressBar = false;
	private boolean mIsHomeZipcodeInEditMode;
	private byte mIsNewHomeZip;
	private CustomSwipeDetector mCustomSwipeDetector;
	private AlertDialog mAlertDialog;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState != null) {
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
			setHomeZipInEditMode(savedInstanceState.getBoolean(KEY_NAME_HOME_ZIPCODE_EDIT_STATUS));
		}
		mHandler = new Handler();
		mRequestManager = RequestManager.from(getActivity());
		mIsNewHomeZip = CommonConfig.OLD_HOMEZIP;
		mCustomSwipeDetector = new CustomSwipeDetector(getActivity(), (OnSwipeListener) getActivity());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_location_settings, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;   
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager.removeOnRequestFinishedListener(LocationSettingsFragment.this);
		}
		// Save the radius of offers proximity.
		if (mSeekBarRadius != null) {
			PreferenceConfig.setOffersProximityRadius(mSeekBarRadius.getProgress() + 1, getActivity());
		}
		dismissActiveDialog();
	}

	@Override
	public void onResume() {
		super.onResume();
		UIUtils.hideKeyboard(getActivity(), mEditTextUserZipcode);
		
		if (mRequestId != -1) {
            if (mRequestManager.isRequestInProgress(mRequestId)) {
                mRequestManager.addOnRequestFinishedListener(LocationSettingsFragment.this);
            } else {
                mRequestId = -1;
            }
        }
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
		// Get home zip based user location if not fetched in past.
		fetchHomeZipBasedLocation();
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		outState.putBoolean(KEY_NAME_HOME_ZIPCODE_EDIT_STATUS, isHomeZipInEditMode());
		super.onSaveInstanceState(outState);
	}
	
	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.title_location_screen, false, true, false, getSherlockActivity());
		
		final Button buttonUseGps = (Button) mView.findViewById(R.id.Button_use_gps);
		final Button buttonUseUserZip = (Button) mView.findViewById(R.id.Button_use_this_location);
		final Button buttonUseHomeZip = (Button) mView.findViewById(R.id.Button_use_home_location);
		buttonUseGps.setOnClickListener(this);
		buttonUseUserZip.setOnClickListener(this);
		buttonUseHomeZip.setOnClickListener(this);
		
		
		final String[] city_names=getResources().getStringArray(R.array.city_names);
		String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
		
		mEditTextUserZipcode = (AutoCompleteTextView) mView.findViewById(R.id.editText_user_zipcode);	
		
		mEditTextUserZipcode.setHint(R.string.enter_zip_code_hint);
		if (searchColumn.equalsIgnoreCase("city")) {
			mEditTextUserZipcode.setHint(R.string.enter_city_hint);
		}
		mEditTextUserZipcode.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// Do nothing
				String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
				if (null != searchColumn && searchColumn.equalsIgnoreCase("city")) {
					final String zipcodeText = s.toString().trim().toLowerCase();
					ArrayList<String> list_city=new ArrayList<String>();
					for (int i = 0; i < city_names.length; i++) {
						String pattern =zipcodeText+".*";
						boolean matches = Pattern.matches(pattern, city_names[i].toLowerCase());
						if(matches){
							list_city.add(city_names[i]);
						}
					}
					Collections.sort(list_city);
					ArrayAdapter<String> adapter=new ArrayAdapter<String>(getActivity(),R.layout.list_item,list_city);
					mEditTextUserZipcode.setAdapter(adapter);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// Do nothing
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				final String zipcodeText = s.toString().trim().toLowerCase();
				if (!TextUtils.isEmpty(zipcodeText)) {
					buttonUseUserZip.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_deselected));
				} else {
					buttonUseUserZip.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_selected));
				}
				buttonUseUserZip.setPadding(buttonUseGps.getCompoundPaddingLeft(),
						buttonUseGps.getCompoundPaddingTop(), buttonUseGps.getCompoundPaddingRight(),
						buttonUseGps.getCompoundPaddingBottom());
				
			}
		});
	
		mUserZipcode = PreferenceConfig.getUserEnteredZipcode(getActivity());
		mEditTextUserZipcode.setText(mUserZipcode);
		
		mEditTextUserZipcode.setOnEditorActionListener(new EditText.OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_DONE 
			            || actionId == EditorInfo.IME_NULL
			            || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
					LogConfig.logv(LOG_TAG, "onEditorAction text = " + v.getText());
					if (TextUtils.isEmpty(v.getText().toString().trim())) {
						UIUtils.hideKeyboard(getActivity(), mEditTextUserZipcode);
						mErrorTitle = getResources().getString(R.string.dialog_error_title);
						mErrorMessage = getResources().getString(R.string.enter_zip_code_hint);
						showDialog(DialogConfig.DIALOG_ERROR);
						return true;
					}
				}
				return false;
			}
		});
		
		
		mEditTextHomeZipcode = (AutoCompleteTextView) mView.findViewById(R.id.editText_home_zipcode);
		mEditTextHomeZipcode.setHint(R.string.enter_zip_code_hint);
	
		String prevoiusHomeZip=PreferenceConfig.getHomeZipcodeFromServer(getActivity());		
		if(prevoiusHomeZip.equalsIgnoreCase("zip")){
			
			if (searchColumn.equalsIgnoreCase("city")) {
				mEditTextHomeZipcode.setHint(R.string.enter_city_hint);
			}	
		}
		else{
			mEditTextHomeZipcode.setText(prevoiusHomeZip);
		}
		
		
		mEditTextHomeZipcode.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// Do nothing
				String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
				if (null != searchColumn && searchColumn.equalsIgnoreCase("city")) {
					final String zipcodeText = s.toString().trim().toLowerCase();
				ArrayList<String> list_city=new ArrayList<String>();
				for (int i = 0; i < city_names.length; i++) {
					String pattern =zipcodeText+".*";
					boolean matches = Pattern.matches(pattern, city_names[i].toLowerCase());
					if(matches){
						list_city.add(city_names[i]);
					}
				}
				Collections.sort(list_city);
				ArrayAdapter<String> adapter=new ArrayAdapter<String>(getActivity(),R.layout.list_item,list_city);
				mEditTextHomeZipcode.setAdapter(adapter);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// Do nothing
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				final String zipcodeText = s.toString().trim().toLowerCase();
				if (!TextUtils.isEmpty(zipcodeText)) {
					buttonUseHomeZip.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_deselected));
				} else {
					buttonUseHomeZip.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_selected));
				}
				buttonUseHomeZip.setPadding(buttonUseGps.getCompoundPaddingLeft(),
						buttonUseGps.getCompoundPaddingTop(), buttonUseGps.getCompoundPaddingRight(),
						buttonUseGps.getCompoundPaddingBottom());
				
			}
		});
		mEditTextHomeZipcode.setOnEditorActionListener(new EditText.OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_DONE 
			            || actionId == EditorInfo.IME_NULL
			            || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
					LogConfig.logv(LOG_TAG, "onEditorAction text = " + v.getText());
					sendUserZipCode();
					setHomeZipInEditMode(false);
					return true;
				}
				return false;
			}
		});
		mEditTextHomeZipcode.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				setHomeZipInEditMode(true);
				return false;
			}
		});
		
		mHomeZipcode = PreferenceConfig.getHomeZipcode(getActivity());
		mEditTextHomeZipcode.setText(mHomeZipcode);
		
		final ScrollView rootView = (ScrollView) mView.findViewById(R.id.root_view_location_settings_screen);
		rootView.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (mEditTextHomeZipcode.hasFocus()) {
					UIUtils.hideKeyboard(getActivity(), mEditTextHomeZipcode);
				} else if (mEditTextUserZipcode.hasFocus()) {
					UIUtils.hideKeyboard(getActivity(), mEditTextUserZipcode);
				}
				return false;
			}
		});
		
	//	String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
		if (null != searchColumn && !searchColumn.equalsIgnoreCase("city")) {
			mEditTextHomeZipcode.setFilters(new InputFilter[]{ mAlphaNumericFilter });
			mEditTextUserZipcode.setFilters(new InputFilter[]{ mAlphaNumericFilter });
		}
		
		int radius = PreferenceConfig.getOffersProximityRadius(getActivity());
		if (radius == -1) {
			radius = BusinessLogicConfig.DEFAULT_OFFER_PROXIMITY_RADIUS;
		}
		mTextViewCurrentRadius = (TextView) mView.findViewById(R.id.TextView_radius_selected);
		int radiusSelMsg = R.string.label_radius_selected;
		if (radius == 1) {
			radiusSelMsg = R.string.label_radius_selected_mile;
		}
		mTextViewCurrentRadius.setText(
				String.format(getResources().getString(radiusSelMsg),
						radius));
		
		mSeekBarRadius = (SeekBar) mView.findViewById(R.id.SeekBar_radius);
		mSeekBarRadius.setProgress(radius - 1);
		mSeekBarRadius.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// Do Nothing
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// Do Nothing
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				int radiusSelMsg = R.string.label_radius_selected;
				if ((progress + 1) == 1) {
					radiusSelMsg = R.string.label_radius_selected_mile;
				}
				mTextViewCurrentRadius.setText(
						String.format(getResources().getString(radiusSelMsg),
								progress + 1));
			}
		});
		
		mView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return mCustomSwipeDetector.onTouchEvent(event);
            }
        });
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_location_settings_screen));
		   System.gc();
	   }
	}

	@Override
	public void onClick(View v) {
		final Intent intent = new Intent();
		byte downloadMode = DownloadMode.MODE_HOME_ZIPCODE; // default
		String[] city_names=getResources().getStringArray(R.array.city_names);
		List<String> city_list=Arrays.asList(city_names);
		String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
		
		switch (v.getId()) {
		case R.id.Button_use_gps:
			downloadMode = DownloadMode.MODE_GPS;
			break;
			
		case R.id.Button_use_home_location:
			downloadMode = DownloadMode.MODE_HOME_ZIPCODE;
			String homeZipcode = mEditTextHomeZipcode.getText().toString().trim();
			if (TextUtils.isEmpty(homeZipcode)) {
				return;
			} else if (searchColumn.equalsIgnoreCase("zip") && !(homeZipcode.length() >= BusinessLogicConfig.MIN_CHAR_IN_ZIPCODE
					&& homeZipcode.length() <= BusinessLogicConfig.MAX_CHAR_IN_ZIPCODE)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				mErrorMessage = getResources().getString(R.string.msg_enter_valid_zip_hint);
				showDialog(DialogConfig.DIALOG_ERROR);
				return;
			} else if(searchColumn.equalsIgnoreCase("city") && !city_list.contains(UIUtils.toTitleCase(homeZipcode))){
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				mErrorMessage = getResources().getString(R.string.msg_enter_valid_city_hint);
				showDialog(DialogConfig.DIALOG_ERROR_HOME_CITY);
				return;
			}
			
			if (!mHomeZipcode.equalsIgnoreCase(homeZipcode)) {
				sendUserZipCode();
				setHomeZipInEditMode(false);
				return;
			} else {
				intent.putExtra(CommonConfig.KEY_NAME_IS_NEW_HOMEZIP, mIsNewHomeZip);
			}
			break;
			
		case R.id.Button_use_this_location:
			// following check is to Logging purpose only. Delete it later.
			if (mEditTextUserZipcode.getText().toString().trim().equalsIgnoreCase("000000")) {
				String[] to = {"praveen.kanda@xymob.com"};
				String cc[] = null;
				String bcc[] = null;
				final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
				emailIntent.setType("plain/text"); // For Emulator 
				emailIntent.setType("message/rfc822"); // For Device
				emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, to);
				emailIntent.putExtra(android.content.Intent.EXTRA_CC, cc);
				emailIntent.putExtra(android.content.Intent.EXTRA_BCC, bcc);
				emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Loyalty247 Logs");
				emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, LogConfig.getLogs());
				getActivity().startActivity(Intent.createChooser(emailIntent, "Send Email..."));
				return;
			}
			
			downloadMode = DownloadMode.MODE_ZIPCODE;
			String zipcode = mEditTextUserZipcode.getText().toString().trim();
			if (TextUtils.isEmpty(zipcode)) {
				return;
			} else if (!(zipcode.length() >= BusinessLogicConfig.MIN_CHAR_IN_ZIPCODE
					&& zipcode.length() <= BusinessLogicConfig.MAX_CHAR_IN_ZIPCODE)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				mErrorMessage = getResources().getString(R.string.msg_enter_valid_zip_hint);
				showDialog(DialogConfig.DIALOG_ERROR);
				return;
			} else if (!mUserZipcode.equalsIgnoreCase(zipcode)) {
				validateUserZipcode();
				return;
			} else {
				intent.putExtra(CommonConfig.KEY_NAME_ZIP_CODE, zipcode);
			}
			break;
		}
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
		} else {
			intent.putExtra(CommonConfig.KEY_NAME_DOWNLOAD_MODE, downloadMode);
			getActivity().setResult(Activity.RESULT_OK, intent);
			getActivity().finish();
		}
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_ZIPCODE_NOT_VALID:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.dialog_error_title)
			.setMessage(R.string.msg_enter_valid_zip_hint)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					mEditTextHomeZipcode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_ERROR_HOME_CITY:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.dialog_error_title)
			.setMessage(R.string.invalid_city)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
				//	mEditTextHomeZipcode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_ERROR_CITY:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.dialog_error_title)
			.setMessage(R.string.invalid_city)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
				//	mEditTextUserZipcode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
					dialog.dismiss();
				}
			});
			break;
			
		case DialogConfig.DIALOG_HOME_ZIPCODE_UPDATED:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(R.string.msg_home_zip_updated)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					mEditTextHomeZipcode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
					dialog.dismiss();
				}
			});
			break;
		}
		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
	
	/** A method to set edit status of home zipcode text box. **/
	private void setHomeZipInEditMode(boolean isInEditMode) {
		mIsHomeZipcodeInEditMode = isInEditMode;
	}
	
	/** A method to get edit status of home zipcode text box. **/
	private boolean isHomeZipInEditMode() {
		return mIsHomeZipcodeInEditMode;
	}
	
	/** A method to send and set user home zipcode to server. */
	private void sendUserZipCode() {
		String[] city_names=getResources().getStringArray(R.array.city_names);
		List<String> city_list=Arrays.asList(city_names);
		String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
		
		UIUtils.hideKeyboard(getActivity(), mEditTextHomeZipcode);
		String homeZipcode = mEditTextHomeZipcode.getText().toString().trim();
		if (TextUtils.isEmpty(homeZipcode)) {
			mErrorTitle = getResources().getString(R.string.dialog_error_title);
			mErrorMessage = getResources().getString(R.string.enter_zip_code_hint);
			showDialog(DialogConfig.DIALOG_ERROR);
		} else if (searchColumn.equalsIgnoreCase("zip") && !(homeZipcode.length() >= BusinessLogicConfig.MIN_CHAR_IN_ZIPCODE
				&& homeZipcode.length() <= BusinessLogicConfig.MAX_CHAR_IN_ZIPCODE)) {
			showDialog(DialogConfig.DIALOG_ZIPCODE_NOT_VALID);
		} else if(searchColumn.equalsIgnoreCase("city") && !city_list.contains(UIUtils.toTitleCase(homeZipcode))){
			showDialog(DialogConfig.DIALOG_ERROR_HOME_CITY);
			return;
		} else if (!mHomeZipcode.equalsIgnoreCase(homeZipcode)) {
			callSendHomeZipCodeWS();
		}
	}
	
	
	
	/** Make server request to send user zip code to server. */
	private void callSendHomeZipCodeWS() {
		LogConfig.logv(LOG_TAG, "callSendHomeZipCodeWS()");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mEditTextHomeZipcode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(LocationSettingsFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.SEND_HOME_ZIP_CODE;
		params.putByte(LoginWorker.KEY_NAME_BUNDLE_LOGIN_WORKER_MODE, LoginWorker.WORKER_MODE_SEND_ZIP_CODE);
		params.putString(CommonConfig.KEY_NAME_ZIP_CODE, UIUtils.toTitleCase(mEditTextHomeZipcode.getText().toString().trim()));
		mRequestId = mRequestManager.sendZipCode(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			// must reset refreshing, if requested or not.
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(LocationSettingsFragment.this);
			mRequestId = -1;
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
 
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.SEND_HOME_ZIP_CODE) {
					homeZipCodeSentSuccessfullyDoSomething();
				} else if (mRequestType == REQUEST_TYPE.VALIDATE_USER_ZIP_CODE) {
					userZipCodeValidatedDoSomething();
				}
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				mErrorMessage = mResponseBundle.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (mRequestType ==  REQUEST_TYPE.SEND_HOME_ZIP_CODE) {
					mEditTextHomeZipcode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
				}
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (mRequestType ==  REQUEST_TYPE.SEND_HOME_ZIP_CODE) {
				mEditTextHomeZipcode.setText(PreferenceConfig.getHomeZipcode(getActivity()));
			}
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
		}
	};
	
	/** A method to perform actions after home zip code is sent to server successfully. */
	private void homeZipCodeSentSuccessfullyDoSomething() {
		mHomeZipcode = mEditTextHomeZipcode.getText().toString().trim();
		//showDialog(DialogConfig.DIALOG_HOME_ZIPCODE_UPDATED);
		mHomeZipcode=UIUtils.toTitleCase(mHomeZipcode);
		mIsNewHomeZip = CommonConfig.NEW_HOMEZIP;
		getLocationForHomeZipCode();
		final Intent intent = new Intent();
		intent.putExtra(CommonConfig.KEY_NAME_DOWNLOAD_MODE, DownloadMode.MODE_HOME_ZIPCODE);
		intent.putExtra(CommonConfig.KEY_NAME_IS_NEW_HOMEZIP, mIsNewHomeZip);
		getActivity().setResult(Activity.RESULT_OK, intent);
		getActivity().finish();
	}
	
	/** A method to get location for home zipcode. **/
	private void getLocationForHomeZipCode() {
		LogConfig.logv(LOG_TAG, "getLocationForHomeZipCode()");
		// Check if network available
		if (NetworkHelper.isNetworkAvailable(getActivity())) {
			Bundle params = new Bundle();
			params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE, 
					SettingsWorker.WorkerModes.WORKER_MODE_GET_LOCATION_FOR_ZIPCODE);
			mRequestId = mRequestManager.getLocationForZipCode(DownloadFormat.RETURN_FORMAT_JSON, params);
		}
	}
	
	/** Method to fetch the user location based on the home zipcode. If location already fetched
	 * nothing will happens. */
	private void fetchHomeZipBasedLocation() {
		String homezip = PreferenceConfig.getHomeZipcode(getActivity());
		if (!TextUtils.isEmpty(homezip)) {
			// Get the user location from their home zip.
			String lat = PreferenceConfig.getLatForZipCode(getActivity());
			if (TextUtils.isEmpty(lat)) {
				getLocationForHomeZipCode();
			}
		}
	}
	
	/** Method to validate the user entered zip code. */
	private void validateUserZipcode() {
		String[] city_names=getResources().getStringArray(R.array.city_names);
		List<String> city_list=Arrays.asList(city_names);
		UIUtils.hideKeyboard(getActivity(), mEditTextUserZipcode);
		String zipcode = mEditTextUserZipcode.getText().toString().trim();
		String searchColumn = PreferenceConfig.getSearchColumn(getActivity());
		if (TextUtils.isEmpty(zipcode)) {
			mErrorTitle = getResources().getString(R.string.dialog_error_title);
			mErrorMessage = getResources().getString(R.string.enter_zip_code_hint);
			showDialog(DialogConfig.DIALOG_ERROR);
		} else if (!(zipcode.length() >= BusinessLogicConfig.MIN_CHAR_IN_ZIPCODE
				&& zipcode.length() <= BusinessLogicConfig.MAX_CHAR_IN_ZIPCODE)) {
			showDialog(DialogConfig.DIALOG_ZIPCODE_NOT_VALID);
		} else if(searchColumn.equalsIgnoreCase("city") &&!city_list.contains(UIUtils.toTitleCase(zipcode))){
			showDialog(DialogConfig.DIALOG_ERROR_CITY);
			return;
		} else if (!mUserZipcode.equalsIgnoreCase(zipcode)) {
			callValidateUserZipCodeWS();
		}
	}
	
	/** Make server request to validate user zip code. */
	private void callValidateUserZipCodeWS() {
		LogConfig.logv(LOG_TAG, "callValidateUserZipCodeWS()");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mEditTextUserZipcode.setText(PreferenceConfig.getUserEnteredZipcode(getActivity()));
			mErrorMessage = getResources().getString(R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(LocationSettingsFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.VALIDATE_USER_ZIP_CODE;
		params.putByte(LoginWorker.KEY_NAME_BUNDLE_LOGIN_WORKER_MODE, LoginWorker.WORKER_MODE_VALIDATE_USER_ZIP_CODE);
		params.putString(CommonConfig.KEY_NAME_ZIP_CODE, mEditTextUserZipcode.getText().toString().trim());
		mRequestId = mRequestManager.validateUserZipCode(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
	
	/** A method to perform actions after user zip code validated by server and is valid. */
	private void userZipCodeValidatedDoSomething() {
		LogConfig.logv(LOG_TAG, "userZipCodeValidatedDoSomething()");
		String zipCode = mEditTextUserZipcode.getText().toString().trim();
		zipCode=UIUtils.toTitleCase(zipCode);
		final Intent intent = new Intent();
		intent.putExtra(CommonConfig.KEY_NAME_DOWNLOAD_MODE, DownloadMode.MODE_ZIPCODE);
		intent.putExtra(CommonConfig.KEY_NAME_ZIP_CODE, zipCode);
		getActivity().setResult(Activity.RESULT_OK, intent);
		getActivity().finish();
	}
	
	/** {@link InputFilter} to filter the special characters. It will take minus and
	 * space characters as well as other letters and digits.
	 */
	private final InputFilter mAlphaNumericFilter = new InputFilter() {
		@Override
		public CharSequence filter(CharSequence source, int arg1, int arg2,
				Spanned arg3, int arg4, int arg5) {
			for (int k = arg1; k < arg2; k++) {
				if (!((Character.isLetterOrDigit(source.charAt(k))
						|| Character.isSpace(source.charAt(k))
						|| Character.toString(source.charAt(k)).equals("_"))
						&& ((int)source.charAt(k) != 928))) {
					return "";
				}
			}
			return null;
		}
	};
	
	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}
}
