/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import static com.manthansystems.loyalty.CommonUtilities.DISPLAY_MESSAGE_ACTION;
import static com.manthansystems.loyalty.CommonUtilities.EXTRA_MESSAGE;
import static com.manthansystems.loyalty.CommonUtilities.SENDER_ID;

import java.util.Random;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.google.android.gcm.GCMRegistrar;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.ServerUtilities;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.PreferenceConfig.PreferenceConstants;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.OffersFragment.OfferNotificationType;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.ui.phone.EnterHomeZipCodeActivity;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.LoginWorker;
import com.manthansystems.loyalty.worker.SettingsWorker;

/**
 * A base activity that displays Splash of the application for few seconds
 * every time the application launches.
 * 
 * @author Rakesh Saytode (rakesh.saytode@xymob.com)
 *
 */
public class SplashActivity extends SherlockFragmentActivity
		implements OnRequestFinishedListener {

	private static final String LOG_TAG = "SplashActivity";
	private static final long mUptimeMillis = 3000;
	private AsyncTask<Void, Void, Void> mRegisterTask;
	private ProgressBar mProgressBarLoading;
	private Handler mHandler;
	private RequestManager mRequestManager;
	private int mRequestId = -1;
    private static byte mRequestType;
    @SuppressWarnings("unused")
	private String mDialogMessage;
    private Bundle mResponseBundle;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
     	// Initialise the app version for logging.
        LogConfig.APP_VER = getResources().getString(R.string.version_name);
        LogConfig.logd(LOG_TAG, "onCreate()");
        mRequestManager = RequestManager.from(this);
        mHandler = new Handler();
        mProgressBarLoading = (ProgressBar) findViewById(R.id.progressbar_loading);
        mProgressBarLoading.setProgress(30);
        callGetSessionIdWS();
        final TextView appVersion = (TextView) findViewById(R.id.TextView_version);
        appVersion.setText(String.format(getResources().getString(R.string.label_app_version),
        		getResources().getString(R.string.client_version)));
        
        final TextView poweredBy = (TextView) findViewById(R.id.TextView_powered_by);
        poweredBy.setText(getResources().getString(R.string.label_powered_by));
        boolean isOptionalUpdate = false;
		String updateType = PreferenceConfig.getAppUpdateType(this);
		if (!TextUtils.isEmpty(updateType)
				&& updateType.equalsIgnoreCase(BusinessLogicConfig.APP_UPDATE_TYPE_OPTIONAL)) {
			isOptionalUpdate = true;
		}
        if (PreferenceConfig.isAppUpdateAvailable(this) && !isOptionalUpdate) {
        	showCustomDialog(DialogConfig.DIALOG_UPGRADE_APP);
        } else if (!PreferenceConfig.isAppUpdateChecked(this)) {
        	callCheckAppUpdateWS();
        } else {
        	callGetAppConfigWS();
        }
        registerForPushNotification();
        // Check if app launch via notification click,
        Bundle extras = getIntent().getExtras();
	    if (extras != null) {
	        if (extras.containsKey(HomeActivity.KEY_EXTRA_STRING_NOTIFICATION_CLICKED)) {
	        	LogConfig.logv(LOG_TAG, "onCreate(): Notification clicked");
	        	PreferenceConfig.setIsLaunchFromNotification(true, SplashActivity.this);
	        	if (PreferenceConfig.getLaunchScreenFromNotification(SplashActivity.this)
	        			.equalsIgnoreCase(OfferNotificationType.PERSONAL_OFFER)) {
	    			PreferenceConfig.setPersonalOffersTimestamp(0L, SplashActivity.this);
	    		} else {
	    			PreferenceConfig.setCommonOffersTimestamp(0L, SplashActivity.this);
	    		}
	        } else {
	        	LogConfig.logv(LOG_TAG, "onCreate(): Notification Not clicked");
	        }
	    }
	    
//	    Setting default GPS Status
	    PreferenceConfig.setDefaultGPSStatus(this);
	}

	@Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        boolean isOptionalUpdate = false;
		String updateType = PreferenceConfig.getAppUpdateType(this);
		if (!TextUtils.isEmpty(updateType)
				&& updateType.equalsIgnoreCase(BusinessLogicConfig.APP_UPDATE_TYPE_OPTIONAL)) {
			isOptionalUpdate = true;
		}
        if (!PreferenceConfig.isAppUpdateAvailable(this) || isOptionalUpdate) {
//        	rakesh setTimerToLaunchNextActivity();
            startProgressBarThread();
        }
        logAvailableMemorySize();
    }
	
	/** Method to launch next screen after splash screen. */
	private void setTimerToLaunchNextActivity() {
		LogConfig.logv(LOG_TAG, "setTimerToLaunchNextActivity()");
		mHandler.postDelayed(mRunnable, mUptimeMillis);
	}
	
	/** A {@link Runnable} object that initiates next activity launch after splash screen. */
 	private Runnable mRunnable =  new Runnable() {
		@Override
		public void run() {
			LogConfig.logv(LOG_TAG, "mRunnable: timer invoked");
			if (mRequestManager != null) {
				mRequestManager.removeOnRequestFinishedListener(SplashActivity.this);
			}
			launchNextActivityAfterSplash();
		}
	};
	
	/**
	 * Call to launch next screen after splash screen.
	 */
	private void launchNextActivityAfterSplash() {
		LogConfig.logd(LOG_TAG, "launchNextActivityAfterSplash()");
		//ProgressBarHelper.dismissProgressBar(mHandler);
		if (PreferenceConfig.isValidUser(SplashActivity.this)) {
			if (!PreferenceConfig.isHomeZipCodeScreenShown(SplashActivity.this)) {
				startActivity(new Intent(SplashActivity.this, EnterHomeZipCodeActivity.class));
			} else {
				startActivity(new Intent(SplashActivity.this, HomeActivity.class));
			}
		} else {
			if (!PreferenceConfig.isEmailScreenShown(SplashActivity.this)) {
				startActivity (new Intent(SplashActivity.this, EnterEmailActivity.class)) ;
			} else if (!PreferenceConfig.isHomeZipCodeScreenShown(SplashActivity.this)) {
				startActivity(new Intent(SplashActivity.this, EnterHomeZipCodeActivity.class));
			} else {
				startActivity(new Intent(SplashActivity.this, HomeActivity.class));
			}
		}
		finish();
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   LogConfig.logd(LOG_TAG, "onDestroy()");
	   UIUtils.unbindDrawables(findViewById(R.id.root_view_splash));
	   if (mRegisterTask != null) {
           mRegisterTask.cancel(true);
       }
	   unregisterReceiver(mHandleMessageReceiver);
       GCMRegistrar.onDestroy(this);
	   System.gc();
	}
	
	private void checkNotNull(Object reference, String name) {
        if (reference == null) {
            throw new NullPointerException(
                    getString(R.string.error_config, name));
        } 
    }
	
	private final BroadcastReceiver mHandleMessageReceiver = new BroadcastReceiver() {
	     @Override
	     public void onReceive(Context context, Intent intent) {
	         String newMessage = intent.getExtras().getString(EXTRA_MESSAGE);
	//         mDisplay.append(newMessage + "\n");
	         if (newMessage != null) {
	        	 LogConfig.logv(LOG_TAG, "gcm:onReceive(): " + newMessage);
	         }
	     }
	};
 
	/** Call this method to register the app for Push notification via GCM. */
 	private void registerForPushNotification() {
 		SharedPreferences prefs = PreferenceConfig.getInstance(this);
        prefs.edit().putBoolean(PreferenceConstants.IS_FROM_GCM, false).commit();
        Intent intent = getIntent();
        if ( intent != null ) {
        	Resources resources = getResources();
        	if (intent.hasExtra(resources.getString(R.string.gcm_alert_title))) {
	        	String alertTitle = intent.getExtras().getString(resources.getString(R.string.gcm_alert_title));
	        	System.out.println("*******alertTitle******"+alertTitle);
	        	LogConfig.logd(LOG_TAG, "title App"+alertTitle);
	        	prefs.edit().putString(PreferenceConstants.GCM_ALERT_TITLE, alertTitle).commit();
	        	prefs.edit().putBoolean(PreferenceConstants.IS_FROM_GCM, true).commit();
        	} 
        	if (intent.hasExtra(resources.getString(R.string.gcm_product_id))) {
	        	String productId = intent.getExtras().getString(resources.getString(R.string.gcm_product_id));
	        	LogConfig.logd(LOG_TAG, "id App"+productId);
	        	prefs.edit().putString(PreferenceConstants.GCM_PRODUCT_ID, productId).commit();
	        	prefs.edit().putBoolean(PreferenceConstants.IS_FROM_GCM, true).commit();
        	}
        	if (intent.hasExtra(resources.getString(R.string.gcm_product_type))) {
	        	String productType = intent.getExtras().getString(resources.getString(R.string.gcm_product_type));
	        	LogConfig.logd(LOG_TAG, "type App"+productType);
	        	prefs.edit().putString(PreferenceConstants.GCM_PRODUCT_TYPE, productType).commit();
	        	prefs.edit().putBoolean(PreferenceConstants.IS_FROM_GCM, true).commit();
        	}
        }
	
		// Check for GCM registration
		checkNotNull(WSConfig.API_BASE_URL, "SERVER_URL");
		checkNotNull(SENDER_ID, "SENDER_ID");
		// Make sure the device has the proper dependencies.
		GCMRegistrar.checkDevice(this);
		// Make sure the manifest was properly set - comment out this line
		// while developing the app, then uncomment it when it's ready.
		GCMRegistrar.checkManifest(this);
		registerReceiver(mHandleMessageReceiver, new IntentFilter(
				DISPLAY_MESSAGE_ACTION));
		final String regId = GCMRegistrar.getRegistrationId(this);
		if (regId.equals("")) {
			LogConfig.logd(LOG_TAG, "GCMRegistrar on startup");
			// Automatically registers application on startup.
			GCMRegistrar.register(this, SENDER_ID);
			LogConfig.logv(LOG_TAG, "push_token = " + PreferenceConfig.getPushToken(this));
		} else {
			// Device is already registered on GCM, check server.
			if (GCMRegistrar.isRegisteredOnServer(this)) {
				// Skips registration.
				LogConfig.logd(LOG_TAG, "Skips registration");
				LogConfig.logv(LOG_TAG, "push_token = " + PreferenceConfig.getPushToken(this));
			} else {
				LogConfig.logd(LOG_TAG, "Try reg again");
				// Try to register again, but not in the UI thread.
				// It's also necessary to cancel the thread onDestroy(),
				// hence the use of AsyncTask instead of a raw thread.
				final Context context = this;
				mRegisterTask = new AsyncTask<Void, Void, Void>() {

					@Override
					protected Void doInBackground(Void... params) {
						boolean registered = ServerUtilities.register(
								context, regId);
						// At this point all attempts to register with the
						// app
						// server failed, so we need to unregister the
						// device
						// from GCM - the app will try to register again
						// when
						// it is restarted. Note that GCM will send an
						// unregistered callback upon completion, but
						// GCMIntentService.onUnregistered() will ignore it.
						if (!registered) {
							GCMRegistrar.unregister(context);
						}
						return null;
					}

					@Override
					protected void onPostExecute(Void result) {
						mRegisterTask = null;
					}
				};
				mRegisterTask.execute(null, null, null);
			}
		}
   }
 	
 	/** A method to start progress bar thread. **/
 	private void startProgressBarThread() {
 	// thread for displaying the SplashScreen
        Thread splashTread = new Thread() {
            @Override
            public void run() {
                try {
                	int waited = 30;
                	int elapsedTime = 0;
                	Random random = new Random();
                    while (elapsedTime < mUptimeMillis) {
                        sleep(500);
                        if (elapsedTime >= BusinessLogicConfig.MAX_PROGRESS_BAR_TIME) {
                        	mProgressBarLoading.setProgress(100);
                        	break;
                        }
                        elapsedTime += 500;
                        waited = waited + random.nextInt(20);
                        mProgressBarLoading.setProgress(waited);
                    }
                } catch(InterruptedException e) {
                    // do nothing
                	Log.e(LOG_TAG, "Exception Message = " + e.getMessage());
                }
            }
        };
        splashTread.start();
 	}
 	
 	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    } else if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	mHandler.removeCallbacks(mRunnable);
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	private void logAvailableMemorySize() {
		LogConfig.logv(LOG_TAG, "---------Memory Statistics-------");
		StatFs statInternal = new StatFs(Environment.getDataDirectory().getPath());
		long kiloBytesAvailableInternalStorage = ((((long)statInternal.getBlockSize() * (long)statInternal.getAvailableBlocks())/1024)*4)/100; // IN KB
		LogConfig.logv(LOG_TAG, "kiloBytesAvailableInternalStorage = " + kiloBytesAvailableInternalStorage);
		
		String state = Environment.getExternalStorageState();
        if (!state.equals(Environment.MEDIA_MOUNTED)){
        	LogConfig.logv(LOG_TAG, "logAvailableMemorySize(): No SDCard mounted.");
        	LogConfig.logv(LOG_TAG, "-------------------------------");
        	return;
        }
		
		// Calculate the available bytes in Memory Card
		// 5% of current remaining space in KB
		StatFs statSdcard = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long kiloBytesAvailableSDCard = ((((long)statSdcard.getBlockSize() * (long)statSdcard.getAvailableBlocks())/1024)*8)/100;
        LogConfig.logv(LOG_TAG, "kiloBytesAvailableSDCard = " + kiloBytesAvailableSDCard);
        LogConfig.logv(LOG_TAG, "-------------------------------");
	}
	
	/** method to make network request to get session id. **/
	private void callGetSessionIdWS() {
		LogConfig.logv(LOG_TAG, "callGetSessionIdWS()");
		// Check if network available
		if (NetworkHelper.isNetworkAvailable(this) && PreferenceConfig.isValidUser(this)) {
			Bundle params = new Bundle();
			params.putByte(LoginWorker.KEY_NAME_BUNDLE_LOGIN_WORKER_MODE, 
					LoginWorker.WORKER_MODE_LOGIN_USER);
			mRequestManager.loginUser(DownloadFormat.RETURN_FORMAT_JSON, params);
		}
	}
	
	/** Method to make network request to check app update on server. */
	private void callCheckAppUpdateWS() {
		LogConfig.logv(LOG_TAG, "callCheckAppUpdateWS()");
		if (NetworkHelper.isNetworkAvailable(this)) {
			/*if (!ProgressBarHelper.isProgressBarRunning()) {
				ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
						false, mHandler, SplashActivity.this);
			}*/
			mRequestManager.addOnRequestFinishedListener(SplashActivity.this);
			mRequestType = NetworkHelper.REQUEST_TYPE.CHECK_APP_UPDATE;
			mRequestId = mRequestManager.checkAppUpdate(DownloadFormat.RETURN_FORMAT_JSON, new Bundle());
		} else {
			LogConfig.logv(LOG_TAG, "callCheckAppUpdateWS(): No N/W");
			callGetAppConfigWS();
		}
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			LogConfig.logv(LOG_TAG, "onRequestFinished()");
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(SplashActivity.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE,
							-1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mDialogMessage = getResources().getString(R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mDialogMessage = getResources().getString(R.string.toast_server_connection_error);
					} else {
						mDialogMessage = getResources().getString(R.string.toast_response_error);
					}
				} else {
					mDialogMessage = getResources().getString(R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}
 
	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			LogConfig.logv(LOG_TAG, "SUCCESS Runnable: mRequestType = " + mRequestType
					+ ", responseStatus = " + responseStatus);
			if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.CHECK_APP_UPDATE) {
					appUpdateCheckedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.GET_APP_CONFIG) {
					//ProgressBarHelper.dismissProgressBar(mHandler);
					appConfigurationDownloadedDoSomething();
				}
			} else if (responseStatus != null && responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				if (mRequestType == REQUEST_TYPE.CHECK_APP_UPDATE) {
					callGetAppConfigWS();
				} else if (mRequestType == REQUEST_TYPE.GET_APP_CONFIG) {
					setTimerToLaunchNextActivity();
				}
			} else {
				//ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};
	
	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			LogConfig.logv(LOG_TAG, "ERROR Runnable: mRequestType = " + mRequestType);
			if (mRequestType == REQUEST_TYPE.CHECK_APP_UPDATE) {
				callGetAppConfigWS();
			} else if (mRequestType == REQUEST_TYPE.GET_APP_CONFIG) {
				setTimerToLaunchNextActivity();
			}
		}
	};
	
	/** A method to perform action after successfully checking the app update. */
	private void appUpdateCheckedDoSomething() {
		LogConfig.logv(LOG_TAG, "appUpdateCheckedDoSomething()");
		boolean isOptionalUpdate = false;
		String updateType = PreferenceConfig.getAppUpdateType(this);
		if (!TextUtils.isEmpty(updateType)
				&& updateType.equalsIgnoreCase(BusinessLogicConfig.APP_UPDATE_TYPE_OPTIONAL)) {
			isOptionalUpdate = true;
		}
		if (PreferenceConfig.isAppUpdateAvailable(SplashActivity.this) && !isOptionalUpdate) {
			LogConfig.logv(LOG_TAG, "appUpdateCheckedDoSomething(): APP Update Available");
			mHandler.removeCallbacks(mRunnable);
			showCustomDialog(DialogConfig.DIALOG_UPGRADE_APP);
		} else {
			callGetAppConfigWS();
		}
	}
	
	/** Method to take action after app configuration download complete from server. */
	private void appConfigurationDownloadedDoSomething() {
		LogConfig.logv(LOG_TAG, "appConfigurationDownloadedDoSomething()");
		PreferenceConfig.setAppConfigDownloadStatus(true, SplashActivity.this);
		setTimerToLaunchNextActivity();
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showCustomDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(SplashActivity.this);
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_UPGRADE_APP:
			final int positiveButtonRes;
			String updateType = PreferenceConfig.getAppUpdateType(SplashActivity.this);
			if (!TextUtils.isEmpty(updateType)
					&& updateType.equalsIgnoreCase(BusinessLogicConfig.APP_UPDATE_TYPE_OPTIONAL)) {
				positiveButtonRes = android.R.string.cancel;
				// Its an optional update so moving to next screen.
				launchNextActivityAfterSplash();
				return;
			} else {
				positiveButtonRes = R.string.label_exit;
			}
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(PreferenceConfig.getAppUpdateMessage(SplashActivity.this))
			.setCancelable(false)
			.setNegativeButton(R.string.label_update,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						Intent intent = new Intent(Intent.ACTION_VIEW, 
					            Uri.parse("market://details?id=com.manthansystems.loyalty"));
			            startActivity(intent);
			            finish();
					}
			})
			.setPositiveButton(positiveButtonRes,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						if (positiveButtonRes == R.string.label_exit) {
							// Its an mandatory update so exit will close the app.
							finish();
						} else {
							// Its an optional update and user has pressed cancel, open next screen.
							launchNextActivityAfterSplash();
						}
					}
			});
			break;
		}
		dlg.show();
	}
	
	/** A method to make server request to get app config. **/
	private void callGetAppConfigWS() {
		LogConfig.logv(LOG_TAG, "callGetAppConfigWS()");
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(SplashActivity.this)) {
			LogConfig.logv(LOG_TAG, "callGetAppConfigWS(): No N/W");
			//ProgressBarHelper.dismissProgressBar(mHandler);
			setTimerToLaunchNextActivity();
			return;
		}
		/*if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(R.string.progress_bar_please_wait,
					false, mHandler, SplashActivity.this);
		}*/
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(SplashActivity.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.GET_APP_CONFIG;
		params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE, 
				SettingsWorker.WorkerModes.WORKER_MODE_GET_APP_CONFIG);
		mRequestId = mRequestManager.getAppConfig(DownloadFormat.RETURN_FORMAT_JSON, params);
	}
}
