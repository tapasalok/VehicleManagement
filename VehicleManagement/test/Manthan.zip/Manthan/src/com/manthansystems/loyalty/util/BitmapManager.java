/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.Observable;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v4.util.LruCache;
import android.text.TextUtils;
import android.widget.ImageView;

/**
 * Class to load the {@link Bitmap} image inside {@link AsyncTask} and keep it cached for
 * a while.
 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
 *
 */
public class BitmapManager extends Observable {  

    private LruCache<String, Bitmap> mMemoryCache;
    private final ExecutorService pool;  
    private Map<ImageView, String> imageViews = Collections.synchronizedMap(new WeakHashMap<ImageView, String>());  
    private Bitmap placeholder;  
  
    /**
     * Constructor method.
     */
    public BitmapManager(Context context) {  
    	// Get memory class of this device, exceeding this amount will throw an
        // OutOfMemory exception.
        final int memClass = ((ActivityManager) context.getSystemService(
                Context.ACTIVITY_SERVICE)).getMemoryClass();

        // Use 1/8th of the available memory for this memory cache.
        final int cacheSize = 1024 * 1024 * memClass / 8;

        mMemoryCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                // The cache size will be measured in bytes rather than number of items.
                return bitmap.getRowBytes() * bitmap.getHeight();
            }
        };
        pool = Executors.newFixedThreadPool(5);  
    }  
  
    /**
     * Call to set the place holder image. This image will be shown in place of 
     * actual image until it gets downloaded.
     * @param bmp place holder image
     */
    public void setPlaceholder(Bitmap bmp) {  
        placeholder = bmp;  
    }  
  
    /**
     * Get the cached {@link Bitmap} image which is linked to the image url in cache.
     * @param url image url
     * @return {@link Bitmap}
     */
    public Bitmap getBitmapFromCache(String url) {  
        return mMemoryCache.get(url);
    }  
  
    /**
     * Call to queue the image downloading calls.
     */
    public void queueJob(final String url, final ImageView imageView,  
            final int width, final int height) {  
        /* Create handler in UI thread. */  
        final Handler handler = new Handler() {  
            @Override  
            public void handleMessage(Message msg) {  
                String tag = imageViews.get(imageView);  
                if (tag != null && tag.equals(url)) {  
                    if (msg.obj != null) {  
                        imageView.setImageBitmap((Bitmap) msg.obj);  
                    } else {  
                        imageView.setImageBitmap(placeholder);  
                      //  LogConfig.logd("BitmapManager", "fail " + url);  
                    }  
                }  
            }  
        };  
  
        pool.submit(new Runnable() {  
            @Override  
            public void run() {  
                final Bitmap bmp = downloadBitmap(url, width, height);  
                Message message = Message.obtain();  
                message.obj = bmp; 
                //LogConfig.logd("BitmapManager", "Item downloaded: " + url); 
                setChanged();
                notifyObservers(url);
  
                handler.sendMessage(message);  
            }  
        });  
    }  
  
    /**
     * Load the bitmap image from cache in image view, if it is not found in cache
     * then a new download task is queued by call via {@link #queueJob(String, ImageView, int, int)}.
     */
    public void loadBitmap(final String url, final ImageView imageView,  
            final int width, final int height) {  
    	if (TextUtils.isEmpty(url)) {
    		imageView.setImageBitmap(placeholder);
    		return;
    	}
    	
        imageViews.put(imageView, url);  
        Bitmap bitmap = getBitmapFromCache(url);  
  
        // check in UI thread, so no concurrency issues  
        if (bitmap != null) { 
        	//LogConfig.logd("BitmapManager", "Item loaded from cache: " + url);  
            imageView.setImageBitmap(bitmap);  
        } else {  
            imageView.setImageBitmap(placeholder);  
            queueJob(url, imageView, width, height);  
        }  
    }  
  
    /**
     * Call to download image from given url and cache it for further use.
     * @param url
     * @param width
     * @param height
     * @return downloaded image a in {@link Bitmap} format.
     */
    private Bitmap downloadBitmap(String url, int width, int height) {  
		try {
			// Decode image size
			InputStream mInputStream = (InputStream) new URL(url).getContent();
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int n = 0;
			while (-1 != (n = mInputStream.read(buffer))) {
				output.write(buffer, 0, n);
			}
			byte[] imageArray = output.toByteArray();
			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;

			InputStream imageInputStream = new ByteArrayInputStream(imageArray);
			BitmapFactory.decodeStream(imageInputStream, null, options);

			int requiredSize = 0;
			if (width > height) {
				requiredSize = height;
			} else {
				requiredSize = width;
			}

			// Find the correct scale value. It should be the power of 2.
			int scale = 1;
			while (options.outWidth / scale / 2 >= requiredSize
					&& options.outHeight / scale / 2 >= requiredSize)
				scale *= 2;

			// Decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize = scale;
			imageInputStream = new ByteArrayInputStream(imageArray);
			Bitmap bitmap = BitmapFactory.decodeStream(imageInputStream, null,
					o2);
			mMemoryCache.put(url, bitmap);
			imageArray = null;
			return bitmap;
		} catch (MalformedURLException e) {
//			e.printStackTrace();
		} catch (IOException e) {
//			e.printStackTrace();
		}

		return null;
    }  
    
    public void clearCache(){
    	if (mMemoryCache != null) {
    		mMemoryCache.evictAll();
    	}
    }
}
