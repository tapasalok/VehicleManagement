/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.content.res.Resources;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.LogConfig;

/**
 * A file handler class to save a file/delete a file in to/from specified file
 * path. If SD Card is available then it checks for sufficient memory to store
 * the file, if no sufficient memory available then it checks the same to store
 * the file inside internal memory of device.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class FileHandler {
	private static String LOG_TAG = "FileHandler";
	
	public static String mPathSDCard;
	public static String mPathInternalStorage;
	public static String mDirectoryName;
	
	/** Method to initialise resource path. */
	private static void initFilePaths(Context inContext) {
		// Setting the path for SDCard and Internal Storage
		Resources res = inContext.getResources();
		mDirectoryName = res.getString(R.string.file_cache_directory_name);
		mPathInternalStorage = res.getString(R.string.path_internal_storage);
		mPathSDCard = res.getString(R.string.path_sd_card);
	}
	
	/** Methtod to check available space in SD card. */
	public static boolean isSpaceAvailableInSDCard() {
	    String state = Environment.getExternalStorageState();
        if (!state.equals(Environment.MEDIA_MOUNTED)){
        	return false;
        }
		// Calculate the available bytes in Memory Card
		// 5% of current remaining space in KB
		StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long kiloBytesAvailableSDCard = ((((long)stat.getBlockSize() 
        		* (long)stat.getAvailableBlocks())/1024)*8)/100;
        long folderSize = calculatFolderSize(mPathSDCard)/1024; // In KB
        // true if space avail false other wise
        return ((folderSize+500) < kiloBytesAvailableSDCard);
	}
	
	/** Methtod to check available space in internal memory. */
	public static boolean isSpaceAvailableInInternalStorage() {
		// Calculate the available bytes in Internal Storage
		// 1% of current remaining space in KB
		StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
		long kiloBytesAvailableInternalStorage = ((((long)stat.getBlockSize()
				* (long)stat.getAvailableBlocks())/1024)*4)/100; // IN KB
        long folderSize = calculatFolderSize(mPathInternalStorage)/1024; // In KB
        // true if space avail false other wise
        return ((folderSize+500) < kiloBytesAvailableInternalStorage);
	}
	
	/** Method to calculate folder size. */
	private static long calculatFolderSize(String folderPath) {
		File directory = new File(folderPath);
		if (directory.exists()) {
			long length = 0;
		    for (File file : directory.listFiles()) {
		        if (file.isFile()) {
		        	length += file.length();
		        }
	    	}
		    return length;	
		}
		return 0;
	}
	
	/** Method to save given {@link InputStream} into file. */
	public static String saveFile(String inFilePath, InputStream inInputStream,
			Context inContext) {
		try {
			initFilePaths(inContext);
			if (isSpaceAvailableInSDCard()) {
				return saveFileInSDCard(inFilePath, inInputStream, inContext);
			} else {
				return saveFileInInternalMemory(inFilePath, inInputStream, inContext);
			}
		} catch (Exception e) {
			LogConfig.logv(LOG_TAG, "saveFile(): " + e);
			return null;
		}
	}
	
	/** Method to save bar code image in internal memory. */
	private static String saveFileInInternalMemory(String inFilePath,
			InputStream inInputStream, Context inContext) {
		FileOutputStream fileout = null;
		String path = null;
		try {
			LogConfig.logv(LOG_TAG, "saveFileInInternalMemory()");
			fileout = inContext.openFileOutput(inFilePath, 0);
			if (writeStreamToFile(inInputStream, fileout, inContext)) {
				LogConfig.logv(LOG_TAG,"saveFileInInternalMemory(): cache success");
				path = mPathInternalStorage + inFilePath;
			}
		} catch (Exception e) {
			Log.e(LOG_TAG, "saveFileInInternalMemory() : Exception: " + e);
		}
		return path;
	}
	
	/** Method to save bar code image in sd card. */
	private static String saveFileInSDCard(String inFileName,
			InputStream inInputStream, Context inContext) {
		try {
			LogConfig.logv(LOG_TAG, "saveFileInSDCard()");
			File sdDir = Environment.getExternalStorageDirectory();
			File uadDir = new File(new StringBuilder(sdDir.getAbsolutePath())
					.append(mDirectoryName).toString());
			uadDir.mkdir();
			LogConfig.logv(LOG_TAG, "uadDir.getAbsolutePath() = " + uadDir.getAbsolutePath());
			File file = new File(new StringBuilder(uadDir.getAbsolutePath())
				.append("/").append(inFileName).toString());
			if (!file.exists()) {
				LogConfig.logv(LOG_TAG,"saveFileInSDCard(): file not exist");
				boolean created = file.createNewFile();
				LogConfig.logv(LOG_TAG, "saveFileInSDCard(): file created status = " + created);
			} else {
				LogConfig.logv(LOG_TAG, "saveFileInSDCard(): file already exist in path =  "
								+ file.getPath());
				file.delete();
				boolean created = file.createNewFile();
				LogConfig.logv(LOG_TAG, "saveFileInSDCard(): file created status = "+ created);
			}
			FileOutputStream fileout = new FileOutputStream(file);
			if (writeStreamToFile(inInputStream, fileout, inContext)) {
				LogConfig.logv(LOG_TAG, "saveFileInSDCard(): SUCCESS: path = " + mPathSDCard
						+ inFileName);
				return (mPathSDCard + inFileName);
			}
		} catch (Exception e) {
			Log.e(LOG_TAG, "saveFileInSDCard() : Exception: " + e);
		}
		return null;
	}
	
	/** Method to write file stream in file.
	 * @see FileOutputStream*/
	private static boolean writeStreamToFile(InputStream inInputStream,
			FileOutputStream fileout, Context inContext) {
		boolean status = false;
		try {
			LogConfig.logv(LOG_TAG, "writeToFile()");
			byte[] buffer = new byte[2048];
			int totalByteRead = 0;
			while (true) {
				int amountRead = inInputStream.read(buffer);
				totalByteRead += amountRead;
				if (amountRead == -1) {
					break;
				}
				fileout.write(buffer, 0, amountRead);
			}
			fileout.flush();
			if (totalByteRead < 512) {
				Log.e(LOG_TAG, "writeToFile(): write to file cache failed");
				status = false;
			}
			status = true;
		} catch (Exception e) {
			Log.e(LOG_TAG, "writeToFile(): exception" + e);
		} finally {
			try {
				if (fileout != null) {
					fileout.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return status;
	}
	
	/**
	 * Method to delete a file in given path if exists.
	 * @param filePath File path name.
	 */
	public static void deleteFile(String filePath) {
		File file = new File(filePath);
		if (file.exists()) {
			boolean status = file.delete();
			LogConfig.logd(LOG_TAG, "deleteFile(): " + status);
		}
	}
}
