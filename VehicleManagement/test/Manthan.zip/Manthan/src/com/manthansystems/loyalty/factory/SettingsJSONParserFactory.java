/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */

package com.manthansystems.loyalty.factory;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDao;
import com.manthansystems.loyalty.model.Category;
import com.manthansystems.loyalty.ui.UIApplication;

/**
 * A JSON parser class that will parse the category response json string coming from server.
 * @author Gaurav Agrawal: gaurav.agrawal@xymob.com
 */
public class SettingsJSONParserFactory extends BaseJsonParser {
	
	@SuppressWarnings("unused")
	private final static String LOG_TAG = "SettingsJSONParserFactory";
	
	/** Call to Parse category response from JSON string. */
	public synchronized static HashMap<String, Object> parseGetAllCategoryResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		ArrayList<Category> categoryArrayList = new ArrayList<Category>();
		final int MAIN_CATEGORY = CategoryDao.FLAG_VALUE_MAIN_CATEGORY;
		final int SUB_CATEGORY = CategoryDao.FLAG_VALUE_SUB_CATEGORY;
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
				JSONArray resultResponseJsonArray = response.getJSONArray(JSONTagConstants.RESPONSE_RESULTS);
				int categoryArraySize = resultResponseJsonArray.length();
				if (categoryArraySize > 0) {
					final Category categoryAll = new Category();
					categoryAll.mCategoryId = UIApplication.All_CATEGORY_ID;
					categoryAll.mCategoryName = UIApplication.ALL_CATEGORY_TITLE;
					categoryAll.mIsCategory = MAIN_CATEGORY;
					categoryArrayList.add(categoryAll);
					
					final Category categoryNew = new Category();
					categoryNew.mCategoryId = UIApplication.NEW_CATEGORY_ID;
					categoryNew.mCategoryName = UIApplication.NEW_CATEGORY_TITLE;
					categoryNew.mIsCategory = MAIN_CATEGORY;
					categoryArrayList.add(categoryNew);
				}
				for (int i = 0; i < categoryArraySize; i++) {
					JSONObject categoryData = resultResponseJsonArray.getJSONObject(i);
					final Category category = new Category();
					if (categoryData.has(JSONTagConstants.CATEGORY_ID_TAG)) {
						category.mCategoryId = categoryData.getString(JSONTagConstants.CATEGORY_ID_TAG);
					}
					if (categoryData.has(JSONTagConstants.CATEGORY_NAME_TAG)) {
						category.mCategoryName = categoryData.getString(JSONTagConstants.CATEGORY_NAME_TAG);
					}
					category.mIsCategory = MAIN_CATEGORY;
					categoryArrayList.add(category);
					if (categoryData.has(JSONTagConstants.SUBCATEGORIES_TAG)) {
						JSONArray subCategoryResponseJsonArray = categoryData.getJSONArray(JSONTagConstants.SUBCATEGORIES_TAG);
						int subCategoryArraySize = subCategoryResponseJsonArray.length();
						for (int j = 0; j < subCategoryArraySize; j++) {
							JSONObject subCategoryData = subCategoryResponseJsonArray.getJSONObject(j);
							final Category subCategory = new Category();
							if (subCategoryData.has(JSONTagConstants.CATEGORY_ID_TAG)) {
								subCategory.mCategoryId = subCategoryData.getString(JSONTagConstants.CATEGORY_ID_TAG);
							}
							if (subCategoryData.has(JSONTagConstants.CATEGORY_NAME_TAG)) {
								subCategory.mCategoryName =  "    " + subCategoryData.getString(JSONTagConstants.CATEGORY_NAME_TAG);
							}
							subCategory.mIsCategory = SUB_CATEGORY;
							categoryArrayList.add(subCategory);
						}
					}
				}
				map.put(CommonConfig.KEY_NAME_ALL_CATEGORY_LIST, categoryArrayList);
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_RESULTS_MESSAGE, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	/** A method to Parse send user category response from JSON string. */
	public synchronized static HashMap<String, Object> parseSendUserCategoryResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
    /** A method to parse get user category response from JSON string. **/
	public synchronized static HashMap<String, Object> parseGetUserCategoryResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		ArrayList<String> userCategoryList = new ArrayList<String>();
		
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
				JSONArray resultResponseJsonArray = response.getJSONArray(JSONTagConstants.RESPONSE_RESULTS);
				int userCategoryArraySize = resultResponseJsonArray.length();
				for (int i = 0; i < userCategoryArraySize; i++) {
					userCategoryList.add(resultResponseJsonArray.getString(i));
				}
				map.put(CommonConfig.KEY_NAME_USER_CATEGORY_LIST, userCategoryList);
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	/** A method to Parse push notification response from JSON string. */
	public synchronized static HashMap<String, Object> parsePushNotificationResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	 /** A method to parse app config response from JSON string. **/
	public synchronized static HashMap<String, Object> parseGetAppConfigResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		HashMap<String, Object> appConfigMap = new HashMap<String, Object>();
		if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
			JSONArray resultResponseJsonArray = response.getJSONArray(JSONTagConstants.RESPONSE_RESULTS);
			int appConfigArraySize = resultResponseJsonArray.length();
			String keyName = "";
			String keyValue = "";
			for (int i = 0; i < appConfigArraySize; i++) {
				JSONObject appconfigData = resultResponseJsonArray.getJSONObject(i);
				if (appconfigData.has(JSONTagConstants.NAME_TAG)) {
					keyName = appconfigData.getString(JSONTagConstants.NAME_TAG);
				}
				if (appconfigData.has(JSONTagConstants.VALUE_TAG)) {
					keyValue = appconfigData.getString(JSONTagConstants.VALUE_TAG);
				}
				appConfigMap.put(keyName, keyValue);
			}
			map.put(CommonConfig.KEY_NAME_APP_CONFIG_MAP, appConfigMap);
		}
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
	
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	/** A method to parse get user category response from JSON string. **/
	public synchronized static HashMap<String, Object> parseGetLocationResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
			JSONArray resultResponseJsonArray = response.getJSONArray(JSONTagConstants.RESPONSE_RESULTS);
			int locationArraySize = resultResponseJsonArray.length();
			for (int i = 0; i < locationArraySize; i++) {
				JSONObject locationData = resultResponseJsonArray.getJSONObject(i);
				if (locationData.has(JSONTagConstants.GEOMETRY_TAG)) {
					JSONObject geometryJSONObject= locationData.getJSONObject(JSONTagConstants.GEOMETRY_TAG);
					if(geometryJSONObject.has(JSONTagConstants.LOCATION_TAG)) {
						JSONObject locationJSONObject = geometryJSONObject.getJSONObject(JSONTagConstants.LOCATION_TAG);
						if (locationJSONObject.has(JSONTagConstants.LAT_TAG)) {
							String lat = locationJSONObject.getString(JSONTagConstants.LAT_TAG);
							map.put(CommonConfig.KEY_NAME_LAT_FOR_ZIPCODE, lat);
						}
						if (locationJSONObject.has(JSONTagConstants.LNG_TAG)) {
							String lng = locationJSONObject.getString(JSONTagConstants.LNG_TAG);
							map.put(CommonConfig.KEY_NAME_LON_FOR_ZIPCODE, lng);
						}
					}
					break;
				}
			}
		}
		if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS)) {
			String status = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, status);
		}
		return map;
	}
}
