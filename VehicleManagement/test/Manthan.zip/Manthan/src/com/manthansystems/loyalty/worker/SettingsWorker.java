/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.apache.http.client.methods.HttpHead;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.ContentProviderOperation;
import android.content.Context;
import android.content.OperationApplicationException;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDao;
import com.manthansystems.loyalty.data.provider.DatabaseProvider;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.SettingsJSONParserFactory;
import com.manthansystems.loyalty.model.Category;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;
import com.manthansystems.loyalty.ui.UIApplication;
import com.manthansystems.loyalty.util.NetworkHelper;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 *  make the network request to related to settings. It handles the parsing,
 *  db caching and error states while of these processes. 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class SettingsWorker extends BaseWorker {

	private final static String LOG_TAG = "SettingsWorker";
	
	public static String KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE = "com.manthansystems.loyalty.worker.SettingsWorker#WorkerMode";
	public final static String KEY_NAME_BUNDLE_BODY_DATA = "com.manthansystems.loyalty.worker.SettingsWorker#Body_Data";
	
	/**
	 * An interface to hold the worker modes that used to check the various
	 * settings operations.
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	public interface WorkerModes {
		public final byte WORKER_MODE_GET_ALL_CATEGORY	= 1;
		public final byte WORKER_MODE_GET_USER_CATEGORY = 2;
		public final byte WORKER_MODE_SEND_USER_CATEGORY = 3;
		public final byte WORKER_MODE_ENABLE_PUSH_NOTIFICATION = 4;
		public final byte WORKER_MODE_DISABLE_PUSH_NOTIFICATION = 5;
		public final byte WORKER_MODE_GET_APP_CONFIG = 6;
		public final byte WORKER_MODE_GET_LOCATION_FOR_ZIPCODE = 7;
	}
	
	/** Start processing the request. */
	@SuppressWarnings("unchecked")
	public static Bundle start(final Context inContext, final int inReturnFormat,
    		final Bundle inBudleData) throws IllegalStateException,
    		IOException,URISyntaxException, RestClientException, ParserConfigurationException,
    		SAXException, JSONException, Exception, OperationApplicationException, ConnectionException {
    	
    	Bundle bundle = new Bundle();
    	byte workerMode = inBudleData.getByte(KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE);
    	String responseStatus = null;
    	String serverRequestUrl = prepareRequestUrl(workerMode, inContext);
    	ArrayList<Header> headerList = getBasicHeaders(inContext);
    	HashMap<String, Object> hashMap = null;
    	NetworkConnectionResult wsResult = null;
    	
    	switch (workerMode) {
		case WorkerModes.WORKER_MODE_GET_ALL_CATEGORY:
			wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.GET, null, headerList, true, false, inContext);
	        hashMap = SettingsJSONParserFactory.parseGetAllCategoryResponse(wsResult.wsResponse);
	        responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
	        	writeAllCategoriesInDB(hashMap, inContext);
	        	PreferenceConfig.setAllCategoryTimestamp(System.currentTimeMillis(), inContext);
			}
	        break;
	        
		case WorkerModes.WORKER_MODE_SEND_USER_CATEGORY:
			String bodyData = inBudleData.getString(KEY_NAME_BUNDLE_BODY_DATA);
			LogConfig.logd(LOG_TAG, "bodyData= "  +bodyData);
			HttpHead head = new HttpHead();
			head.addHeader("Content-Type", "application/json");
			Header headers[] = head.getAllHeaders();
			headerList.add(headers[0]);
			wsResult = NetworkConnection.retrieveResponseFromService(serverRequestUrl,
					Method.POST, null, headerList, true, null, bodyData, false, inContext);
			
			hashMap = SettingsJSONParserFactory.parseSendUserCategoryResponse(wsResult.wsResponse);
			break;
			
		case WorkerModes.WORKER_MODE_GET_USER_CATEGORY:
			wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.GET, null, headerList, true, false, inContext);
	       	hashMap = SettingsJSONParserFactory.parseGetUserCategoryResponse(wsResult.wsResponse);
	       	ArrayList<String> selectedCategoryIds = (ArrayList<String>) 
	       		hashMap.get(CommonConfig.KEY_NAME_USER_CATEGORY_LIST);
	       	if (selectedCategoryIds.size() > 0) {
				Cursor cursor = inContext.getContentResolver().query(CategoryDao.CONTENT_URI, null,
						null, null, null);
				if (cursor != null) {
					if (cursor.getCount() == (selectedCategoryIds.size() + 1)) {
						selectedCategoryIds.add(UIApplication.All_CATEGORY_ID);
					}
					cursor.close();
				}
	       	}
	       	bundle.putStringArrayList(CommonConfig.KEY_NAME_USER_CATEGORY_LIST, selectedCategoryIds);
			break;
			
    	case WorkerModes.WORKER_MODE_DISABLE_PUSH_NOTIFICATION:
    		resetPostBuffer();
    		addToPostBuffer(JSONTagConstants.PUSH_TOKEN_TAG, PreferenceConfig.getPushToken(inContext));
    		wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.POST, mParameters, headerList, true, false, inContext);
    		hashMap = SettingsJSONParserFactory.parsePushNotificationResponse(wsResult.wsResponse);
    		break;
    		
    	case WorkerModes.WORKER_MODE_ENABLE_PUSH_NOTIFICATION:
    		resetPostBuffer();
    		addToPostBuffer(JSONTagConstants.PUSH_TOKEN_TAG, PreferenceConfig.getPushToken(inContext));
			wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.POST, mParameters, headerList, false, inContext);
			hashMap = SettingsJSONParserFactory.parsePushNotificationResponse(wsResult.wsResponse);
    		break;
    		
    	case WorkerModes.WORKER_MODE_GET_APP_CONFIG:
    		wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.GET, null, headerList, true, false, inContext);
	       	hashMap = SettingsJSONParserFactory.parseGetAppConfigResponse(wsResult.wsResponse);
	       	HashMap<String, Object> appConfigMap = (HashMap<String, Object>) 
	       		hashMap.get(CommonConfig.KEY_NAME_APP_CONFIG_MAP);
	       	if (appConfigMap != null && !appConfigMap.isEmpty()) {
				Iterator<String> iterator = appConfigMap.keySet().iterator();
				while (iterator.hasNext()) {
				    String key = (String) iterator.next();
				    String value = (String) appConfigMap.get(key);
				    if (key.equalsIgnoreCase(JSONTagConstants.COUPON_BURNING_ENABLED)) {
				    	boolean redeemSupported = value.equalsIgnoreCase("true") ? true : false;
				    	PreferenceConfig.setIsAppSupportRedemption(redeemSupported, inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_REFRESH_INTERVAL)) {
				    	PreferenceConfig.setOfferRefreshInterval(Integer.parseInt(value), inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_GEO_SIGNIFICANT_DISTANCE)) {
				    	PreferenceConfig.setGeoSignificantDistance(value, inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_ACTIVE_TRIGGER_LIST)) {
				    	PreferenceConfig.setActiveTriggersList(value, inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_GEO_SIGNIFICANT_FREQUENCY)) {
				    	PreferenceConfig.setGeoSignificantFrequency(value, inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_STORE_SEARCH_DISTANCE)) {
				    	PreferenceConfig.setOffersNotificationProximityRadius(Integer.parseInt(value), inContext);
				    	int radius = PreferenceConfig.getOffersProximityRadius(inContext);
						if (radius == -1) {
							if (Integer.parseInt(value) > BusinessLogicConfig.MAX_OFFER_PROXIMITY_RADIUS_FOR_SLIDER) {
								PreferenceConfig.setOffersProximityRadius(
										BusinessLogicConfig.MAX_OFFER_PROXIMITY_RADIUS_FOR_SLIDER, inContext);
							} else {
								PreferenceConfig.setOffersProximityRadius(Integer.parseInt(value), inContext);
							}
						}
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_COLOR_CODE)) {
				    	String[] colorArray = value.split(",");
				    	int red = Integer.parseInt(colorArray[0]);
				    	int green = Integer.parseInt(colorArray[1]);
				    	int blue = Integer.parseInt(colorArray[2]);
				    	int colorCode = Color.rgb(red, green, blue);
				    	PreferenceConfig.setMarketingMsgBgColorCode(colorCode, inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_MARKETING_MESSAGE_IMAGE_URL)) {
				    	PreferenceConfig.setMaketMessageImageUrl(NetworkHelper.getEncodedUrl(value), inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_MIN_BAR_CODE_DIGIT)) {
				    	PreferenceConfig.setBarCodeMinRange(Integer.parseInt(value), inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_MAX_BAR_CODE_DIGIT)) {
				    	PreferenceConfig.setBarCodeMaxRange(Integer.parseInt(value), inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_SEARCH_COLUMN)) {
				    	PreferenceConfig.setSearchColumn(value, inContext);
				    } else if (key.equalsIgnoreCase(JSONTagConstants.CONFIG_LMS_INTEGRATED)) {
				    	boolean isloyaltyCardEnabled = value.equalsIgnoreCase("true") ? true : false;
				    	PreferenceConfig.setLoyaltyCardEnabled(isloyaltyCardEnabled, inContext);
				    }
				}
			}
	       	responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
	        	PreferenceConfig.setAppConfigTimestamp(System.currentTimeMillis(), inContext);
			}
    		break;
    		
    	case WorkerModes.WORKER_MODE_GET_LOCATION_FOR_ZIPCODE:
    		wsResult = NetworkConnection.retrieveResponseFromService(
	        		serverRequestUrl, Method.GET, null, headerList, true, false, inContext);
	       	hashMap = SettingsJSONParserFactory.parseGetLocationResponse(wsResult.wsResponse);
	       	responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
	        	writeLocationForZipCodeInPreferences(hashMap, inContext);
			}
    		break;
    	}
    	responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        } else {
        	bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
        }
        
        return bundle;
    }
    
    /** A method to store categories into database. */
    private static void writeAllCategoriesInDB(HashMap<String, Object>map, Context inContext)
    	throws Exception, OperationApplicationException  {
    	@SuppressWarnings("unchecked")
		ArrayList<Category> categoryList = (ArrayList<Category>) map.get(CommonConfig.KEY_NAME_ALL_CATEGORY_LIST);
    	int totalCategories = 0;
    	if (categoryList != null) {
    		totalCategories = categoryList.size();
    	}
		ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
        ops.add(ContentProviderOperation.newDelete(CategoryDao.CONTENT_URI).build());
        for (int i = 0; i<totalCategories; i++) {
        	final Category category = categoryList.get(i);
        	category.mCategoryCheckFlag = "0";
        	CategoryDao.addContentValues(CategoryDao.CONTENT_URI, ops, category);
        }
		//executing all queries added above in batch
    	inContext.getContentResolver().applyBatch(DatabaseProvider.AUTHORITY, ops);
    }
    
    /** Method to prepare the appropriate server request url based on the worker mode. */
    private static String prepareRequestUrl(final byte workerMode, Context inContext) throws URISyntaxException,
    		UnsupportedEncodingException {
    	switch (workerMode) {
		case WorkerModes.WORKER_MODE_GET_ALL_CATEGORY:
			return WSConfig.URL_GET_ALL_CATEGORY;
		case WorkerModes.WORKER_MODE_SEND_USER_CATEGORY:
			// Pass-through
		case WorkerModes.WORKER_MODE_GET_USER_CATEGORY:
			return WSConfig.URL_USER_CATEGORY;
		case WorkerModes.WORKER_MODE_DISABLE_PUSH_NOTIFICATION:
			return WSConfig.URL_DISABLE_PUSH_NOTIFICATION;
		case WorkerModes.WORKER_MODE_ENABLE_PUSH_NOTIFICATION:
			return WSConfig.URL_ENABLE_PUSH_NOTIFICATION;
		case WorkerModes.WORKER_MODE_GET_APP_CONFIG:
			return WSConfig.URL_GET_APP_CONFIG;
		case WorkerModes.WORKER_MODE_GET_LOCATION_FOR_ZIPCODE:
			StringBuilder url = new StringBuilder(WSConfig.URL_GET_LOCATION_FOR_ZIPCODE);
			int valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()),
    				PreferenceConfig.getHomeZipcode(inContext));
			return url.toString();
		default:
			throw new URISyntaxException("SettingsWorker mode not set.",
					"The caller for method prepareRequestUrl() has not set the" +
					"worker mode.");
		}
    }
    
    /** A method to write location data into Preferences. **/
    private static void writeLocationForZipCodeInPreferences(HashMap<String,Object> hashMap, Context inContext) {
    	String lat = (String) hashMap.get(CommonConfig.KEY_NAME_LAT_FOR_ZIPCODE);
    	String lon = (String) hashMap.get(CommonConfig.KEY_NAME_LON_FOR_ZIPCODE);
    	if (!TextUtils.isEmpty(lat)) {
    		PreferenceConfig.setLatForZipCode(lat, inContext);
    	} else {
    		PreferenceConfig.setLatForZipCode("", inContext);
    	}
    	if (!TextUtils.isEmpty(lon)) {
    		PreferenceConfig.setLonForZipCode(lon, inContext);
    	} else {
    		PreferenceConfig.setLonForZipCode("", inContext);
    	}
	 }
}
