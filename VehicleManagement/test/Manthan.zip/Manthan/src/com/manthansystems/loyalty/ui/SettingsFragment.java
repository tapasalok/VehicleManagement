/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.CursorLoader;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.actionbarsherlock.app.SherlockFragment;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryDao;
import com.manthansystems.loyalty.data.requestmanager.RequestManager;
import com.manthansystems.loyalty.data.requestmanager.RequestManager.OnRequestFinishedListener;
import com.manthansystems.loyalty.service.WorkerService;
import com.manthansystems.loyalty.ui.phone.EnterEmailActivity;
import com.manthansystems.loyalty.util.AnalyticsHelper;
import com.manthansystems.loyalty.util.NetworkHelper;
import com.manthansystems.loyalty.util.NetworkHelper.REQUEST_TYPE;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;
import com.manthansystems.loyalty.worker.BaseWorker.DownloadFormat;
import com.manthansystems.loyalty.worker.SettingsWorker;

/**
 * A Fragment class that will manage user settings. This class extends
 * {@link SherlockFragment}.
 * 
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class SettingsFragment extends SherlockFragment implements
		OnRequestFinishedListener {

	private final String LOG_TAG = "SettingsFragment";

	private final String SAVED_STATE_REQUEST_ID = "com.manthansystems.loyalty.ui.SettingsFragment#RequestId";
	private final String KEY_NAME_SELECTED_CATEGORY_LIST = "com.manthansystems.loyalty.ui.SettingsFragment#SelectedCategoryList";
	private final String KEY_NAME_CLICKED_CATEGORY_NAME_LIST = "com.manthansystems.loyalty.ui.SettingsFragment#ClickedCategoryNameList";
	private final String CHECK_FLAG = "1";
	private final String UNCHECK_FLAG = "0";

	private ViewGroup mView;
	private Handler mHandler;
	private RequestManager mRequestManager;
	private int mRequestId = -1;

	private String mErrorMessage;
	private String mErrorTitle;
	private Bundle mResponseBundle;
	private byte mRequestType;
	private boolean mShowProgressBar = false;
	private ToggleButton mToggleButtonNotification;
	private ArrayList<String> mSelectedCategoryIdList;
	private ArrayList<String> mCategoryClickedNameList;
	private Button mButtonDone;

	private AlertDialog mAlertDialog;

	private LinearLayout mLinearLayoutCategoryContainer;
	private LinearLayout mLinearLayoutCategoryList;
	private LinearLayout mLinearLayoutCategoryBottomBar;
	String prefmsg;

	private SparseArray<CategoryRowData> mCategoryRowDataMap;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState == null) {
			mSelectedCategoryIdList = new ArrayList<String>();
			mCategoryClickedNameList = new ArrayList<String>();

		} else {

			mSelectedCategoryIdList = savedInstanceState
					.getStringArrayList(KEY_NAME_SELECTED_CATEGORY_LIST);
			mCategoryClickedNameList = savedInstanceState
					.getStringArrayList(KEY_NAME_CLICKED_CATEGORY_NAME_LIST);
			mRequestId = savedInstanceState.getInt(SAVED_STATE_REQUEST_ID);
		}
		mHandler = new Handler();
		mRequestManager = RequestManager.from(getActivity());
		mCategoryRowDataMap = new SparseArray<SettingsFragment.CategoryRowData>();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(
				R.layout.fragment_settings_screen, null);

		// For some reason, if we omit this, NoSaveStateFrameLayout thinks we
		// are
		// FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top
		// of the activity.
		root.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT));
		mView = root;
		bindViews();
		return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onPause() {
		super.onPause();
		// un-register sliding menu open listener.
		((HomeActivity) getActivity()).getSlidingMenu().setOnOpenListener(null);
		if (mRequestId != -1) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
			mRequestManager
					.removeOnRequestFinishedListener(SettingsFragment.this);
		}
		dismissActiveDialog();
	}

	@Override
	public void onResume() {
		super.onResume();
		// register sliding menu open listener to update slide menu row
		// selection.
		((HomeActivity) getActivity()).getSlidingMenu().setOnOpenListener(
				onSlidingMenuOpenListener);
		if (mRequestId != -1) {
			if (mRequestManager.isRequestInProgress(mRequestId)) {
				mRequestManager
						.addOnRequestFinishedListener(SettingsFragment.this);
			} else {
				mRequestId = -1;
			}
		}
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		}
		mShowProgressBar = true;

		if (PreferenceConfig.isAllCategoryTimestampExpired(getActivity())) {
			LogConfig.logv(LOG_TAG,
					"onResume(): Timestamp expired: downloaded categories");
			callGetCategoryWS();

		} else {
			LogConfig.logv(LOG_TAG, "onResume(): Timestamp Valid");

			if (PreferenceConfig.isValidUser(getActivity())) {

				LogConfig.logv(LOG_TAG, "onResume(): callGetUserCategoryWS()");
				callGetCategoryWS();
				callGetUserCategoryWS();
			} else {

				renderCategoryList();
				dismissActiveDialog();
				showDialog(DialogConfig.DIALOG_SIGN_UP);
			}
		}
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putInt(SAVED_STATE_REQUEST_ID, mRequestId);
		outState.putStringArrayList(KEY_NAME_SELECTED_CATEGORY_LIST,
				mSelectedCategoryIdList);
		outState.putStringArrayList(KEY_NAME_CLICKED_CATEGORY_NAME_LIST,
				mCategoryClickedNameList);
		super.onSaveInstanceState(outState);
	}

	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.label_tab_preferences, false, true,
				true, getSherlockActivity());
		View view = ((SherlockFragmentActivity) getActivity())
				.getSupportActionBar().getCustomView();
		if (view != null) {
			view.findViewById(R.id.ImageView_Slide_Menu_icon)
					.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							((BaseSlidingActivity) getActivity())
									.getSlidingMenu().showMenu(true);
						}
					});
		}
		mToggleButtonNotification = (ToggleButton) mView
				.findViewById(R.id.toggle_button_notification);
		mButtonDone = (Button) mView.findViewById(R.id.button_done);
		mButtonDone.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				callSendUserCategoryToServerWS();
				if (mCategoryClickedNameList.size() > 0) {
					AnalyticsHelper.sendMyCategoryClickedAnalytics(
							getActivity(), mCategoryClickedNameList);
					mCategoryClickedNameList.clear();
				}
				prefmsg = getResources().getString(R.string.pref_update_msg);
			}
		});

		setToggleButton(PreferenceConfig.isEnableNotification(getActivity()));
		mToggleButtonNotification.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				boolean toggleStatus = mToggleButtonNotification.isChecked();
				setToggleButton(toggleStatus);
				callSetPushNoticationWS(toggleStatus);
			}
		});

		mLinearLayoutCategoryContainer = (LinearLayout) mView
				.findViewById(R.id.category_list_container);
		mLinearLayoutCategoryList = (LinearLayout) mView
				.findViewById(R.id.LinearLayout_category_list);
		mLinearLayoutCategoryBottomBar = (LinearLayout) mView
				.findViewById(R.id.LinearLayout_List_Bottom_Bar);
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			// must reset refreshing, if requested or not.
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(SettingsFragment.this);
			mRequestId = -1;
			if (resultCode != WorkerService.ERROR_CODE) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			} else {
				// Handle error states here !
				if (payload != null) {
					final int errorType = payload.getInt(
							RequestManager.RECEIVER_EXTRA_ERROR_TYPE, -1);
					if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA) {
						mErrorMessage = getResources().getString(
								R.string.toast_parsing_error);
					} else if (errorType == RequestManager.RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION) {
						mErrorMessage = getResources().getString(
								R.string.toast_server_connection_error);
					} else {
						mErrorMessage = getResources().getString(
								R.string.toast_response_error);
					}
				} else {
					mErrorMessage = getResources().getString(
							R.string.toast_response_error);
				}
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			}
		}
	}

	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {

		@Override
		public void run() {
			String responseStatus = mResponseBundle
					.getString(CommonConfig.KEY_NAME_RESPONSE_STATUS);
			if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
				if (mRequestType == REQUEST_TYPE.GET_ALL_CATEGORIES) {
					allCategoriesDownloadedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.GET_USER_CATEGORIES) {
					userCategoriesDownloadedDoSomething();
				} else if (mRequestType == REQUEST_TYPE.ENABLE_PUSH_NOTIFICATION) {
					ProgressBarHelper.dismissProgressBar(mHandler);
					PreferenceConfig.setEnableNotification(true, getActivity());
					AnalyticsHelper.sendPushNotificationClickedAnalytics(
							getActivity(),
							getResources().getString(R.string.toggle_on));
				} else if (mRequestType == REQUEST_TYPE.DISABLE_PUSH_NOTIFICATION) {
					ProgressBarHelper.dismissProgressBar(mHandler);
					PreferenceConfig
							.setEnableNotification(false, getActivity());
					AnalyticsHelper.sendPushNotificationClickedAnalytics(
							getActivity(),
							getResources().getString(R.string.toggle_off));
				} else if (mRequestType == REQUEST_TYPE.SEND_USER_CATEGORIES) {
					allCategoriesDownloadedDoSomething();
					ProgressBarHelper.dismissProgressBar(mHandler);
					showDialog(DialogConfig.DIALOG_PREF_UPDATED);

				}
			} else if (responseStatus != null
					&& responseStatus
							.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
				ProgressBarHelper.dismissProgressBar(mHandler);

				mErrorMessage = mResponseBundle
						.getString(CommonConfig.KEY_NAME_ERROR_MSG);
				if (!TextUtils.isEmpty(mErrorMessage)) {
					mErrorTitle = getResources().getString(
							R.string.dialog_error_title);
					showDialog(DialogConfig.DIALOG_ERROR);
				}
				if (mRequestType == REQUEST_TYPE.DISABLE_PUSH_NOTIFICATION) {
					errorHandlingForPushNotificationToggle();
				} else if (mRequestType == REQUEST_TYPE.ENABLE_PUSH_NOTIFICATION) {
					errorHandlingForPushNotificationToggle();
				} else {
					if (!PreferenceConfig.isValidUser(getActivity())) {
						dismissActiveDialog();
						showDialog(DialogConfig.DIALOG_SIGN_UP);
					}
					renderCategoryList();
				}
			} else {
				ProgressBarHelper.dismissProgressBar(mHandler);
			}
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			if (!TextUtils.isEmpty(mErrorMessage)) {
				mErrorTitle = getResources().getString(
						R.string.dialog_error_title);
				showDialog(DialogConfig.DIALOG_ERROR);
			}
			if (mRequestType == REQUEST_TYPE.DISABLE_PUSH_NOTIFICATION) {
				errorHandlingForPushNotificationToggle();
			} else if (mRequestType == REQUEST_TYPE.ENABLE_PUSH_NOTIFICATION) {
				errorHandlingForPushNotificationToggle();
			} else {
				if (!PreferenceConfig.isValidUser(getActivity())) {
					dismissActiveDialog();
					showDialog(DialogConfig.DIALOG_SIGN_UP);
				}
				renderCategoryList();
			}
		}
	};

	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
					.setTitle(mErrorTitle)
					.setMessage(mErrorMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							});
			break;
		case DialogConfig.DIALOG_PREF_UPDATED:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(R.string.pref_update_msg)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									
								}
							});
			break;
		case DialogConfig.DIALOG_SIGN_UP:
			dlg.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(R.string.dialog_signup_user_message_preferences)
					.setCancelable(false)
					.setNegativeButton(android.R.string.cancel,
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									((HomeActivity) getActivity())
											.setCurrentTab(HomeActivity.TAB_OFFERS);

								}
							})
					.setPositiveButton(R.string.label_sign_up,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
									getActivity().startActivity(
											new Intent(getActivity(),
													EnterEmailActivity.class));

								}
							});
			break;
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mView != null) {
			UIUtils.unbindDrawables(mView
					.findViewById(R.id.root_view_settings_screen));
			System.gc();
		}
	}

	/** Make server request to get category from server. */
	private void callGetCategoryWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			renderCategoryList();
			mErrorMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}

		ProgressBarHelper.showProgressBarSmall(
				R.string.progress_bar_please_wait, false, mHandler,
				getSherlockActivity());
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(SettingsFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.GET_ALL_CATEGORIES;
		params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
				SettingsWorker.WorkerModes.WORKER_MODE_GET_ALL_CATEGORY);
		mRequestId = mRequestManager.getAllCategories(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/**
	 * A method to perform action after sucessfully downloading of all category.
	 **/
	private void allCategoriesDownloadedDoSomething() {

		if (PreferenceConfig.isValidUser(getActivity())) {

			LogConfig.logv(LOG_TAG, "onResume(): callGetUserCategoryWS()");
			callGetUserCategoryWS();
		} else {

			ProgressBarHelper.dismissProgressBar(mHandler);
			mSelectedCategoryIdList.clear();
			renderCategoryList();
			dismissActiveDialog();
			showDialog(DialogConfig.DIALOG_SIGN_UP);
		}
	}

	/** A method to render category list from database. */
	private void renderCategoryList() {
		Activity activity = getActivity();
		CursorLoader cursorLoader = new CursorLoader(activity,
				CategoryDao.CONTENT_URI, null, CategoryDao.IS_MAIN_CATEGORY
						+ " = " + CategoryDao.IS_MAIN_CATEGORY + " AND "
						+ CategoryDao.CATEGORY_ID + " != "
						+ UIApplication.NEW_CATEGORY_ID, null, null);
		Cursor cursor = cursorLoader.loadInBackground();

		if (cursor != null && cursor.getCount() > 0) {
			LogConfig.logv(LOG_TAG, "queryCategoryList(): cursor.getCount() = "
					+ cursor.getCount());
			LayoutInflater inflater = (LayoutInflater) activity
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			// Initially hide the category container.
			mLinearLayoutCategoryBottomBar.setVisibility(View.GONE);

			// first remove all previously added category views, if any.
			mLinearLayoutCategoryList.removeAllViews();

			// reset the scroll position of root view to top.
			mView.findViewById(R.id.root_view_settings_screen).scrollTo(0, 0);

			String categoryOwnerId = "";
			int rowIndex = 0;

			cursor.moveToPosition(-1);
			while (cursor.moveToNext()) {
				String categoryName = cursor
						.getString(CategoryDao.CONTENT_CATEGORY_NAME_COLUMN);
				if (!TextUtils.isEmpty(categoryName)) {
					String categoryId = cursor
							.getString(CategoryDao.CONTENT_CATEGORY_ID_COLUMN);

					final int index = rowIndex;

					final CategoryRowData rowData = new CategoryRowData();
					rowData.mCategoryId = categoryId;
					rowData.mCategoryName = categoryName;
					rowData.mCategoryCheckFlag = cursor
							.getString(CategoryDao.CONTENT_CATEGORY_CHECK_FLAG_COLUMN);

					// Inflate and populate the category row data.
					final View rowView = inflater.inflate(
							R.layout.row_for_categories, null);
					TextView textViewCategoryName = (TextView) rowView
							.findViewById(R.id.textView_category_name);
					if (categoryName.startsWith(" ")) {
						textViewCategoryName.setTypeface(
								textViewCategoryName.getTypeface(),
								Typeface.NORMAL);
					} else {
						textViewCategoryName.setTypeface(
								textViewCategoryName.getTypeface(),
								Typeface.BOLD);
						categoryOwnerId = categoryId;
					}
					textViewCategoryName.setText(categoryName);
					rowData.mCategoryOwnerId = categoryOwnerId;
					mCategoryRowDataMap.put(rowIndex, rowData);
					rowIndex++;

					final ImageView imageViewTick = (ImageView) rowView
							.findViewById(R.id.imageView_select_category);
					if (rowData.mCategoryCheckFlag.equals(CHECK_FLAG)) {
						imageViewTick
								.setBackgroundResource(R.drawable.tick_category_prefs);
					} else {
						imageViewTick.setBackgroundResource(R.drawable.untick);
					}
					// don't add the line separator in last category item.
					if (!cursor.isLast()) {
						rowView.setBackgroundResource(R.drawable.category_list_row_line_bg);
					}

					// Set the click listener to check/un-check the categories.
					rowView.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							handleCategoryCheckFlags(index);
						}
					});
					mLinearLayoutCategoryList.addView(rowView);
				}
			}

			// Do update the category selection flags.
			for (int index = 0; index < mLinearLayoutCategoryList
					.getChildCount(); ++index) {
				CategoryRowData rowMetaData = mCategoryRowDataMap.get(index);
				if (rowMetaData != null
						&& !TextUtils.isEmpty(rowMetaData.mCategoryId)
						&& mSelectedCategoryIdList
								.contains(rowMetaData.mCategoryId)) {
					LogConfig.logv(LOG_TAG,
							"renderCategoryList(): CategoryId = "
									+ rowMetaData.mCategoryId
									+ ", categoryName = "
									+ rowMetaData.mCategoryName);
					checkMarkSelectedCategory(rowMetaData, index);
					LogConfig.logv(LOG_TAG, "mSelectedCategoryIdList.size() = "
							+ mSelectedCategoryIdList.size());
					LogConfig.logv(LOG_TAG, "mCategoryRowDataMap.size() = "
							+ mCategoryRowDataMap.size());
				}
			}

			// show the updated category list.
			mLinearLayoutCategoryContainer.setVisibility(View.VISIBLE);
			mLinearLayoutCategoryBottomBar.setVisibility(View.VISIBLE);
		}
		if (cursor != null) {
			cursor.close();
		}
		ProgressBarHelper.dismissProgressBar(mHandler);
	}

	/**
	 * A method to make server request to send user selected category to server.
	 **/
	private void callSendUserCategoryToServerWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}
		Bundle params = new Bundle();
		String selectedCategoryID = "";
		if (mSelectedCategoryIdList.contains(UIApplication.All_CATEGORY_ID)) {
			mSelectedCategoryIdList.remove(UIApplication.All_CATEGORY_ID);
			selectedCategoryID = mSelectedCategoryIdList.toString();
			mSelectedCategoryIdList.add(UIApplication.All_CATEGORY_ID);
		} else {
			selectedCategoryID = mSelectedCategoryIdList.toString();
		}
		StringBuilder data = new StringBuilder("{\"categories\":");
		data.append(selectedCategoryID).append("}");
		mRequestManager.addOnRequestFinishedListener(SettingsFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.SEND_USER_CATEGORIES;
		params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
				SettingsWorker.WorkerModes.WORKER_MODE_SEND_USER_CATEGORY);
		params.putString(SettingsWorker.KEY_NAME_BUNDLE_BODY_DATA,
				data.toString());
		mRequestId = mRequestManager.sendUserCategory(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/** A method to make server for getting user category. **/
	private void callGetUserCategoryWS() {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			renderCategoryList();
			mErrorMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(SettingsFragment.this);
		mRequestType = NetworkHelper.REQUEST_TYPE.GET_USER_CATEGORIES;
		params.putByte(SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
				SettingsWorker.WorkerModes.WORKER_MODE_GET_USER_CATEGORY);
		mRequestId = mRequestManager.getUserCategory(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/** A method to make server request for enable/disable push notification. **/
	private void callSetPushNoticationWS(boolean checked) {
		// Check if network available
		if (!NetworkHelper.isNetworkAvailable(getActivity())) {
			mErrorMessage = getResources().getString(
					R.string.network_not_available_msg);
			mErrorTitle = getResources().getString(
					R.string.network_not_available_title);
			showDialog(DialogConfig.DIALOG_ERROR);
			errorHandlingForPushNotificationToggle();
			return;
		}
		if (!ProgressBarHelper.isProgressBarRunning()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, false, mHandler,
					getSherlockActivity());
		}
		Bundle params = new Bundle();
		mRequestManager.addOnRequestFinishedListener(SettingsFragment.this);
		if (checked) {
			mRequestType = NetworkHelper.REQUEST_TYPE.ENABLE_PUSH_NOTIFICATION;
			params.putByte(
					SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
					SettingsWorker.WorkerModes.WORKER_MODE_ENABLE_PUSH_NOTIFICATION);
		} else {
			mRequestType = NetworkHelper.REQUEST_TYPE.DISABLE_PUSH_NOTIFICATION;
			params.putByte(
					SettingsWorker.KEY_NAME_BUNDLE_SETTINGS_WORKER_MODE,
					SettingsWorker.WorkerModes.WORKER_MODE_DISABLE_PUSH_NOTIFICATION);
		}
		mRequestId = mRequestManager.setPushNotification(
				DownloadFormat.RETURN_FORMAT_JSON, params);
	}

	/** A method to perform action after successfully download of category. **/
	private void userCategoriesDownloadedDoSomething() {
		ProgressBarHelper.dismissProgressBar(mHandler);
		mSelectedCategoryIdList = mResponseBundle
				.getStringArrayList(CommonConfig.KEY_NAME_USER_CATEGORY_LIST);

		// update the category check flags in db.
		updateCategoryCheckFlags();
		// render the category list with user selection status.
		renderCategoryList();
	}

	/** A method to handle error response to toggle push notification request. */
	private void errorHandlingForPushNotificationToggle() {
		setToggleButton(PreferenceConfig.isEnableNotification(getActivity()));
	}

	/** A method to set toggle Push notification On/Off status. */
	private void setToggleButton(boolean toggle) {
		mToggleButtonNotification.setChecked(toggle);
		if (mToggleButtonNotification.isChecked()) {
			mToggleButtonNotification.setGravity(Gravity.LEFT
					| Gravity.CENTER_VERTICAL);
			mToggleButtonNotification.setTextColor(getResources().getColor(
					android.R.color.white));
		} else {
			mToggleButtonNotification.setGravity(Gravity.RIGHT
					| Gravity.CENTER_VERTICAL);
			mToggleButtonNotification.setTextColor(getResources().getColor(
					android.R.color.black));
		}
	}

	/** Method to dismiss any active {@link AlertDialog}. */
	private void dismissActiveDialog() {
		if (mAlertDialog != null && mAlertDialog.isShowing()) {
			mAlertDialog.dismiss();
		}
	}

	/**
	 * A model class that holds the category row data.
	 * 
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 *
	 */
	private class CategoryRowData {
		public String mCategoryId;
		public String mCategoryName;
		public String mCategoryCheckFlag;
		public String mCategoryOwnerId;
	}

	/** Method to handle the category clicks on category list. */
	private void handleCategoryCheckFlags(int rowIndex) {
		CategoryRowData rowMetaData = mCategoryRowDataMap.get(rowIndex);
		if (!TextUtils.isEmpty(rowMetaData.mCategoryId)) {
			LogConfig.logv(LOG_TAG, "onListItemClick(): CategoryId = "
					+ rowMetaData.mCategoryId + ", categoryName = "
					+ rowMetaData.mCategoryName);
			if (rowMetaData.mCategoryId
					.equalsIgnoreCase(UIApplication.All_CATEGORY_ID)) {
				LogConfig.logv(LOG_TAG, "onListItemClick(): ALL Clicked");
				handleCategoryALLClick();
			} else {
				if (mSelectedCategoryIdList.contains(rowMetaData.mCategoryId)) {
					uncheckSelectedCetegory(rowMetaData, rowIndex);
				} else {
					checkMarkSelectedCategory(rowMetaData, rowIndex);
				}
			}
			LogConfig.logv(LOG_TAG, "mSelectedCategoryIdList.size() = "
					+ mSelectedCategoryIdList.size());
			LogConfig.logv(LOG_TAG, "mCategoryRowDataMap.size() = "
					+ mCategoryRowDataMap.size());
		}
	}

	/** Method to update the category check flags based on users selection. */
	private void updateCategoryCheckFlags() {
		String userSelectedCetegoryIds = mSelectedCategoryIdList.toString();
		LogConfig.logd(LOG_TAG,
				"updateCategoryCheckFlags(): userSelectedCetegoryIds = "
						+ userSelectedCetegoryIds);
		userSelectedCetegoryIds = userSelectedCetegoryIds.replace("[", "");
		userSelectedCetegoryIds = userSelectedCetegoryIds.replace("]", "");
		String where = CategoryDao.CATEGORY_ID + " IN ("
				+ userSelectedCetegoryIds + ")";
		ContentValues values = new ContentValues();
		values.put(CategoryDao.CATEGORY_CHECK_FLAG, CHECK_FLAG);
		getActivity().getContentResolver().update(CategoryDao.CONTENT_URI,
				values, where, null);
		where = CategoryDao.CATEGORY_ID + " NOT IN (" + userSelectedCetegoryIds
				+ ")";
		values = new ContentValues();
		values.put(CategoryDao.CATEGORY_CHECK_FLAG, UNCHECK_FLAG);
		getActivity().getContentResolver().update(CategoryDao.CONTENT_URI,
				values, where, null);
	}

	/** Method to check all the categories in UI. */
	private void checkAllCategories() {
		LogConfig.logv(LOG_TAG, "checkAllCategories()");
		if (mLinearLayoutCategoryList != null
				&& mLinearLayoutCategoryList.getChildCount() > 0) {
			int size = mLinearLayoutCategoryList.getChildCount();
			LogConfig.logv(LOG_TAG, "checkAllCategories() Check all views: "
					+ size);
			View rowView = null;
			for (int index = 0; index < size; ++index) {
				rowView = mLinearLayoutCategoryList.getChildAt(index);
				rowView.findViewById(R.id.imageView_select_category)
						.setBackgroundResource(R.drawable.tick_category_prefs);
			}
		}
	}

	/** Method to un-check all the categories in UI. */
	private void uncheckAllCategories() {
		LogConfig.logv(LOG_TAG, "uncheckAllCategories()");
		if (mLinearLayoutCategoryList != null
				&& mLinearLayoutCategoryList.getChildCount() > 0) {
			int size = mLinearLayoutCategoryList.getChildCount();
			LogConfig.logv(LOG_TAG,
					"uncheckAllCategories() UnCheck all views: " + size);
			View rowView = null;
			for (int index = 0; index < size; ++index) {
				rowView = mLinearLayoutCategoryList.getChildAt(index);
				rowView.findViewById(R.id.imageView_select_category)
						.setBackgroundResource(R.drawable.untick);
			}
		}
	}

	/** Method to process the category selection when category ALL is clicked. */
	private void handleCategoryALLClick() {
		LogConfig.logv(LOG_TAG, "handleCategoryALLClick()");
		if (mSelectedCategoryIdList.contains(UIApplication.All_CATEGORY_ID)) {
			mSelectedCategoryIdList.clear();
			// UnCheck all views here.
			uncheckAllCategories();
		} else {
			int categoryListSize = mCategoryRowDataMap.size();
			mSelectedCategoryIdList.clear();
			for (int i = 0; i < categoryListSize; i++) {
				mSelectedCategoryIdList
						.add(mCategoryRowDataMap.get(i).mCategoryId);
				mCategoryClickedNameList
						.add(mCategoryRowDataMap.get(i).mCategoryName);
			}
			// check all categories here.
			checkAllCategories();
		}
	}

	/** Method to uncheck selected categories. */
	private void uncheckSelectedCetegory(CategoryRowData rowMetaData,
			int rowIndex) {
		LogConfig.logv(LOG_TAG, "uncheckSelectedCetegory(): Remove tick ");
		mSelectedCategoryIdList.remove(rowMetaData.mCategoryId);
		mLinearLayoutCategoryList.getChildAt(rowIndex)
				.findViewById(R.id.imageView_select_category)
				.setBackgroundResource(R.drawable.untick);
		if (mSelectedCategoryIdList.contains(UIApplication.All_CATEGORY_ID)) {
			LogConfig.logv(LOG_TAG,
					"uncheckSelectedCetegory(): Remove tick : Uncheck ALL");
			mSelectedCategoryIdList.remove(UIApplication.All_CATEGORY_ID);
			// Uncheck only ALL category here.
			mLinearLayoutCategoryList.getChildAt(0)
					.findViewById(R.id.imageView_select_category)
					.setBackgroundResource(R.drawable.untick);
		}

		if (rowMetaData.mCategoryId
				.equalsIgnoreCase(rowMetaData.mCategoryOwnerId)) {
			LogConfig
					.logv(LOG_TAG,
							"uncheckSelectedCetegory(): Remove tick : Its  Main Category");
			// Its a Main category.
			// Un-Check all its sub categories also.
			for (int i = 0; i < mCategoryRowDataMap.size(); ++i) {
				CategoryRowData data = mCategoryRowDataMap.get(i);
				if (data.mCategoryOwnerId
						.equalsIgnoreCase(rowMetaData.mCategoryId)) {
					LogConfig.logv(LOG_TAG,
							"uncheckSelectedCetegory(): UnCheck its Sub Cats : "
									+ data.mCategoryName);
					mLinearLayoutCategoryList.getChildAt(i)
							.findViewById(R.id.imageView_select_category)
							.setBackgroundResource(R.drawable.untick);
					mSelectedCategoryIdList.remove(data.mCategoryId);
				}
			}
		} else {
			LogConfig.logv(LOG_TAG,
					"uncheckSelectedCetegory(): Its a Sub Category");
			// Its a Sub category
			// Un-Check its Main category if not unchecked.
			for (int i = 0; i < mCategoryRowDataMap.size(); ++i) {
				CategoryRowData data = mCategoryRowDataMap.get(i);
				if (data.mCategoryId
						.equalsIgnoreCase(rowMetaData.mCategoryOwnerId)) {
					LogConfig
							.logv(LOG_TAG,
									"uncheckSelectedCetegory(): UnCheck its Main Cat if not.");
					mLinearLayoutCategoryList.getChildAt(i)
							.findViewById(R.id.imageView_select_category)
							.setBackgroundResource(R.drawable.untick);
					mSelectedCategoryIdList.remove(data.mCategoryId);
					break;
				}
			}
		}
	}

	/** Method to make check mark to the selected categories. */
	private void checkMarkSelectedCategory(CategoryRowData rowMetaData,
			int rowIndex) {
		LogConfig.logv(LOG_TAG, "checkMarkSelectedCategory(): Add tick ");
		if (rowMetaData.mCategoryId
				.equalsIgnoreCase(rowMetaData.mCategoryOwnerId)) {
			LogConfig
					.logv(LOG_TAG,
							"checkMarkSelectedCategory(): Add tick: Its a main category ");
			// Its a Main category.
			// Check all its sub categories also.
			for (int i = 0; i < mCategoryRowDataMap.size(); ++i) {
				CategoryRowData data = mCategoryRowDataMap.get(i);
				if (data.mCategoryOwnerId
						.equalsIgnoreCase(rowMetaData.mCategoryId)) {
					LogConfig.logv(LOG_TAG,
							"checkMarkSelectedCategory(): Add tick: check all sub cats: "
									+ data.mCategoryName);
					mLinearLayoutCategoryList
							.getChildAt(i)
							.findViewById(R.id.imageView_select_category)
							.setBackgroundResource(
									R.drawable.tick_category_prefs);
					if (!mSelectedCategoryIdList.contains(data.mCategoryId)) {
						mSelectedCategoryIdList.add(data.mCategoryId);
						mCategoryClickedNameList.add(data.mCategoryName);
					}
				}
			}
		} else {
			LogConfig
					.logv(LOG_TAG,
							"checkMarkSelectedCategory(): Add tick: Its a sub category");
			// Its a Sub category
			// Check if all Sub categories are selected.
			// If yes, then Check its Main category too.
			if (!mSelectedCategoryIdList.contains(rowMetaData.mCategoryId)) {
				mSelectedCategoryIdList.add(rowMetaData.mCategoryId);
				mCategoryClickedNameList.add(rowMetaData.mCategoryName);
			}
			mLinearLayoutCategoryList.getChildAt(rowIndex)
					.findViewById(R.id.imageView_select_category)
					.setBackgroundResource(R.drawable.tick_category_prefs);

			boolean isAllSelected = true;
			int mainCategoryIndex = -1;
			for (int i = 0; i < mCategoryRowDataMap.size(); ++i) {
				CategoryRowData data = mCategoryRowDataMap.get(i);
				if (data.mCategoryOwnerId
						.equalsIgnoreCase(rowMetaData.mCategoryOwnerId)) {
					if (!data.mCategoryId
							.equalsIgnoreCase(rowMetaData.mCategoryOwnerId)) {
						if (!mSelectedCategoryIdList.contains(data.mCategoryId)) {
							isAllSelected = false;
							break;
						}
					} else {
						mainCategoryIndex = i;
					}
				}
			}
			if (isAllSelected) {
				LogConfig
						.logv(LOG_TAG,
								"checkMarkSelectedCategory(): Add tick: Its a sub category: every sub cat is selected so check mark Main cat too.");
				mLinearLayoutCategoryList.getChildAt(mainCategoryIndex)
						.findViewById(R.id.imageView_select_category)
						.setBackgroundResource(R.drawable.tick_category_prefs);
				if (!mSelectedCategoryIdList.contains(mCategoryRowDataMap
						.get(mainCategoryIndex).mCategoryId)) {
					mSelectedCategoryIdList.add(mCategoryRowDataMap
							.get(mainCategoryIndex).mCategoryId);
					mCategoryClickedNameList.add(mCategoryRowDataMap
							.get(mainCategoryIndex).mCategoryName);
				}
			}
		}
		// Check if all categories are checked then also check the ALL.
		if (mCategoryRowDataMap.size() == (mSelectedCategoryIdList.size() + 1)) {
			LogConfig
					.logv(LOG_TAG,
							"checkMarkSelectedCategory(): Every cat is selected so check mark ALL.");
			mLinearLayoutCategoryList.getChildAt(0)
					.findViewById(R.id.imageView_select_category)
					.setBackgroundResource(R.drawable.tick_category_prefs);
			mSelectedCategoryIdList.add(UIApplication.All_CATEGORY_ID);
		}
	}

	/** Listener that invokes for Sliding menu open event. */
	private SlidingMenu.OnOpenListener onSlidingMenuOpenListener = new SlidingMenu.OnOpenListener() {
		@Override
		public void onOpen() {
			// Now update the sliding menu selected item position.
			SliderMenuFragment sliderMenuFragment = (SliderMenuFragment) getSherlockActivity()
					.getSupportFragmentManager().findFragmentById(
							R.id.menu_frame);
			if (sliderMenuFragment != null) {
				sliderMenuFragment
						.setRowSelected(HomeActivity.POSITION_TAB_PREFERENCES);
			}
		}
	};
}
