/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.factory;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.text.TextUtils;

import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.model.CategoryCount;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.Store;
import com.manthansystems.loyalty.ui.UIApplication;
import com.manthansystems.loyalty.util.NetworkHelper;

/**
 * A JSON parser class that will parse the {@link Coupon} list response
 *  from json string coming from server.
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 *
 */
public class OffersJSONParserFactory extends BaseJsonParser {
	
	private static String LOG_TAG = "OffersJSONParserFactory";

	/** Call to parse coupons and stores response from JSON string. */
	public synchronized static HashMap<String, Object> parseCouponsAndStores(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		ArrayList<Coupon> couponList = new ArrayList<Coupon>();
		ArrayList<Store> storeList = new ArrayList<Store>();
		ArrayList<CategoryCount> categoryCount = new ArrayList<CategoryCount>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);

		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.OFFERS_RESULTS_TAG)) {
				JSONObject offersJsonObject = response.getJSONObject(JSONTagConstants.OFFERS_RESULTS_TAG);
				// parse coupons
				couponList = parseCoupons(offersJsonObject);
				// parse stores
				storeList = parseStores(offersJsonObject);
				// parse category count
				categoryCount = parseCategoryIds(offersJsonObject);
				if (couponList.size() == 0) {
					// parse message
					if (response.has(JSONTagConstants.RESPONSE_RESULTS_MESSAGE)) {
						map.put(CommonConfig.KEY_NAME_RESULTS_MESSAGE, response.getString(JSONTagConstants.RESPONSE_RESULTS_MESSAGE));
					}
				}
			}
			map.put(CommonConfig.KEY_NAME_OFFER_LIST, couponList);
			map.put(CommonConfig.KEY_NAME_STORE_LIST, storeList);
			map.put(CommonConfig.KEY_NAME_CATEGORY_COUNT, categoryCount);
			map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
		} else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	/**
	 * Method to parse all the {@link Coupon} from json response.
	 * @param offersJsonObject offer json object
	 * @return array list of {@link Coupon}
	 * @throws JSONException
	 */
	public static ArrayList<Coupon> parseCoupons(JSONObject offersJsonObject) throws JSONException {
		ArrayList<Coupon> couponsArray = new ArrayList<Coupon>();
		if (offersJsonObject.has(JSONTagConstants.OFFERS_ROOT_TAG)) {
			JSONArray offersJsonArray = offersJsonObject.getJSONArray(JSONTagConstants.OFFERS_ROOT_TAG);
			int size = offersJsonArray.length();
			LogConfig.logv(LOG_TAG, " ---- ****TOTAL COUPON*****  ---- " + size);
			for (int i = 0; i < size; ++i) {
				JSONObject couponData = offersJsonArray.getJSONObject(i);
				final Coupon coupon = new Coupon();
				//Log.v(LOG_TAG, " ---- *********  ----");
				if (couponData.has(JSONTagConstants.OFFERS_COUPON_TYPE)) {
					coupon.mCouponType = couponData.getString(JSONTagConstants.OFFERS_COUPON_TYPE);
					//Log.v(LOG_TAG, "coupon.mCouponType = " + coupon.mCouponType);
				}
				if (couponData.has(JSONTagConstants.OFFERS_COUPON_URL)) {
					coupon.mCouponUrl = NetworkHelper.getEncodedUrl(
							couponData.getString(JSONTagConstants.OFFERS_COUPON_URL));
					//Log.v(LOG_TAG, "coupon.mCouponUrl = " + coupon.mCouponUrl);
				}
				if (couponData.has(JSONTagConstants.OFFERS_DESCRIPTION)) {
					coupon.mDescription = couponData.getString(JSONTagConstants.OFFERS_DESCRIPTION);
					//Log.v(LOG_TAG, "coupon.mDescription = " + coupon.mDescription);
				}
				if (couponData.has(JSONTagConstants.OFFERS_DISCOUNT)) {
					coupon.mDiscount = couponData.getString(JSONTagConstants.OFFERS_DISCOUNT);
					//Log.v(LOG_TAG, "coupon.mDiscount = " + coupon.mDiscount);
				}
				if (couponData.has(JSONTagConstants.OFFERS_EXPIRY_DATE)) {
					coupon.mExpiryDate = couponData.getString(JSONTagConstants.OFFERS_EXPIRY_DATE);
					//Log.v(LOG_TAG, "coupon.mExpiryDate = " + coupon.mExpiryDate);
				}
				if (couponData.has(JSONTagConstants.OFFERS_ID)) {
					coupon.mId = couponData.getInt(JSONTagConstants.OFFERS_ID);
					//Log.v(LOG_TAG, "coupon.mId = " + coupon.mId);
				}
				if (couponData.has(JSONTagConstants.OFFERS_IMAGE_URL)) {
					coupon.mImageUrl = NetworkHelper.getEncodedUrl(
							couponData.getString(JSONTagConstants.OFFERS_IMAGE_URL));
					//Log.v(LOG_TAG, "coupon.mImageUrl = " + coupon.mImageUrl);
				}
				if (couponData.has(JSONTagConstants.OFFERS_TITLE)) {
					coupon.mTitle = couponData.getString(JSONTagConstants.OFFERS_TITLE);
					//Log.v(LOG_TAG, "coupon.mTitle = " + coupon.mTitle);
				}
				if (couponData.has(JSONTagConstants.OFFERS_STORE_IDS)) {
					JSONArray storeIdArray = couponData.getJSONArray(JSONTagConstants.OFFERS_STORE_IDS);
					int storeIdListSize = storeIdArray.length();
					
					for (int j = 0 ; j < storeIdListSize; ++ j) {
						//Log.v(LOG_TAG, "coupon.mStoreIds = " + storeIdArray.getString(j));
						coupon.mStoreIds.add(storeIdArray.getString(j));
					}
				}
				if (couponData.has(JSONTagConstants.OFFERS_EXPIRES)) {
					coupon.mExpires = couponData.getInt(JSONTagConstants.OFFERS_EXPIRES);
					//Log.v(LOG_TAG, "coupon.mExpires = " + coupon.mExpires);
				}
				if (couponData.has(JSONTagConstants.OFFERS_DECORATORES)) {
					JSONObject decoratorObject = couponData.getJSONObject(JSONTagConstants.OFFERS_DECORATORES);
					if (decoratorObject.has(JSONTagConstants.OFFERS_DECORATORES_BOLD)) {
						JSONArray decoratorBoldArray = decoratorObject.getJSONArray(
								JSONTagConstants.OFFERS_DECORATORES_BOLD);
						int boldItemsSize = decoratorBoldArray.length();
						for (int k = 0; k < boldItemsSize; k ++) {
							coupon.mDecorators.add(decoratorBoldArray.getString(k));
						}
						//Log.v(LOG_TAG, "coupon.mDecorators = " + coupon.mDecorators.toString());
					}
				}
				if (couponData.has(JSONTagConstants.OFFERS_BARCODE)) {
					coupon.mBarcode = couponData.getString(JSONTagConstants.OFFERS_BARCODE);
					//Log.v(LOG_TAG, "coupon.mBarcode = " + coupon.mBarcode);
				}
				if (couponData.has(JSONTagConstants.OFFERS_BARCODE_IMAGE_URL)) {
					coupon.mBarcodeImageUrl = NetworkHelper.getEncodedUrl(
							couponData.getString(JSONTagConstants.OFFERS_BARCODE_IMAGE_URL));
					//Log.v(LOG_TAG, "coupon.mBarcodeImageUrl = " + coupon.mBarcodeImageUrl);
				}
				if (couponData.has(JSONTagConstants.OFFERS_LARGE_IMAGE_URL)) {
					coupon.mLargeImageUrl = NetworkHelper.getEncodedUrl(
							couponData.getString(JSONTagConstants.OFFERS_LARGE_IMAGE_URL));
					if (TextUtils.isEmpty(coupon.mLargeImageUrl)) {
						coupon.mLargeImageUrl = "";
					}
					//Log.v(LOG_TAG, "coupon.mLargeImageUrl = " + coupon.mLargeImageUrl);
				}
				if (couponData.has(JSONTagConstants.OFFERS_COUPON_CODE)) {
					coupon.mCouponCode = couponData.getString(JSONTagConstants.OFFERS_COUPON_CODE);
					//Log.v(LOG_TAG, "coupon.mCouponCode = " + coupon.mCouponCode);
				}
				if (couponData.has(JSONTagConstants.OFFERS_IS_NEW_COUPON)) {
					if (couponData.getBoolean(JSONTagConstants.OFFERS_IS_NEW_COUPON)) {
						coupon.mIsNewCouponFlag = CouponDao.FLAG_VALUE_NEW_COUPON;
					} else {
						coupon.mIsNewCouponFlag = CouponDao.FLAG_VALUE_NOT_NEW_COUPON;
					}
//					Log.v(LOG_TAG, "coupon.mIsNewCouponFlag = " + coupon.mIsNewCouponFlag);
				}
				if (couponData.has(JSONTagConstants.OFFER_LONG_DESCRIPTION)) {
					coupon.mLongDescription = couponData.getString(JSONTagConstants.OFFER_LONG_DESCRIPTION);
				}
				if (couponData.has(JSONTagConstants.OFFERS_IS_MARKETING_MESSAGE)) {
					if (couponData.getBoolean(JSONTagConstants.OFFERS_IS_MARKETING_MESSAGE)) {
						coupon.mIsMarketingMessageFlag = CouponDao.FLAG_VALUE_MARKETING_MESSAGE;
					} else {
						coupon.mIsMarketingMessageFlag = CouponDao.FLAG_VALUE_NON_MARKETING_MESSAGE;
					}
					//Log.v(LOG_TAG, "coupon.mIsMarketingMessageFlag = " + coupon.mIsMarketingMessageFlag);
				}
				if (couponData.has(JSONTagConstants.OFFERS_REDEEMABLE)) {
					if (couponData.optBoolean(JSONTagConstants.OFFERS_REDEEMABLE)
							&& couponData.getBoolean(JSONTagConstants.OFFERS_REDEEMABLE)) {
						coupon.mRedeemableFlag = CommonConfig.FLAG_TRUE;
					} else {
						coupon.mRedeemableFlag = CommonConfig.FLAG_FALSE;
					}
					//Log.v(LOG_TAG, "coupon.mRedeemableFlag = " + coupon.mRedeemableFlag);
				} else {
					coupon.mRedeemableFlag = CommonConfig.FLAG_FALSE;
				}
				if (couponData.has(JSONTagConstants.OFFERS_USAGE_TYPE)) {
					coupon.mUsageType = couponData.getInt(JSONTagConstants.OFFERS_USAGE_TYPE);
					//Log.v(LOG_TAG, "coupon.mUsageType = " + coupon.mUsageType);
				}
				if (couponData.has(JSONTagConstants.OFFERS_THRESHOLD_LIMIT)) {
					coupon.mThresholdLimit = couponData.getInt(JSONTagConstants.OFFERS_THRESHOLD_LIMIT);
					//Log.v(LOG_TAG, "coupon.mThresholdLimit = " + coupon.mThresholdLimit);
				}
				if (couponData.has(JSONTagConstants.OFFERS_EXHAUSTED)) {
					if (couponData.optBoolean(JSONTagConstants.OFFERS_EXHAUSTED)
							&& couponData.getBoolean(JSONTagConstants.OFFERS_EXHAUSTED)) {
						coupon.mExhaustedFlag = CommonConfig.FLAG_TRUE;
					} else {
						coupon.mExhaustedFlag = CommonConfig.FLAG_FALSE;
					}
					//Log.v(LOG_TAG, "coupon.mExhaustedFlag = " + coupon.mExhaustedFlag);
				} else {
					coupon.mExhaustedFlag = CommonConfig.FLAG_FALSE;
				}
				couponsArray.add(coupon);
			}
		}
		return couponsArray;
	}
	
	/**
	 * Method to parse all the {@link Store} from json response.
	 * @param offersJsonObject offers json object
	 * @return array list of {@link Store}
	 * @throws JSONException
	 */
	public static ArrayList<Store> parseStores(JSONObject offersJsonObject) throws JSONException {
		ArrayList<Store> storesArray = new ArrayList<Store>();
		if (offersJsonObject.has(JSONTagConstants.STORE_ROOT_TAG)) {
			JSONArray storeJsonArray = offersJsonObject.getJSONArray(JSONTagConstants.STORE_ROOT_TAG);
			int size = storeJsonArray.length();
			LogConfig.logv(LOG_TAG, " ---- =====TOTAL store=====  ---- " + size);
			for (int i = 0; i < size; ++i) {
				JSONObject storeData = storeJsonArray.getJSONObject(i);
				final Store store = new Store();
				//Log.v(LOG_TAG, " ---- ==========  ----");
				if (storeData.has(JSONTagConstants.STORE_ADDRESS1)) {
					store.mAddress1 = storeData.getString(JSONTagConstants.STORE_ADDRESS1);
					//Log.v(LOG_TAG, "store.mAddress1 = " + store.mAddress1);
				}
				if (storeData.has(JSONTagConstants.STORE_ADDRESS2)) {
					store.mAddress2 = storeData.getString(JSONTagConstants.STORE_ADDRESS2);
					//Log.v(LOG_TAG, "store.mAddress2 = " + store.mAddress2);
				}
				if (storeData.has(JSONTagConstants.STORE_PHONE)) {
					store.mPhoneNumber = storeData.getString(JSONTagConstants.STORE_PHONE);
					//Log.v(LOG_TAG, "store.mPhoneNumber = " + store.mPhoneNumber);
				}
				if (storeData.has(JSONTagConstants.STORE_CITY)) {
					store.mCity = storeData.getString(JSONTagConstants.STORE_CITY);
					//Log.v(LOG_TAG, "store.mCity = " + store.mCity);
				}
				if (storeData.has(JSONTagConstants.STORE_ID)) {
					store.mId = storeData.getString(JSONTagConstants.STORE_ID);
					//Log.v(LOG_TAG, "store.mId = " + store.mId);
				}
				if (storeData.has(JSONTagConstants.STORE_LAT)) {
					store.mLat = storeData.getString(JSONTagConstants.STORE_LAT);
					//Log.v(LOG_TAG, "store.mLat = " + store.mLat);
				}
				if (storeData.has(JSONTagConstants.STORE_LON)) {
					store.mLong = storeData.getString(JSONTagConstants.STORE_LON);
					//Log.v(LOG_TAG, "store.mLong = " + store.mLong);
				}
				if (storeData.has(JSONTagConstants.STORE_STATE)) {
					store.mState = storeData.getString(JSONTagConstants.STORE_STATE);
					//Log.v(LOG_TAG, "store.mState = " + store.mState);
				}
				if (storeData.has(JSONTagConstants.STORE_ZIP)) {
					store.mZip = storeData.getString(JSONTagConstants.STORE_ZIP);
					//Log.v(LOG_TAG, "store.mZip = " + store.mZip);
				}
				if (storeData.has(JSONTagConstants.STORE_NAME)) {
					store.mName = storeData.getString(JSONTagConstants.STORE_NAME);
					//Log.v(LOG_TAG, "store.mName = " + store.mName);
				}
				
				storesArray.add(store);
			}
		}
		return storesArray;
	}
	
	/** 
	 *  Method to parse offer count json response.
	 * @param jsonData {@link String}
	 * @return map {@link HashMap}
	 * @throws JSONException {@link JSONException}
	 */
	public synchronized static HashMap<String, Object> parseOfferCountResponse(String jsonData)
		throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));
		String statusCode = response.getString(JSONTagConstants.RESPONSE_TAG_STATUS_CODE);
		if (statusCode.equals(JSONTagConstants.RESPONSE_CODE_OK)) {
			if (parseErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_RESULTS)) {
				JSONObject resultResponseJsonObject = response.getJSONObject(JSONTagConstants.RESPONSE_RESULTS);
				if (resultResponseJsonObject.has(JSONTagConstants.PERSONAL_TAG)
						&& !resultResponseJsonObject.isNull(JSONTagConstants.PERSONAL_TAG)) {
					map.put(CommonConfig.KEY_NAME_PERSONAL_OFFER_COUNT,
							resultResponseJsonObject.getInt(JSONTagConstants.PERSONAL_TAG));
				} else {
					map.put(CommonConfig.KEY_NAME_PERSONAL_OFFER_COUNT, 0);
				}
				if (resultResponseJsonObject.has(JSONTagConstants.COMMON_TAG)
						&& !resultResponseJsonObject.isNull(JSONTagConstants.COMMON_TAG)) {
					map.put(CommonConfig.KEY_NAME_COMMON_OFFER_COUNT,
							resultResponseJsonObject.getInt(JSONTagConstants.COMMON_TAG));
				} else {
					map.put(CommonConfig.KEY_NAME_COMMON_OFFER_COUNT, 0);
				}
				if (resultResponseJsonObject.has(JSONTagConstants.FAVORITES_TAG)
						&& !resultResponseJsonObject.isNull(JSONTagConstants.FAVORITES_TAG)) {
					map.put(CommonConfig.KEY_NAME_FAVORITE_OFFER_COUNT,
							resultResponseJsonObject.getInt(JSONTagConstants.FAVORITES_TAG));
				} else {
					map.put(CommonConfig.KEY_NAME_FAVORITE_OFFER_COUNT, 0);
				}
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_SUCCESS);
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_MESSAGE)) {
				map.put(CommonConfig.KEY_NAME_ERROR_MSG, response.getString(JSONTagConstants.RESPONSE_TAG_MESSAGE));
			}
		}  else {
			if (!parseErrorJSON(response, map)) {
				// If there is not error tag in response then set status as failure.
				map.put(CommonConfig.KEY_NAME_RESPONSE_STATUS, JSONTagConstants.RESPONSE_STATUS_FAILURE);
			}
		}
		return map;
	}
	
	/**
	 * Method to parse all the category ids from json response.
	 * @param offersJsonObject offer json object
	 * @return array list of {@link CategoryCount}
	 * @throws JSONException
	 */
	public static ArrayList<CategoryCount> parseCategoryIds(JSONObject offersJsonObject) throws JSONException {
		ArrayList<CategoryCount> categoryCountList = new ArrayList<CategoryCount>();
		if (offersJsonObject.has(JSONTagConstants.OFFERS_ROOT_TAG)) {
			JSONArray offersJsonArray = offersJsonObject.getJSONArray(JSONTagConstants.OFFERS_ROOT_TAG);
			int size = offersJsonArray.length();
			for (int i = 0; i < size; ++i) {
				JSONObject couponData = offersJsonArray.getJSONObject(i);
				String offerId = "";
				if (couponData.has(JSONTagConstants.OFFERS_ID)) {
					offerId = couponData.getInt(JSONTagConstants.OFFERS_ID) + "";
				}
				if (couponData.has(JSONTagConstants.OFFERS_IS_NEW_COUPON) &&
						couponData.getBoolean(JSONTagConstants.OFFERS_IS_NEW_COUPON)) {
					final CategoryCount categoryCount = new CategoryCount();
					categoryCount.mOfferId = offerId;
					categoryCount.mCategoryId = UIApplication.NEW_CATEGORY_ID;
					categoryCountList.add(categoryCount);
				}
				if (couponData.has(JSONTagConstants.RESPONSE_TAG_CATEGORY_IDS)) {
					JSONArray categoryIdsJSONArray = couponData.getJSONArray(
							JSONTagConstants.RESPONSE_TAG_CATEGORY_IDS);
					int categoryIdArrayLength = categoryIdsJSONArray.length();
					for (int j = 0; j < categoryIdArrayLength; ++j) {
						JSONObject categoryIdJSONObject = categoryIdsJSONArray.getJSONObject(j);
						if (categoryIdJSONObject.has(JSONTagConstants.RESPONSE_TAG_CATEGORY)) {
							String categoryId = categoryIdJSONObject.getInt(
									JSONTagConstants.RESPONSE_TAG_CATEGORY) + "";
							final CategoryCount categoryCount = new CategoryCount();
							categoryCount.mOfferId = offerId;
							categoryCount.mCategoryId = categoryId;
							categoryCountList.add(categoryCount);
						}
					}
					if (categoryIdArrayLength == 0 && couponData.has(JSONTagConstants.OFFERS_IS_MARKETING_MESSAGE)
							&& couponData.getBoolean(JSONTagConstants.OFFERS_IS_MARKETING_MESSAGE)) {
						final CategoryCount categoryCount = new CategoryCount();
						categoryCount.mOfferId = offerId;
						categoryCount.mCategoryId = UIApplication.PROMO_CATEGORY_ID;
						categoryCountList.add(categoryCount);
					}
				} else if (couponData.has(JSONTagConstants.OFFERS_IS_MARKETING_MESSAGE)
						&& couponData.getBoolean(JSONTagConstants.OFFERS_IS_MARKETING_MESSAGE)) {
					final CategoryCount categoryCount = new CategoryCount();
					categoryCount.mOfferId = offerId;
					categoryCount.mCategoryId = UIApplication.PROMO_CATEGORY_ID;
					categoryCountList.add(categoryCount);
				}
			}
		}
		return categoryCountList;
	}
}
