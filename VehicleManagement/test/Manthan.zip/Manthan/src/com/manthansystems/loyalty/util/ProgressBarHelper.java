/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.util;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnKeyListener;
import android.os.Handler;
import android.view.KeyEvent;

import com.manthansystems.loyalty.R;

/**
 * A helper class to manage the progress bar throughout the app.
 *
 * @author Rakesh Saytode { rakesh.saytode@xymob.com }
 */
public class ProgressBarHelper {
	private static ProgressBarHelper mProgressBarHelper = null;
	private static ProgressDialog mProgressDialog = null;
	private static Handler mLastHandler;

	/** Method to get the singleton instance of the progress bar helper class.*/
	public static ProgressBarHelper getSingletonInstance() {
		if (mProgressBarHelper == null) mProgressBarHelper = new ProgressBarHelper();
		return mProgressBarHelper;
	}
	
	/** Method to show normal progressbar that can be either cancellable or
	 * non-cancellable, this behaviour is depends upon boolean parameter named
	 *  <code>isCancellable</code>.*/
	public static void showProgressBarSmall(final int messageResID, final boolean isCancellable,
			Handler handler, final Context context) {
		String message = context.getResources().getString(messageResID);
		showProgressBarSmall(message, isCancellable, handler, context);
	}
	
	/** Method to show small progressbar that can be either cancellable or
	 * non-cancellable, this behaviour is depends upon boolean parameter named
	 *  <code>isCancellable</code>.*/
	public static void showProgressBarSmall(final String message, final boolean isCancellable,
			Handler handler, final Context context) {
		mLastHandler = handler;
		handler.post(new Runnable() {
			@Override
			public void run() {
				closeProgressbar();
				mProgressDialog = new ProgressDialog(context);
				mProgressDialog.setOnKeyListener(mProgressBarKeyListener);
				mProgressDialog.setCancelable(isCancellable);
				mProgressDialog.setMessage(message);
				mProgressDialog.show();
			}
		});
	}
	
	/** Method to show normal progressbar that can be either cancellable or
	 * non-cancellable, this behaviour is depends upon boolean parameter named
	 *  <code>isCancellable</code>.*/
	public static void showProgressBarNormal(final int messageResID, final boolean isCancellable, 
			Handler handler, final Context context) {
		String message = context.getResources().getString(messageResID);
		showProgressBarNormal(message, isCancellable, handler, context);
	}
	
	/** Method to show normal progressbar that can be either cancellable or
	 * non-cancellable, this behaviour is depends upon boolean parameter named
	 *  <code>isCancellable</code>.*/
	public static void showProgressBarNormal(final String message, final boolean isCancellable, 
			Handler handler, final Context context) {
		mLastHandler = handler;
		handler.post(new Runnable() {
			@Override
			public void run() {
				closeProgressbar();
				mProgressDialog = new ProgressDialog(context);
				mProgressDialog.setOnKeyListener(mProgressBarKeyListener);
				mProgressDialog.setCancelable(isCancellable);
				mProgressDialog.setTitle(context.getResources().getString(R.string.app_name));
				mProgressDialog.setIcon(R.drawable.icon);
				mProgressDialog.setMessage(message);
				mProgressDialog.show();
			}
		});
	}
	
	/** Method to show cancellable progressbar. A cancel listener can be supplied by the caller
	 * of this method to get the progress bar cancellation event. */
	public static void showProgressBarCancellable(final int messageResID, final Context context,
			Handler handler, final OnCancelListener cancelListener) {
		String message = context.getResources().getString(messageResID);
		showProgressBarCancellable(message, context, handler, cancelListener);
	}
	
	/** Method to show cancellable progressbar. A cancel listener can be supplied by the caller
	 * of this method to get the progress bar cancellation event. */
	public static void showProgressBarCancellable(final String message, final Context context,
			Handler handler, final OnCancelListener cancelListener) {
		mLastHandler = handler;
		handler.post(new Runnable() {
			@Override
			public void run() {
				closeProgressbar();
				mProgressDialog = new ProgressDialog(context);
				mProgressDialog.setOnKeyListener(mProgressBarKeyListener);
				mProgressDialog.setOnCancelListener(cancelListener);
				mProgressDialog.setCancelable(true);
				mProgressDialog.setTitle(context.getResources().getString(R.string.app_name));
				mProgressDialog.setIcon(R.drawable.icon);
				mProgressDialog.setMessage(message);
				mProgressDialog.show();
			}
		});
	}
	
	/** Call this method to dismiss progress bar inside the Ui thread. */
	public static void dismissProgressBar(Handler handler) {
		handler.post(new Runnable() {
			@Override
			public void run() {
				closeProgressbar();
			}
		});
	}
	
	/** Method to check if progress bar is running or not. */
	public static boolean isProgressBarRunning() {
		if (mProgressDialog != null) {
			return true;
		} else {
			return false;
		}
	}
	
	/** Method to dismiss the running progress bar. */
	private static void closeProgressbar() {
		try {
			if (mProgressDialog != null) {
				mProgressDialog.dismiss();
				mProgressDialog = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 *  ProgressBar onKeyListener to prevent progress bar dismissal on Hard search key press. */
	private static final OnKeyListener mProgressBarKeyListener = new OnKeyListener() {
		
		@Override
		public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
			if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
	            return true;
	        }
	        return false;
		}
	};
	
	/** Call this method to dismiss any running progress bar from previous screen. */
	public static void dismissProgressbarFromOtherScreen() {
		if (mLastHandler != null) {
			mLastHandler.post(new Runnable() {
				@Override
				public void run() {
					closeProgressbar();
				}
			});
		}
	}
	
	/** Method to set the progress bar message based on string resource id. */
	public static void setProgressMessage(final int messageResID, final Context context) {
		if (mProgressDialog != null) {
			String message = context.getResources().getString(messageResID);
			setProgressMessage(message);
		}
	}
	
	/** Method to set the progress bar message based on string value. */
	public static void setProgressMessage(final String message) {
		if (mProgressDialog != null) {
			mProgressDialog.setMessage(message);
		}
	}
	
	/** Method to set the progress bar {@link OnCancelListener}. */
	public static void setProgressOnCancelListener(final OnCancelListener cancelListener) {
		if (mProgressDialog != null) {
			mProgressDialog.setOnCancelListener(cancelListener);
		}
	}
	
	/** Method to set the progress bar cancellable status. */
	public static void setCancelable(final boolean isCancellable) {
		if (mProgressDialog != null) {
			mProgressDialog.setCancelable(isCancellable);
		}
	}
}