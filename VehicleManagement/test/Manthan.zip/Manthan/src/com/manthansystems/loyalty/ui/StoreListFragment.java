/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.actionbarsherlock.app.SherlockListFragment;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDao;
import com.manthansystems.loyalty.model.BaseViewHolder;
import com.manthansystems.loyalty.model.Store;
import com.manthansystems.loyalty.model.ViewHolderStoreList;
import com.manthansystems.loyalty.util.CallHelper;
import com.manthansystems.loyalty.util.ProgressBarHelper;
import com.manthansystems.loyalty.util.UIUtils;

/**
 * A class to display the store listing. It extends {@link SherlockListFragment}.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class StoreListFragment extends SherlockListFragment  implements
		LoaderManager.LoaderCallbacks<Cursor> {

	private static final String LOG_TAG = "StoreListFragment";
	public static String STORE_IDS = "com.manthansystems.loyalty.ui.StoreListFragment#STORE_IDS";
	
	private ViewGroup mView;
	
	private SectionAdapter mSectionAdapter;
	private int mSectionGroupColumn;
	private Handler mHandler;
    
    private String mErrorMessage;
    private String mErrorTitle;
	
	private boolean mShowProgressBar = false;
	
	private AlertDialog mAlertDialog;
	private ArrayList<String> mStoreIdList;
	private String mStoreIds = "";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mHandler = new Handler();
		if (savedInstanceState == null) {
			mStoreIdList = getActivity().getIntent().getStringArrayListExtra(STORE_IDS);
		} else {
			mStoreIdList = savedInstanceState.getStringArrayList(STORE_IDS);
		}
		mStoreIds = mStoreIdList.toString();
		mStoreIds = mStoreIds.replace("[", "").replace("]", "").replace(" ", "");
		LogConfig.logv(LOG_TAG, "storeIds = " + mStoreIds);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_list, null);

        // For some reason, if we omit this, NoSaveStateFrameLayout thinks we are
        // FILL_PARENT / WRAP_CONTENT, making the progress bar stick to the top of the activity.
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT));
        mView = root;   
        bindViews();
        return root;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		LogConfig.logv(LOG_TAG, "onActivityCreated()");
		getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		mSectionAdapter = new SectionAdapter(getActivity(), null,
				R.layout.list_header, getSectionGroupColumn());
		getListView().setAdapter(mSectionAdapter);	
		getLoaderManager().initLoader(DatabaseConfig.QUERY_TOKEN_STORE_LIST, null, this);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		LogConfig.logv(LOG_TAG, "onPause()");
	}

	@Override
	public void onResume() {
		super.onResume();
		LogConfig.logv(LOG_TAG, "onResume()");
		if (mShowProgressBar) {
			ProgressBarHelper.dismissProgressbarFromOtherScreen();
		} 
		mShowProgressBar = true;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putStringArrayList(STORE_IDS, mStoreIdList);
		super.onSaveInstanceState(outState);
	}

	/** Bind the view elements to local view objects, to handle their events. */
	private void bindViews() {
		// Set the screen title view.
		UIUtils.setTitleView(R.string.title_nearby_stores, false, true, false, getSherlockActivity());
		mView.findViewById(R.id.search_bar_layout).setVisibility(View.GONE);
	}
	
	/**
	 * A custom {@link CursorAdapter} class to render the store list.
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 *
	 */
	private class SectionAdapter extends SectionCursorAdapter {

		private Activity mActivity;
		private int mPosition;
		private int mSelectedPosition = -1;
		
		/** Parameterized constructor. */
		public SectionAdapter(Context context, Cursor c, int headerLayout,
				int groupColumn) {
			super(context, c, headerLayout, groupColumn);
			mActivity = (Activity) context;
		}

		/** {@inheritDoc} */
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			mPosition = position;
			StoreListViewHolder viewHolder;
			if (convertView == null) {
				convertView = mActivity.getLayoutInflater().inflate(
						R.layout.row_for_store, null);
				viewHolder = new StoreListViewHolder(convertView);
				convertView.setTag(viewHolder);
			} else  {
				viewHolder = (StoreListViewHolder) convertView.getTag();
			}
			return super.getView(position, convertView, parent);
		}

		/** {@inheritDoc} */
		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {
			return null;
		}

		/** {@inheritDoc} */
		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			if (view != null) {
				final Cursor c = cursor;
				final int mapCursorPos = getSectionForPosition(mPosition);
				c.moveToPosition(mapCursorPos);
				final StoreListViewHolder holder = (StoreListViewHolder) view.getTag();
				holder.setRowPosition(mPosition, mSelectedPosition);
				holder.populateView(c, view);
			}
		}

		/** {@inheritDoc} */
		public String getGroupCustomFormat(Object obj) {
			return (String) obj;
		}
	}
	
	/**
	 * Get the section group column name for list, the groups will be
	 * created based on this column name.
	 */
	private int getSectionGroupColumn() {
		return mSectionGroupColumn;
	}
	
	/**
	 * A view holder class that extends {@link BaseViewHolder} which holds the view of
	 * {@link Store} list row layout.
	 * @author Rakesh Saytode {rakesh.saytode@xymob.com}
	 *
	 */
	private static class StoreListViewHolder extends ViewHolderStoreList {
		public StoreListViewHolder(View view) {
			super(view);
		}
	}

	@Override
	public void onListItemClick(ListView l, final View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		LogConfig.logv(LOG_TAG, "position = " + position);
		final Object obj = mSectionAdapter.getItem(position);
    	if (obj instanceof Cursor) { // Normal row is clicked.
    		final Cursor c = (Cursor) obj;
    		if ( c != null && c.getCount() > 0) {
    			String phoneNumber = c.getString(StoreDao.CONTENT_STORE_PHONE_COLUMN);
    			if (!TextUtils.isEmpty(phoneNumber)) {
    				CallHelper.getInstance().makeCall(phoneNumber, getActivity());
    			}
    		}
    	}
	}

	@Override
	public Loader<Cursor> onCreateLoader(int token, Bundle bundle) {
		if (token == DatabaseConfig.QUERY_TOKEN_STORE_LIST) {
			return new CursorLoader(getActivity(), StoreDao.CONTENT_URI, null,
					StoreDao.STORE_ID + " IN (" + mStoreIds + ")" , 
					null, null);
		}
		return null;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
		final int token = loader.getId();
		LogConfig.logd(LOG_TAG, "onloadFinished");
		if (token == DatabaseConfig.QUERY_TOKEN_STORE_LIST) {
			if (cursor != null) {
				LogConfig.logd(LOG_TAG, "count is " + cursor.getCount());
				if (cursor.getCount() <= 0) {
					mHandler.post(new Runnable() {
						
						@Override
						public void run() {
							mErrorTitle = getResources().getString(R.string.app_name);
							mErrorMessage = getResources().getString(R.string.msg_no_result_found);
							showDialog(DialogConfig.DIALOG_ERROR);
						}
					});
				}
			}
			mSectionAdapter.swapCursor(cursor);
			if (cursor != null && cursor.getCount() > 0) {
				getListView().setSelectionAfterHeaderView();
			}
			getListView().setVisibility(View.VISIBLE);
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		// This is called when the last Cursor provided to onLoadFinished()
        // above is about to be closed.  We need to make sure we are no
        // longer using it.
		mSectionAdapter.swapCursor(null);
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_ERROR:
			dlg.setIcon(R.drawable.icon)
			.setTitle(mErrorTitle)
			.setMessage(mErrorMessage)
			.setCancelable(false)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			break;
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onDestroy() {
	   super.onDestroy();
	   if (mView != null) {
		   UIUtils.unbindDrawables(mView.findViewById(R.id.root_view_list_screen));
		   System.gc();
	   }
	}
}