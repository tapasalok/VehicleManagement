/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui.phone;

import android.os.Bundle;
import android.view.KeyEvent;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.ui.CategoryFilterFragment;

/**
 * An activity class that will provide user to set category filter options. This class extends
 * {@link SherlockFragmentActivity}.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class CategoryFilterActivity extends SherlockFragmentActivity {

	@SuppressWarnings("unused")
	private final String LOG_TAG = "CategoryFilterActivity";
	private CategoryFilterFragment mCategoryFilterFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_category_filter);
		mCategoryFilterFragment = (CategoryFilterFragment)getSupportFragmentManager().
									findFragmentById(R.id.fragment_category_filter);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    } else if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	if (mCategoryFilterFragment != null) {
	    		if(mCategoryFilterFragment.handleBackKeyPress()) {
	    			return true;
	    		}
	    	}
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	public void finish() {
	    super.finish();
	    overridePendingTransition(0, R.anim.translate_slide_right_out);
	}
}