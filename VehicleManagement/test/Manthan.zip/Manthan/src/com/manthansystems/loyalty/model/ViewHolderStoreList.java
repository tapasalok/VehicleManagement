/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.model;

import android.database.Cursor;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDao;

/**
 * A view holder class that holds the row elements of store list item.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class ViewHolderStoreList implements BaseViewHolder {

	@SuppressWarnings("unused")
	private int mPosition;
	@SuppressWarnings("unused")
	private int mSelectedPosition;
	
	private TextView mTextViewStoreName;
	private TextView mTextViewAddress;
	private TextView mTextViewPhoneNumber;
	
	/** Paramterised constructor. */
	public ViewHolderStoreList(final View view) {
		bindViews(view);
	}
	
	/** Method to bind the views from the row layout. */
	private void bindViews(View view) {
		mTextViewStoreName = (TextView) view.findViewById(R.id.textView_store_name);
		mTextViewAddress = (TextView) view.findViewById(R.id.textView_store_address);
		mTextViewPhoneNumber = (TextView) view.findViewById(R.id.textView_store_phone_no);
	}
	
	@Override
	public void populateView(Cursor inCursor, View view) {
		String storeName = inCursor.getString(StoreDao.CONTENT_STORE_NAME_COLUMN);
		String storeAddress1 = inCursor.getString(StoreDao.CONTENT_STORE_ADDRESS1_COLUMN);
		String phoneNumber = inCursor.getString(StoreDao.CONTENT_STORE_PHONE_COLUMN);
		String city = inCursor.getString(StoreDao.CONTENT_STORE_CITY_COLUMN);
		String state = inCursor.getString(StoreDao.CONTENT_STORE_STATE_COLUMN);
		String zipCode = inCursor.getString(StoreDao.CONTENT_STORE_ZIP_COLUMN);
		if (TextUtils.isEmpty(storeName)) {
			mTextViewStoreName.setText("");
		} else {
			mTextViewStoreName.setText(storeName);
		}
		if (TextUtils.isEmpty(phoneNumber)) {
			mTextViewPhoneNumber.setText("");
		} else {
			mTextViewPhoneNumber.setText(phoneNumber);
		}
		StringBuilder storeAddressStringBuilder = new StringBuilder("");
		if (!TextUtils.isEmpty(storeAddress1)) {
			storeAddressStringBuilder.append(storeAddress1).append(", ");
		}
    	if (!TextUtils.isEmpty(city)) {
    		storeAddressStringBuilder.append(city).append(", ");
		}
		if (!TextUtils.isEmpty(state)) {
			storeAddressStringBuilder.append(state).append(", ");
		}
		if (!TextUtils.isEmpty(zipCode)) {
			storeAddressStringBuilder.append(zipCode);
		}
		String storeAddress = storeAddressStringBuilder.toString();
		if (TextUtils.isEmpty(storeAddress)) {
			mTextViewAddress.setText("");
		} else {
			mTextViewAddress.setText(storeAddress);
		}
	}
	
	@Override
	public void setRowPosition(int position, int selectedPosition) {
		mPosition = position;
		mSelectedPosition = selectedPosition;
	}

	@Override
	public ImageView getFavoriteIconView() {
		return null;
	}

	@Override
	public ImageView getOfferIconView() {
		return null;
	}
}
