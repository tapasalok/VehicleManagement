/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.ContentProviderOperation;
import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.BusinessLogicConfig;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.DatabaseConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CategoryCountDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.CouponDao;
import com.manthansystems.loyalty.data.provider.DatabaseContent.StoreDao;
import com.manthansystems.loyalty.data.provider.DatabaseProvider;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.OffersJSONParserFactory;
import com.manthansystems.loyalty.location.LocationHandler;
import com.manthansystems.loyalty.model.CategoryCount;
import com.manthansystems.loyalty.model.Coupon;
import com.manthansystems.loyalty.model.Store;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;
import com.manthansystems.loyalty.ui.OffersFragment;
import com.manthansystems.loyalty.ui.OffersFragment.OffersType;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 * make the network request to get the personal and common offers. It
 * handles the parsing, db caching and error states while of these processes.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class OffersWorker extends BaseWorker {

	private final static String LOG_TAG = "OffersWorker";
	
	public static final String DOWNLOAD_MODE = "com.manthansystems.loyalty.worker.OfferWorker#DownloadMode";
	public static final String OFFERS_TYPE = "com.manthansystems.loyalty.worker.OfferWorker#OffersType";
	
	/** Start processing the request. */
	public static Bundle start(final Context inContext, final int inReturnFormat,
    		final Bundle inBudleData) throws IllegalStateException,
    		IOException,URISyntaxException, RestClientException, ParserConfigurationException,
    		SAXException, JSONException, Exception, OperationApplicationException, ConnectionException {
    	
    	final Bundle bundle = new Bundle();
    	byte offersType = inBudleData.getByte(OFFERS_TYPE);
    	String serverRequestUrl = prepareRequestUrl(inContext, inBudleData, offersType);
    	ArrayList<Header> headerList = getBasicHeaders(inContext);
    	LogConfig.logv(LOG_TAG, "offer serverRequestUrl= " + serverRequestUrl);
    	NetworkConnectionResult wsResult = NetworkConnection.retrieveResponseFromService(
        		serverRequestUrl, Method.POST, null, headerList, true, false, inContext);

    	HashMap<String, Object> hashMap = OffersJSONParserFactory.parseCouponsAndStores(
    			wsResult.wsResponse);
        
        final String responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        } else {
        	bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE,
        			(String) hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
        }
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
        	writeOffersInDB(hashMap, offersType, inContext);
        }
        return bundle;
    }
    
    /** Prepare the server request url to get the offers. */
    private static String prepareRequestUrl(final Context inContext,
    		Bundle bundle, byte offersType) throws URISyntaxException{
    	if (bundle != null) {
    		byte downloadMode = bundle.getByte(DOWNLOAD_MODE);
    		StringBuilder url = new StringBuilder();
    		int valuePosition = 0;
    		int radius = PreferenceConfig.getOffersProximityRadius(inContext);
    		/*if (PreferenceConfig.getIsLaunchFromNotification(inContext)) {
    			radius = PreferenceConfig.getOffersNotificationProximityRadius(inContext);
    		}*/
			if (radius == -1) {
				radius = BusinessLogicConfig.DEFAULT_OFFER_PROXIMITY_RADIUS;
			}
    		switch (downloadMode) {
	    	case DownloadMode.MODE_GPS:
	    		if (offersType == OffersFragment.OffersType.COMMON_OFFERS) {
	    			url.append(WSConfig.URL_GET_COMMON_OFFERS_GPS);
	    		} else {
	    			url.append(WSConfig.URL_GET_PERSONAL_OFFERS_GPS);
	    		}
    	    	valuePosition = 0;
    	    	double[] locationData = LocationHandler.getSavedLocation(true, inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_LAT);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LAT.length()), "" 
	    				+ locationData[LocationHandler.LATTITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_LON);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LON.length()), "" 
	    				+ locationData[LocationHandler.LONGITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_ZIPCODE:
	    		if (offersType == OffersFragment.OffersType.COMMON_OFFERS) {
	    			url = new StringBuilder(WSConfig.URL_GET_COMMON_OFFERS_ZIP);
	    		} else {
	    			url = new StringBuilder(WSConfig.URL_GET_PERSONAL_OFFERS_ZIP);
	    		}
    	    	valuePosition = 0;
    	    	String zip = PreferenceConfig.getUserEnteredZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zip));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_HOME_ZIPCODE:
	    		if (offersType == OffersFragment.OffersType.COMMON_OFFERS) {
	    			url = new StringBuilder(WSConfig.URL_GET_COMMON_OFFERS_ZIP);
	    		} else {
	    			url = new StringBuilder(WSConfig.URL_GET_PERSONAL_OFFERS_ZIP);
	    		}
	    		valuePosition = 0;
	    		String zipcode = PreferenceConfig.getHomeZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zipcode));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    	}
    	}
    	return null;
    }
    
    /** Call this method to write the offers and stores into database. */
    private static void writeOffersInDB(HashMap<String, Object>map, byte inOffersType, Context inContext)
    	throws Exception, OperationApplicationException  {
    	@SuppressWarnings("unchecked")
		ArrayList<Coupon> offerList = (ArrayList<Coupon>) map.get(CommonConfig.KEY_NAME_OFFER_LIST);
    	@SuppressWarnings("unchecked")
		ArrayList<Store> storeList = (ArrayList<Store>) map.get(CommonConfig.KEY_NAME_STORE_LIST);
		@SuppressWarnings("unchecked")
		ArrayList<CategoryCount> categoryCountList = (ArrayList<CategoryCount>) map.get(CommonConfig.KEY_NAME_CATEGORY_COUNT);
    	int totalOffers = 0;
    	if (offerList != null) {
    		totalOffers = offerList.size();
    	}
    	int totalStores = 0;
    	if (storeList != null) {
    		totalStores = storeList.size();
    	}
    	int categoryCountSize = 0;
    	if (categoryCountList != null) {
    		categoryCountSize = categoryCountList.size();
    	}
    	if (totalOffers > 0) {
    		// save timestamp of offer download success.
    		if (inOffersType == OffersType.COMMON_OFFERS) {
    			PreferenceConfig.setCommonOffersTimestamp(System.currentTimeMillis(), inContext);
    		} else {
    			PreferenceConfig.setPersonalOffersTimestamp(System.currentTimeMillis(), inContext);
    		}
    	}
    	
		ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
		int couponChooser = -1;
		if (inOffersType == OffersType.PERSONAL_OFFERS) {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_PERSONAL;
			PreferenceConfig.setPersonalOfferCount(totalOffers, inContext);
		} else {
			couponChooser = DatabaseConfig.DB_OFFER_TYPE_COMMON;
			PreferenceConfig.setCommonOfferCount(totalOffers, inContext);
		}
        ops.add(ContentProviderOperation.newDelete(CouponDao.CONTENT_URI)
    		.withSelection(CouponDao.WHERE_CLAUSE_COUPON_CHOOSER 
    				+ couponChooser, null)
		.build());
        ops.add(ContentProviderOperation.newDelete(StoreDao.CONTENT_URI).build());
        ops.add(ContentProviderOperation.newDelete(CategoryCountDao.CONTENT_URI)
        		.withSelection(CategoryCountDao.WHERE_CLAUSE_OFFER_TYPE
        				+ couponChooser, null)
        .build());
        for (int i = 0; i < totalOffers; ++i) {
        	final Coupon coupon = offerList.get(i);
        	// based on coupon chooser we will distinguish between type of Offer
        	// i.e. either Personal or Common coupon.
        	coupon.mCouponChooser = couponChooser;
        	CouponDao.addContentValues(CouponDao.CONTENT_URI, ops, coupon);
        }
        for (int i = 0; i < totalStores; i++) {
        	StoreDao.addContentValues(StoreDao.CONTENT_URI, ops, storeList.get(i));
        }
        for (int i = 0; i < categoryCountSize; ++i ) {
        	final CategoryCount categoryCount = categoryCountList.get(i);
        	categoryCount.mOfferType = couponChooser;
        	CategoryCountDao.addContentValues(CategoryCountDao.CONTENT_URI, ops, categoryCount);
        }
		//executing all queries added above in batch
    	inContext.getContentResolver().applyBatch(DatabaseProvider.AUTHORITY, ops);
    }
    
    /** Method to make server request for getting offers count. */
	public static Bundle getOffersCount(final Context inContext, final int inReturnFormat,
    		final Bundle inBudleData) throws IllegalStateException,
    		IOException,URISyntaxException, RestClientException, ParserConfigurationException,
    		SAXException, JSONException, Exception, OperationApplicationException, ConnectionException {
    	
    	Bundle bundle = new Bundle();
    	String serverRequestUrl = prepareCountRequestUrl(inContext, inBudleData);
    	ArrayList<Header> headerList = getBasicHeaders(inContext);
    	LogConfig.logv(LOG_TAG, "count serverRequestUrl= " + serverRequestUrl);
    	NetworkConnectionResult wsResult = NetworkConnection.retrieveResponseFromService(
        		serverRequestUrl, Method.POST, null, headerList, true, false, inContext);
    	HashMap<String, Object> hashMap = OffersJSONParserFactory.parseOfferCountResponse(
    			wsResult.wsResponse);
        
        final String responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        } else {
        	bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE,
        			(String) hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
        }
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_SUCCESS)) {
        	writeOffersCountInPrefs(hashMap, inContext);
        }
        return bundle;
    }
    
    /**
     *  Method to write offers count in Preferences.
     * @param map {@link HashMap}
     * @param inContext {@link Context}
     */
    private static void writeOffersCountInPrefs(HashMap<String, Object>map, Context inContext)  {
		int commonOffersCount = (Integer) map.get(CommonConfig.KEY_NAME_COMMON_OFFER_COUNT);
		int personalOffersCount = (Integer) map.get(CommonConfig.KEY_NAME_PERSONAL_OFFER_COUNT);
		int favoriteOffersCount = (Integer) map.get(CommonConfig.KEY_NAME_FAVORITE_OFFER_COUNT);
		LogConfig.logv(LOG_TAG, "commonOffersCount = " + commonOffersCount);
		LogConfig.logv(LOG_TAG, "personalOffersCount = " + personalOffersCount);
		LogConfig.logv(LOG_TAG, "favoriteOffersCount = " + favoriteOffersCount);
    	PreferenceConfig.setPersonalOfferCount(personalOffersCount, inContext);
    	PreferenceConfig.setCommonOfferCount(commonOffersCount, inContext);
    	PreferenceConfig.setFavoriteOfferCount(favoriteOffersCount, inContext);
    }
    
    /** Prepare the server request url to get the offers count based on location settings. */
    private static String prepareCountRequestUrl(final Context inContext,
    		Bundle bundle) throws URISyntaxException{
    	if (bundle != null) {
    		byte downloadMode = bundle.getByte(DOWNLOAD_MODE);
    		StringBuilder url = new StringBuilder();
    		int radius = PreferenceConfig.getOffersProximityRadius(inContext);
    		/*if (PreferenceConfig.getIsLaunchFromNotification(inContext)) {
    			radius = PreferenceConfig.getOffersNotificationProximityRadius(inContext);
    		}*/
			if (radius == -1) {
				radius = BusinessLogicConfig.DEFAULT_OFFER_PROXIMITY_RADIUS;
			}
    		switch (downloadMode) {
	    	case DownloadMode.MODE_GPS:
	    		url = new StringBuilder(WSConfig.URL_OFFER_COUNTS_GPS);
    	    	int valuePosition = 0;
    	    	double[] locationData = LocationHandler.getSavedLocation(true, inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_LAT);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LAT.length()), "" 
	    				+ locationData[LocationHandler.LATTITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_LON);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_LON.length()), "" 
	    				+ locationData[LocationHandler.LONGITUDE]);
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_ZIPCODE:
	    		url = new StringBuilder(WSConfig.URL_OFFER_COUNTS_ZIP);
    	    	valuePosition = 0;
    	    	String zip = PreferenceConfig.getUserEnteredZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zip));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    		
	    	case DownloadMode.MODE_HOME_ZIPCODE:
	    		url = new StringBuilder(WSConfig.URL_OFFER_COUNTS_ZIP);
	    		valuePosition = 0;
	    		String zipcode = PreferenceConfig.getHomeZipcode(inContext);
	    		valuePosition = url.indexOf(WSConfig.WS_ZIP_CODE);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_ZIP_CODE.length()), URLEncoder.encode(zipcode));
	    		valuePosition = url.indexOf(WSConfig.WS_RADIUS);
	    		url.replace(valuePosition, (valuePosition + WSConfig.WS_RADIUS.length()), "" 
	    				+ radius);
	    		return url.toString();
	    	}
    	}
    	return null;
    }
}
