/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.ui.phone;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.DialogConfig;
import com.manthansystems.loyalty.config.PreferenceConfig;

/**
 * An activity class that will manage user email address. This class extends
 * {@link SherlockFragmentActivity}.
 * @author Gaurav Agrawal : gaurav.agrawal@xymob.com
 *
 */
public class EnterEmailActivity extends SherlockFragmentActivity {

	@SuppressWarnings("unused")
	private final String TAG = "EnterEmailActivity";
	
	private boolean mIsExited = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enter_email);
		setTheme(R.style.TabHostTheme);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_MENU && event.isLongPress()) {
	        return true;
	    } else if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	if (!PreferenceConfig.isEmailScreenShown(this)) {
	    		showCustomDialog(DialogConfig.DIALOG_EXIT_APP);
	    		return true;
	    	}
	    }
		return super.onKeyDown(keyCode, event);
	}
	
	/** Method to show dialog on the basis of different dialog ids. */
	private void showCustomDialog(final int id) {
		AlertDialog.Builder dlg = new AlertDialog.Builder(this);
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH && event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		switch (id) {
		case DialogConfig.DIALOG_EXIT_APP:
			dlg.setIcon(R.drawable.icon)
			.setTitle(R.string.app_name)
			.setMessage(R.string.msg_app_exit_confirmation)
			.setCancelable(true)
			.setPositiveButton(R.string.label_yes,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						mIsExited = true;
						dialog.dismiss();
						finish();
						
						if (PreferenceConfig.isDefaultGPSStatus(getApplicationContext()) != PreferenceConfig.getCurrentGPSStatus(getApplicationContext())) {
							startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
						}
					}
				})
			.setNegativeButton(R.string.label_no,
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						// Removing dialog box
						dialog.dismiss();
					}
				});
			break;
		}
		dlg.show();
	}
	
	@Override
	public void finish() {
	    super.finish();
	    if (!mIsExited) {	
	    	overridePendingTransition(0, R.anim.translate_slide_right_out);
	    }
	}
}