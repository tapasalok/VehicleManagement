/**
 * Copyright XYMOB Inc 2013. All rights reserved.
 */
package com.manthansystems.loyalty.worker;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.Header;
import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.text.TextUtils;

import com.manthansystems.loyalty.R;
import com.manthansystems.loyalty.config.CommonConfig;
import com.manthansystems.loyalty.config.JSONTag.JSONTagConstants;
import com.manthansystems.loyalty.config.LogConfig;
import com.manthansystems.loyalty.config.WSConfig;
import com.manthansystems.loyalty.exception.ConnectionException;
import com.manthansystems.loyalty.exception.RestClientException;
import com.manthansystems.loyalty.factory.RedeemJSONParserFactory;
import com.manthansystems.loyalty.network.NetworkConnection;
import com.manthansystems.loyalty.network.NetworkConnection.Method;
import com.manthansystems.loyalty.network.NetworkConnection.NetworkConnectionResult;

/**
 * A worker class that extends {@link BaseWorker} class. It will prepare and
 * make the network request related to Coupon redemption. It handles the
 * parsing, caching and error states while of these processes.
 * 
 * @author Rakesh Saytode : rakesh.saytode@xymob.com
 * 
 */
public class CouponRedemptionWorker extends BaseWorker {

	private final static String LOG_TAG = "CouponRedemptionWorker";
	
	public static String KEY_NAME_WORKER_MODE =
		"com.manthansystems.loyalty.worker.CouponRedemptionWorker#WorkerMode";
	public final static String KEY_NAME_COUPON_ID =
		"com.manthansystems.loyalty.worker.CouponRedemptionWorker#couponId";
	
	/**
	 * An interface to hold the worker modes that used to check the various
	 * coupon redemtion operations.
	 * 
	 * @author Rakesh Saytode : rakesh.saytode@xymob.com
	 * 
	 */
	public interface WorkerModes {
		public final byte WORKER_MODE_CHECK_REDEMPTION_AVAILABILITY = 1;
		public final byte WORKER_MODE_CONFIRM_REDEMPTION = 2;
	}
	
	/** Start processing the request. */
	public static Bundle start(final Context inContext, final int inReturnFormat,
    		final Bundle inBudleData) throws IllegalStateException,
    		IOException,URISyntaxException, RestClientException, ParserConfigurationException,
    		SAXException, JSONException, Exception, OperationApplicationException, ConnectionException {
    	
    	Bundle bundle = new Bundle();
    	byte workerMode = inBudleData.getByte(KEY_NAME_WORKER_MODE);
    	int couponId = inBudleData.getInt(KEY_NAME_COUPON_ID);
    	LogConfig.logd(LOG_TAG, "couponId = " + couponId + ", workerMode = " + workerMode);
    	String responseStatus = null;
    	String serverRequestUrl = prepareRequestUrl(workerMode, couponId, inContext);
    	ArrayList<Header> headerList = getBasicHeaders(inContext);
    	HashMap<String, Object> hashMap = new HashMap<String, Object>(1);
    	LogConfig.logd(LOG_TAG, "url = " + serverRequestUrl);
    	NetworkConnectionResult wsResult = NetworkConnection.retrieveResponseFromService(serverRequestUrl,
				Method.POST, null, headerList, true, null, "id=" + couponId, false, inContext);
    	
    	LogConfig.longInfo(LOG_TAG, "wsResult = " + wsResult.wsResponse);
    	hashMap = RedeemJSONParserFactory.parseRedemptionResponse(wsResult.wsResponse);
    	
    	responseStatus = (String) hashMap.get(CommonConfig.KEY_NAME_RESPONSE_STATUS);
        bundle.putString(CommonConfig.KEY_NAME_RESPONSE_STATUS, responseStatus);
        bundle.putString(CommonConfig.KEY_NAME_ERROR_CODE, (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_CODE));
        
        if (responseStatus.equalsIgnoreCase(JSONTagConstants.RESPONSE_STATUS_FAILURE)) {
        	String errorMsg = (String) hashMap.get(CommonConfig.KEY_NAME_ERROR_MSG);
        	if (TextUtils.isEmpty(errorMsg)) {
        		errorMsg = inContext.getResources().getString(R.string.msg_invalid_response_error);
        	}
        	bundle.putString(CommonConfig.KEY_NAME_ERROR_MSG, errorMsg);
        } else {
        	bundle.putString(CommonConfig.KEY_NAME_RESULTS_MESSAGE, 
					(String)hashMap.get(CommonConfig.KEY_NAME_RESULTS_MESSAGE));
        	if (workerMode == WorkerModes.WORKER_MODE_CHECK_REDEMPTION_AVAILABILITY) {
        		bundle.putString(CommonConfig.KEY_NAME_REDEEM_AVAILABLE,
        				(String) hashMap.get(CommonConfig.KEY_NAME_REDEEM_AVAILABLE));
        	}
        }
        return bundle;
    }
    
    /** Method to prepare the appropriate server request url based on the worker mode. */
    private static String prepareRequestUrl(final byte workerMode, final int inCouponId,
    		Context inContext) throws URISyntaxException,
    		UnsupportedEncodingException {
    	switch (workerMode) {
    	case WorkerModes.WORKER_MODE_CHECK_REDEMPTION_AVAILABILITY:
    		return WSConfig.URL_REDEMPTION_CHECK_AVAILABILITY;
		case WorkerModes.WORKER_MODE_CONFIRM_REDEMPTION:
			return WSConfig.URL_REDEMPTION_CONFIRMATION;
		default:
			throw new URISyntaxException("Redeem: Worker mode not set.",
					"The caller for this method has not set the" +
					"worker mode.");
		}
    }
}
