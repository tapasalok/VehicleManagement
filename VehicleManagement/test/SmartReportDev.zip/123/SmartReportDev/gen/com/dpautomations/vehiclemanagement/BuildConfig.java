/** Automatically generated file. DO NOT MODIFY */
package com.dpautomations.vehiclemanagement;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}