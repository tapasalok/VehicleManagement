package com.dpautomations.vehiclemanagement.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
	
	boolean isInternetPresent;
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// TODO Auto-generated method stub
		super.onConfigurationChanged(newConfig);
	}

	public boolean isConnectingToInternet() {
		ConnectivityManager connectivity = (ConnectivityManager) this
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity != null) {
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null)
				for (int i = 0; i < info.length; i++)
					if (info[i].getState() == NetworkInfo.State.CONNECTED) {
						return true;
					}

		}
		return false;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		isInternetPresent = isConnectingToInternet();
	}

	/*@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);

		String[] menu_item_string={"Create Excel Sheet","Share Excel Sheet"};
		
		for(int positionOfMenuItem = 0; positionOfMenuItem<=1; positionOfMenuItem++){
			TextChanger(menu_item_string[positionOfMenuItem],positionOfMenuItem,menu);
		}

		return true;
	}
	
	private void TextChanger(String string, int position, Menu menu){
		MenuItem item = menu.getItem(position);
		Typeface font2 = Typeface.createFromAsset(getAssets(), "fonts/Quicksand-Regular.otf");
		SpannableStringBuilder ss = new SpannableStringBuilder(string);
		float pixels = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics());
		ss.setSpan(new CustomTypefaceSpan("", (int)pixels, font2), 0, ss.length(), Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
		item.setTitle(ss);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		ExcelOperation excelOperation = ExcelOperation.getInstance();
		switch (id)
        {
        case R.id.action_excel_sheet_create:
           excelOperation.writeToExcel_VehicleData(this);
           excelOperation.writeToExcel_StoreData(this);
            return true;
 
        case R.id.action_excel_sheet_share:
			File file1 = new File(file_path1);
			File file2 = new File(file_path2);

			if (file1.exists() && file2.exists()) {
				Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
				intent.setType("application/vnd.ms-excel");

				//has to be an ArrayList
			    ArrayList<Uri> uris = new ArrayList<Uri>();
			    //convert from paths to Android friendly Parcelable Uri's
			    for (String file : filePaths)
			    {
			        File fileIn = new File(file);
			        Uri u = Uri.fromFile(fileIn);
			        uris.add(u);
			    }
			    intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(Intent.createChooser(intent, "Send Attachment"));

			} else if(file1.exists()){
				Intent intent = new Intent(Intent.ACTION_SEND);
				intent.setType("application/vnd.ms-excel");

				intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file1));
				System.out.println("RVD TESTING MISSCALL.XLS PATH : "
						+ Uri.fromFile(file1));
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(Intent.createChooser(intent, "Send Attachment"));
				}
			else if(file2.exists()){
				Intent intent = new Intent(Intent.ACTION_SEND);
				intent.setType("application/vnd.ms-excel");

				intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file2));
				System.out.println("RVD TESTING MISSCALL.XLS PATH : "
						+ Uri.fromFile(file2));
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(Intent.createChooser(intent, "Send Attachment"));
			}
			else{
				Toast.makeText(this, "Oops!!Excel Sheet is not created.", Toast.LENGTH_SHORT).show();
			}
			
            return true;     
 
        default:
            return super.onOptionsItemSelected(item);
        }*/
		
}
