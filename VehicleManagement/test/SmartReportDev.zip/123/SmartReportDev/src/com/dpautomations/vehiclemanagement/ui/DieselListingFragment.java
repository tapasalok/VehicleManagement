package com.dpautomations.vehiclemanagement.ui;

import com.dpautomations.vehiclemanagement.R;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class DieselListingFragment extends BaseFragment{

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.custom_diesel_list_view, container, false);
		
		
		return view;
	}
}
