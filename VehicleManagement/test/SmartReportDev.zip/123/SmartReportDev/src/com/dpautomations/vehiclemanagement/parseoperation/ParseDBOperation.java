package com.dpautomations.vehiclemanagement.parseoperation;

import com.parse.ParseObject;

import android.app.Activity;

public class ParseDBOperation {

	private Activity context;
	private static ParseDBOperation parseDBOperation;
	
	private ParseDBOperation(Activity context){
		this.context = context;
		createTablesinParse();
	}
	
	public static ParseDBOperation getInstance(Activity context){
		if(parseDBOperation == null){
			parseDBOperation = new ParseDBOperation(context);
		}
		return parseDBOperation;
	}
	
	public void createTablesinParse(){
		ParseObject vehicle_registration_Object = new ParseObject("vehicle_registration");
		vehicle_registration_Object.saveInBackground();
		ParseObject store_registration_Object = new ParseObject("store_registration");
		store_registration_Object.saveInBackground();
	}
	
}
