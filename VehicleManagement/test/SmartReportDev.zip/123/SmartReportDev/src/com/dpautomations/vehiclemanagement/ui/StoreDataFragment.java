package com.dpautomations.vehiclemanagement.ui;

import com.dpautomations.vehiclemanagement.R;
import com.dpautomations.vehiclemanagement.adapters.ViewPagerAdapter;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class StoreDataFragment extends BaseFragment {

	private TabLayout tabLayout;
	private ViewPager viewPager;

	private AppCompatActivity appCompatActivity;

	public StoreDataFragment(AppCompatActivity appCompatActivity) {
		this.appCompatActivity = appCompatActivity;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_store_data, container, false);

		viewPager = (ViewPager) view.findViewById(R.id.viewpager);
		tabLayout = (TabLayout) view.findViewById(R.id.tabs);

		setUpTabLayout();

		return view;
	}

	private void setUpTabLayout() {
		setupViewPager(viewPager);
		tabLayout.setupWithViewPager(viewPager);
		tabLayout.setTabTextColors(Color.parseColor("#9b9b9b"), Color.parseColor("#737373"));

		tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {

				viewPager.setCurrentItem(tab.getPosition());

				switch (tab.getPosition()) {
				case 0:
					break;
				case 1:
					break;
				}
			}

			@Override
			public void onTabUnselected(TabLayout.Tab tab) {

			}

			@Override
			public void onTabReselected(TabLayout.Tab tab) {

			}
		});
	}

	private void setupViewPager(ViewPager viewPager) {
		ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
		adapter.addFragment(new StoreListingFragment(), "STORE LISTING");
		adapter.addFragment(new MaterialWeightListingFragment(), "MATERIAL WEIGHT");
		viewPager.setAdapter(adapter);
	}
}
