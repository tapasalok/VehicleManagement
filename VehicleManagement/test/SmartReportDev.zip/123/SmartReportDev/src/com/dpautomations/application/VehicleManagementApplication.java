package com.dpautomations.application;

import com.parse.Parse;

import android.app.Application;

public class VehicleManagementApplication extends Application {

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		
		Parse.initialize(this, "XNSjHBhDVRfNhFoVEXm81tjQy0enNBIewY99pgkq", "l6aPzE2DoJIuJJ1MBGo1zgVzO4l4FlHVm7BSFh44");
	}

}
