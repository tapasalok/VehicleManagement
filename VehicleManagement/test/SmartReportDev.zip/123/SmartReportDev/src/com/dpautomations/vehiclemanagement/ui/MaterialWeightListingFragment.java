package com.dpautomations.vehiclemanagement.ui;

import java.util.ArrayList;
import java.util.List;

import com.dpautomations.vehiclemanagement.R;
import com.dpautomations.vehiclemanagement.config.StoreData_Info;
import com.dpautomations.vehiclemanagement.dto.Store;
import com.dpautomations.vehiclemanagement.util.ProgressBarHelper;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class MaterialWeightListingFragment extends BaseFragment {

	private TextView textView_noStoreData, total_netWeight, sand_netWeight, crf_netWeight, mm10_netWeight,
			mm20_netWeight, cement_netWeight, ggbs_netWeight, fylash_netWeight, water_netWeight, admixture_netWeight;

	private double calculating_netWeight = 0, individual_netWeight_Sand = 0, individual_netWeight_crf = 0,
			individual_netWeight_10mm = 0, individual_netWeight_20mm = 0, individual_netWeight_cement = 0,
			individual_netWeight_ggbs = 0, individual_netWeight_fylash = 0, individual_netWeight_water = 0,
			individual_netWeight_admixture = 0;

	private List<Store> allStoreData = new ArrayList<Store>();

	final ProgressBarHelper progressBarHelper = ProgressBarHelper.getSingletonInstance();
	private Handler handler = new Handler();
	private List<Store> store_management_data;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_material_weight_listing, container, false);

		textView_noStoreData = (TextView) view.findViewById(R.id.noStoreMaterialWeightData);
		total_netWeight = (TextView) view.findViewById(R.id.netWeight_TOTAL);
		sand_netWeight = (TextView) view.findViewById(R.id.netWeight_SAND);
		crf_netWeight = (TextView) view.findViewById(R.id.netWeight_CRF);
		mm10_netWeight = (TextView) view.findViewById(R.id.netWeight_10MM);
		mm20_netWeight = (TextView) view.findViewById(R.id.netWeight_20MM);
		cement_netWeight = (TextView) view.findViewById(R.id.netWeight_CEMENT);
		ggbs_netWeight = (TextView) view.findViewById(R.id.netWeight_GGBS);
		fylash_netWeight = (TextView) view.findViewById(R.id.netWeight_FYLASH);
		water_netWeight = (TextView) view.findViewById(R.id.netWeight_WATER);
		admixture_netWeight = (TextView) view.findViewById(R.id.netWeight_ADMIXTURE);

		getStoreFromDatabase();

		return view;
	}

	private void getStoreFromDatabase() {
		fetchingAllStoreManagementDataa();
	}

	private void fetchingAllStoreManagementDataa() {
		store_management_data = new ArrayList<Store>();
		progressBarHelper.showProgressBarSmall("Please Wait while fetching Store data...", false, handler,
				getActivity());
		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(StoreData_Info.TABLE_STORE_MANAGEMENT);
		parseQuery.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				for (ParseObject management_data_from_parse : arg0) {
					Store store = new Store();
					store.setStoreManagement_rowid(management_data_from_parse.getObjectId());
					store.setDate_for_entered_material_detail(
							management_data_from_parse.getString(StoreData_Info.KEY_DATE));
					store.setType_of_material(management_data_from_parse.getString(StoreData_Info.KEY_MATERIAL_TYPE));
					store.setSupplierName(management_data_from_parse.getString(StoreData_Info.KEY_SUPPLIERNAME));
					store.setChallan_Number(management_data_from_parse.getString(StoreData_Info.KEY_CHALLANNUMBER));
					store.setMaterial_vehicle_no(
							management_data_from_parse.getString(StoreData_Info.KEY_MATERIAL_VEHICLE_NO));
					store.setLoad_Weight(management_data_from_parse.getString(StoreData_Info.KEY_LOAD_WEIGHT));
					store.setDate_Time_Hold(management_data_from_parse.getString(StoreData_Info.KEY_DATE_TIME));
					store.setEmpty_Weight(management_data_from_parse.getString(StoreData_Info.KEY_EMPTY_WEIGHT));
					store.setNet_Weight(management_data_from_parse.getString(StoreData_Info.KEY_NET_WEIGHT));
					store.setDate_Time_Update(management_data_from_parse.getString(StoreData_Info.KEY_DATE_TIME_1));
					store.setHold(management_data_from_parse.getString(StoreData_Info.KEY_HOLD));
					store_management_data.add(store);
				}
				allStoreData = store_management_data;
				listStore();
				progressBarHelper.dismissProgressBar(handler);
			}
		});
	}

	private void listStore() {
		if (allStoreData.isEmpty()) {
			textView_noStoreData.setVisibility(View.VISIBLE);
		} else {
			textView_noStoreData.setVisibility(View.GONE);
		}
		for (Store store_data : allStoreData) {

			if (!store_data.getNet_Weight().equals("")) {
				switch (store_data.getType_of_material()) {
				case "SAND":
					individual_netWeight_Sand = individual_netWeight_Sand + Double.parseDouble(store_data.getNet_Weight());
					break;
				case "CRF":
					individual_netWeight_crf = individual_netWeight_crf + Double.parseDouble(store_data.getNet_Weight());
					break;
				case "10MM":
					individual_netWeight_10mm = individual_netWeight_10mm + Double.parseDouble(store_data.getNet_Weight());
					break;
				case "20MM":
					individual_netWeight_20mm = individual_netWeight_20mm + Double.parseDouble(store_data.getNet_Weight());
					break;
				case "CEMENT":
					individual_netWeight_cement = individual_netWeight_cement
							+ Double.parseDouble(store_data.getNet_Weight());
					break;
				case "GGBS":
					individual_netWeight_ggbs = individual_netWeight_ggbs + Double.parseDouble(store_data.getNet_Weight());
					break;
				case "FYLASH":
					individual_netWeight_fylash = individual_netWeight_fylash
							+ Double.parseDouble(store_data.getNet_Weight());
					break;
				case "WATER":
					individual_netWeight_water = individual_netWeight_water
							+ Double.parseDouble(store_data.getNet_Weight());
					break;
				case "ADMIXTURE":
					individual_netWeight_admixture = individual_netWeight_admixture
							+ Double.parseDouble(store_data.getNet_Weight());
					break;

				default:
					break;
				}
				calculating_netWeight = calculating_netWeight + Double.parseDouble(store_data.getNet_Weight());
			}
		}
		total_netWeight.append(" " + Double.toString(calculating_netWeight));
		sand_netWeight.append(" " + Double.toString(individual_netWeight_Sand));
		crf_netWeight.append(" " + Double.toString(individual_netWeight_crf));
		mm10_netWeight.append(" " + Double.toString(individual_netWeight_10mm));
		mm20_netWeight.append(" " + Double.toString(individual_netWeight_20mm));
		cement_netWeight.append(" " + Double.toString(individual_netWeight_cement));
		ggbs_netWeight.append(" " + Double.toString(individual_netWeight_ggbs));
		fylash_netWeight.append(" " + Double.toString(individual_netWeight_fylash));
		water_netWeight.append(" " + Double.toString(individual_netWeight_water));
		admixture_netWeight.append(" " + Double.toString(individual_netWeight_admixture));

	}
}
