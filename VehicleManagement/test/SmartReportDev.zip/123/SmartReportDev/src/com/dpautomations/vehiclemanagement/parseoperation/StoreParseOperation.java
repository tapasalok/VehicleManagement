package com.dpautomations.vehiclemanagement.parseoperation;

import java.util.List;

import com.dpautomations.vehiclemanagement.R;
import com.dpautomations.vehiclemanagement.config.StoreData_Info;
import com.dpautomations.vehiclemanagement.database.DatabaseOperation_Store;
import com.dpautomations.vehiclemanagement.dto.Store;
import com.dpautomations.vehiclemanagement.ui.StoreListingFragment;
import com.dpautomations.vehiclemanagement.util.ProgressBarHelper;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.SaveCallback;

import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class StoreParseOperation {

	private AppCompatActivity activityContext;
	private static StoreParseOperation storeParseOperationSingelton;
	private DatabaseOperation_Store databaseOperation = DatabaseOperation_Store.getInstance(activityContext);

	final ProgressBarHelper progressBarHelper = ProgressBarHelper.getSingletonInstance();
	private Handler handler = new Handler();
	
	private boolean flag_store_register = false;

	private StoreParseOperation(AppCompatActivity activityContext) {
		this.activityContext = activityContext;
	}

	public static StoreParseOperation getInstatce(AppCompatActivity activityContext) {
		if (storeParseOperationSingelton == null) {
			storeParseOperationSingelton = new StoreParseOperation(activityContext);
		}
		return storeParseOperationSingelton;
	}

	public void createStoreManagementInParse(final Store store){
		progressBarHelper.showProgressBarSmall("Please wait...", false, handler, activityContext);
		
		ParseObject parseObject = new ParseObject(StoreData_Info.TABLE_STORE_MANAGEMENT);
		parseObject.put(StoreData_Info.KEY_DATE, store.getDate_for_entered_material_detail());
		parseObject.put(StoreData_Info.KEY_MATERIAL_TYPE, store.getType_of_material());
		parseObject.put(StoreData_Info.KEY_SUPPLIERNAME, store.getSupplierName());
		parseObject.put(StoreData_Info.KEY_CHALLANNUMBER, store.getChallan_Number());
		parseObject.put(StoreData_Info.KEY_MATERIAL_VEHICLE_NO, store.getMaterial_vehicle_no());
		parseObject.put(StoreData_Info.KEY_LOAD_WEIGHT, store.getLoad_Weight());
		parseObject.put(StoreData_Info.KEY_DATE_TIME, store.getDate_Time_Hold());
		parseObject.put(StoreData_Info.KEY_EMPTY_WEIGHT, store.getEmpty_Weight());
		parseObject.put(StoreData_Info.KEY_NET_WEIGHT, store.getNet_Weight());
		parseObject.put(StoreData_Info.KEY_DATE_TIME_1, store.getDate_Time_Update());
		parseObject.put(StoreData_Info.KEY_HOLD, store.getHold());
		parseObject.saveInBackground(new SaveCallback() {
			
			@Override
			public void done(ParseException arg0) {
				progressBarHelper.dismissProgressBar(handler);
				Toast.makeText(activityContext, "Data is inserted..", Toast.LENGTH_SHORT).show();
				//Call the insert API from DatabaseOperation_Vehicle class
				flag_store_register = databaseOperation.createStoreManagement(store);
				switchToFragment();
			}
		});
	}
	
	public void fetchingAllStoreManagementData(){
		
	}
	
	public void fetchingIndividualStoreManagementData(){
		
	}
	
	public void updateStoreManagementInParse(final Store updateStore){
		progressBarHelper.showProgressBarSmall("Updating this store data...", false, handler, activityContext);
		ParseQuery<ParseObject> query = ParseQuery.getQuery(StoreData_Info.TABLE_STORE_MANAGEMENT);
	    query.whereEqualTo("objectId", updateStore.getStoreManagement_rowid());
	    query.findInBackground(new FindCallback<ParseObject>() {
			
			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				if(arg1 == null){
					for(ParseObject objectIDS : arg0){
	                     objectIDS.put(StoreData_Info.KEY_EMPTY_WEIGHT, updateStore.getEmpty_Weight());
	                     objectIDS.put(StoreData_Info.KEY_NET_WEIGHT, updateStore.getNet_Weight());
	                     objectIDS.put(StoreData_Info.KEY_DATE_TIME_1, updateStore.getDate_Time_Update());
	                     objectIDS.put(StoreData_Info.KEY_HOLD, updateStore.getHold());
	                     objectIDS.saveInBackground(new SaveCallback() {
							
							@Override
							public void done(ParseException arg0) {
								if(arg0 == null){
									progressBarHelper.dismissProgressBar(handler);
									Toast.makeText(activityContext, "Updation is processed..", Toast.LENGTH_SHORT).show();
									int update_result = databaseOperation.updateStoreManagement(updateStore);
									switchToFragment();	
								}
							}
						});
	                }
	    		}else{
	    			Toast.makeText(activityContext, "Sorry, some problem occurred!!!", Toast.LENGTH_SHORT).show();
	    		}
			}
		});
	}

	private void switchToFragment() {
		Fragment detail = new StoreListingFragment();
		FragmentManager fragmentManager = activityContext.getSupportFragmentManager();
		fragmentManager.beginTransaction().replace(R.id.nav_contentframe, detail).commit();
	}

}
