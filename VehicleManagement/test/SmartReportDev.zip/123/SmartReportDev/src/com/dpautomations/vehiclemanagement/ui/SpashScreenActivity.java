package com.dpautomations.vehiclemanagement.ui;

import com.dpautomations.vehiclemanagement.R;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class SpashScreenActivity extends BaseActivity {
	private static int SPLASH_TIME_OUT = 3000;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_screen);
		startAnimation();
	}

	private void startAnimation() {
		Animation anim = AnimationUtils.loadAnimation(this, R.anim.alpha);
		anim.reset();
		RelativeLayout l = (RelativeLayout) findViewById(R.id.splashScreen);
		l.clearAnimation();
		l.startAnimation(anim);
		anim = AnimationUtils.loadAnimation(this, R.anim.tranlate);
		anim.reset();

		// check for Internet status
		if (isInternetPresent) {
			launchLoginScreen();
		} else {
			// Internet connection is not present
			// Ask user to connect to Internet
			Toast.makeText(this, "Can't find internet connection, Try again!", Toast.LENGTH_SHORT).show();
			finish();
		}
	}

	private void launchLoginScreen() {
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				Intent intent = new Intent(SpashScreenActivity.this, MainActivity.class);
				startActivity(intent);
				finish();
			}
		}, SPLASH_TIME_OUT);
	}
	
	/*@Override
	protected void onResume() {
		super.onResume();
		launchLoginScreen();
	}*/

}
