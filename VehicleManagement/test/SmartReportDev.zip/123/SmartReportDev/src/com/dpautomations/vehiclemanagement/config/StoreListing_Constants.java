package com.dpautomations.vehiclemanagement.config;

public interface StoreListing_Constants {

	//STORE LISTING COLUMNS CONSTANTS
	public static final String FIRST_COLUMN="First";
	public static final String SECOND_COLUMN="Second";
	public static final String THIRD_COLUMN="Third";
	public static final String FOUR_COLUMN="four";
	public static final String FIVE_COLUMN="five";
	public static final String SIX_COLUMN="six";
	public static final String SEVEN_COLUMN="seven";
	public static final String EIGHT_COLUMN="eight";
	public static final String NINE_COLUMN="nine";
	public static final String TEN_COLUMN="ten";
	
	public static final String HOLD_COLUMN = "hold";
	public static final String UPDATE_COLUMN = "update";
	
	
}
