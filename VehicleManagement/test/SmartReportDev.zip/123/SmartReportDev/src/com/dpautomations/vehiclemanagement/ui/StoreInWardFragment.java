package com.dpautomations.vehiclemanagement.ui;

import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.dpautomations.vehiclemanagement.R;
import com.dpautomations.vehiclemanagement.config.StoreData_Info;
import com.dpautomations.vehiclemanagement.database.DatabaseOperation_Store;
import com.dpautomations.vehiclemanagement.dto.Store;
import com.dpautomations.vehiclemanagement.parseoperation.StoreParseOperation;
import com.dpautomations.vehiclemanagement.util.DatePicker_Dialog_Fragment;
import com.dpautomations.vehiclemanagement.util.GettingDateTime;
import com.dpautomations.vehiclemanagement.util.PreferenceOperation;
import com.dpautomations.vehiclemanagement.util.ProgressBarHelper;
import com.dpautomations.vehiclemanagement.util.TimePicker_Dialog_Fragment;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

public class StoreInWardFragment extends BaseFragment {
	private EditText suppliername, vehicleNumber, loadWeight, emptyWeight, netWeight, challan_Number, hold_date_Time, update_date_Time;
	private TextView textView_show_StorecreationDate;;
	private Button updating_button, holding_button;
	private Spinner typesofmaterial;
	private ArrayAdapter<String> dataAdapter;

	private boolean flag_holded_data = false, flag_call_from_storeListing = false, flag_update_data = false;
	protected int index;
	private String selected_material_type;

	private Store store_data_from_context_menu;
	private List<Store> allHoldedStore = new ArrayList<Store>();

	private StoreParseOperation storeParseOperation;
	final ProgressBarHelper progressBarHelper = ProgressBarHelper.getSingletonInstance();
	private Handler handler = new Handler();
	private List<Store> store_management_data;

	public StoreInWardFragment(Store store_data_from_context_menu) {
		this.store_data_from_context_menu = store_data_from_context_menu;
		flag_call_from_storeListing = true;
	}

	public StoreInWardFragment() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_store_in_ward, container, false);

		textView_show_StorecreationDate = (TextView) view.findViewById(R.id.store_datee_created);

		typesofmaterial = (Spinner) view.findViewById(R.id.typeofmateials);
		suppliername = (EditText) view.findViewById(R.id.supplierName);
		vehicleNumber = (EditText) view.findViewById(R.id.vehicleNumber);
		loadWeight = (EditText) view.findViewById(R.id.loadWeight);
		emptyWeight = (EditText) view.findViewById(R.id.emptyWeight);
		netWeight = (EditText) view.findViewById(R.id.netWeight);
		challan_Number = (EditText) view.findViewById(R.id.challanNumber);
		hold_date_Time = (EditText) view.findViewById(R.id.Hold_dateTimeStore);
		update_date_Time = (EditText) view.findViewById(R.id.Update_dateTimeStore);

		holding_button = (Button) view.findViewById(R.id.button_store_inward_hold);
		updating_button = (Button) view.findViewById(R.id.button_store_inward_update);

		hold_date_Time.setOnClickListener(outTimeListener);
		update_date_Time.setOnClickListener(inTimeListener);

		// Spinner Drop down elements
		List<String> categories = new ArrayList<String>();

		categories.add("Select Material Type");
		categories.add("SAND");
		categories.add("CRF");
		categories.add("10MM");
		categories.add("20MM");
		categories.add("CEMENT");
		categories.add("GGBS");
		categories.add("FYLASH");
		categories.add("WATER");
		categories.add("ADMIXTURE");

		dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, categories);
		// Drop down layout style - list view with radio button
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// attaching data adapter to spinner
		typesofmaterial.setAdapter(dataAdapter);

		typesofmaterial.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
				selected_material_type = parent.getItemAtPosition(pos).toString();
			}

			public void onNothingSelected(AdapterView<?> parent) {
			}
		});

		if (flag_call_from_storeListing) {
			manageStoreFromDatabase();
		}

		GettingDateTime gettingDateTime = GettingDateTime.getInstance();
		textView_show_StorecreationDate.setText(gettingDateTime.getDate());

		updating_button.setOnClickListener(Update_registerListener);
		holding_button.setOnClickListener(Hold_registerListener);

		return view;
	}

	android.view.View.OnClickListener outTimeListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			DialogFragment datePickerFragment = new DatePicker_Dialog_Fragment() {
				int yy, mm, dd;

				boolean timerOpened = false;

				@Override
				public void onDateSet(DatePicker view, int year, int month, int day) {
					Calendar c = Calendar.getInstance();
					c.set(year, month, day);
					yy = year;
					mm = month + 1;
					dd = day;

					DialogFragment timePickerFragment = new TimePicker_Dialog_Fragment() {

						@Override
						public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
							super.onTimeSet(view, hourOfDay, minute);
							// timerOpened = false;
							hold_date_Time.setText(dd + "/" + mm + "/" + yy + " " + hourOfDay + ":" + minute);
						}
					};
					if (!timerOpened) {
						timerOpened = true;
						timePickerFragment.show(getActivity().getFragmentManager(), "timePicker");
					}

				}
			};

			datePickerFragment.show(getActivity().getFragmentManager(), "datePicker");
		}
	};

	android.view.View.OnClickListener inTimeListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			DialogFragment datePickerFragment = new DatePicker_Dialog_Fragment() {
				int yy, mm, dd;
				boolean timerOpened = false;

				@Override
				public void onDateSet(DatePicker view, int year, int month, int day) {
					Calendar c = Calendar.getInstance();
					c.set(year, month, day);
					yy = year;
					mm = month + 1;
					dd = day;

					DialogFragment timePickerFragment = new TimePicker_Dialog_Fragment() {

						@Override
						public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
							super.onTimeSet(view, hourOfDay, minute);
							// timerOpened = false;
							update_date_Time.setText(dd + "/" + mm + "/" + yy + " " + hourOfDay + ":" + minute);
						}

					};
					if (!timerOpened) {
						timerOpened = true;
						timePickerFragment.show(getActivity().getFragmentManager(), "timePicker");
					}

				}
			};

			datePickerFragment.show(getActivity().getFragmentManager(), "datePicker");
		}
	};

	OnClickListener Hold_registerListener = new OnClickListener() {

		@Override
		public void onClick(View v) {

			if (selected_material_type.equals("Select Material Type")) {
				Toast.makeText(getActivity(), "Please choose Material Type", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(suppliername.getText())) {
				Toast.makeText(getActivity(), "Please enter Supplier Name", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(vehicleNumber.getText())) {
				Toast.makeText(getActivity(), "Please enter Vehicle Number", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(loadWeight.getText())) {
				Toast.makeText(getActivity(), "Please enter Load weight", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(challan_Number.getText())) {
				Toast.makeText(getActivity(), "Please enter Challan Number", Toast.LENGTH_SHORT).show();
				return;
			}

			// Take All the strings coming from EditText
			String show_StorecreationDate_text = textView_show_StorecreationDate.getText().toString();
			String suppliernameString = suppliername.getText().toString();
			String vehicleNumberSting = vehicleNumber.getText().toString();
			String loadweightString = loadWeight.getText().toString();
			String emptyWeightString = emptyWeight.getText().toString();
			String netWeightString = netWeight.getText().toString();
			String challanNumber = challan_Number.getText().toString();
			String dateTime_hold = hold_date_Time.getText().toString();
			String dateTIme_update = update_date_Time.getText().toString();

			Store storeDTO = new Store();
			// Set all the strings in DTO
			storeDTO.setDate_for_entered_material_detail(show_StorecreationDate_text);
			storeDTO.setType_of_material(selected_material_type);
			storeDTO.setSupplierName(suppliernameString);
			storeDTO.setMaterial_vehicle_no(vehicleNumberSting);
			storeDTO.setLoad_Weight(loadweightString);
			storeDTO.setEmpty_Weight(emptyWeightString);
			storeDTO.setNet_Weight(netWeightString);
			storeDTO.setChallan_Number(challanNumber);
			storeDTO.setDate_Time_Hold(dateTime_hold);
			storeDTO.setDate_Time_Update(dateTIme_update);
			storeDTO.setHold("Yes");

			DatabaseOperation_Store databaseOperation = DatabaseOperation_Store.getInstance(getActivity());
			StoreParseOperation storeParseOperation = StoreParseOperation.getInstatce((AppCompatActivity) getActivity());

			if (!flag_holded_data && !flag_update_data) {
				storeParseOperation.createStoreManagementInParse(storeDTO);
			} else if (flag_holded_data && !flag_update_data) {
				Toast.makeText(getActivity(), "Hold is already Done", Toast.LENGTH_SHORT).show();
			} else if (flag_update_data) {
				Toast.makeText(getActivity(), "Data is already present...", Toast.LENGTH_SHORT).show();
			}
		}
	};

	OnClickListener Update_registerListener = new OnClickListener() {

		@Override
		public void onClick(View v) {

			if (selected_material_type.equals("Select Material Type")) {
				Toast.makeText(getActivity(), "Please choose Material Type", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(suppliername.getText())) {
				Toast.makeText(getActivity(), "Please enter Supplier Name", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(vehicleNumber.getText())) {
				Toast.makeText(getActivity(), "Please enter Vehicle Number", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(loadWeight.getText())) {
				Toast.makeText(getActivity(), "Please enter Load weight", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(emptyWeight.getText())) {
				Toast.makeText(getActivity(), "Please enter Empty Weight", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(netWeight.getText())) {
				Toast.makeText(getActivity(), "Please enter Net Weight", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(challan_Number.getText())) {
				Toast.makeText(getActivity(), "Please enter Challan Number", Toast.LENGTH_SHORT).show();
				return;
			}
			if (TextUtils.isEmpty(update_date_Time.getText())) {
				Toast.makeText(getActivity(), "Please enter Update Date/Time", Toast.LENGTH_SHORT).show();
				return;
			}

			// Take All the strings coming from EditText
			String show_StorecreationDate_text = textView_show_StorecreationDate.getText().toString();
			String suppliernameString = suppliername.getText().toString();
			String vehicleNumberSting = vehicleNumber.getText().toString();
			String loadweightString = loadWeight.getText().toString();
			String emptyWeightString = emptyWeight.getText().toString();
			String netWeightString = netWeight.getText().toString();
			String challanNumber = challan_Number.getText().toString();
			String dateTime_hold = hold_date_Time.getText().toString();
			String dateTIme_update = update_date_Time.getText().toString();

			Store storeDTO = new Store();
			// Set all the strings in DTO
			if (flag_call_from_storeListing) {
				storeDTO.setStoreManagement_rowid(store_data_from_context_menu.getStoreManagement_rowid());
			}
			storeDTO.setDate_for_entered_material_detail(show_StorecreationDate_text);
			storeDTO.setType_of_material(selected_material_type);
			storeDTO.setSupplierName(suppliernameString);
			storeDTO.setMaterial_vehicle_no(vehicleNumberSting);
			storeDTO.setLoad_Weight(loadweightString);
			storeDTO.setEmpty_Weight(emptyWeightString);
			storeDTO.setNet_Weight(netWeightString);
			storeDTO.setChallan_Number(challanNumber);
			storeDTO.setDate_Time_Hold(dateTime_hold);
			storeDTO.setDate_Time_Update(dateTIme_update);
			storeDTO.setHold("No");

			PreferenceOperation preferenceOperation = PreferenceOperation.getInstance(getActivity());
			if (!TextUtils.isEmpty(netWeightString)) {
				String lastNetWeight = preferenceOperation.getNetWeight();
				DateFormat df = new SimpleDateFormat("dd/MM/yy");
				Calendar calobj = Calendar.getInstance();
				String currentDate = df.format(calobj.getTime());
				if (TextUtils.isEmpty(lastNetWeight)) {
					preferenceOperation.putNetWeight(netWeightString);
					preferenceOperation.putLastUpdatedWeightDate(currentDate);
				} else {
					Double double1 = Double.parseDouble(lastNetWeight);
					Double double2 = Double.parseDouble(netWeightString);
					if (currentDate.equals(preferenceOperation.getLastUpdatedWeightDate())) {
						Double resultantWeight = double1 + double2;
						preferenceOperation.putNetWeight(resultantWeight.toString());
					} else {
						preferenceOperation.putNetWeight(double2.toString());
					}
					preferenceOperation.putLastUpdatedWeightDate(currentDate);
				}
				// if (!TextUtils.isEmpty(netWeightString)) {
				// String lastNetWeight = preferenceOperation.getNetWeight();
				// DateFormat df = new SimpleDateFormat("dd/MM/yy");
				// Calendar calobj = Calendar.getInstance();
				// String currentDate = df.format(calobj.getTime());
				// if (TextUtils.isEmpty(lastNetWeight)) {
				// preferenceOperation.putNetWeight(netWeightString);
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// } else {
				// Double double1 = Double.parseDouble(lastNetWeight);
				// Double double2 = Double.parseDouble(netWeightString);
				// if
				// (currentDate.equals(preferenceOperation.getLastUpdatedWeightDate()))
				// {
				// Double resultantWeight = double1 + double2;
				// preferenceOperation.putNetWeight(resultantWeight.toString());
				// } else {
				// preferenceOperation.putNetWeight(double2.toString());
				// }
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// }
				// if (!TextUtils.isEmpty(netWeightString)) {
				// String lastNetWeight = preferenceOperation.getNetWeight();
				// DateFormat df = new SimpleDateFormat("dd/MM/yy");
				// Calendar calobj = Calendar.getInstance();
				// String currentDate = df.format(calobj.getTime());
				// if (TextUtils.isEmpty(lastNetWeight)) {
				// preferenceOperation.putNetWeight(netWeightString);
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// } else {
				// Double double1 = Double.parseDouble(lastNetWeight);
				// Double double2 = Double.parseDouble(netWeightString);
				// if
				// (currentDate.equals(preferenceOperation.getLastUpdatedWeightDate()))
				// {
				// Double resultantWeight = double1 + double2;
				// preferenceOperation.putNetWeight(resultantWeight.toString());
				// } else {
				// preferenceOperation.putNetWeight(double2.toString());
				// }
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// }
				// if (!TextUtils.isEmpty(netWeightString)) {
				// String lastNetWeight = preferenceOperation.getNetWeight();
				// DateFormat df = new SimpleDateFormat("dd/MM/yy");
				// Calendar calobj = Calendar.getInstance();
				// String currentDate = df.format(calobj.getTime());
				// if (TextUtils.isEmpty(lastNetWeight)) {
				// preferenceOperation.putNetWeight(netWeightString);
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// } else {
				// Double double1 = Double.parseDouble(lastNetWeight);
				// Double double2 = Double.parseDouble(netWeightString);
				// if
				// (currentDate.equals(preferenceOperation.getLastUpdatedWeightDate()))
				// {
				// Double resultantWeight = double1 + double2;
				// preferenceOperation.putNetWeight(resultantWeight.toString());
				// } else {
				// preferenceOperation.putNetWeight(double2.toString());
				// }
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// }
				// if (!TextUtils.isEmpty(netWeightString)) {
				// String lastNetWeight = preferenceOperation.getNetWeight();
				// DateFormat df = new SimpleDateFormat("dd/MM/yy");
				// Calendar calobj = Calendar.getInstance();
				// String currentDate = df.format(calobj.getTime());
				// if (TextUtils.isEmpty(lastNetWeight)) {
				// preferenceOperation.putNetWeight(netWeightString);
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// } else {
				// Double double1 = Double.parseDouble(lastNetWeight);
				// Double double2 = Double.parseDouble(netWeightString);
				// if
				// (currentDate.equals(preferenceOperation.getLastUpdatedWeightDate()))
				// {
				// Double resultantWeight = double1 + double2;
				// preferenceOperation.putNetWeight(resultantWeight.toString());
				// } else {
				// preferenceOperation.putNetWeight(double2.toString());
				// }
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// }
				// if (!TextUtils.isEmpty(netWeightString)) {
				// String lastNetWeight = preferenceOperation.getNetWeight();
				// DateFormat df = new SimpleDateFormat("dd/MM/yy");
				// Calendar calobj = Calendar.getInstance();
				// String currentDate = df.format(calobj.getTime());
				// if (TextUtils.isEmpty(lastNetWeight)) {
				// preferenceOperation.putNetWeight(netWeightString);
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// } else {
				// Double double1 = Double.parseDouble(lastNetWeight);
				// Double double2 = Double.parseDouble(netWeightString);
				// if
				// (currentDate.equals(preferenceOperation.getLastUpdatedWeightDate()))
				// {
				// Double resultantWeight = double1 + double2;
				// preferenceOperation.putNetWeight(resultantWeight.toString());
				// } else {
				// preferenceOperation.putNetWeight(double2.toString());
				// }
				// preferenceOperation.putLastUpdatedWeightDate(currentDate);
				// }
			}

			DatabaseOperation_Store databaseOperation = DatabaseOperation_Store.getInstance(getActivity());
			StoreParseOperation storeParseOperation = StoreParseOperation.getInstatce((AppCompatActivity) getActivity());

			if (!flag_holded_data && !flag_update_data) {
				// Call the createStoreManagement API from
				// DatabaseOperation_Store class
				storeParseOperation.createStoreManagementInParse(storeDTO);
			} else if (flag_holded_data && !flag_update_data) {
				// Call the updateStoreManagement API from
				// DatabaseOperation_Store class
				storeParseOperation.updateStoreManagementInParse(storeDTO);
			} else if (flag_update_data) {
				Toast.makeText(getActivity(), "Data is already present...", Toast.LENGTH_SHORT).show();
			}
		}
	};

	private void manageStoreFromDatabase() {
		// Call the select getAllHoldedStoreManagementData from
		// DatabaseOperation_Store class to get all the
		// Store DTO

		DatabaseOperation_Store databaseOperation_Store = DatabaseOperation_Store.getInstance(getActivity());
		allHoldedStore = databaseOperation_Store.getAllHoldedStoreManagementData(store_data_from_context_menu);

		storeParseOperation = StoreParseOperation.getInstatce((AppCompatActivity) getActivity());
		fetchingIndividualStoreManagementDataa();
	}

	private void fetchingIndividualStoreManagementDataa() {
		store_management_data = new ArrayList<Store>();
		progressBarHelper.showProgressBarSmall("Please Wait while fetching Store data...", false, handler,
				getActivity());
		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(StoreData_Info.TABLE_STORE_MANAGEMENT);
		parseQuery.whereEqualTo("objectId", store_data_from_context_menu.getStoreManagement_rowid());
		parseQuery.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				for (ParseObject management_data_from_parse : arg0) {
					Store store = new Store();
					store.setDate_for_entered_material_detail(
							management_data_from_parse.getString(StoreData_Info.KEY_DATE));
					store.setType_of_material(management_data_from_parse.getString(StoreData_Info.KEY_MATERIAL_TYPE));
					store.setSupplierName(management_data_from_parse.getString(StoreData_Info.KEY_SUPPLIERNAME));
					store.setChallan_Number(management_data_from_parse.getString(StoreData_Info.KEY_CHALLANNUMBER));
					store.setMaterial_vehicle_no(
							management_data_from_parse.getString(StoreData_Info.KEY_MATERIAL_VEHICLE_NO));
					store.setLoad_Weight(management_data_from_parse.getString(StoreData_Info.KEY_LOAD_WEIGHT));
					store.setDate_Time_Hold(management_data_from_parse.getString(StoreData_Info.KEY_DATE_TIME));
					store.setEmpty_Weight(management_data_from_parse.getString(StoreData_Info.KEY_EMPTY_WEIGHT));
					store.setNet_Weight(management_data_from_parse.getString(StoreData_Info.KEY_NET_WEIGHT));
					store.setDate_Time_Update(management_data_from_parse.getString(StoreData_Info.KEY_DATE_TIME_1));
					store.setHold(management_data_from_parse.getString(StoreData_Info.KEY_HOLD));
					store_management_data.add(store);
				}
				allHoldedStore = store_management_data;
				showingIndividualStoreManagementDataa();
				progressBarHelper.dismissProgressBar(handler);
			}
		});
	}

	private void showingIndividualStoreManagementDataa() {
		for (Store storeHoldedData : allHoldedStore) {
			if (!storeHoldedData.getType_of_material().isEmpty() && !storeHoldedData.getSupplierName().isEmpty()
					&& !storeHoldedData.getMaterial_vehicle_no().isEmpty()
					&& !storeHoldedData.getLoad_Weight().isEmpty() && !storeHoldedData.getChallan_Number().isEmpty()
					&& !storeHoldedData.getDate_Time_Hold().isEmpty()) {
				flag_holded_data = true;

				typesofmaterial.setSelection(dataAdapter.getPosition(storeHoldedData.getType_of_material()));
				typesofmaterial.setEnabled(false);
				suppliername.setText(storeHoldedData.getSupplierName());
				suppliername.setEnabled(false);
				vehicleNumber.setText(storeHoldedData.getMaterial_vehicle_no());
				vehicleNumber.setEnabled(false);
				loadWeight.setText(storeHoldedData.getLoad_Weight());
				loadWeight.setEnabled(false);
				challan_Number.setText(storeHoldedData.getChallan_Number());
				challan_Number.setEnabled(false);
				hold_date_Time.setText(storeHoldedData.getDate_Time_Hold());
				hold_date_Time.setEnabled(false);

			}
			if (!storeHoldedData.getType_of_material().isEmpty() && !storeHoldedData.getSupplierName().isEmpty()
					&& !storeHoldedData.getMaterial_vehicle_no().isEmpty()
					&& !storeHoldedData.getLoad_Weight().isEmpty() && !storeHoldedData.getChallan_Number().isEmpty()
					&& !storeHoldedData.getEmpty_Weight().isEmpty() && !storeHoldedData.getNet_Weight().isEmpty()
					&& !storeHoldedData.getDate_Time_Update().isEmpty()) {
				flag_update_data = true;

				typesofmaterial.setEnabled(false);
				suppliername.setText(storeHoldedData.getSupplierName());
				suppliername.setEnabled(false);
				vehicleNumber.setText(storeHoldedData.getMaterial_vehicle_no());
				vehicleNumber.setEnabled(false);
				loadWeight.setText(storeHoldedData.getLoad_Weight());
				loadWeight.setEnabled(false);
				challan_Number.setText(storeHoldedData.getChallan_Number());
				challan_Number.setEnabled(false);
				hold_date_Time.setText(storeHoldedData.getDate_Time_Hold());
				hold_date_Time.setEnabled(false);

				emptyWeight.setText(storeHoldedData.getEmpty_Weight());
				emptyWeight.setEnabled(false);
				netWeight.setText(storeHoldedData.getNet_Weight());
				netWeight.setEnabled(false);
				update_date_Time.setText(storeHoldedData.getDate_Time_Update());
				update_date_Time.setEnabled(false);
			}
		}
	}
}
