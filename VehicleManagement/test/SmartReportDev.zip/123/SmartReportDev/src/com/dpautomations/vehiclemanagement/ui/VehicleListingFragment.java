package com.dpautomations.vehiclemanagement.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.dpautomations.vehiclemanagement.R;
import com.dpautomations.vehiclemanagement.adapters.VehicleColumnsAdapter;
import com.dpautomations.vehiclemanagement.adapters.VehicleList_CustomAdapter;
import com.dpautomations.vehiclemanagement.config.VehicleData_Info;
import com.dpautomations.vehiclemanagement.config.VehicleListing_Constants;
import com.dpautomations.vehiclemanagement.database.DatabaseOperation_DBCreation;
import com.dpautomations.vehiclemanagement.database.DatabaseOperation_Vehicle;
import com.dpautomations.vehiclemanagement.dto.Vehicle;
import com.dpautomations.vehiclemanagement.parseoperation.VehicleParseOperation;
import com.dpautomations.vehiclemanagement.util.GettingDateTime;
import com.dpautomations.vehiclemanagement.util.PreferenceOperation;
import com.dpautomations.vehiclemanagement.util.ProgressBarHelper;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

public class VehicleListingFragment extends BaseFragment{
	private ListView listView, listView_columnNames;
	private TextView textView_noVehicleData, totalQuantity;
	private String state_of_vehicle;
	private double calculating_totalQuantity = 0;
	
	public List<Vehicle> allvehicles = new ArrayList<Vehicle>();
	private HashMap<String, String> temp;
	private ArrayList<HashMap<String, String>> list, list_columnNames;

	private DatabaseOperation_Vehicle databaseOperation_Vehicle;

	private VehicleParseOperation vehicleParseOperation;
	final ProgressBarHelper progressBarHelper = ProgressBarHelper.getSingletonInstance();
	private Handler handler = new Handler();
	private List<Vehicle> vehicle_registrtion_data;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		DatabaseOperation_DBCreation.getInstance(getActivity());
		//ParseDBOperation.getInstance(getActivity());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.custom_vehicle_list_view, container, false);
		textView_noVehicleData = (TextView) view.findViewById(R.id.noRegisteredVehicle);
		listView_columnNames = (ListView) view.findViewById(R.id.vehicle_columnName_listing);
		listView = (ListView) view.findViewById(R.id.vehicle_listing);
		totalQuantity = (TextView) view.findViewById(R.id.totalQuantity);

		/*DateFormat df = new SimpleDateFormat("dd/MM/yy");
		Calendar calobj = Calendar.getInstance();
		String currentDate = df.format(calobj.getTime());*/
		GettingDateTime gettingDateTime = GettingDateTime.getInstance();
		String currentDate = gettingDateTime.getDate();

		PreferenceOperation preferenceOperation = PreferenceOperation.getInstance(getActivity());
		if (!currentDate.equals(preferenceOperation.getLastUpdatedQuantityDate())) {
			preferenceOperation.putTotalQuantity("0");
		}
		if (!TextUtils.isEmpty(preferenceOperation.getTotalQuantity())) {
			//totalQuantity.setText("Total Quantity: " + preferenceOperation.getTotalQuantity());
		}

		list = new ArrayList<HashMap<String, String>>();
		list_columnNames = new ArrayList<HashMap<String, String>>();

		HashMap<String, String> temp_Columns = new HashMap<String, String>();
		temp_Columns.put(VehicleListing_Constants.FIRST_COLUMN, "Vehicle No.");
		temp_Columns.put(VehicleListing_Constants.SECOND_COLUMN, "In/Out Timings");
		temp_Columns.put(VehicleListing_Constants.THIRD_COLUMN, "Transporter");
		list_columnNames.add(temp_Columns);

		getVehiclesFromDatabase();

		VehicleColumnsAdapter vehicleColumnsAdapter = new VehicleColumnsAdapter(getActivity(), list_columnNames);
		listView_columnNames.setAdapter(vehicleColumnsAdapter);
		//VehicleList_CustomAdapter adapter = new VehicleList_CustomAdapter(getActivity(), list);
		//listView.setAdapter(adapter);
		// Register the ListView for Context menu
		registerForContextMenu(listView);
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
				String individual_vehicle_plant = allvehicles.get(position).getPlant();

				AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
				// Setting Dialog Title
				alertDialog.setTitle("Vehicle Information");
				// Setting Dialog Message
				alertDialog.setMessage("Plant : " + individual_vehicle_plant);
				alertDialog.setCancelable(true);

				// Showing Alert Message
				alertDialog.show();
			}

		});

		return view;
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.setHeaderTitle("Select The Action");
		menu.add(0, 0, 0, "Make It Out");// groupId, itemId, order, title
		menu.add(0, 1, 0, "Make It In");
		menu.add(0, 2, 0, "Manage the Vehicle");
		menu.add(0, 3, 0, "Delete this Vehicle");
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {

		AdapterContextMenuInfo adapterContextMenuInfo = (AdapterContextMenuInfo) item.getMenuInfo();
		int index = adapterContextMenuInfo.position;
		HashMap<String, String> map = list.get(index);
		final Vehicle vehicleDTO = new Vehicle();
		// Set all the strings in DTO
		vehicleDTO.setVehicleRegistration_rowId(map.get(VehicleListing_Constants.FIRST_COLUMN));
		vehicleDTO.setVehicle_no(map.get(VehicleListing_Constants.SECOND_COLUMN));
		vehicleDTO.setPlant(map.get(VehicleListing_Constants.THIRD_COLUMN));
		vehicleDTO.setTransporter_name(map.get(VehicleListing_Constants.FOURTH_COLUMN));
		vehicleDTO.setVehicleState(map.get(VehicleListing_Constants.FIFTH_COLUMN));

		state_of_vehicle = map.get(VehicleListing_Constants.FIFTH_COLUMN);
		int menuItemId = item.getItemId();

		switch (menuItemId) {
		case 0:
			if (state_of_vehicle.equals("Out")) {
				Toast.makeText(getActivity().getApplicationContext(), "Vehicle is already Out.", Toast.LENGTH_SHORT)
						.show();

			}
			if (state_of_vehicle.equals("In")) {
				listView.getChildAt(index).setBackgroundColor(Color.parseColor("#f75d59"));
				vehicleDTO.setVehicleState("Out");

				// Call the insert API from DatabaseOperation_Vehicle class
				DatabaseOperation_Vehicle databaseOperation = DatabaseOperation_Vehicle.getInstance(getActivity());
				databaseOperation.updateVehicleRegistration(vehicleDTO);
				vehicleParseOperation.updateVehicleRegistrationData(vehicleDTO);
			}

			break;
		case 1:
			if (state_of_vehicle.equals("In")) {
				Toast.makeText(getActivity().getApplicationContext(), "Vehicle is already In.", Toast.LENGTH_SHORT)
						.show();
			}
			if (state_of_vehicle.equals("Out")) {
				listView.getChildAt(index).setBackgroundColor(Color.parseColor("#728c00"));
				vehicleDTO.setVehicleState("In");

				// Call the insert API from DatabaseOperation_Vehicle class
				DatabaseOperation_Vehicle databaseOperation = DatabaseOperation_Vehicle.getInstance(getActivity());
				databaseOperation.updateVehicleRegistration(vehicleDTO);
				vehicleParseOperation.updateVehicleRegistrationData(vehicleDTO);
			}

			break;
		case 2:
			Fragment detail = new VehicleInOutFragment(vehicleDTO);
			FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
			fragmentManager.beginTransaction().replace(R.id.nav_contentframe, detail).commit();
			break;
		case 3:
			AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
			// Setting Dialog Title
			alertDialog.setTitle(R.string.vehicle_delete_confirm);
			// Setting Dialog Message
			alertDialog.setMessage(R.string.vehicle_delete);
			// Setting Positive "Yes" Button
			alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					databaseOperation_Vehicle.deleteVehicleRegistration(vehicleDTO);
					vehicleParseOperation.deleteVehicleData(vehicleDTO);
				}
			});
			// Setting Negative "NO" Button
			alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					dialog.cancel();
				}
			});
			// Showing Alert Message
			alertDialog.show();
			break;
		default:
			break;
		}

		return super.onContextItemSelected(item);
	}

	private void getVehiclesFromDatabase() {

		// Call the select API from DatabaseOperation class to get all the
		// Vehicle DTO
		databaseOperation_Vehicle = DatabaseOperation_Vehicle.getInstance(getActivity());
		// allvehicles = databaseOperation_Vehicle.getAllVehicleRegistrationData();

		vehicleParseOperation = VehicleParseOperation.getInstance((AppCompatActivity) getActivity());
		fetchingRegisteredVehicledataa();
		//listVehicles();
	}
	
	private void fetchingRegisteredVehicledataa(){
		vehicle_registrtion_data = new ArrayList<Vehicle>();
		progressBarHelper.showProgressBarSmall("Please Wait while fetching registered Vehicles...", false, handler, getActivity());
		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(VehicleData_Info.TABLE_VEHICLE_REGISTER);
		parseQuery.findInBackground(new FindCallback<ParseObject>() {
			
			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				//Toast.makeText(getActivity(), "HEY SIZE 1 : "+arg0.size(), Toast.LENGTH_SHORT).show();
		        for(final ParseObject registration_data_from_parse : arg0){
		        	//Toast.makeText(getActivity(), ""+registration_data_from_parse.getObjectId(), Toast.LENGTH_SHORT).show();
		        	final Vehicle vehicle = new Vehicle();
		        	vehicle.setVehicleRegistration_rowId(registration_data_from_parse.getObjectId());
		        	vehicle.setVehicle_no(registration_data_from_parse.getString(VehicleData_Info.KEY_VEHICLE_NO));
		        	vehicle.setPlant(registration_data_from_parse.getString(VehicleData_Info.KEY_PLANT));
		        	vehicle.setTransporter_name(registration_data_from_parse.getString(VehicleData_Info.KEY_TRANSPORTERNAME));
		        	vehicle.setVehicleState(registration_data_from_parse.getString(VehicleData_Info.KEY_VEHICLE_STATE));
		        	
		        	ParseObject parseObjectVehicle = ParseObject.createWithoutData(VehicleData_Info.TABLE_VEHICLE_REGISTER, registration_data_from_parse.getObjectId());;
		    		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(VehicleData_Info.TABLE_VEHICLE_MANAGEMENT);
		    		parseQuery.whereEqualTo(VehicleData_Info.KEY_VEHICLE_MANAGEMENT_ID, parseObjectVehicle);
		    		parseQuery.findInBackground(new FindCallback<ParseObject>() {
		    			
		    			@Override
		    			public void done(List<ParseObject> arg0, ParseException arg1) {
		    				if(arg1 == null && arg0.size() > 0){
		    					ParseObject parseObject = arg0.get(arg0.size()-1);
		    					//Toast.makeText(getActivity(), "HOBBIT!! "+parseObject.getString(VehicleData_Info.KEY_OUT_DATE_TIME), Toast.LENGTH_SHORT).show();
		    					vehicle.setIn_date_time(parseObject.getString(VehicleData_Info.KEY_IN_DATE_TIME));
		    					vehicle.setOut_date_time(parseObject.getString(VehicleData_Info.KEY_OUT_DATE_TIME));
		    					vehicle_registrtion_data.add(vehicle);
		    					for(ParseObject manageVehicle : arg0){
		    						if(!manageVehicle.getString(VehicleData_Info.KEY_QTY).equals("")){
		    							calculating_totalQuantity = calculating_totalQuantity + Double.parseDouble(manageVehicle.getString(VehicleData_Info.KEY_QTY));
		    						}
		    					}
		    					
		    	    		}else if(arg1 != null){
		    	    			//progressBarHelper.dismissProgressBar(handler);
		    	    			Toast.makeText(getActivity(), "Sorry, some problem occurred!!! "+arg1.getMessage().toString(), Toast.LENGTH_SHORT).show();
		    	    		}else{
		    	    			vehicle.setIn_date_time("Not yet decided");
		    	    			vehicle.setOut_date_time("Not yet decided");
		    	    			vehicle_registrtion_data.add(vehicle);
		    	    			//Toast.makeText(getActivity(), "HOBBIT 2!! ", Toast.LENGTH_SHORT).show();
		    	    			
		    	    		}
		    			}
		    		});
		    		//Toast.makeText(getActivity(), "ghost", Toast.LENGTH_SHORT).show();
		        }
		        new Handler().postDelayed(new Runnable() {

	    			@Override
	    			public void run() {
	    				//Toast.makeText(getActivity(), "HELLO RVD : "+vehicle_registrtion_data.size(), Toast.LENGTH_SHORT).show();
	    		        listVehicles();
	    		        progressBarHelper.dismissProgressBar(handler);
	    			}
	    		}, 10000);  
			}
		});
	}
	
	public void listVehicles(){
		allvehicles = vehicle_registrtion_data;
		if (allvehicles.isEmpty()) {
			//Toast.makeText(getActivity(), "HEY RAGHAV WASSUP??", Toast.LENGTH_SHORT).show();
			textView_noVehicleData.setVisibility(View.VISIBLE);
		} else {
			textView_noVehicleData.setVisibility(View.GONE);
		}
		
		//Toast.makeText(getActivity(), ""+allvehicles.size(), Toast.LENGTH_SHORT).show();
		for (Vehicle vehcleNumbr : allvehicles) {
			//Toast.makeText(getActivity(), ""+vehcleNumbr.getVehicle_no(), Toast.LENGTH_SHORT).show();
			temp = new HashMap<String, String>();
			temp.put(VehicleListing_Constants.FIRST_COLUMN, vehcleNumbr.getVehicleRegistration_rowId());
			temp.put(VehicleListing_Constants.SECOND_COLUMN, vehcleNumbr.getVehicle_no());
			temp.put(VehicleListing_Constants.THIRD_COLUMN, vehcleNumbr.getPlant());
			temp.put(VehicleListing_Constants.FOURTH_COLUMN, vehcleNumbr.getTransporter_name());
			temp.put(VehicleListing_Constants.FIFTH_COLUMN, vehcleNumbr.getVehicleState());
			temp.put(VehicleListing_Constants.OUT_TIMING_ROW, vehcleNumbr.getOut_date_time());
			temp.put(VehicleListing_Constants.IN_TIMING_ROW, vehcleNumbr.getIn_date_time());
			temp.put(VehicleListing_Constants.TOTAL_QUANTITY, vehcleNumbr.getQuantity());
			list.add(temp);
		}
		VehicleList_CustomAdapter adapter = new VehicleList_CustomAdapter(getActivity(), list);
		listView.setAdapter(adapter);
		totalQuantity.setText("Total Quantity: "+Double.toString(calculating_totalQuantity));
	}
	
}
