package com.dpautomations.vehiclemanagement.config;

public interface VehicleListing_Constants {

	//VEHICLE LISTING COLUMNS CONSTANTS
	public static final String FIRST_COLUMN="First";
	public static final String SECOND_COLUMN="Second";
	public static final String THIRD_COLUMN="Third";
	public static final String FOURTH_COLUMN="Fourth";
	public static final String FIFTH_COLUMN="Fifth";
	public static final String OUT_TIMING_ROW="Out_timing";
	public static final String IN_TIMING_ROW="In_timing";
	public static final String TOTAL_QUANTITY="Total_Quantity";
}
