package com.dpautomations.vehiclemanagement.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.AdapterContextMenuInfo;

import com.dpautomations.vehiclemanagement.R;
import com.dpautomations.vehiclemanagement.adapters.StoreList_CustomAdapter;
import com.dpautomations.vehiclemanagement.adapters.StoreColumnsAdapter;
import com.dpautomations.vehiclemanagement.config.StoreData_Info;
import com.dpautomations.vehiclemanagement.config.StoreListing_Constants;
import com.dpautomations.vehiclemanagement.database.DatabaseOperation_Store;
import com.dpautomations.vehiclemanagement.dto.Store;
import com.dpautomations.vehiclemanagement.parseoperation.StoreParseOperation;
import com.dpautomations.vehiclemanagement.util.ProgressBarHelper;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

public class StoreListingFragment extends BaseFragment {
	private ListView listView, listView_columnNames;
	private TextView textView_noStoreData;

	private List<Store> allStoreData = new ArrayList<Store>();
	private HashMap<String, String> temp;
	private ArrayList<HashMap<String, String>> list, list_columnNames;

	private StoreParseOperation storeParseOperation;
	final ProgressBarHelper progressBarHelper = ProgressBarHelper.getSingletonInstance();
	private Handler handler = new Handler();
	private List<Store> store_management_data;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.custom_store_list_view, container, false);

		textView_noStoreData = (TextView) view.findViewById(R.id.noStoreData);
		listView_columnNames = (ListView) view.findViewById(R.id.store_columnName_listing);

		listView = (ListView) view.findViewById(R.id.store_listing);
		list = new ArrayList<HashMap<String, String>>();
		list_columnNames = new ArrayList<HashMap<String, String>>();

		HashMap<String, String> temp_Columns = new HashMap<String, String>();
		temp_Columns.put(StoreListing_Constants.FIRST_COLUMN, "Vehicle Number");
		temp_Columns.put(StoreListing_Constants.SECOND_COLUMN, "Supplier Name");
		list_columnNames.add(temp_Columns);

		getStoreFromDatabase();

		StoreColumnsAdapter storeColumnsAdapter = new StoreColumnsAdapter(getActivity(), list_columnNames);
		listView_columnNames.setAdapter(storeColumnsAdapter);

		// Register the ListView for Context menu
		registerForContextMenu(listView);
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
			}

		});
		return view;
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.setHeaderTitle("Select The Action");
		menu.add(0, 0, 0, "Manage the Store");// groupId, itemId, order, title
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {

		AdapterContextMenuInfo adapterContextMenuInfo = (AdapterContextMenuInfo) item.getMenuInfo();
		int index = adapterContextMenuInfo.position;
		HashMap<String, String> map = list.get(index);
		Store storeDTO = new Store();
		// Set all the strings in DTO
		storeDTO.setStoreManagement_rowid(map.get(StoreListing_Constants.FIRST_COLUMN));
		storeDTO.setMaterial_vehicle_no(map.get(StoreListing_Constants.SECOND_COLUMN));
		storeDTO.setSupplierName(map.get(StoreListing_Constants.THIRD_COLUMN));

		int menuItemId = item.getItemId();

		switch (menuItemId) {
		case 0:
			Fragment detaill = new StoreInWardFragment(storeDTO);
			FragmentManager fragmentManagerr = getActivity().getSupportFragmentManager();
			fragmentManagerr.beginTransaction().replace(R.id.nav_contentframe, detaill).commit();
			break;
		default:
			break;
		}

		return super.onContextItemSelected(item);
	}

	private void getStoreFromDatabase() {

		// Call the select API from DatabaseOperation_Store class to get all the
		// Vehicle DTO
		DatabaseOperation_Store databaseOperation_Store = DatabaseOperation_Store.getInstance(getActivity());

		storeParseOperation = StoreParseOperation.getInstatce((AppCompatActivity) getActivity());
		// allStoreData = databaseOperation_Store.getAllStoreManagementData();
		fetchingAllStoreManagementDataa();
	}

	private void fetchingAllStoreManagementDataa() {
		store_management_data = new ArrayList<Store>();
		progressBarHelper.showProgressBarSmall("Please Wait while fetching Store data...", false, handler,
				getActivity());
		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(StoreData_Info.TABLE_STORE_MANAGEMENT);
		parseQuery.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				// Toast.makeText(getActivity(), "HEY SIZE 1 : "+arg0.size(),
				// Toast.LENGTH_SHORT).show();
				for (ParseObject management_data_from_parse : arg0) {
					//Toast.makeText(getActivity(), "" + management_data_from_parse.getObjectId(), Toast.LENGTH_SHORT).show();
					Store store = new Store();
					store.setStoreManagement_rowid(management_data_from_parse.getObjectId());
					store.setDate_for_entered_material_detail(
							management_data_from_parse.getString(StoreData_Info.KEY_DATE));
					store.setType_of_material(management_data_from_parse.getString(StoreData_Info.KEY_MATERIAL_TYPE));
					store.setSupplierName(management_data_from_parse.getString(StoreData_Info.KEY_SUPPLIERNAME));
					store.setChallan_Number(management_data_from_parse.getString(StoreData_Info.KEY_CHALLANNUMBER));
					store.setMaterial_vehicle_no(
							management_data_from_parse.getString(StoreData_Info.KEY_MATERIAL_VEHICLE_NO));
					store.setLoad_Weight(management_data_from_parse.getString(StoreData_Info.KEY_LOAD_WEIGHT));
					store.setDate_Time_Hold(management_data_from_parse.getString(StoreData_Info.KEY_DATE_TIME));
					store.setEmpty_Weight(management_data_from_parse.getString(StoreData_Info.KEY_EMPTY_WEIGHT));
					store.setNet_Weight(management_data_from_parse.getString(StoreData_Info.KEY_NET_WEIGHT));
					store.setDate_Time_Update(management_data_from_parse.getString(StoreData_Info.KEY_DATE_TIME_1));
					store.setHold(management_data_from_parse.getString(StoreData_Info.KEY_HOLD));
					store_management_data.add(store);
				}
				// Toast.makeText(getActivity(), "HELLO RVD :
				// "+vehicle_registrtion_data.size(),
				// Toast.LENGTH_SHORT).show();
				allStoreData = store_management_data;
				listStore();
				progressBarHelper.dismissProgressBar(handler);
			}
		});
	}

	private void listStore() {
		if (allStoreData.isEmpty()) {
			textView_noStoreData.setVisibility(View.VISIBLE);
		} else {
			textView_noStoreData.setVisibility(View.GONE);
		}
		for (Store store_data : allStoreData) {
			temp = new HashMap<String, String>();
			temp.put(StoreListing_Constants.FIRST_COLUMN, store_data.getStoreManagement_rowid());
			temp.put(StoreListing_Constants.SECOND_COLUMN, store_data.getMaterial_vehicle_no());
			temp.put(StoreListing_Constants.THIRD_COLUMN, store_data.getSupplierName());
			temp.put(StoreListing_Constants.HOLD_COLUMN, store_data.getHold());
			list.add(temp);
		}
		StoreList_CustomAdapter adapter = new StoreList_CustomAdapter(getActivity(), list);
		listView.setAdapter(adapter);
	}
}
