package com.dpautomations.vehiclemanagement.parseoperation;

import java.util.ArrayList;
import java.util.List;

import com.dpautomations.vehiclemanagement.R;
import com.dpautomations.vehiclemanagement.config.VehicleData_Info;
import com.dpautomations.vehiclemanagement.database.DatabaseOperation_Vehicle;
import com.dpautomations.vehiclemanagement.dto.Vehicle;
import com.dpautomations.vehiclemanagement.ui.VehicleListingFragment;
import com.dpautomations.vehiclemanagement.util.ProgressBarHelper;
import com.parse.DeleteCallback;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.SaveCallback;

import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class VehicleParseOperation {

	private AppCompatActivity context;
	private static VehicleParseOperation vehicleParseOperation;
	private List<Vehicle> vehicle_registrtion_data;

	final ProgressBarHelper progressBarHelper = ProgressBarHelper.getSingletonInstance();
	private Handler handler = new Handler();

	private VehicleParseOperation(AppCompatActivity context) {
		this.context = context;
	}

	public static VehicleParseOperation getInstance(AppCompatActivity context) {
		if (vehicleParseOperation == null) {
			vehicleParseOperation = new VehicleParseOperation(context);
		}
		return vehicleParseOperation;
	}

	public void registerVehicle(final Vehicle vehicle) {
		progressBarHelper.showProgressBarSmall("Please wait while registering your vehicle...", false, handler,
				context);

		ParseObject parseObject = new ParseObject(VehicleData_Info.TABLE_VEHICLE_REGISTER);
		parseObject.put(VehicleData_Info.KEY_VEHICLE_NO, vehicle.getVehicle_no());
		parseObject.put(VehicleData_Info.KEY_PLANT, vehicle.getPlant());
		parseObject.put(VehicleData_Info.KEY_TRANSPORTERNAME, vehicle.getTransporter_name());
		parseObject.put(VehicleData_Info.KEY_VEHICLE_STATE, vehicle.getVehicleState());
		parseObject.saveInBackground(new SaveCallback() {

			@Override
			public void done(ParseException arg0) {
				progressBarHelper.dismissProgressBar(handler);
				// Call the insert API from DatabaseOperation_Vehicle class
				DatabaseOperation_Vehicle databaseOperation = DatabaseOperation_Vehicle.getInstance(context);
				databaseOperation.createVehicleRegistration(vehicle);
				switchToFragment();
			}
		});
	}

	public List<Vehicle> fetchingRegisteredVehicledata() {
		vehicle_registrtion_data = new ArrayList<Vehicle>();
		progressBarHelper.showProgressBarSmall("Please Wait...", false, handler, context);
		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(VehicleData_Info.TABLE_VEHICLE_REGISTER);
		parseQuery.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				// Toast.makeText(context, "HEY SIZE 1 : "+arg0.size(),
				// Toast.LENGTH_SHORT).show();
				progressBarHelper.dismissProgressBar(handler);
				for (ParseObject registration_data_from_parse : arg0) {
					// Toast.makeText(context,
					// ""+registration_data_from_parse.getObjectId(),
					// Toast.LENGTH_SHORT).show();
					Vehicle vehicle = new Vehicle();
					vehicle.setVehicleRegistration_rowId(registration_data_from_parse.getObjectId());
					vehicle.setVehicle_no(registration_data_from_parse.getString(VehicleData_Info.KEY_VEHICLE_NO));
					vehicle.setPlant(registration_data_from_parse.getString(VehicleData_Info.KEY_PLANT));
					vehicle.setTransporter_name(
							registration_data_from_parse.getString(VehicleData_Info.KEY_TRANSPORTERNAME));
					vehicle.setVehicleState(registration_data_from_parse.getString(VehicleData_Info.KEY_VEHICLE_STATE));
					vehicle_registrtion_data.add(vehicle);
				}
				// Toast.makeText(context, "HELLO RVD :
				// "+vehicle_registrtion_data.size(),
				// Toast.LENGTH_SHORT).show();
			}
		});
		// Toast.makeText(context, "HEY SIZE :
		// "+vehicle_registrtion_data.size(), Toast.LENGTH_SHORT).show();
		return vehicle_registrtion_data;
	}

	public void deleteVehicleData(Vehicle vehicle) {
		progressBarHelper.showProgressBarSmall("Deleting this vehicle...", false, handler, context);
		ParseQuery<ParseObject> query = ParseQuery.getQuery(VehicleData_Info.TABLE_VEHICLE_REGISTER);
		query.whereEqualTo("objectId", vehicle.getVehicleRegistration_rowId());
		query.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				if (arg1 == null) {
					for (ParseObject objectIDS : arg0) {
						objectIDS.deleteInBackground(new DeleteCallback() {

							@Override
							public void done(ParseException arg0) {
								if (arg0 == null) {
									progressBarHelper.dismissProgressBar(handler);
									Toast.makeText(context, "Vehicle is deleted..", Toast.LENGTH_SHORT).show();
									switchToFragment();
								}
							}
						});
					}
				} else {
					progressBarHelper.dismissProgressBar(handler);
					Toast.makeText(context, "Sorry, some problem occurred!!!", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	public void updateVehicleRegistrationData(final Vehicle updateVehicle) {
		progressBarHelper.showProgressBarSmall("Updating this vehicle...", false, handler, context);
		ParseQuery<ParseObject> query = ParseQuery.getQuery(VehicleData_Info.TABLE_VEHICLE_REGISTER);
		query.whereEqualTo("objectId", updateVehicle.getVehicleRegistration_rowId());
		query.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				if (arg1 == null) {
					for (ParseObject objectIDS : arg0) {
						objectIDS.put(VehicleData_Info.KEY_VEHICLE_STATE, updateVehicle.getVehicleState());
						objectIDS.saveInBackground(new SaveCallback() {

							@Override
							public void done(ParseException arg0) {
								if (arg0 == null) {
									progressBarHelper.dismissProgressBar(handler);
									Toast.makeText(context, "Vehicle's state is updated", Toast.LENGTH_SHORT).show();
									switchToFragment();
								}
							}
						});
					}
				} else {
					progressBarHelper.dismissProgressBar(handler);
					Toast.makeText(context, "Sorry, some problem occurred!!!", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	public void creatingVehicleManagementDataInParse(final Vehicle vehicleManagementData) {
		progressBarHelper.showProgressBarSmall("Please wait...", false, handler, context);
		ParseObject parseObject = new ParseObject(VehicleData_Info.TABLE_VEHICLE_MANAGEMENT);
		parseObject.put(VehicleData_Info.KEY_VEHICLE_MANAGEMENT_ID, ParseObject.createWithoutData(
				VehicleData_Info.TABLE_VEHICLE_REGISTER, vehicleManagementData.getVehicleRegistration_rowId()));
		parseObject.put(VehicleData_Info.KEY_DATE, vehicleManagementData.getDate_for_entered_data());
		parseObject.put(VehicleData_Info.KEY_DC_NO, vehicleManagementData.getDc_no());
		parseObject.put(VehicleData_Info.KEY_QTY, vehicleManagementData.getQuantity());
		parseObject.put(VehicleData_Info.KEY_MAN_PUMP, vehicleManagementData.getMan_pump());
		parseObject.put(VehicleData_Info.KEY_DIESEL_ISSUED, vehicleManagementData.getDiesel_issued());
		parseObject.put(VehicleData_Info.KEY_OPEN_KMS, vehicleManagementData.getOpen_kms());
		parseObject.put(VehicleData_Info.KEY_START_ENGINE_HRS, vehicleManagementData.getStart_engine_hrs());
		parseObject.put(VehicleData_Info.KEY_OUT_DATE_TIME, vehicleManagementData.getOut_date_time());
		parseObject.put(VehicleData_Info.KEY_CLOSING_KMS, vehicleManagementData.getClosing_kms());
		parseObject.put(VehicleData_Info.KEY_CLOSING_ENGINE_HRS, vehicleManagementData.getClosing_engine_hrs());
		parseObject.put(VehicleData_Info.KEY_FOW_HRS, vehicleManagementData.getFow_hrs());
		parseObject.put(VehicleData_Info.KEY_REV_HRS, vehicleManagementData.getRev_hrs());
		parseObject.put(VehicleData_Info.KEY_IN_DATE_TIME, vehicleManagementData.getIn_date_time());
		parseObject.saveInBackground(new SaveCallback() {

			@Override
			public void done(ParseException arg0) {
				progressBarHelper.dismissProgressBar(handler);
				updateVehicleRegistrationData(vehicleManagementData);
			}
		});
	}

	public void fetchingLastAddedVehicleManagementDataFromParse(final Vehicle contextVehicle) {
		progressBarHelper.showProgressBarSmall("Please Wait while fetching Vehicle data", false, handler, context);
		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(VehicleData_Info.TABLE_VEHICLE_MANAGEMENT);
		parseQuery.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				if (arg1 == null) {
					progressBarHelper.dismissProgressBar(handler);
					Toast.makeText(context, "Awesome!!", Toast.LENGTH_SHORT).show();
				} else {
					progressBarHelper.dismissProgressBar(handler);
					Toast.makeText(context, "Sorry, some problem occurred!!!", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	public void updatingLastAddedVehicleManagementDataInParse(final Vehicle updateVehicleManagement) {
		progressBarHelper.showProgressBarSmall("Updating this vehicle...", false, handler, context);
		ParseObject parseObjectVehicle = ParseObject.createWithoutData(VehicleData_Info.TABLE_VEHICLE_REGISTER,
				updateVehicleManagement.getVehicleRegistration_rowId());

		ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery(VehicleData_Info.TABLE_VEHICLE_MANAGEMENT);
		parseQuery.whereEqualTo(VehicleData_Info.KEY_VEHICLE_MANAGEMENT_ID, parseObjectVehicle);
		parseQuery.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> arg0, ParseException arg1) {
				if (arg1 == null) {
					ParseObject parseObject = arg0.get(arg0.size() - 1);
					parseObject.put(VehicleData_Info.KEY_DATE, updateVehicleManagement.getDate_for_entered_data());
					parseObject.put(VehicleData_Info.KEY_DC_NO, updateVehicleManagement.getDc_no());
					parseObject.put(VehicleData_Info.KEY_DIESEL_ISSUED, updateVehicleManagement.getDiesel_issued());
					parseObject.put(VehicleData_Info.KEY_OPEN_KMS, updateVehicleManagement.getOpen_kms());
					parseObject.put(VehicleData_Info.KEY_OUT_DATE_TIME, updateVehicleManagement.getOut_date_time());
					parseObject.put(VehicleData_Info.KEY_CLOSING_KMS, updateVehicleManagement.getClosing_kms());
					parseObject.put(VehicleData_Info.KEY_IN_DATE_TIME, updateVehicleManagement.getIn_date_time());
					parseObject.put(VehicleData_Info.KEY_START_ENGINE_HRS,
							updateVehicleManagement.getStart_engine_hrs());
					parseObject.put(VehicleData_Info.KEY_CLOSING_ENGINE_HRS,
							updateVehicleManagement.getClosing_engine_hrs());
					parseObject.put(VehicleData_Info.KEY_FOW_HRS, updateVehicleManagement.getFow_hrs());
					parseObject.put(VehicleData_Info.KEY_REV_HRS, updateVehicleManagement.getRev_hrs());
					parseObject.put(VehicleData_Info.KEY_QTY, updateVehicleManagement.getQuantity());
					parseObject.put(VehicleData_Info.KEY_MAN_PUMP, updateVehicleManagement.getMan_pump());
					parseObject.saveInBackground(new SaveCallback() {

						@Override
						public void done(ParseException arg0) {
							if (arg0 == null) {
								progressBarHelper.dismissProgressBar(handler);
								Toast.makeText(context, "Vehicle's data is updated", Toast.LENGTH_SHORT).show();
								switchToFragment();
							}
						}
					});

				} else {
					progressBarHelper.dismissProgressBar(handler);
					Toast.makeText(context, "Sorry, some problem occurred!!!", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	private void switchToFragment() {
		Fragment detail = new VehicleListingFragment();
		FragmentManager fragmentManager = context.getSupportFragmentManager();
		fragmentManager.beginTransaction().replace(R.id.nav_contentframe, detail).commit();
	}
}
