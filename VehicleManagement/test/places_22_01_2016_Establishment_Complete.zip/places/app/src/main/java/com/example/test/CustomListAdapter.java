package com.example.test;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class CustomListAdapter extends BaseAdapter {
	private String[] bitmapList;
	private String bitmapPlaceholder;
	private Context context;
	private List<BusinessSummary> businessSummaryList = new ArrayList<BusinessSummary>();

	private ViewHolder holder;

	private void initBitmapListWithPlaceholders() {
		// call this whenever the list size changes
		// you can also use a list or a map or whatever so you
		// don't need to drop all the previously loaded bitmap whenever
		// the list contents are modified
		int count = businessSummaryList.size();
		bitmapList = new String[count];
		for (int i = 0; i < count; i++) {
			bitmapList[i] = bitmapPlaceholder;
		}
	}

	private void onBitmapLoaded(int position, String bmp) {
		// this is your callback when the load async is done
		bitmapList[position] = bmp;
	}

	public CustomListAdapter(Context context, List<BusinessSummary> businessSummaryList) {
		this.context = context;
		this.businessSummaryList = businessSummaryList;
		initBitmapListWithPlaceholders();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return businessSummaryList.size();
	}

	@Override
	public BusinessSummary getItem(int position) {
		// TODO Auto-generated method stub
		return businessSummaryList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		initBitmapListWithPlaceholders();
		BusinessSummary summary = businessSummaryList.get(position);
		onBitmapLoaded(position, summary.getPhotoUrl());
		View v = convertView;
		ImageView imageView;
		TextView desription;
		ImageView updatedetails;
		TextView name;
		if (v == null) {
			LayoutInflater vi = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			v = vi.inflate(R.layout.listofrestaurants, null);
		}

		if (summary != null && v != null) {
			imageView = (ImageView) v.findViewById(R.id.imageview);
			desription = (TextView) v.findViewById(R.id.description);
			name = (TextView) v.findViewById(R.id.name);
			updatedetails = (ImageView) v.findViewById(R.id.updatedetails);
			desription.setText(summary.getDescription());
			name.setText(summary.getName());

			imageView.setVisibility(View.GONE);
			try {
				if (TextUtils.isEmpty(summary.getPhotoUrl())) {
					imageView.setVisibility(View.VISIBLE);
					Picasso.with(context).load(R.drawable.no_media).into(imageView);
				} else {
					// show The Image
					imageView.setVisibility(View.VISIBLE);
					Picasso.with(context).load(summary.getPhotoUrl()).resize(350, 350).error(R.drawable.no_media)
							.into(imageView);

				}
			} catch (Exception e) {
				// TODO: handle exception
				imageView.setVisibility(View.VISIBLE);
				Picasso.with(context).load(R.drawable.no_media).into(holder.imageView);

			}
		}
		initBitmapListWithPlaceholders();
		try {
			if (businessSummaryList.get(position + 1) != null) {
				summary = businessSummaryList.get(position + 1);
				onBitmapLoaded(position + 1, summary.getPhotoUrl());
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return v;

	}

	public class ViewHolder {
		public TextView desription;
		public TextView name;
		// public TextView location;
		public ImageView imageView;
	}

}
