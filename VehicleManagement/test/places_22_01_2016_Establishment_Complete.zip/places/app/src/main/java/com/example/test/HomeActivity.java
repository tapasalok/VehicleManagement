package com.example.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.test.helper.HttpRequest;
import com.example.test.helper.URLConstants;
import com.restuarant.utils.ProgressBarHelper;
import com.restuarant.view.FloatingActionButton;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {
	Button btnGPSShowLocation;
	Button btnShowAddress;
	TextView tvAddress;
	double longitude;
	double latitude;
	AppLocationService appLocationService;

	private static final String TAG = "com.example.test.HomeActivity";
	private ListView listView;
	private Map<String, String> locationMap = new HashMap<String, String>();
	private ProgressBarHelper progressBarHelper;
	private ArrayList<String> restaurantNames;
	private List<BusinessSummary> resultFromServer;
	private SharedPreferences sharedPreference;
	private TextView noRestaurantAvailable;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.homescreen);
		
		Intent service = new Intent(HomeActivity.this, AppLocationService.class);
		startService(service );
		
		sharedPreference = getSharedPreferences("common_preference", Activity.MODE_PRIVATE);

		restaurantNames = new ArrayList<String>();
		resultFromServer = new ArrayList<BusinessSummary>();

		progressBarHelper = ProgressBarHelper.getSingletonInstance();
		LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

		if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			// Toast.makeText(this, "GPS is Enabled in your devide",
			// Toast.LENGTH_SHORT).show();
		} else {
			showSettingsAlert();
		}
		android.support.v7.app.ActionBar actionbar = getSupportActionBar();
		getSupportActionBar().setDisplayShowHomeEnabled(true);
		getSupportActionBar().setIcon(R.drawable.actionbarlogo);
//		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//		actionbar.setLogo(R.drawable.actionbarlogo);
//		actionbar.setHomeButtonEnabled(false);

//		ActionBar actionbar = getActionBar();
//		actionbar.setLogo(R.drawable.actionbarlogo);
//		actionbar.setDisplayShowCustomEnabled(true);
		actionbar.setTitle(" Restaurants Near to You");
////		actionbar.setHomeButtonEnabled(true);
		actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#ba68c8")));

		listView = (ListView) findViewById(R.id.listView);
		noRestaurantAvailable = (TextView) findViewById(R.id.noRestaurantAvailable);
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				Log.v("long clicked", "pos: " + position);
				final Bundle bundle = new Bundle();
				bundle.putBoolean("update_restaurant", true);

				// Instantiate the RequestQueue.
				RequestQueue queue = Volley.newRequestQueue(HomeActivity.this);
				String url = "http://130.211.255.181/places-impl-web/rest/business/"
						+ resultFromServer.get(position).getSid();

				// Request a string response from the provided URL.
				StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
						new Response.Listener<String>() {
					@Override
					public void onResponse(String response) {
						// Display the first 500 characters of the
						// response string.
						final Intent intent = new Intent(HomeActivity.this, Restaurant_Environment.class);
						try {
							JSONObject jsonObject = new JSONObject(response);
							bundle.putString("name", jsonObject.optString("name"));
							bundle.putString("description", jsonObject.optString("description"));
							bundle.putString("profilePhoto", jsonObject.optString("photoUrl"));
//							if (jsonObject.has("establishMentType")) {
//								bundle.putString("ownerName", jsonObject.optString("establishMentType") + "");
//							}
							bundle.putString("ownerName", jsonObject.optString("ownerName"));
							bundle.putString("emailId", jsonObject.optString("ownerEmail"));
							bundle.putString("PhonoNo", jsonObject.optString("ownerPhoneNo"));

							JSONObject location = (JSONObject) jsonObject.opt("location");
							if (location != null) {
								bundle.putString("longitude", location.optString("longitude"));
								bundle.putString("latitude", location.optString("latitude"));
							} else {
								bundle.putString("longitude", "No Location Present");

							}

							bundle.putString("sid", jsonObject.optString("sid"));

							bundle.putString("nooftable", jsonObject.optInt("numberOfTables") + "");
							bundle.putString("noofwaiter", jsonObject.optInt("numberOfWaiters") + "");
//							bundle.putString("typeofestablishment", jsonObject.optString("establishMentType"));

							if (jsonObject.has("wifiAvailable")) {
								bundle.putString("wifiavailable", jsonObject.optBoolean("wifiAvailable") + "");
							}

							bundle.putString("signalstrenth", jsonObject.optString("networkStrength"));

							if (jsonObject.has("foodDeilvery")) {
								bundle.putString("deliverfood", jsonObject.optBoolean("foodDeilvery") + "");
							}

							bundle.putString("deliverby", jsonObject.optString("deliveredBy"));

							bundle.putString("deleverytime", jsonObject.optInt("deliverWithin") + "");
//							int hours = t / 60; //since both are ints, you get an int
//							int minutes = t % 60;
//							System.out.printf("%d:%02d", hours, minutes);
//							bundle.putString("deleverytime",jsonObject.optInt("deliverWithin") + "");
							bundle.putString("deliverydistance", jsonObject.optInt("deliverAround") + "");
							ArrayList<String> menuImages = new ArrayList<String>();
							JSONArray jsonArray = jsonObject.optJSONArray("menus");
							int length = jsonArray.length();
							for (int i = 0; i < length; i++) {
								menuImages.add(jsonArray.getString(i));
							}
							bundle.putStringArrayList("menus", menuImages);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						intent.putExtras(bundle);
						startActivity(intent);
						return;
					}
				}, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error) {

					}
				});
				// Add the request to the RequestQueue.
				queue.add(stringRequest);

				// Do for remaining items

			}
		});

		FloatingActionButton fabButton = new FloatingActionButton.Builder(this)
				.withDrawable(getResources().getDrawable(R.drawable.fab)).withButtonColor(Color.WHITE)
				.withGravity(Gravity.BOTTOM | Gravity.RIGHT).withMargins(0, 0, 16, 16).create();

		OnClickListener fab = new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HomeActivity.this, Restaurant_Environment.class);
				intent.putStringArrayListExtra("restaurant_names", restaurantNames);

				startActivity(intent);

			}
		};
		fabButton.setOnClickListener(fab);
		/* tvAddress = (TextView) findViewById(R.id.tvAddress); */
		
		Location location = AppLocationService.getBestLastGeolocation(HomeActivity.this);
		if (location != null) {
			longitude = location.getLongitude();
			latitude = location.getLatitude();
			locationMap.put("latitude", String.valueOf(latitude));
			locationMap.put("longitude", String.valueOf(longitude));
		}

		if (location != null) {
			double latitude = location.getLatitude();
			double longitude = location.getLongitude();
			LocationAddress locationAddress = new LocationAddress();
			locationAddress.getAddressFromLocation(latitude, longitude, getApplicationContext(), new GeocoderHandler());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		try {
			locationMap.put("latitude", String.valueOf(latitude));
			locationMap.put("longitude", String.valueOf(longitude));
		} catch (Exception e) {
			locationMap.put("latitude", "0.0");
			locationMap.put("longitude", "0.0");
		}

		NearByRestaurant nearByAsyncTask = new NearByRestaurant();
//		Log.i("anisha", "latitude " + latitude + "longitute " + longitude);
//
//		Toast.makeText(HomeActivity.this,
//				"Fetching Restaurants for" + "\n Longitude:" + longitude + "\n Latitude: " + latitude, 0).show();

		nearByAsyncTask.execute(locationMap);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	public void showSettingsAlert() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(HomeActivity.this);
		alertDialog.setTitle("SETTINGS");
		alertDialog.setMessage("Enable Location Provider!If It is OFF! Go to settings menu?");
		alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				HomeActivity.this.startActivity(intent);
			}
		});
		alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		alertDialog.show();
	}

	private class GeocoderHandler extends Handler {
		@Override
		public void handleMessage(Message message) {
			switch (message.what) {
			case 1:
				break;
			default:
			}
			// tvAddress.setText(locationAddress);
		}
	}

	public class NearByRestaurant extends AsyncTask<Map<String, String>, Void, List<BusinessSummary>> {

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressBarHelper.showProgressBarSmall("Please Wait...Fetching Restaurants...", true, HomeActivity.this);

		}

		@Override
		protected List<BusinessSummary> doInBackground(Map<String, String>... params) {
			// TODO Auto-generated method stub
			Map<String, String> location = params[0];
			try {

				String response = HttpRequest.get(URLConstants.PLACES_URL).headers(location).body();
				ObjectMapper mapper = new ObjectMapper();
				TypeFactory typeFactory = TypeFactory.defaultInstance();
				List<BusinessSummary> businessSummary = mapper.readValue(response,
						typeFactory.constructCollectionType(List.class, BusinessSummary.class));
//				Log.i(TAG + " NEARBY RESPONSE IS ", response);
				return businessSummary;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(List<BusinessSummary> result) {
			// TODO Auto-generated method stub
			progressBarHelper.dismissProgressBar();
			resultFromServer = result;

			if (result == null) {
				Toast.makeText(HomeActivity.this, "No Restaurant Available.", Toast.LENGTH_SHORT).show();
				noRestaurantAvailable.setVisibility(View.VISIBLE);
			} else {
				noRestaurantAvailable.setVisibility(View.GONE);
				for (BusinessSummary businessSummary : result) {
//					Log.i("anisha", "Image URL: " + businessSummary.getPhotoUrl());
//					Log.i("anisha", "Name: " + businessSummary.getName());

					restaurantNames.add(businessSummary.getName());
				}

				listView.setAdapter(new CustomListAdapter(HomeActivity.this, result));
			}

		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.refreshmenu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		switch (id) {
		case R.id.action_logout:
			Editor editor = sharedPreference.edit();
			editor.putBoolean("isLoggedIn", false);
			editor.commit();
			Intent intent = new Intent(HomeActivity.this, MainActivity.class);
			startActivity(intent);
			finish();
			break;
		case R.id.action_refresh:
			refreshRestaurant();
			break;

		default:
			break;
		}

		return super.onOptionsItemSelected(item);
	}

	public void refreshRestaurant() {
		// TODO Auto-generated method stub
		onStart();
	}

//	@Override
//	public void onBackPressed() {
//		// TODO Auto-generated method stub
//		super.onBackPressed();
//	}
}