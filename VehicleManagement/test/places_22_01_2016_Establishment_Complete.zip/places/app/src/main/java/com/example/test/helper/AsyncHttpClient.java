package com.example.test.helper;

import android.os.AsyncTask;
import android.util.Log;

import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;



/**
 * Created by root on 26/11/15.
 */
public class AsyncHttpClient extends AsyncTask<AsyncCommon,Void, String> {

    private static final String TAG = AsyncHttpClient.class.getSimpleName();

//    RestAdapter restAdapter;
    ICallBack callback;
    String key;

    public AsyncHttpClient(ICallBack callback, String key){
        this.callback = callback;
        this.key = key;
    }

    @Override
    protected void onPreExecute() {
//        restAdapter = new RestAdapter.Builder()
//                .setEndpoint(URLConstants.PLACES_UPDATEDATA)
//                .build();
    }

    @Override
    protected String doInBackground(AsyncCommon... params) {
        AsyncCommon common = params[0];
        String response = null;

            switch(common.getRequestType()) {
                case PUT:
                    response = putResponse(common);
                    break;
                case POST:
                    response = postResponse(common);
                    break;
                case GET:
                    response = getResponse(common);
                    break;
                case DELETE:
                    response = deleteResponse(common);
//                    IAPIMethods methods = restAdapter.create(IAPIMethods.class);
//                    response = methods.unSubScribeChannel(common.getPathParams().get(0), common.getPathParams().get(1));
                    break;
               default:
                    Log.e(TAG, "invalid request type");
            }

        return response;
    }

    private String deleteResponse(AsyncCommon common) {
        String response = null;
        ObjectMapper m = new ObjectMapper();
        if(common.getHeaders() != null) {
            try {
                response = HttpRequest.delete(common.getUrl()).contentType("application/json").headers(common.getHeaders()).json(m.writeValueAsString(common.getRequestObject())).body();
            } catch (IOException e) {
                Log.e(TAG,e.toString());
            }
            Log.e("delete response with headers : ", response);
        }else {
            try {
                response = HttpRequest.delete(common.getUrl()).contentType("application/json").json(m.writeValueAsString(common.getRequestObject())).body();
            } catch (IOException e) {
                Log.e(TAG, e.toString());
            }
            Log.e("delete response : ", response);
        }
        return response;
    }

    @Override
    protected void onPostExecute(String s) {
        callback.processResponse(key,s);
    }

    private String putResponse(AsyncCommon common){
        String response = null;
        ObjectMapper m = new ObjectMapper();
        if(common.getHeaders() != null) {
            try {
                response = HttpRequest.put(common.getUrl()).contentType("application/json").headers(common.getHeaders()).json(m.writeValueAsString(common.getRequestObject())).body();
            } catch (IOException e) {
                Log.e(TAG,e.toString());
            }
            Log.e("put response with headers : ", response);
        }else {
            try {
                response = HttpRequest.put(common.getUrl()).contentType("application/json").json(m.writeValueAsString(common.getRequestObject())).body();
            } catch (IOException e) {
                Log.e(TAG, e.toString());
            }
            Log.e("put response : ", response);
        }
        return response;
    }

    private String postResponse(AsyncCommon common){
        String response = null;
        ObjectMapper m = new ObjectMapper();
        if(common.getHeaders() != null) {
            try {
                response = HttpRequest.post(common.getUrl()).contentType("application/json").headers(common.getHeaders()).json(m.writeValueAsString(common.getRequestObject())).body();
            } catch (IOException e) {
                Log.e(TAG,e.toString());
            }
            Log.e("post response with headers : ", response);
        }else {
            try {
                response = HttpRequest.post(common.getUrl()).contentType("application/json").json(m.writeValueAsString(common.getRequestObject())).body();
            } catch (IOException e) {
                Log.e(TAG, e.toString());
            }
            Log.e("post response : ", response);
        }
        return response;
    }

    private String getResponse(AsyncCommon common){
        String response = null;
        ObjectMapper m = new ObjectMapper();
        if(common.getHeaders() != null) {
            response = HttpRequest.get(common.getUrl()).headers(common.getHeaders()).body();
            Log.e("get response with headers : ", response);
        }else {
            response = HttpRequest.get(common.getUrl()).body();
            Log.e("get response : ", response);
        }
        return response;
    }
}
