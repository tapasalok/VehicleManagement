package com.example.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.CursorLoader;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.Volley;
import com.example.test.helper.Constants;
import com.example.test.helper.CustomGallery;
import com.example.test.helper.HttpRequest;
import com.example.test.helper.HttpRequest.HttpRequestException;
import com.example.test.helper.URLConstants;
import com.restuarant.utils.CommonUtils;
import com.restuarant.utils.MultipartRequest;
import com.restuarant.utils.NothingSelectedSpinnerAdapter;
import com.restuarant.utils.ProgressBarHelper;
import com.squareup.picasso.Picasso;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Restaurant_Environment extends AppCompatActivity implements OnClickListener {
    String name = null;
    String description = null;
    String profilePhoto = null;
    String ownerName = null;
    String emailId = null;
    String phoneNumber = null;
    String nooftable = null;
    String noofwaiter = null;
    String establishMentType = null;
    String wifiAvailable = null;
    String networkStrength = null;
    String foodDeilvery = null;
    String deliverby = null;
    String deliveryTime = null;
    String deliverydistance = null;
    private EditText descriptionEditText;
    private EditText nameEditText;
    //    private EditText ownernameEditText;
    private EditText owneridEditText;
    private EditText ownerphonenoEditText;
    private EditText tablesEditText;
    private EditText waitersEditText;
    private EditText deliveryhourEditText;
    private EditText deliverykmEditText;
    //    private Spinner establishMentTypeSpinner;
    private ArrayAdapter<String> adapter;
    private Spinner signalStrengthSpinner;
    private Spinner deliverFoodSpinner;
    private Spinner wifiavailableSpinner;
    private Spinner deliveredBySpinner;
    // private ExpandableListView expandableListView;
    private HorizontalScrollView horizontalScrollView;
    // private ExpandableListAdapter expandableListAdapter;
    // private List<String> expandableListTitle;
    // private HashMap<String, List<String>> expandableListDetail;
    private ImageView restaurantpic;
    private Button camera;
    private int PICK_IMAGE_REQUEST = 200;
    private static final int REQUEST_IMAGE_CAPTURE = 300;
    private static final int REQUEST_IMAGE_MENU_CAPTURE = 400;
    public static final int MEDIA_TYPE_IMAGE = 1;

    public ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();
    private LinkedList<String> restaurantProfilePics;
    private boolean showDialog = false;
    private LinkedHashMap<String, String> linkedHashMapProfilePics;
    private LinkedList<String> restaurantMenuPics;
    private LinkedList<String> restaurantMenuPicsFromServer;
    private LinkedList<Bitmap> restaurantMenuPicsBitmap;
    private LinkedHashMap<String, String> linkedHashMapMenuPics;
    private ProgressBarHelper progressBarHelper;
    private List<String> restaurantNames = new ArrayList<String>();
    // private String[] otherRestaurantDetails = new String[20];
    private Location location;
    private boolean isUpdateRestaurant = false;
    private String sid;
    private View selectedImageView;
    private Bitmap bitmapToRemove;
    private String URLToRemove;
    private SharedPreferences sharedPreference;
    //    public static final String[] SPINNER_PROMPT_TITLES = {"Type of Establishment ?", "Wifi Availablity ?",
//            "Mobile Signal Strengh:", "Do they deliver food ?", "Delivered By:"};

    private LinearLayout layout;
    private Button establishMentTypeSpinner;
    protected List<String> selectedEstablishment = new ArrayList<String>();

    public Restaurant_Environment() {
        super();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.restaurant_form);
        establishMentTypeSpinner = (Button) findViewById(R.id.establishmenttype);
        horizontalScrollView = (HorizontalScrollView) findViewById(R.id.horizontal_scroll);
        registerForContextMenu(horizontalScrollView);
        layout = (LinearLayout) horizontalScrollView.findViewById(R.id.linear);
        sharedPreference = getSharedPreferences("common_preference", Activity.MODE_PRIVATE);

        Intent service = new Intent(Restaurant_Environment.this, AppLocationService.class);
        startService(service);

        location = AppLocationService.getBestLastGeolocation(Restaurant_Environment.this);

        nameEditText = (EditText) findViewById(R.id.name);
        descriptionEditText = (EditText) findViewById(R.id.description);
        restaurantpic = (ImageView) findViewById(R.id.restaurantpic);
        restaurantpic.setOnClickListener(restaurantPicture);

//        ownernameEditText = (EditText) findViewById(R.id.ownername);
//        ownernameEditText.setInputType(InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
//
//        InputFilter[] ownernamefilterArray = new InputFilter[]{alphaFilter};
//        ownernamefilterArray[0] = new InputFilter.LengthFilter(20);
//        ownernameEditText.setFilters(ownernamefilterArray);

        owneridEditText = (EditText) findViewById(R.id.ownerid);
        owneridEditText.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);


        ownerphonenoEditText = (EditText) findViewById(R.id.ownerph);
        ownerphonenoEditText.setInputType(InputType.TYPE_CLASS_PHONE);
        ownerphonenoEditText.setKeyListener(DigitsKeyListener.getInstance("1234567890"));
        InputFilter[] ownerphonenofilterArray = new InputFilter[1];
        ownerphonenofilterArray[0] = new InputFilter.LengthFilter(13);
        ownerphonenoEditText.setFilters(ownerphonenofilterArray);


        tablesEditText = (EditText) findViewById(R.id.tables);
        tablesEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
        tablesEditText.setKeyListener(DigitsKeyListener.getInstance("1234567890"));
        InputFilter[] tablesfilterArray = new InputFilter[1];
        tablesfilterArray[0] = new InputFilter.LengthFilter(3);
        tablesEditText.setFilters(tablesfilterArray);

        waitersEditText = (EditText) findViewById(R.id.waiters);
        waitersEditText.setKeyListener(DigitsKeyListener.getInstance("1234567890"));
        InputFilter[] waitersfilterArray = new InputFilter[1];
        waitersfilterArray[0] = new InputFilter.LengthFilter(3);
        waitersEditText.setFilters(waitersfilterArray);

        deliveryhourEditText = (EditText) findViewById(R.id.time);
        deliveryhourEditText.setKeyListener(DigitsKeyListener.getInstance("1234567890."));
        InputFilter[] deliveryhourfilterArray = new InputFilter[1];
        deliveryhourfilterArray[0] = new InputFilter.LengthFilter(3);
        deliveryhourEditText.setFilters(deliveryhourfilterArray);

        deliverykmEditText = (EditText) findViewById(R.id.distance);
        deliverykmEditText.setKeyListener(DigitsKeyListener.getInstance("1234567890."));
        InputFilter[] deliverykmfilterArray = new InputFilter[1];
        deliverykmfilterArray[0] = new InputFilter.LengthFilter(4);
        deliverykmEditText.setFilters(deliverykmfilterArray);

//        establishMentTypeSpinner = (Spinner) findViewById(R.id.establishment);
        wifiavailableSpinner = (Spinner) findViewById(R.id.wifiSpinner);
        signalStrengthSpinner = (Spinner) findViewById(R.id.spinnersignal);
        deliverFoodSpinner = (Spinner) findViewById(R.id.fooddelivery);
        deliveredBySpinner = (Spinner) findViewById(R.id.deliveredby);

        progressBarHelper = ProgressBarHelper.getSingletonInstance();
        restaurantProfilePics = new LinkedList<String>();
        restaurantMenuPics = new LinkedList<String>();
        restaurantMenuPicsFromServer = new LinkedList<String>();
        restaurantMenuPicsBitmap = new LinkedList<Bitmap>();
        linkedHashMapProfilePics = new LinkedHashMap<String, String>();
        linkedHashMapMenuPics = new LinkedHashMap<String, String>();


        android.support.v7.app.ActionBar actionbar = getSupportActionBar();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//		actionbar.setLogo(R.drawable.backbutton);
        getSupportActionBar().setLogo(R.drawable.backbutton);
        actionbar.setHomeButtonEnabled(true);

//		getSupportActionBar().setHomeAsUpIndicator(R.color.light_white_);
//		ActionBar actionbar = getActionBar();
//		actionbar.setLogo(R.drawable.backbutton);
//		actionbar.setHomeButtonEnabled(true);
        actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#ba68c8")));
        camera = (Button) findViewById(R.id.camera);
        OnClickListener menupics = new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                takePhotoForMenu();
            }
        };
        camera.setOnClickListener(menupics);
        Intent intent = getIntent();
        if (intent != null) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {

                // isUpdateRestaurant flag will be true in case It's the update
                // case
                isUpdateRestaurant = bundle.getBoolean("update_restaurant");
                if (isUpdateRestaurant) {
                    getSupportActionBar().setTitle("Update Restaurant");
                } else {
                    restaurantNames = intent.getStringArrayListExtra("restaurant_names");
                    getSupportActionBar().setTitle("Add Restaurant");
                }

                // getting all the data coming from server through bundle
                profilePhoto = bundle.getString("profilePhoto");
                name = bundle.getString("name");
                description = bundle.getString("description");
                ownerName = bundle.getString("ownerName");
//                establishMentType = bundle.getString("typeofestablishment");
                emailId = bundle.getString("emailId");
                phoneNumber = bundle.getString("PhonoNo");
                nooftable = bundle.getString("nooftable");
                noofwaiter = bundle.getString("noofwaiter");
//               establishMentType = bundle.getString("typeofestablishment");
                wifiAvailable = bundle.getString("wifiavailable");
                networkStrength = bundle.getString("signalstrenth");
                foodDeilvery = bundle.getString("deliverfood");
                deliverby = bundle.getString("deliverby");
                deliveryTime = bundle.getString("deleverytime");
                deliverydistance = bundle.getString("deliverydistance");

				/*
                 * If no profile picture coming from Server then, set the
				 * default picture
				 */
                if (TextUtils.isEmpty(profilePhoto)) {
                    Picasso.with(Restaurant_Environment.this).load(R.drawable.restaurantpic).into(restaurantpic);
                } else {

					/*
                     * If Profile picture coming from Server then, add the
					 * profile picture which is coming into the list
					 */
                    restaurantProfilePics.add(profilePhoto);
                    try {

						/*
                         * get the timestamp from the URL using substring and
						 * make it key
						 */
                        String timeStamp = profilePhoto.substring(profilePhoto.length() - 13);
                        linkedHashMapProfilePics.put(timeStamp, profilePhoto);
                    } catch (Exception e) {
                        // In Case of exception, make the current time as key
                        String timeStamp = System.currentTimeMillis() + "";
                        linkedHashMapProfilePics.put(timeStamp, profilePhoto);
                    }

                    // Put that image to the ImageView
                    Picasso.with(Restaurant_Environment.this).load(profilePhoto).resize(350, 350)
                            .error(R.drawable.no_media).into(restaurantpic);
                }

//                this.establishMentTypeSpinner.setVisibility(View.VISIBLE);
//                this.establishMentTypeSpinner.setPrompt(SPINNER_PROMPT_TITLES[0]);
//                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(Restaurant_Environment.this,
//                        android.R.layout.simple_spinner_item, ESTABLISHMENT);
//                arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_multiple_choice);
//                this.establishMentTypeSpinner.setAdapter(new NothingSelectedSpinnerAdapter(arrayAdapter,
//                        R.layout.spinner_row_nothing_selected_establishment,
//                        // R.layout.contact_spinner_nothing_selected_dropdown,
//                        // // Optional
//                        this));


                wifiavailableSpinner.setVisibility(View.VISIBLE);
//                wifiavailableSpinner.setPrompt(SPINNER_PROMPT_TITLES[1]);
                ArrayAdapter<String> arrayAdapter1 = new ArrayAdapter<String>(Restaurant_Environment.this,
                        android.R.layout.simple_spinner_item, RegisterRestaurantConstants.WIFIAVAILABLE);
                arrayAdapter1.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
                wifiavailableSpinner.setAdapter(
                        new NothingSelectedSpinnerAdapter(arrayAdapter1, R.layout.spinner_row_nothing_selected_wifi,
                                // R.layout.contact_spinner_nothing_selected_dropdown,
                                // // Optional
                                this));
                if (!(TextUtils.isEmpty(wifiAvailable) || "null".equals(wifiAvailable))) {
                    if (wifiAvailable.equals(RegisterRestaurantConstants.WIFIAVAILABLESERVER[0])) {
                        this.wifiavailableSpinner.setSelection(1);
                    } else if (wifiAvailable.equals(RegisterRestaurantConstants.WIFIAVAILABLESERVER[1])) {
                        this.wifiavailableSpinner.setSelection(2);
                    }
                }

                signalStrengthSpinner.setVisibility(View.VISIBLE);
//                signalStrengthSpinner.setPrompt(SPINNER_PROMPT_TITLES[2]);
                ArrayAdapter<String> arrayAdaptersignal = new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_item, RegisterRestaurantConstants.SIGNAL);
                arrayAdaptersignal.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
                signalStrengthSpinner.setAdapter(new NothingSelectedSpinnerAdapter(arrayAdaptersignal,
                        R.layout.spinner_row_nothing_selected_signal,
                        // R.layout.contact_spinner_nothing_selected_dropdown,
                        // // Optional
                        this));
                if (!(TextUtils.isEmpty(networkStrength) || "null".equals(networkStrength))) {
                    if (networkStrength.equals(RegisterRestaurantConstants.SIGNAL[0])) {
                        this.signalStrengthSpinner.setSelection(1);
                    } else if (networkStrength.equals(RegisterRestaurantConstants.SIGNAL[1])) {
                        this.signalStrengthSpinner.setSelection(2);
                    } else if (networkStrength.equals(RegisterRestaurantConstants.SIGNAL[2])) {
                        this.signalStrengthSpinner.setSelection(3);
                    }
                }
                deliverFoodSpinner.setVisibility(View.VISIBLE);
//                deliverFoodSpinner.setPrompt(SPINNER_PROMPT_TITLES[3]);
                ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<String>(Restaurant_Environment.this,
                        android.R.layout.simple_spinner_item, RegisterRestaurantConstants.DELIVERFOOD);
                arrayAdapter3.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
                deliverFoodSpinner.setAdapter(new NothingSelectedSpinnerAdapter(arrayAdapter3,
                        R.layout.spinner_row_nothing_selected_deliveryfood,
                        // R.layout.contact_spinner_nothing_selected_dropdown,
                        // // Optional
                        this));
                if (!(TextUtils.isEmpty(foodDeilvery) || "null".equals(foodDeilvery))) {
                    if (foodDeilvery.equals(RegisterRestaurantConstants.DELIVERFOODSERVER[0])) {
                        this.deliverFoodSpinner.setSelection(1);
                    } else if (foodDeilvery.equals(RegisterRestaurantConstants.DELIVERFOODSERVER[1])) {
                        this.deliverFoodSpinner.setSelection(2);
                    }
                }
                deliveredBySpinner.setVisibility(View.VISIBLE);
//                deliveredBySpinner.setPrompt(SPINNER_PROMPT_TITLES[4]);
                ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_item, RegisterRestaurantConstants.DELIVEREDBY);
                arrayAdapter2.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
                deliveredBySpinner.setAdapter(new NothingSelectedSpinnerAdapter(arrayAdapter2,
                        R.layout.spinner_row_nothing_selected_deliveredby,
                        // R.layout.contact_spinner_nothing_selected_dropdown,
                        // // Optional
                        this));
                if (!(TextUtils.isEmpty(deliverby) || "null".equals(deliverby))) {
                    if (deliverby.equals(RegisterRestaurantConstants.DELIVEREDBY[0])) {
                        this.deliveredBySpinner.setSelection(1);
                    } else if (deliverby.equals(RegisterRestaurantConstants.DELIVEREDBY[1])) {
                        this.deliveredBySpinner.setSelection(2);
                    }
                }
                sid = bundle.getString("sid");

                ArrayList<String> menuImages = bundle.getStringArrayList("menus");
                if (menuImages != null && menuImages.size() > 0) {
                    restaurantMenuPicsFromServer.addAll(menuImages);
                }

                if (restaurantMenuPicsFromServer != null && restaurantMenuPicsFromServer.size() > 0) {
                    LinearLayout layout = (LinearLayout) horizontalScrollView.findViewById(R.id.linear);
                    for (final String imageURL : restaurantMenuPicsFromServer) {
                        ImageView imageViewMenuPics = new ImageView(Restaurant_Environment.this);
                        imageViewMenuPics.setPadding(2, 2, 2, 2);
                        if (TextUtils.isEmpty(imageURL)) {
                            Picasso.with(Restaurant_Environment.this).load(R.drawable.restaurantpic)
                                    .into(imageViewMenuPics);
                        } else {
                            Picasso.with(Restaurant_Environment.this).load(imageURL).resize(350, 350)
                                    .error(R.drawable.no_media).into(imageViewMenuPics);
                        }
                        imageViewMenuPics.setScaleType(ScaleType.FIT_XY);
                        layout.addView(imageViewMenuPics);
                        imageViewMenuPics.setOnLongClickListener(new OnLongClickListener() {

                            @Override
                            public boolean onLongClick(View v) {
                                // TODO Auto-generated method stub
                                selectedImageView = v;
                                URLToRemove = imageURL;
                                return false;
                            }
                        });
                    }
                }

                if (!(TextUtils.isEmpty(name) || "null".equals(name))) {
                    this.nameEditText.setText(name);
                }
                if (!(TextUtils.isEmpty(description) || "null".equals(description))) {
                    this.descriptionEditText.setText(description);
                }
//                if (!(TextUtils.isEmpty(ownerName) || "null".equals(ownerName))) {
//                    this.ownernameEditText.setText(ownerName);
//                }
                if (!(TextUtils.isEmpty(emailId) || "null".equals(emailId))) {
                    this.owneridEditText.setText(emailId);
                }
                if (!(TextUtils.isEmpty(phoneNumber) || "null".equals(phoneNumber))) {
                    this.ownerphonenoEditText.setText(phoneNumber);
                }
                if (!(TextUtils.isEmpty(nooftable) || "null".equals(nooftable))) {
                    this.tablesEditText.setText(nooftable);
                }
                if (!(TextUtils.isEmpty(noofwaiter) || "null".equals(noofwaiter))) {
                    this.waitersEditText.setText(noofwaiter);
                }
                if (!(TextUtils.isEmpty(deliveryTime) || "null".equals(deliveryTime))) {
                    this.deliveryhourEditText.setText(deliveryTime);
                }

                if (!(TextUtils.isEmpty(deliverydistance) || "null".equals(deliverydistance))) {
                    this.deliverykmEditText.setText(deliverydistance);
                }

            }
        }

        if (TextUtils.isEmpty(ownerName) || "null".equals(ownerName)) {

        } else {
            ownerName.replace(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[0], RegisterRestaurantConstants.ESTABLISHMENT[0]);
            ownerName.replace(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[1], RegisterRestaurantConstants.ESTABLISHMENT[1]);
            ownerName.replace(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[2], RegisterRestaurantConstants.ESTABLISHMENT[2]);
            ownerName.replace(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[3], RegisterRestaurantConstants.ESTABLISHMENT[3]);

            establishMentTypeSpinner.setText(ownerName);

            String[] establishArray = ownerName.split(",");
            selectedEstablishment = new ArrayList<String>(Arrays.asList(establishArray));
            for (int i = 0; i < selectedEstablishment.size(); i++) {
                String selectedOne = selectedEstablishment.get(i);

                if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[0]) ||
                        selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[1]) ||
                        selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[2]) ||
                        selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[3]) ||
                        selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[0]) ||
                        selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[1]) ||
                        selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[2]) ||
                        selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[3])) {

                    if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[0])) {
                        selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENT[0]);
                    } else if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[1])) {
                        selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENT[1]);
                    } else if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[2])) {
                        selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENT[2]);
                    } else if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENTACTUAL[3])) {
                        selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENT[3]);
                    }

                } else {
                    // Wrong data should be removed from List
                    selectedEstablishment.remove(selectedOne);
                }
            }

            if (selectedEstablishment !=null && selectedEstablishment.size()>0){
                onChangeSelectedColours();
            }

        }


        OnClickListener l = new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                switch (v.getId()) {
                    case R.id.establishmenttype:
                        showSelectColoursDialog();
                        break;

                    default:
                        break;
                }

            }

            protected void showSelectColoursDialog() {
                boolean[] checkedColours = new boolean[RegisterRestaurantConstants.ESTABLISHMENT.length];
                int count = RegisterRestaurantConstants.ESTABLISHMENT.length;

                for (int i = 0; i < count; i++)
                    checkedColours[i] = selectedEstablishment.contains(RegisterRestaurantConstants.ESTABLISHMENT[i]);

                DialogInterface.OnMultiChoiceClickListener coloursDialogListener = new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        if (isChecked)
                            selectedEstablishment.add(RegisterRestaurantConstants.ESTABLISHMENT[which]);
                        else
                            selectedEstablishment.remove(RegisterRestaurantConstants.ESTABLISHMENT[which]);

                        onChangeSelectedColours();
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(Restaurant_Environment.this);
//                builder.setTitle("Type of establishment");
                builder.setMultiChoiceItems(RegisterRestaurantConstants.ESTABLISHMENT, checkedColours, coloursDialogListener);

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        };

        establishMentTypeSpinner.setOnClickListener(l);

    }

    OnClickListener restaurantPicture = new OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            takePhotoForIdentity();
        }
    };

    protected void onChangeSelectedColours() {
        StringBuilder stringBuilder = new StringBuilder();

        for (CharSequence colour : selectedEstablishment)
            stringBuilder.append(colour + ",");

        establishMentTypeSpinner.setText(stringBuilder.toString());
    }

    protected void takePhotoForIdentity() {
        // TODO Auto-generated method stub
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }

    }

    /* Takes the picture for the Menu pictures */
    protected void takePhotoForMenu() {
        // TODO Auto-generated method stub
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_MENU_CAPTURE);
        }

    }

    @Override
    public void onClick(View v) {
        saveRestaurantDetailsOnBackPress();
    }

    private void uploadPicturesAndSubmit() {
        try {
            // validateFields() validates all the fields
            if (validateFields()) {
                progressBarHelper.showProgressBarSmall("Uploading... Please wait...", true,
                        Restaurant_Environment.this);

                String url = "http://130.211.255.181/places-impl-web/rest/attachment/upload_menus";

                // Upload Restaurant Profile Picture
                uploadRestaurantProfilePic(url);
            }
        } catch (Exception e) {
            // TODO: handle exception
        } finally {
        }
    }

    private void uploadRestaurantProfilePic(final String url) {
        if (restaurantProfilePics != null && restaurantProfilePics.size() > 0) {
            if (restaurantProfilePics.getLast().contains("http:")
                    || restaurantProfilePics.getLast().contains("130.211.255.181")) {
                uploadRestaurantMenuPic(url);
            } else {
                String filePath = restaurantProfilePics.getLast();
                File file = new File(filePath);
                String filePartName = "uploadedFile";
                Listener<NetworkResponse> resultDelivery = new Listener<NetworkResponse>() {

                    @Override
                    public void onResponse(NetworkResponse response) {
                        // TODO Auto-generated method stub
                        Log.i("anisha", "Receive time" + response.headers.get("X-Android-Received-Millis"));
                        try {
                            String profilePicResponse = new String(response.data,
                                    HttpHeaderParser.parseCharset(response.headers));
                            Log.i("anisha", "ImageResponse: " + profilePicResponse);

                            linkedHashMapProfilePics.put(response.headers.get("X-Android-Received-Millis"),
                                    profilePicResponse);

                            // After Profile Picture. Upload Menu Pictures now
                            uploadRestaurantMenuPic(url);

                        } catch (UnsupportedEncodingException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(Restaurant_Environment.this,
                                    "Some problem in uploading Restaurant Profile Picture.", Toast.LENGTH_SHORT).show();
                            if (progressBarHelper != null) {
                                progressBarHelper.dismissProgressBar();
                            }
                        } catch (Exception e) {
                            // TODO: handle exception
                            Toast.makeText(Restaurant_Environment.this,
                                    "Some problem in uploading Restaurant Profile Picture.", Toast.LENGTH_SHORT).show();
                            if (progressBarHelper != null) {
                                progressBarHelper.dismissProgressBar();
                            }
                        }

                    }
                };
                ErrorListener errorListener = new ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError errorResponse) {
                        // TODO Auto-generated method stub
                        Toast.makeText(Restaurant_Environment.this,
                                "Some problem in uploading Restaurant Profile Picture.", Toast.LENGTH_SHORT).show();
                        if (progressBarHelper != null) {
                            progressBarHelper.dismissProgressBar();
                        }

                    }
                };
                Map<String, String> params = new HashMap<String, String>();

                params.put("filename", "" + System.currentTimeMillis());

                uploadImage(url, file, filePartName, resultDelivery, errorListener, params);
            }
        } else {
            uploadRestaurantMenuPic(url);
        }

    }

    private void uploadRestaurantMenuPic(final String url) {

        if (restaurantMenuPics == null || restaurantMenuPics.size() <= 0) {
            submitRestaurantInfo();
        } else {
            for (final String filePath : restaurantMenuPics) {
                if (filePath.contains("http:") || filePath.contains("130.211.255.181")) {
                    if (restaurantMenuPics.getLast().equals(filePath)) {
                        submitRestaurantInfo();
                    }

                } else {
                    File file = new File(filePath);
                    String filePartName = "uploadedFile";
                    Listener<NetworkResponse> resultDelivery = new Listener<NetworkResponse>() {

                        @Override
                        public void onResponse(NetworkResponse response) {
                            // TODO Auto-generated method stub
                            Log.i("anisha", "Receive time" + response.headers.get("X-Android-Received-Millis"));
                            try {
                                String profilePicResponse = new String(response.data,
                                        HttpHeaderParser.parseCharset(response.headers));
                                Log.i("anisha", "ImageResponse: " + profilePicResponse);

                                linkedHashMapMenuPics.put(response.headers.get("X-Android-Received-Millis"),
                                        profilePicResponse);
                                if (filePath.equals(restaurantMenuPics.getLast())) {

									/*
                                     * If this is the last image for Menu
									 * Pictures. Then, submit the Restaurant
									 * information to Server
									 */
                                    submitRestaurantInfo();
                                }

                            } catch (UnsupportedEncodingException e) {
                                // TODO Auto-generated catch block
                                Toast.makeText(Restaurant_Environment.this,
                                        "Some problem in uploading Restaurant Menu Picture.", Toast.LENGTH_SHORT)
                                        .show();
                                if (progressBarHelper != null) {
                                    progressBarHelper.dismissProgressBar();
                                }
                            } catch (Exception e) {
                                // TODO: handle exception
                                Toast.makeText(Restaurant_Environment.this,
                                        "Some problem in submitting restaurant data.", Toast.LENGTH_SHORT).show();
                                if (progressBarHelper != null) {
                                    progressBarHelper.dismissProgressBar();
                                }
                            }

                        }
                    };
                    ErrorListener errorListener = new ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError errorResponse) {
                            // TODO Auto-generated method stub
                            Toast.makeText(Restaurant_Environment.this,
                                    "Some problem in uploading Restaurant Menu Picture onErrorResponse.", Toast.LENGTH_SHORT).show();
                            if (progressBarHelper != null) {
                                progressBarHelper.dismissProgressBar();
                            }

                        }
                    };
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("filename", "" + System.currentTimeMillis());

                    uploadImage(url, file, filePartName, resultDelivery, errorListener, params);

                }
            }
        }

    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public String getStoragePath(Uri uri) {
        String filePath = "";
        String wholeID = uri.getPath();

        // Split at colon, use second item in the array
        try {
            String id = wholeID.split(":")[1];

            String[] column = {MediaStore.Images.Media.DATA};

            // where id is equal to
            String sel = MediaStore.Images.Media._ID + "=?";

            Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel,
                    new String[]{id}, null);

            int columnIndex = cursor.getColumnIndex(column[0]);

            if (cursor.moveToFirst()) {
                filePath = cursor.getString(columnIndex);
            }
            cursor.close();
        } catch (Exception e) {
            // TODO: handle exception
            try {
                String[] proj = {MediaStore.Images.Media.DATA};
                String result = null;

                CursorLoader cursorLoader = new CursorLoader(Restaurant_Environment.this, uri, proj, null, null, null);
                Cursor cursor = cursorLoader.loadInBackground();

                if (cursor != null) {
                    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                    cursor.moveToFirst();
                    result = cursor.getString(column_index);
                }
                return result;
            } catch (Exception e2) {
                // TODO: handle exception
                String[] proj = {MediaStore.Images.Media.DATA};
                Cursor cursor = Restaurant_Environment.this.getContentResolver().query(uri, proj, null, null, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                return cursor.getString(column_index);
            }

        }

        return filePath;
    }

    /**
     * This method uploads image to server using Volley
     */
    protected <T> void uploadImage(final String url, final File file, final String filePartName,
                                   final Response.Listener<NetworkResponse> resultDelivery, final Response.ErrorListener errorListener,
                                   Map<String, String> params) {

        MultipartRequest mr = new MultipartRequest(url, errorListener, resultDelivery, file, filePartName, params);
        Volley.newRequestQueue(this).add(mr);
    }

    /**
     * Validates the fields whether those are correct or not
     *
     * @return
     */
    private boolean validateFields() {
        // TODO Auto-generated method stub
        String name = this.nameEditText.getText().toString();

        if (TextUtils.isEmpty(name)) {
            TextInputLayout tilEmail = (TextInputLayout) findViewById(R.id.restname);
            tilEmail.setError("   Please enter Restuarant Name");
            Toast.makeText(Restaurant_Environment.this, "Please enter Restuarant Name", Toast.LENGTH_SHORT).show();

            if (validateEmailId()) return false;

            return false;
        }

        if (isUpdateRestaurant == false && restaurantNames != null && restaurantNames.contains(name)) {
            Toast.makeText(Restaurant_Environment.this, "This Restaurant is already registered with us",
                    Toast.LENGTH_SHORT).show();
            return false;
        }

        if (validateEmailId()) return false;

        return true;
    }

    private boolean validateEmailId() {
        String ownerEmail = "";
        if (owneridEditText.getText() != null) {
            ownerEmail = owneridEditText.getText().toString();
        }

        if (TextUtils.isEmpty(ownerEmail)) {

        } else {
            if (!CommonUtils.isValidEmail(ownerEmail)) {
                TextInputLayout til = (TextInputLayout) owneridEditText.getParent();
                til.setErrorEnabled(true);
                til.setError("Please enter valid email Id");
                Toast.makeText(Restaurant_Environment.this, "Please enter valid email Id", Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return false;
    }

    /**
     * Submits all the restaurant information to Server
     */
    private void submitRestaurantInfo() {
        location = AppLocationService.getBestLastGeolocation(Restaurant_Environment.this);

        String photoUrl = "";
        if (linkedHashMapProfilePics != null && linkedHashMapProfilePics.size() > 0) {

            if (restaurantProfilePics.getLast().contains("http:")
                    || restaurantProfilePics.getLast().contains("130.211.255.181")) {
                photoUrl = restaurantProfilePics.getLast();
            } else {
                Set<String> keySet = linkedHashMapProfilePics.keySet();
                for (String string : keySet) {
                    photoUrl = "http://130.211.255.181/places-impl-web/rest/attachment/images/"
                            + linkedHashMapProfilePics.get(string) + "?timestamp=" + string;
                }
            }
        }

        String name = this.nameEditText.getText().toString();
        String description = this.descriptionEditText.getText().toString();
//       String ownerName = this.ownernameEditText.getText().toString();
        String ownerEmail = this.owneridEditText.getText().toString();
        String ownerPhoneNo = this.ownerphonenoEditText.getText().toString();

        String numberOfTables = this.tablesEditText.getText().toString();
        String numberOfWaiters = this.waitersEditText.getText().toString();
        String deliverwithin = this.deliveryhourEditText.getText().toString();
        String deliveraround = this.deliverykmEditText.getText().toString();


        String wifiavailable = "";
        if (this.wifiavailableSpinner.getItemAtPosition(this.wifiavailableSpinner.getSelectedItemPosition()) != null
                && !TextUtils.isEmpty(this.wifiavailableSpinner
                .getItemAtPosition(this.wifiavailableSpinner.getSelectedItemPosition()).toString())) {
            wifiavailable = this.wifiavailableSpinner
                    .getItemAtPosition(this.wifiavailableSpinner.getSelectedItemPosition()).toString();
        }

        String signalstrength = "";
        if (this.signalStrengthSpinner.getItemAtPosition(this.signalStrengthSpinner.getSelectedItemPosition()) != null
                && !TextUtils.isEmpty(this.signalStrengthSpinner
                .getItemAtPosition(this.signalStrengthSpinner.getSelectedItemPosition()).toString())) {
            signalstrength = this.signalStrengthSpinner
                    .getItemAtPosition(this.signalStrengthSpinner.getSelectedItemPosition()).toString();
        }

        String deliverfood = "";
        if (this.deliverFoodSpinner.getItemAtPosition(this.deliverFoodSpinner.getSelectedItemPosition()) != null
                && !TextUtils.isEmpty(this.deliverFoodSpinner
                .getItemAtPosition(this.deliverFoodSpinner.getSelectedItemPosition()).toString())) {
            deliverfood = this.deliverFoodSpinner.getItemAtPosition(this.deliverFoodSpinner.getSelectedItemPosition())
                    .toString();
        }

        String deliveredBy = "";
        if (this.deliveredBySpinner.getItemAtPosition(this.deliveredBySpinner.getSelectedItemPosition()) != null && !TextUtils
                .isEmpty(this.deliveredBySpinner.getItemAtPosition(this.deliveredBySpinner.getSelectedItemPosition()).toString())) {
            deliveredBy = this.deliveredBySpinner.getItemAtPosition(this.deliveredBySpinner.getSelectedItemPosition()).toString();
        }
        // String deliverwithin = expandableListAdapter.getChildData(2, 2);
        // String deliveraround = expandableListAdapter.getChildData(2, 3);
        List<String> menus = new ArrayList<String>();

        if (restaurantMenuPicsFromServer != null && restaurantMenuPicsFromServer.size() > 0) {
            for (String menu : restaurantMenuPicsFromServer) {
                menus.add(menu);
            }
        }

        if (linkedHashMapMenuPics != null & linkedHashMapMenuPics.size() > 0) {
            Set<String> menuPics = linkedHashMapMenuPics.keySet();
            for (String string : menuPics) {
                menus.add("http://130.211.255.181/places-impl-web/rest/attachment/images/"
                        + linkedHashMapMenuPics.get(string) + "?timestamp=" + string);
            }
        }

        RestaurantDetails restaurantDetails = new RestaurantDetails();

        // restaurantDetails.ownerEmail = ownerEmail;
        // restaurantDetails.ownerPhoneNo = ownerPhoneNo;
        restaurantDetails.name = name;
        restaurantDetails.description = description;
//        restaurantDetails.ownerName = ownerName;
        restaurantDetails.ownerEmail = ownerEmail;
        restaurantDetails.ownerPhoneNo = ownerPhoneNo;
        restaurantDetails.numberOfTables = numberOfTables;
        restaurantDetails.numberOfWaiters = numberOfWaiters;

//         restaurantDetails.deliverWithin = deliverwithin;
//         restaurantDetails.deliverAround = deliveryhour;
        // restaurantDetails.address = address;

        // PhotoUrl and menus should be actual URL
        restaurantDetails.photoUrl = photoUrl;

        restaurantDetails.menus = menus.toArray(new String[menus.size()]);
        // restaurantDetails.numberOfTables = numberOfTables;
        // restaurantDetails.numberOfWaiters = numberOfWaiters;
        //
//        if (establishMentType.equals(RegisterRestaurantConstants.ESTABLISHMENT[0])) {
//            restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.DineIn;
//        } else if (establishMentType.equals(RegisterRestaurantConstants.ESTABLISHMENT[1])) {
//            restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.Buffet;
//        } else if (establishMentType.equals(RegisterRestaurantConstants.ESTABLISHMENT[2])) {
//            restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.TakeAway;
//        } else if (establishMentType.equals(RegisterRestaurantConstants.ESTABLISHMENT[3])) {
//            restaurantDetails.establishMentType = RestaurantDetails.EstablishMentType.QSR;
//        }

        for (int i = 0; i < selectedEstablishment.size(); i++) {
            String selectedOne = selectedEstablishment.get(i);
            if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[0])) {
                selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENTACTUAL[0]);
            } else if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[1])) {
                selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENTACTUAL[1]);
            } else if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[2])) {
                selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENTACTUAL[2]);
            } else if (selectedOne.contains(RegisterRestaurantConstants.ESTABLISHMENT[3])) {
                selectedEstablishment.set(i, RegisterRestaurantConstants.ESTABLISHMENTACTUAL[3]);
            }
        }

        String ownerName = "";
        if (selectedEstablishment != null) {
            Set<String> selectedSet = new HashSet<String>(selectedEstablishment);

            if (selectedSet != null && selectedSet.size() > 0) {
                ownerName = selectedSet.toString().substring(1, selectedSet.toString().length() - 1);
            }
//            for (String selectedOne : selectedSet) {
//                if (TextUtils.isEmpty(ownerName)) {
//                    ownerName = ownerName + selectedOne;
//                } else {
//                    ownerName = "," + selectedOne;
//                }
//            }
        }

        restaurantDetails.ownerName = ownerName;

        if (wifiavailable.equals(RegisterRestaurantConstants.WIFIAVAILABLE[0])) {
            restaurantDetails.wifiAvailable = true;
        } else if (wifiavailable.equals(RegisterRestaurantConstants.WIFIAVAILABLE[1])) {
            restaurantDetails.wifiAvailable = false;
        }

        if (signalstrength.equals(RegisterRestaurantConstants.SIGNAL[0])) {
            restaurantDetails.networkStrength = RestaurantDetails.NetworkStrength.Excellent;
        } else if (signalstrength.equals(RegisterRestaurantConstants.SIGNAL[1])) {
            restaurantDetails.networkStrength = RestaurantDetails.NetworkStrength.Moderate;
        } else if (signalstrength.equals(RegisterRestaurantConstants.SIGNAL[2])) {
            restaurantDetails.networkStrength = RestaurantDetails.NetworkStrength.Poor;
        }

        if (deliverfood.equals(RegisterRestaurantConstants.DELIVERFOOD[0])) {
            restaurantDetails.foodDeilvery = true;
        } else if (deliverfood.equals(RegisterRestaurantConstants.DELIVERFOOD[1])) {
            restaurantDetails.foodDeilvery = false;
        }

        restaurantDetails.deliveredBy = deliveredBy;

        if (TextUtils.isEmpty(deliverwithin)) {
            restaurantDetails.deliverWithin = 0;
        } else {
            try {
                restaurantDetails.deliverWithin = Double.parseDouble(deliverwithin);
            } catch (Exception e) {
                // TODO: handle exception
                restaurantDetails.deliverWithin = 0;
            }
        }

        if (TextUtils.isEmpty(deliveraround)) {
            restaurantDetails.deliverAround = 0;
        } else {
            try {
                restaurantDetails.deliverAround = Double.parseDouble(deliveraround);
            } catch (Exception e) {
                // TODO: handle exception
                restaurantDetails.deliverAround = 0;
            }

        }

        // Longitude and Latitude should be from mobile GPS
        restaurantDetails.location = new com.example.test.Location();
        if (location != null && location.getLatitude() != 0.0 && location.getLongitude() != 0.0) {
            restaurantDetails.location.setLatitude(location.getLatitude() + "");
            restaurantDetails.location.setLongitude(location.getLongitude() + "");
        } else {
            restaurantDetails.location.setLatitude("0.0");
            restaurantDetails.location.setLongitude("0.0");
        }

        Toast.makeText(Restaurant_Environment.this,
                "Submiting Restaurant for" + "\n Longitude:" + restaurantDetails.location.getLongitude()
                        + "\n Latitude: " + restaurantDetails.location.getLatitude(),
                Toast.LENGTH_SHORT).show();

        if (isUpdateRestaurant && !TextUtils.isEmpty(sid)) {
            restaurantDetails.sid = sid;
        }

        // Call AsyncTask for add / update restarant
        new AddRestautantDetails().execute(restaurantDetails);

    }

    public class AddRestautantDetails extends AsyncTask<RestaurantDetails, Void, Integer> {

        @Override
        protected Integer doInBackground(RestaurantDetails... params) {
            // TODO Auto-generated method stub
            RestaurantDetails restaurantDetails = params[0];
            ObjectMapper m = new ObjectMapper();
            try {
                HttpRequest httpRequest = null;

				/*
                 * If flag is of update. Update it using put request or else
				 * using post for add restaurant case
				 */
                if (isUpdateRestaurant) {
                    httpRequest = HttpRequest.put(URLConstants.PLACES_DETAILS).contentType("application/json")
                            .json(m.writeValueAsString(restaurantDetails));
                } else {
                    httpRequest = HttpRequest.post(URLConstants.PLACES_DETAILS).contentType("application/json")
                            .json(m.writeValueAsString(restaurantDetails));
                }

                String response = httpRequest.body();
                Log.i("anisha Response", response);
                int responseCode = httpRequest.code();
                Log.i("anisha Response Code", "" + responseCode);
                return responseCode;
            } catch (JsonGenerationException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (JsonMappingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (HttpRequestException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return 0;
        }

        @Override
        protected void onPostExecute(Integer result) {
            // TODO Auto-generated method stub
            if (progressBarHelper != null) {
                progressBarHelper.dismissProgressBar();
            }
            if (result == 200) {
                restaurantProfilePics = new LinkedList<String>();
                restaurantMenuPics = new LinkedList<String>();
                restaurantMenuPicsBitmap = new LinkedList<Bitmap>();
                linkedHashMapProfilePics = new LinkedHashMap<String, String>();
                linkedHashMapMenuPics = new LinkedHashMap<String, String>();
                finish();
            } else {
                Toast.makeText(Restaurant_Environment.this, "Server Unavailable. Please have patience", Toast.LENGTH_SHORT).show();
                // finish();
            }

        }

    }

    public String getStringImage(Bitmap bmp) {

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bmp.compress(CompressFormat.JPEG, 75, bos);
        byte[] data = bos.toByteArray();
        String encodedImage = Base64.encodeToString(data, Base64.DEFAULT);
        return encodedImage;
    }

    private void showFileChooser() {

        Intent intent1 = new Intent(Constants.ACTION_MULTIPLE_PICK);
        startActivityForResult(intent1, PICK_IMAGE_REQUEST);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
                showDialog = true;
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");

                Uri uri = getImageUri(Restaurant_Environment.this, imageBitmap);
                String restaurantpicPath = getStoragePath(uri);

                while (!restaurantProfilePics.isEmpty()) {
                    restaurantProfilePics.remove();
                }
                restaurantProfilePics.add(restaurantpicPath);

                imageBitmap = imageBitmap.createScaledBitmap(imageBitmap, 350, 350, true);

                restaurantpic.setImageBitmap(imageBitmap);

            } else if (requestCode == REQUEST_IMAGE_MENU_CAPTURE && resultCode == RESULT_OK) {
                showDialog = true;
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                Uri uri = getImageUri(Restaurant_Environment.this, imageBitmap);
                String restaurantMenuPath = getStoragePath(uri);
                restaurantMenuPics.add(restaurantMenuPath);
                imageBitmap = imageBitmap.createScaledBitmap(imageBitmap, 350, 350, true);
                restaurantMenuPicsBitmap.add(imageBitmap);
                // expandableListAdapter.addImageViewString(restaurantMenuPics);
                // expandableListAdapter.updateMenuPictureBitmap(restaurantMenuPicsBitmap);
                // expandableListAdapter.notifyDataSetChanged();

                // camera.setVisibility(View.VISIBLE);

                horizontalScrollView.setVisibility(View.GONE);
                horizontalScrollView.setVisibility(View.VISIBLE);
                // if (restaurantMenuPicsBitmap != null &&
                // restaurantMenuPicsBitmap.size() > 0) {
                // final int totalSize = restaurantMenuPicsBitmap.size();
                // for (int i = 0; i < totalSize; i++) {
                final Bitmap bitMap = imageBitmap;
                ImageView imageViewMenuPics = new ImageView(this);
                imageViewMenuPics.setPadding(2, 2, 2, 2);
                imageViewMenuPics.setImageBitmap(bitMap);
                imageViewMenuPics.setScaleType(ScaleType.FIT_XY);
                layout.addView(imageViewMenuPics);
                imageViewMenuPics.setOnLongClickListener(new OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        // TODO Auto-generated method stub
                        selectedImageView = v;
                        bitmapToRemove = bitMap;
                        return false;
                    }
                });
                horizontalScrollView.invalidate();
                horizontalScrollView.requestLayout();
                // }
                // //
                // }
            }
        } catch (

                Exception e)

        {

            // TODO: handle exception
        }

    }

    private void showLatestPictures() {
        LinearLayout layout = (LinearLayout) horizontalScrollView.findViewById(R.id.linear);
        if (restaurantMenuPicsBitmap != null && restaurantMenuPicsBitmap.size() > 0) {
            final int totalSize = restaurantMenuPicsBitmap.size();
            for (int i = 0; i < totalSize; i++) {
                final Bitmap bitMap = restaurantMenuPicsBitmap.get(i);
                ImageView imageViewMenuPics = new ImageView(this);
                imageViewMenuPics.setPadding(2, 2, 2, 2);
                imageViewMenuPics.setImageBitmap(bitMap);
                imageViewMenuPics.setScaleType(ScaleType.FIT_XY);
                layout.addView(imageViewMenuPics);
                imageViewMenuPics.setOnLongClickListener(new OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        // TODO Auto-generated method stub
                        selectedImageView = v;
                        bitmapToRemove = bitMap;
                        return false;
                    }
                });
            }
            //
        }

        if (restaurantMenuPicsFromServer != null && restaurantMenuPicsFromServer.size() > 0) {
            for (final String imageURL : restaurantMenuPicsFromServer) {
                ImageView imageViewMenuPics = new ImageView(Restaurant_Environment.this);
                imageViewMenuPics.setPadding(2, 2, 2, 2);
                if (TextUtils.isEmpty(imageURL)) {
                    Picasso.with(Restaurant_Environment.this).load(R.drawable.restaurantpic).into(imageViewMenuPics);
                } else {
                    Picasso.with(Restaurant_Environment.this).load(imageURL).resize(350, 350).error(R.drawable.no_media)
                            .into(imageViewMenuPics);
                }
                imageViewMenuPics.setScaleType(ScaleType.FIT_XY);
                layout.addView(imageViewMenuPics);
                imageViewMenuPics.setOnLongClickListener(new OnLongClickListener() {

                    @Override
                    public boolean onLongClick(View v) {
                        // TODO Auto-generated method stub
                        selectedImageView = v;
                        URLToRemove = imageURL;
                        return false;
                    }
                });
            }
        }
    }

    protected void gotTOGalleryActivity() {
        showFileChooser();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch (id) {
            case R.id.action_logout:
                Editor editor = sharedPreference.edit();
                editor.putBoolean("isLoggedIn", false);
                editor.commit();
                Intent intent = new Intent(Restaurant_Environment.this, MainActivity.class);
                startActivity(intent);
                finish();
                break;

            case R.id.action_save:
                saveRestaurantDetailsOnBackPress();
                break;

            case android.R.id.home:
                if (compareData() == true) {
                    super.onBackPressed();
                } else {
                    saveRestaurantDetailsOnBackPress();
                }
                break;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        saveRestaurantDetailsOnBackPress();
    }

    private boolean isEmpty(String str) {
        if (str == null || str.length() == 0 || str.trim().equals("null"))
            return true;
        else
            return false;
    }

//    private boolean compareParticularSpinnerData(String serverDataSpinnerString, String spinnerString) {
//        if (isEmpty(serverDataSpinnerString)) {
//            serverDataSpinnerString = "";
//        }
//
//        if (isEmpty(spinnerString)) {
//            spinnerString = "";
//        }
//
//        if (!isEmpty(serverDataSpinnerString)) {
//            serverDataSpinnerString = serverDataSpinnerString.trim();
//        }
//
//        if (!isEmpty(spinnerString)) {
//            spinnerString = spinnerString.trim();
//        }
//
//        Log.i("anisha", "Server Value: " + serverDataSpinnerString + " EditText Value: " + spinnerString);
//        if (isEmpty(serverDataSpinnerString) && isEmpty(spinnerString)) {
//            return true;
//        }
//
//        if (serverDataSpinnerString.equals(spinnerString)) {
//            return true;
//        }
//        return false;
//    }

    private boolean compareParticularData(String serverDataString, String editTextString) {
        if (isEmpty(serverDataString)) {
            serverDataString = "";
        }

        if (isEmpty(editTextString)) {
            editTextString = "";
        }

        if (!isEmpty(serverDataString)) {
            serverDataString = serverDataString.trim();
        }

        if (!isEmpty(editTextString)) {
            editTextString = editTextString.trim();
        }

        Log.i("anisha", "Server Value: " + serverDataString + " EditText Value: " + editTextString);
        if (isEmpty(serverDataString) && isEmpty(editTextString)) {
            return true;
        }

        if (serverDataString.equals(editTextString)) {
            return true;
        }
        return false;
    }

    private boolean showDialogBecauseOfPicture() {
        return !showDialog;
    }

    private boolean compareData() {
        String nameString = this.nameEditText.getText().toString();
        String descriptionString = this.descriptionEditText.getText().toString();
//      String ownerNameString = this.ownernameEditText.getText().toString();
        String ownerEmailString = this.owneridEditText.getText().toString();
        String ownerPhoneNoString = this.ownerphonenoEditText.getText().toString();
//        String establishMentTypeString = this.establishMentTypeSpinner.toString();

        String numberOfTablesString = this.tablesEditText.getText().toString();
        String numberOfWaitersString = this.waitersEditText.getText().toString();
        String deliverTimeString = this.deliveryhourEditText.getText().toString();
        String deliverDistanceString = this.deliverykmEditText.getText().toString();

        String wifiavailable = "";
        if (this.wifiavailableSpinner.getItemAtPosition(this.wifiavailableSpinner.getSelectedItemPosition()) != null
                && !TextUtils.isEmpty(this.wifiavailableSpinner
                .getItemAtPosition(this.wifiavailableSpinner.getSelectedItemPosition()).toString())) {
            wifiavailable = this.wifiavailableSpinner
                    .getItemAtPosition(this.wifiavailableSpinner.getSelectedItemPosition()).toString();
        }

        String signalstrength = "";
        if (this.signalStrengthSpinner.getItemAtPosition(this.signalStrengthSpinner.getSelectedItemPosition()) != null
                && !TextUtils.isEmpty(this.signalStrengthSpinner
                .getItemAtPosition(this.signalStrengthSpinner.getSelectedItemPosition()).toString())) {
            signalstrength = this.signalStrengthSpinner
                    .getItemAtPosition(this.signalStrengthSpinner.getSelectedItemPosition()).toString();
        }

        String deliverfood = "";
        if (this.deliverFoodSpinner.getItemAtPosition(this.deliverFoodSpinner.getSelectedItemPosition()) != null
                && !TextUtils.isEmpty(this.deliverFoodSpinner
                .getItemAtPosition(this.deliverFoodSpinner.getSelectedItemPosition()).toString())) {
            deliverfood = this.deliverFoodSpinner.getItemAtPosition(this.deliverFoodSpinner.getSelectedItemPosition())
                    .toString();
        }

        String deliveredBy = "";
        if (this.deliveredBySpinner.getItemAtPosition(this.deliveredBySpinner.getSelectedItemPosition()) != null && !TextUtils
                .isEmpty(this.deliveredBySpinner.getItemAtPosition(this.deliveredBySpinner.getSelectedItemPosition()).toString())) {
            deliveredBy = this.deliveredBySpinner.getItemAtPosition(this.deliveredBySpinner.getSelectedItemPosition()).toString();
        }

        if (wifiavailable.equals(RegisterRestaurantConstants.WIFIAVAILABLE[0])) {
            wifiavailable = "true";
        } else if (wifiavailable.equals(RegisterRestaurantConstants.WIFIAVAILABLE[1])) {
            wifiavailable = "false";
        }

        if (signalstrength.equals(RegisterRestaurantConstants.SIGNAL[0])) {
            signalstrength = "Excellent";
        } else if (signalstrength.equals(RegisterRestaurantConstants.SIGNAL[1])) {
            signalstrength = "Moderate";
        } else if (signalstrength.equals(RegisterRestaurantConstants.SIGNAL[2])) {
            signalstrength = "Poor";
        }

        if (deliverfood.equals(RegisterRestaurantConstants.DELIVERFOOD[0])) {
            deliverfood = "true";
        } else if (deliverfood.equals(RegisterRestaurantConstants.DELIVERFOOD[1])) {
            deliverfood = "false";
        }


        // Write similar check for rest of the strings

        if (compareParticularData(name, nameString) && compareParticularData(description, descriptionString) &&
                compareParticularData(emailId, ownerEmailString) && compareParticularData(phoneNumber, ownerPhoneNoString) &&
                compareParticularData(nooftable, numberOfTablesString) && compareParticularData(noofwaiter, numberOfWaitersString) &&
                compareParticularData(wifiavailable, wifiAvailable)
                && compareParticularData(signalstrength, networkStrength) && compareParticularData(deliverfood, foodDeilvery)
                && compareParticularData(deliveredBy, deliverby) &&
                compareParticularData(deliveryTime, deliverTimeString) && compareParticularData(deliverydistance, deliverDistanceString)
                && showDialogBecauseOfPicture()) {
            return true;
        } else {
            return false;
        }
    }

    private void saveRestaurantDetailsOnBackPress() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Restaurant_Environment.this);
        // set title
        alertDialogBuilder.setTitle(getString(R.string.app_name));
        // set icon
        alertDialogBuilder.setIcon(R.drawable.thirtysix);
        // set dialog message
        alertDialogBuilder.setMessage(getString(R.string.save_alert_message)).setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, close
                        // current activity
                        uploadPicturesAndSubmit();
                        dialog.cancel();


                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // if this button is clicked, just close
                // the dialog box and do nothing
                dialog.cancel();
                finish();
            }
        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCancelable(true);
        // show it
        alertDialog.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        // TODO Auto-generated method stub
        menu.add(0, 0, 0, "Remove the selected picture ?");
//        menu.add(0, 1, 1, "Remove all menu pictures ?");
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        // TODO Auto-generated method stub
        int itemId = item.getItemId();

        switch (itemId) {
            case 0:
                removeOnlySelectedMenuPicture();
                break;
            case 1:
                removeAllMenuPictures();
                restaurantMenuPicsBitmap = new LinkedList<Bitmap>();
                restaurantMenuPicsFromServer = new LinkedList<String>();
                restaurantMenuPics = new LinkedList<String>();
                linkedHashMapMenuPics = new LinkedHashMap<String, String>();
                break;
            default:
                break;
        }
        return super.onContextItemSelected(item);
    }

    public static InputFilter alphaFilter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            String blockCharacterSet = "0123456789*-+.=-_)(&^%$#@!~`{}[]|;:'<>/?";
            if (source != null && blockCharacterSet.contains(("" + source))) {
                return "";
            }
            return null;
        }
    };

    public void changedDataSets(final LinkedList<Bitmap> restaurantMenuPicsBitmap2,
                                final LinkedList<String> restaurantMenuPicsFromServer2, final Bitmap imageBitmap,
                                final String URLToRemove) {
        // TODO Auto-generated method stub
        restaurantMenuPicsBitmap = restaurantMenuPicsBitmap2;
        restaurantMenuPicsFromServer = restaurantMenuPicsFromServer2;

        if (URLToRemove != null) {
            if (linkedHashMapMenuPics != null & linkedHashMapMenuPics.size() > 0) {
                Set<String> menuPics = linkedHashMapMenuPics.keySet();
                for (String string : menuPics) {
                    if (URLToRemove.equalsIgnoreCase("http://130.211.255.181/places-impl-web/rest/attachment/images/"
                            + linkedHashMapMenuPics.get(string) + "?timestamp=" + string)) {
                        linkedHashMapMenuPics.remove(string);
                        break;
                    }
                }
            }
        }

        if (imageBitmap != null && restaurantMenuPics != null && restaurantMenuPics.size() > 0) {
            Uri uri = getImageUri(Restaurant_Environment.this, imageBitmap);
            String restaurantMenuPath = getStoragePath(uri);
            restaurantMenuPics.remove(restaurantMenuPath);
        }

        if (restaurantMenuPicsBitmap == null || restaurantMenuPicsBitmap.size() <= 0) {
            restaurantMenuPics = new LinkedList<String>();
        }
    }

    public void removeAllViews() {
        if (horizontalScrollView != null) {
            ViewGroup parentLayout = (ViewGroup) horizontalScrollView.getChildAt(0);

            if (parentLayout.getChildCount() > 0) {
                for (int i = 0; i < parentLayout.getChildCount(); i++) {
                    parentLayout.removeView(parentLayout.getChildAt(i));
                }
            }
        }
        horizontalScrollView.removeAllViews();
        horizontalScrollView.invalidate();
        horizontalScrollView.requestLayout();
    }

    public void removeAllMenuPictures() {
        if (horizontalScrollView != null) {
            ViewGroup parentLayout = (ViewGroup) horizontalScrollView.getChildAt(0);

            if (parentLayout.getChildCount() > 0) {
                for (int i = 0; i < parentLayout.getChildCount(); i++) {
                    parentLayout.removeView(parentLayout.getChildAt(i));
                }
            }
        }
        restaurantMenuPicsBitmap = new LinkedList<Bitmap>();
        restaurantMenuPicsFromServer = new LinkedList<String>();
        horizontalScrollView.removeAllViewsInLayout();
        horizontalScrollView.invalidate();
        horizontalScrollView.requestLayout();
    }

    /**
     * It will remove only the selected image from the Menu Picture Gallery
     */
    public void removeOnlySelectedMenuPicture() {
        if (horizontalScrollView != null) {
            ViewGroup parentLayout = (ViewGroup) horizontalScrollView.getChildAt(0);

            if (parentLayout.getChildCount() > 0) {
                for (int i = 0; i < parentLayout.getChildCount(); i++) {
                    if (selectedImageView.equals(parentLayout.getChildAt(i))) {
                        parentLayout.removeView(parentLayout.getChildAt(i));
                    }

                }
            }
        }

        if (bitmapToRemove != null) {
            restaurantMenuPicsBitmap.remove(bitmapToRemove);
        } else if (URLToRemove != null) {
            restaurantMenuPicsFromServer.remove(URLToRemove);
        }

        ((Restaurant_Environment) this).changedDataSets(restaurantMenuPicsBitmap, restaurantMenuPicsFromServer,
                bitmapToRemove, URLToRemove);

        bitmapToRemove = null;
        URLToRemove = null;
    }

    /**
     * This method will update the Menu picture Bitmap
     *
     * @param bitmaps
     */
    public void updateMenuPictureBitmap(LinkedList<Bitmap> bitmaps) {
        restaurantMenuPicsBitmap = bitmaps;
        // notifyDataSetChanged();
    }
}
