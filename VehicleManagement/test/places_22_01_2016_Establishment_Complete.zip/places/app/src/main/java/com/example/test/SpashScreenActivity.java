package com.example.test;

import java.util.List;

import com.restuarant.utils.CommonUtils;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

public class SpashScreenActivity extends Activity {
	private static int SPLASH_TIME_OUT = 5000;
	private Handler mHandler;
	private ProgressBar mProgressBarLoading;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_screen);

		Intent service = new Intent(SpashScreenActivity.this, AppLocationService.class);
		startService(service);
		startAnimation();
	}

	private void startAnimation() {
		Animation anim = AnimationUtils.loadAnimation(this, R.anim.alpha);
		anim.reset();
		RelativeLayout l = (RelativeLayout) findViewById(R.id.splashScreen);
		l.clearAnimation();
		l.startAnimation(anim);
		anim = AnimationUtils.loadAnimation(this, R.anim.tranlate);
		anim.reset();
		/*
		 * TextView iv = (TextView) findViewById(R.id.splashName);
		 * iv.clearAnimation(); iv.startAnimation(anim);
		 */
		launchLoginScreen();
	}

	private void launchLoginScreen() {
		// TODO Auto-generated method stub
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				Intent intent = new Intent(SpashScreenActivity.this, MainActivity.class);
				startActivity(intent);
				finish();
				// TODO Auto-generated method stub

			}
		}, SPLASH_TIME_OUT);
	}

}
