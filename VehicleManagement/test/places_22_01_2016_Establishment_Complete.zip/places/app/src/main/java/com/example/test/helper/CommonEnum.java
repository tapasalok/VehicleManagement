package com.example.test.helper;

/**
 * Created by anisha on 28/10/15.
 */
public class CommonEnum {
    public enum RequestMethod{
        GET,PUT,POST,DELETE,UPDATE,PATCH
    }
    public RequestMethod method;
}
