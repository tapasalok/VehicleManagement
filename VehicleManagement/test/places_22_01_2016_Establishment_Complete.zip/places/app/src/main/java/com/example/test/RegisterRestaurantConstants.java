package com.example.test;

public interface RegisterRestaurantConstants {
    //	public static final String[] SPINNER_PROMPT_TITLES = { "Type of Establishment ?", "Wifi Availablity ?",
//			"Mobile Signal Strengh:", "Do they deliver food ?", "Delivered By:" };
    String[] ESTABLISHMENT = {"Dine In", "Buffet", "Take Away", "QSR"};
    String[] ESTABLISHMENTACTUAL = {"DineIn", "Buffet", "TakeAway", "QSR"};
    String[] WIFIAVAILABLE = {"Yes", "No"};
    String[] WIFIAVAILABLESERVER = {"true", "false"};
    String[] SIGNAL = {"Excellent", "Moderate", "Poor"};
    String[] DELIVERFOOD = {"Yes", "No"};
    String[] DELIVERFOODSERVER = {"true", "false"};
    String[] DELIVEREDBY = {"Restaurant", "third party"};

}