package com.example.test.helper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by vikash on 28/10/15.
 */
public class HttpCall {

    public static String getGetUrl(String url, List<NameValuePair> pairList) {
        if (pairList != null && pairList.size() != 0) {
            for (NameValuePair param : pairList) {
                url = url.replace(addSpecialSymbole(param.getKeyName()), param.getValueName());
            }
        }
        return url;
    }

    private static String addSpecialSymbole(String key) {
        return URLConstants.OPEN_BRASSICAS.concat(key).concat(URLConstants.CLOSE_BRASSICAS);
    }

}
