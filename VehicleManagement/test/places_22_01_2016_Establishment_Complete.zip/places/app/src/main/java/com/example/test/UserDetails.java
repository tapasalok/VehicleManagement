package com.example.test;

import java.io.Serializable;

public class UserDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3598182390685435138L;
	public  String emailId;
	
	public String password;
	
	public String deviceId;
	
	public String deviceType;
	
	public String deviceName;
	
	public String mobileId;
}
