package com.example.test.helper;

/**
 * Created by root on 26/11/15.
 */
public interface ICallBack {
    public void processResponse(String key, String response);
}
