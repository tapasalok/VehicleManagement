package com.example.test.helper;

public interface Constants {

	String ACTION_MULTIPLE_PICK = "luminous.ACTION_MULTIPLE_PICK";

}
