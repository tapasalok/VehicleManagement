package com.example.test;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.test.helper.HttpRequest;
import com.example.test.helper.HttpRequest.HttpRequestException;
import com.example.test.helper.URLConstants;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.restuarant.utils.ProgressBarHelper;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;

public class MainActivity extends FragmentActivity implements OnClickListener,
        OnConnectionFailedListener {
    private static final int RC_SIGN_IN = 200;
    private Button button;
    private EditText email;
    private EditText password;
    private ProgressBarHelper progressBarHelper;
    private SignInButton signInButton;

    private GoogleApiClient mGoogleApiClient;
    private SharedPreferences sharedPreference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreference = getSharedPreferences("common_preference",
                Activity.MODE_PRIVATE);

        if (sharedPreference != null && sharedPreference.contains("isLoggedIn")) {
            if (sharedPreference.getBoolean("isLoggedIn", false)) {
                Intent intent = new Intent(MainActivity.this,
                        HomeActivity.class);
                startActivity(intent);
                finish();
            }
        }

        email = (EditText) findViewById(R.id.emailid1);
        password = (EditText) findViewById(R.id.password1);
        signInButton = (SignInButton) findViewById(R.id.sign_in_button);

        progressBarHelper = ProgressBarHelper.getSingletonInstance();
        button = (Button) findViewById(R.id.button);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
        signInButton.setColorScheme(SignInButton.COLOR_LIGHT);

        signInButton.setOnClickListener(this);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(
                GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();

        mGoogleApiClient = new GoogleApiClient.Builder(MainActivity.this)
                .enableAutoManage(this /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso).build();

        email.setText("vikash@bci.com");
        password.setText("test1234");

        OnClickListener l = new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                UserDetails userDetails = new UserDetails();

                if (TextUtils.isEmpty(email.getText())
                        && TextUtils.isEmpty(password.getText())) {
                    Toast.makeText(MainActivity.this,
                            "Please enter Email Id and Password.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(email.getText())) {
                    Toast.makeText(MainActivity.this, "Please enter Email Id.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password.getText())) {
                    Toast.makeText(MainActivity.this, "Please enter Password.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                userDetails.emailId = email.getText().toString();
                userDetails.password = password.getText().toString();
                userDetails.deviceId = "123";
                userDetails.mobileId = "xyz123";
                userDetails.deviceType = "ANDROID";
                userDetails.deviceName = "Lenovo";

//                Editor editor = sharedPreference.edit();
//                editor.putBoolean("isLoggedIn", true);
//                editor.commit();
//
//                Intent intent = new Intent(MainActivity.this,
//                        HomeActivity.class);
//                startActivity(intent);
//                finish();

				new Login().execute(userDetails);

            }

        };
        button.setOnClickListener(l);
    }

	/*
     * @Override public boolean onCreateOptionsMenu(Menu menu) { // Inflate the
	 * menu; this adds items to the action bar if it is present.
	 * getMenuInflater().inflate(R.menu.main, menu); return true; }
	 */

    public class Login extends AsyncTask<UserDetails, Void, Integer> {

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            progressBarHelper.showProgressBarSmall(
                    "Please wait...Logging in...", false, MainActivity.this);
            super.onPreExecute();
        }

        @Override
        protected Integer doInBackground(UserDetails... params) {
            // TODO Auto-generated method stub
            UserDetails userDetails = params[0];
            ObjectMapper m = new ObjectMapper();
            try {
                String response = HttpRequest.post(URLConstants.APP_LOGIN)
                        .contentType("application/json")
                        .json(m.writeValueAsString(userDetails)).body();
                Log.i("response ", response);
                int responseCode = HttpRequest.post(URLConstants.APP_LOGIN)
                        .contentType("application/json")
                        .json(m.writeValueAsString(userDetails)).code();

                return responseCode;
            } catch (JsonGenerationException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (JsonMappingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (HttpRequestException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return 0;
        }

        @Override
        protected void onPostExecute(Integer result) {
            // TODO Auto-generated method stub
            progressBarHelper.dismissProgressBar();

            if (result == 200) {

                Editor editor = sharedPreference.edit();
                editor.putBoolean("isLoggedIn", true);
                editor.commit();

                Intent intent = new Intent(MainActivity.this,
                        HomeActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(MainActivity.this,
                        "Please enter correct credentials", Toast.LENGTH_SHORT).show();
            }
        }

    }

    @Override
    public void onClick(View view) {
        // TODO Auto-generated method stub
        switch (view.getId()) {
            case R.id.sign_in_button:
                signIn();
                break;
            // ...
        }

    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi
                .getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from
        // GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi
                    .getSignInResultFromIntent(data);
            handleSignInResult(result);
        }
    }

    private void handleSignInResult(GoogleSignInResult result) {
        String string = result.getStatus().getStatusMessage();
        if (result.isSuccess()) {
            // Signed in successfully, show authenticated UI.
            GoogleSignInAccount acct = result.getSignInAccount();
            // mStatusTextView.setText(getString(R.string.signed_in_fmt,
            // acct.getDisplayName()));
            // updateUI(true);

            Editor editor = sharedPreference.edit();
            editor.putBoolean("isLoggedIn", true);
            editor.commit();

            Toast.makeText(MainActivity.this,
                    "Welcome:" + result.getSignInAccount().getDisplayName(), Toast.LENGTH_SHORT)
                    .show();
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        } else {
            // Signed out, show unauthenticated UI.
            // updateUI(false);
            Toast.makeText(
                    MainActivity.this,
                    "Some Problem with Google Plus Login. You can also use the other Login",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onConnectionFailed(ConnectionResult arg0) {
        // TODO Auto-generated method stub

    }

}
