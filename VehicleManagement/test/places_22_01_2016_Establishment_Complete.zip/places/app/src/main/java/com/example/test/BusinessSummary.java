package com.example.test;

import java.io.Serializable;

public class BusinessSummary implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3598182390685435138L;

	private String description;

	private String name;

	private String photoUrl;

	private String sid;

	private Location location;
	private String ownerName;
	private String emailId;
	private String phoneNo;
//	private String pinNo;
	private String nooftable;
	private String noofwaiter;
	private String typeofestablishment;
	private String wifiavailable;
	private String signalstrenth;
	private String deliverfood;
	private String deliverby;
	private String deliverytime;
	private String deliveydistance;
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhotoUrl() {
		return photoUrl;
	}

	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getNooftable() {
		return nooftable;
	}

	public void setNooftable(String nooftable) {
		this.nooftable = nooftable;
	}

	public String getNoofwaiter() {
		return noofwaiter;
	}

	public void setNoofwaiter(String noofwaiter) {
		this.noofwaiter = noofwaiter;
	}

	public String getTypeofestablishment() {
		return typeofestablishment;
	}

	public void setTypeofestablishment(String typeofestablishment) {
		this.typeofestablishment = typeofestablishment;
	}

	public String getWifiavailable() {
		return wifiavailable;
	}

	public void setWifiavailable(String wifiavailable) {
		this.wifiavailable = wifiavailable;
	}

	public String getSignalstrenth() {
		return signalstrenth;
	}

	public void setSignalstrenth(String signalstrenth) {
		this.signalstrenth = signalstrenth;
	}

	public String getDeliverfood() {
		return deliverfood;
	}

	public void setDeliverfood(String deliverfood) {
		this.deliverfood = deliverfood;
	}

	public String getDeliverby() {
		return deliverby;
	}

	public void setDeliverby(String deliverby) {
		this.deliverby = deliverby;
	}

	public String getDeliverytime() {
		return deliverytime;
	}

	public void setDeliverytime(String deliverytime) {
		this.deliverytime = deliverytime;
	}

	public String getDeliveydistance() {
		return deliveydistance;
	}

	public void setDeliveydistance(String deliveydistance) {
		this.deliveydistance = deliveydistance;
	}

	
}
