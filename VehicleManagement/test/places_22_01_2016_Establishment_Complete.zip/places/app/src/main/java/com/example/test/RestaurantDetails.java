package com.example.test;

import java.io.Serializable;

public class RestaurantDetails implements Serializable {
	/**
	 * 
	 */

	enum EstablishMentType {
		DineIn, Buffet, TakeAway, QSR
	}

	enum NetworkStrength {
		Excellent, Moderate, Poor
	}

	private static final long serialVersionUID = -3598182390685435138L;
	public String name;
	public String description;
	public String ownerName;

	public String ownerEmail;
	public String photoUrl;
	public String[] menus;
	public String ownerPhoneNo;
	public String numberOfTables;
	public String numberOfWaiters;
	public EstablishMentType establishMentType;
	public boolean wifiAvailable;
	public NetworkStrength networkStrength;
	public boolean foodDeilvery;
	public String deliveredBy;
	public double deliverWithin;
	public double deliverAround;
	public Location location = new Location();
	public String sid;
}
