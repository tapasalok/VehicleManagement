package com.example.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

public class ExpandableListDataPump {
	public static HashMap<String, List<String>> getData() {
		HashMap<String, List<String>> expandableListDetail = new LinkedHashMap<String, List<String>>();

		List<String> OwnersInfo = new ArrayList<String>();
		OwnersInfo.add("Name");
		OwnersInfo.add("Email Id");
		OwnersInfo.add("Phone no");
//		OwnersInfo.add("Address*");
//		OwnersInfo.add("City*");
//		OwnersInfo.add("PinCode*");

		List<String> RestaurantEnvironment = new ArrayList<String>();
		RestaurantEnvironment.add("No of Tables");
		RestaurantEnvironment.add("No of Waiters");
		RestaurantEnvironment.add("Type of Establishment");
		RestaurantEnvironment.add("Wifi Availability?");
		RestaurantEnvironment.add("Mobile Signal Strenth");

		List<String> HomeDeliveryFacility = new ArrayList<String>();
		HomeDeliveryFacility.add("Do they Deliver Food?");
		HomeDeliveryFacility.add("Delivered By?");
		HomeDeliveryFacility.add("Delivery Time(in hour)");
		HomeDeliveryFacility.add("Delivery Distance(in km)");

		List<String> menu = new ArrayList<String>();
		menu.add("Camera");
		menu.add("ScrollViewImage");
		expandableListDetail.put("Owners Info", OwnersInfo);
		expandableListDetail.put("Restaurant Environment", RestaurantEnvironment);
		expandableListDetail.put("Home Delivery Facility", HomeDeliveryFacility);
		expandableListDetail.put("Menu", menu);
		return expandableListDetail;
	}
}
