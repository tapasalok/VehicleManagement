package com.example.test.helper;

import java.util.List;
import java.util.Map;

/**
 * Created by root on 26/11/15.
 */
public class AsyncCommon {

    public enum RequestType {
        PUT, POST, GET, DELETE, SUBSCRIBE
    }

    private RequestType requestType;

    private String url;

    private Object requestObject;

    private Map<String, String> headers;

    private List<String> pathParams;

    public RequestType getRequestType() {
        return requestType;
    }

    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Object getRequestObject() {
        return requestObject;
    }

    public void setRequestObject(Object requestObject) {
        this.requestObject = requestObject;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public List<String> getPathParams() {
        return pathParams;
    }

    public void setPathParams(List<String> pathParams) {
        this.pathParams = pathParams;
    }
}
