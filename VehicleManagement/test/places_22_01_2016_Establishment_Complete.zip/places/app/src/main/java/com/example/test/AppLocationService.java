package com.example.test;

import java.util.List;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;

public class AppLocationService extends Service implements LocationListener {

	protected static LocationManager locationManager;
	private static Location newLocation;

	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);

		Thread thread = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				Looper.prepare();
				locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
				String provider = LocationManager.GPS_PROVIDER;
				List<String> providers = locationManager.getAllProviders();
				Location bestLocation = null;
				for (String it : providers) {
					Location location = locationManager.getLastKnownLocation(it);
					if (location != null) {
						newLocation = location;
						if (bestLocation == null || location.getAccuracy() < bestLocation.getAccuracy()) {
							bestLocation = location;
							provider = it;
						}
					}
				}

				locationManager.requestLocationUpdates(provider, 0, 0, AppLocationService.this);
				Looper.loop();
			}
		});
		thread.start();

	}

	@Override
	public void onLocationChanged(Location location1) {
		if (location1 != null) {
			newLocation = location1;
		}
	}

	@Override
	public void onProviderDisabled(String provider) {
	}

	@Override
	public void onProviderEnabled(String provider) {
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	public static Location getBestLastGeolocation(Context context) {
		locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
		List<String> providers = locationManager.getAllProviders();
		Location bestLocation = null;
		for (String it : providers) {
			Location location = locationManager.getLastKnownLocation(it);
			if (location != null) {
				if (bestLocation == null || location.getAccuracy() < bestLocation.getAccuracy()) {
					bestLocation = location;
				}
				newLocation = location;
			}
		}
		if (bestLocation !=null) {
			return bestLocation;
		} else {
			return newLocation;
		}
		
	}

	public static Location getLastBestLocation(Context context, int minDistance, long minTime) {
		Location bestLocation = null;
		float bestAccuracy = Float.MAX_VALUE;
		long bestTime = Long.MIN_VALUE;

		locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

		// Iterate through all the providers on the system, keeping
		// note of the most accurate result within the acceptable time limit.
		// If no result is found within maxTime, return the newest Location.
		List<String> matchingProviders = locationManager.getAllProviders();
		for (String provider : matchingProviders) {
			Location location = locationManager.getLastKnownLocation(provider);
			if (location != null) {
				float accuracy = location.getAccuracy();
				long time = location.getTime();
				
				if ((time > minTime && accuracy < bestAccuracy)) {
					bestLocation = location;
					bestAccuracy = accuracy;
					bestTime = time;
				} else if (time < minTime && bestAccuracy == Float.MAX_VALUE && time > bestTime) {
					bestLocation = location;
					bestTime = time;
				}
				newLocation = location;
			}
		}
		// If the best result is beyond the allowed time limit, or the accuracy
		// of the best result is wider than the acceptable maximum distance,
		// need
		// location update so return null.
//		if (bestTime < minTime || bestAccuracy > minDistance) {
//			return null;
//		}
		if (bestLocation !=null) {
			return bestLocation;
		} else {
			return newLocation;
		}
	}

}