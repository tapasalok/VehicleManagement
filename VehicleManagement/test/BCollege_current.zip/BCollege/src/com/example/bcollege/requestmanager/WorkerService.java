package com.example.bcollege.requestmanager;

import java.net.ConnectException;

import org.json.JSONException;

import android.content.Intent;
import android.os.Bundle;

import com.example.bcollege.worker.BaseWorker;
import com.example.bcollege.worker.BranchSemesterWorker;
import com.example.bcollege.worker.LoginRegisterWorker;

/**
 * This class is called by the {@link RequestManager} through the {@link Intent}
 * system. Get the parameters stored in the {@link Intent} and call the right
 * Worker.
 * 
 */
public class WorkerService extends BaseWorkerService {

	// TODO : Set the number of thread
	// Max number of parallel threads used
	private static final int MAX_THREADS = 3;

	// TODO : Set a numeric constant for each worker (to distinguish them).
	// These constants will be sent in the Intent in order to see which worker
	// to call
	// Worker types
	public static final int WORKER_TYPE_BRANCH = 1;
	public static final int WORKER_TYPE_LOGIN = 2;
	public static final int WORKER_TYPE_REGISTER = 3;
	public static final int WORKER_TYPE_FORGOTPASSOWRD = 4;
	public static final int WORKER_TYPE_SEMESTER = 5;
	public static final int WORKER_TYPE_SUBJECT = 6;
	public static final int WORKER_TYPE_CHAPTER = 7;
	public static final int WORKER_TYPE_SUB_CHAPTER = 8;
	public static final int WORKER_TYPE_DETAILS = 9;
	public static final int WORKER_TYPE_AUDIO = 10;
	public static final int WORKER_TYPE_POST_COMMENT = 11;
	public static final int WORKER_TYPE_POST_VIEWS = 12;
	// TODO : Set a string constants for each param to send to the worker. You
	// should use these constants in the Intent as extra name
	public static final String INTENT_EXTRA_RETURN_FORMAT = "com.bcollege.ematerial.ReturnFormat";
	public static final String INTENT_EXTRA_BUNDLE_DATA = "com.bcollege.ematerial.BundleData";

	private Bundle mBundle = new Bundle();

	public WorkerService() {
		super(MAX_THREADS);
	}

	@Override
	protected void onHandleIntent(final Intent intent) {
		final int workerType = intent.getIntExtra(INTENT_EXTRA_WORKER_TYPE, -1);
		mBundle.clear();
		try {
			switch (workerType) {
			case WORKER_TYPE_BRANCH:
				mBundle = BranchSemesterWorker.start(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;

			case WORKER_TYPE_SEMESTER:
				mBundle = BranchSemesterWorker.fetchSemester(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;

			case WORKER_TYPE_REGISTER:
				mBundle = LoginRegisterWorker.register(this, intent
						.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
								BaseWorker.DownloadFormat.RETURN_FORMAT_JSON),
						intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;

			case WORKER_TYPE_FORGOTPASSOWRD:
				mBundle = LoginRegisterWorker.forgotPassword(this, intent
						.getIntExtra(INTENT_EXTRA_RETURN_FORMAT,
								BaseWorker.DownloadFormat.RETURN_FORMAT_JSON),
						intent.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;

			case WORKER_TYPE_LOGIN:
				mBundle = LoginRegisterWorker.login(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			case WORKER_TYPE_SUBJECT:
				mBundle = BranchSemesterWorker.fetchSemesterWiseSubject(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			case WORKER_TYPE_CHAPTER:
				mBundle = BranchSemesterWorker.fetchChapterList(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			case WORKER_TYPE_SUB_CHAPTER:
				mBundle = BranchSemesterWorker.fetchSubChapterList(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			case WORKER_TYPE_DETAILS:
				mBundle = BranchSemesterWorker.fetchDetails(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			case WORKER_TYPE_AUDIO:
				mBundle = BranchSemesterWorker.fetchAudio(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			case WORKER_TYPE_POST_COMMENT:
				mBundle = BranchSemesterWorker.postComment(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			case WORKER_TYPE_POST_VIEWS:
				mBundle = BranchSemesterWorker.fetchPostViewrs(this, intent.getIntExtra(
						INTENT_EXTRA_RETURN_FORMAT,
						BaseWorker.DownloadFormat.RETURN_FORMAT_JSON), intent
						.getBundleExtra(INTENT_EXTRA_BUNDLE_DATA));
				sendSuccess(intent, mBundle);
				break;
			default:
				sendFailure(intent, null);
				break;
			}
			// This block (which should be the last one in your implementation)
			// will catch all the RuntimeException and send you back an error
			// that you can manage. If you remove this catch, the
			// RuntimeException will still crash the Service but you will not be
			// informed (as it is in 'background') so you should never remove
			// this catch
		} catch (final JSONException e) {
			sendDataFailure(intent, null);
		} catch (final ConnectException e) {
			sendConnectionFailure(intent, null);
		} catch (final Exception e) {
			sendFailure(intent, null);
		}
	}
}
