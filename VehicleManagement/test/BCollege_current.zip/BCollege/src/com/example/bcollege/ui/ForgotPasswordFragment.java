package com.example.bcollege.ui;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.requestmanager.WorkerService;
import com.example.bcollege.utils.DialogHelper;
import com.example.bcollege.utils.ProgressBarHelper;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class ForgotPasswordFragment extends BaseFragment implements
		OnRequestFinishedListener {
	private EditText emaiId, oldPassword, newPassword, confirmPassword;
	private Button register;
	private static byte mRequestType;
	private RequestManager mRequestManager;
	private Bundle mResponseBundle;
	private int mRequestId = -1;
	private int branchRequestId = -1;
	private Handler mHandler;
	private String responseMessage;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		mHandler = new Handler();

		mRequestManager = RequestManager.from(getActivity());
		mHandler = new Handler();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.fragment_forgotpassword,
				container, false);

		setHasOptionsMenu(true);
		initApp(view);
		return view;
	}

	private void initApp(final View view) {
		emaiId = (EditText) view.findViewById(R.id.email);
		oldPassword = (EditText) view.findViewById(R.id.oldPassword);
		newPassword = (EditText) view.findViewById(R.id.newPassword);
		// confirmPassword = (EditText) view.findViewById(R.id.confirmPassword);
		register = (Button) view.findViewById(R.id.setPassword);
		register.setOnClickListener(registerListener);

	}

	public OnClickListener registerListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			Bundle registerData = new Bundle();

			if (TextUtils.isEmpty(emaiId.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter EmailId");
//				Toast.makeText(getActivity(), "Please enter name", 0).show();
				return;
			}

			if (TextUtils.isEmpty(oldPassword.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter password");
//				Toast.makeText(getActivity(), "Please enter name", 0).show();
				return;
			}
			if (TextUtils.isEmpty(newPassword.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter new password");
//				Toast.makeText(getActivity(), "Please enter name", 0).show();
				return;
			}
			// if (TextUtils.isEmpty(confirmPassword.getText())) {
			// Toast.makeText(getActivity(), "Please enter name", 0).show();
			// return;
			// }

			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDEMAILID,
					emaiId.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.OPWD, oldPassword
					.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.NPWD, newPassword
					.getText().toString());
			mRequestManager
					.addOnRequestFinishedListener(ForgotPasswordFragment.this);
			mRequestType = WSConfig.FORGOT_PASSWORD;
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_forgot_please_wait, true, mHandler,
					getActivity());
			mRequestId = mRequestManager.forgotPassword(
					DownloadFormat.RETURN_FORMAT_JSON, registerData);

		}
	};

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(ForgotPasswordFragment.this);
			mRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			}
		}

	}

	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			responseMessage = mResponseBundle.getString(
					JSONTagConstants.RESPONSE_TAG_DATA);
			((BaseFragmentActivity) getActivity()).Toast(responseMessage);
//			Toast.makeText(getActivity(), responseMessage, 0).show();
			getActivity().finish();
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			responseMessage = mResponseBundle.getString(
					JSONTagConstants.RESPONSE_TAG_DATA);
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(responseMessage, "Ok", "Cancel");
			((BaseFragmentActivity) getActivity()).Toast(responseMessage);
//			Toast.makeText(getActivity(), responseMessage, 0).show();
		}
	};

}
