package com.example.bcollege.ui;

import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.model.SubjectDto;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class ChapterExpandableAdapter extends BaseExpandableListAdapter implements
OnRequestFinishedListener{
	private static byte mRequestType;
	private int SubSsubjectRequestedId=-1;
	private Handler mHandler;
	private RequestManager mRequestManager;
	private Context context;
	View vi;
	List<SubjectDto> finalData;
	private LayoutInflater inflater;
	public static class ViewHolder{
		TextView chapterName;
	}
	public ChapterExpandableAdapter(Context context,
			List<SubjectDto> chapterDataList) {
		this.context=context;
		this.finalData=chapterDataList;
	}
	// TODO Auto-generated constructor stub

	public void setInflater(LayoutInflater inflater, Context activity) {
		this.inflater = inflater;
		this.context = activity;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getChildId(int arg0, int arg1) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getChildView( int groupPosition,  int childPosition, boolean isLastChild, View convertView,
			ViewGroup parent) {

		vi=convertView;

		final ViewHolder holder;
		if (vi == null) {
			holder = new ViewHolder();
			LayoutInflater inflater = LayoutInflater.from(context);
			//			vi = inflater.inflate(R.layout.child_diet, parent,false);
			vi.setTag( holder );
		}else{

			return vi;
		}
		return parent;
	}
	@Override
	public int getChildrenCount(int groupPosition) {
		if (groupPosition==0) {
			return groupPosition;
		}
		// TODO Auto-generated method stub

		return groupPosition;

	}

	@Override
	public Object getGroup(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getGroupCount() {
		// TODO Auto-generated method stub
		return finalData.size();
	}

	@Override
	public long getGroupId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
		View vi=convertView;
		final ViewHolder holder;
		
		if (convertView == null) {
			holder = new ViewHolder();
			LayoutInflater inflater = LayoutInflater.from(context);
			vi = inflater.inflate(R.layout.chapter_parent_layout, parent,false);
			holder.chapterName=(TextView) vi.findViewById(R.id.chapterName);
			vi.setTag( holder );
		}else
		{
			holder=(ViewHolder)vi.getTag();
		}
		
		holder.chapterName.setText(finalData.get(groupPosition).getChapter_name());
	if (isExpanded) {
		mHandler = new Handler();
		mRequestType = WSConfig.FETCH_SUBJECT;
		mRequestManager.addOnRequestFinishedListener(ChapterExpandableAdapter.this);

		mRequestType = WSConfig.FETCH_SUB_SUBJECT;
		Bundle semesterBundle=new Bundle();
		semesterBundle.putString(JSONTag.JSONTagConstants.SUBSUBJECTID, finalData.get(groupPosition).getChapterId());
		SubSsubjectRequestedId = mRequestManager.getChapterList(
				DownloadFormat.RETURN_FORMAT_JSON, semesterBundle);
		
	}
		return vi;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isChildSelectable(int arg0, int arg1) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void onGroupExpanded(int groupPosition) {
		// TODO Auto-generated method stub
		super.onGroupExpanded(groupPosition);
	}
	@Override
	public void onGroupCollapsed(int groupPosition) {
		// TODO Auto-generated method stub
		super.onGroupCollapsed(groupPosition);
	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		// TODO Auto-generated method stub
		
	}




}

