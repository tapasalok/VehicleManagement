package com.example.bcollege.ui;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.model.FileListDto;
import com.example.bcollege.model.SubjectDto;
import com.example.bcollege.model.ViewPostDto;
import com.example.bcollege.ui.FileListAdapter.ViewHolder;
import com.example.bcollege.utils.DialogHelper;

public class ViewPostAdapter extends ArrayAdapter<ViewPostDto>{


	Context context;
	List<ViewPostDto> finalData;
	public class ViewHolder{
		TextView studentName;
		TextView studentPostedDate;
		TextView studentPostedText;
		TextView replyText;
		TextView replyDate;
		TextView studentPostedTextStatus;


	}
	public ViewPostAdapter(Context context, int gridBranchLayout,
			List<ViewPostDto> chapterListData) {
		super(context,gridBranchLayout,chapterListData);
		this.context=context;
		this.finalData=chapterListData;

		// TODO Auto-generated constructor stub
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View vi = convertView;
		final ViewHolder holder;
		if (vi==null) {
			holder = new ViewHolder();
			LayoutInflater inflater = LayoutInflater.from(context);
			vi = inflater.inflate(R.layout.posted_view_layout, parent,false);
			holder.studentName=(TextView) vi.findViewById(R.id.studentName);
			holder.studentPostedDate=(TextView) vi.findViewById(R.id.studentPostedDate);
			holder.studentPostedText=(TextView) vi.findViewById(R.id.studentPostedText);
			holder.replyText=(TextView) vi.findViewById(R.id.replyText);
			holder.replyDate=(TextView) vi.findViewById(R.id.replyDate);
			holder.studentPostedTextStatus=(TextView) vi.findViewById(R.id.studentPostedTextStatus);
			vi.setTag( holder );
		} else {
			holder=(ViewHolder)vi.getTag();

		}
		holder.studentName.setText(finalData.get(position).getStudentName());
		holder.studentPostedDate.setText(finalData.get(position).getPostedDate());
		holder.studentPostedText.setText(finalData.get(position).getPostedText());
		if (finalData.get(position).getReplyText().equals("")&& finalData.get(position).getStudentId().equals(PreferenceConfig.getStudentId(context))) {
			holder.studentPostedTextStatus.setVisibility(View.GONE);
			holder.replyText.setText("Not Yet Reply");
		} else {
			holder.studentPostedTextStatus.setVisibility(View.GONE);
			holder.replyText.setText(finalData.get(position).getReplyText());
		}
		if (finalData.get(position).getReplyDate().equals("null")) {
			holder.replyDate.setVisibility(View.GONE);
		} else {
			holder.replyDate.setText(finalData.get(position).getReplyDate());
		}
		
		// TODO Auto-generated method stub
		return vi;
	}
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		super.clear();
	}





}
