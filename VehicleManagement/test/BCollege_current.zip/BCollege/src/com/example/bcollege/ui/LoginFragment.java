package com.example.bcollege.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.ActionBar;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.model.BranchDto;
import com.example.bcollege.model.FileListDto;
import com.example.bcollege.model.SemesterDto;
import com.example.bcollege.model.SubjectDto;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.requestmanager.WorkerService;
import com.example.bcollege.utils.DialogHelper;
import com.example.bcollege.utils.FragmentOperation;
import com.example.bcollege.utils.ProgressBarHelper;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class LoginFragment extends BaseFragment implements
OnRequestFinishedListener {
	private TextView registerHeading, forgotHeading;
	private static boolean isRememberMeChecked;
	private Button loginButton;
	private CheckBox showPassword, rememberMe;
	private EditText email, password;
	private static byte mRequestType;
	private SharedPreferences preference;
	private RequestManager mRequestManager;
	private int mRequestId = -1;
	private Handler mHandler;
	private Bundle mResponseBundle;
	private String responseMessage;
	private String emailId, tempPassword;
	private int branchRequestId = -1;
	private int subjectRequestedId=-1;
	private int SubSsubjectRequestedId = -1;
	private List<BranchDto> branches;
	private List<SemesterDto> semesters;
	private List<SubjectDto> subjects;
	private int SubChapterRequestedId = -1;
	private List<SubjectDto> subChapters;
	private List<FileListDto> audioDetails;
	private int detailRequestId = -1;
	public static List<SubjectDto> chapterListData = new ArrayList<SubjectDto>();
	private List<SubjectDto> chapters;
	private List<SubjectDto> subjectListData = new ArrayList<SubjectDto>();
	private List<BranchDto> branchListData = new ArrayList<BranchDto>();
	ActionBar bar;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		mHandler = new Handler();
		preference = PreferenceConfig.getInstance(getActivity());
		mRequestManager = RequestManager.from(getActivity());
		mRequestManager.addOnRequestFinishedListener(LoginFragment.this);
		mHandler = new Handler();
		PreferenceConfig.getInstance(getActivity());
//		getBranchList(savedInstanceState);
	}

	private void getBranchList(Bundle savedInstanceState) {

		mRequestType = WSConfig.FETCH_BRANCH;
		mRequestManager.addOnRequestFinishedListener(LoginFragment.this);
		branchRequestId = mRequestManager.getBranchList(
				DownloadFormat.RETURN_FORMAT_JSON, savedInstanceState);
		// TODO Auto-generated method stub

	
		// TODO Auto-generated method stub
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		// TODO Auto-generated method stub
		View view = null;
		if (PreferenceConfig.getLoggedIn(getActivity())) {
			loginToBCollegeDirectly(PreferenceConfig.getEmail(getActivity()),
					PreferenceConfig.getPassword(getActivity()));
		}else{
			view = inflater.inflate(R.layout.fragment_login, container, false);
			initApp(view);
		}
		return view;
	}

	private void initApp(final View view) {
		showPassword = (CheckBox) view.findViewById(R.id.checkBox1);
		rememberMe = (CheckBox) view.findViewById(R.id.checkBox2);
		showPassword.setOnCheckedChangeListener(showPasswordListener);
		rememberMe.setOnCheckedChangeListener(rememberMeListener);
		password = (EditText) view.findViewById(R.id.password);
		registerHeading = (TextView) view.findViewById(R.id.registerHeading);
		forgotHeading = (TextView) view.findViewById(R.id.forgotHeading);
		loginButton = (Button) view.findViewById(R.id.btnLogin);
		email = (EditText) view.findViewById(R.id.email);

		loginButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
			
				loginToBCollege();
					/*if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
						loginToBCollege();
					} else {
						List<SemesterDto> data=	BaseFragmentActivity.dbAdapter.fetchSemesters();
						FragmentOperation fragmentOperation = FragmentOperation
								.getInstance(getActivity());

						Bundle args = new Bundle();
						args.putParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_LIST_WITHOUT_INTERNET, (ArrayList<? extends Parcelable>) data);
						fragmentOperation.switchFragment(WSConfig.MODULE_SEMESTER, args);


					}*/



			}
		});

		registerHeading.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {

				Intent registerIntent = new Intent(getActivity(),
						RegistrationActivity.class);
				startActivity(registerIntent);
				return false;
			}
		});

		forgotHeading.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {

				Intent intent = new Intent(getActivity(),
						ForgotPasswordActivity.class);
				startActivity(intent);
				return false;
			}
		});
	}

	public OnCheckedChangeListener showPasswordListener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			if (!isChecked) {
				password.setTransformationMethod(PasswordTransformationMethod
						.getInstance());

			} else {
				password.setTransformationMethod(HideReturnsTransformationMethod
						.getInstance());
			}
			// TODO Auto-generated method stub

		}
	};

	public OnCheckedChangeListener rememberMeListener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			isRememberMeChecked = isChecked;
		}
	};

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager.removeOnRequestFinishedListener(LoginFragment.this);
			mRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			}

			/*
			 * if (resultCode != WorkerService.ERROR_CODE &&
			 * statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK) &&
			 * statusMessage.equals("true") && data.equals("success")) { // take
			 * further actions inside runnable.
			 * mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			 * }else{ mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			 * }
			 */
		}
		if (requestId == branchRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(LoginFragment.this);
			mRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mBranchRunnableHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mBranchRunnableHandleOnRequestFinishedSuccessState);
			}
		}
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(LoginFragment.this);
			mRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableSemesterHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableSemesterHandleOnRequestFinishedSuccessState);
			}
		}
		if (requestId == subjectRequestedId) {
			mResponseBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(LoginFragment.this);
			subjectRequestedId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestSucjectFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestSubjectFinishedSuccessState);
			}
		}
		if (requestId == SubSsubjectRequestedId) {
			mResponseBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(LoginFragment.this);
			SubSsubjectRequestedId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableSubjectHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableSubjectHandleOnRequestFinishedSuccessState);
			}
		}
		if (requestId == SubChapterRequestedId) {
			mResponseBundle = payload;
			//			mRequestManager
			//					.removeOnRequestFinishedListener(ChapterFragment.this);
			SubChapterRequestedId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableChapterHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				subChapters = mResponseBundle
						.getParcelableArrayList(JSONTagConstants.RESPONSE_SUB_CHAPTER_LIST);
				mHandler.post(mRunnableChapterHandleOnRequestFinishedSuccessState);
			}
		}
		if (requestId == detailRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(LoginFragment.this);
			detailRequestId = -1;


		}
		// TODO Auto-generated method stub

	}
	private final Runnable mRunnableChapterHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			mRequestManager
			.addOnRequestFinishedListener(LoginFragment.this);

			/*audioRequestedId = mRequestManager.getChapterWithAudio(
					DownloadFormat.RETURN_FORMAT_JSON, audioBundle);*/

			chapterListData.clear();

			ProgressBarHelper.dismissProgressBar(mHandler);

			if (subChapters == null || subChapters.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
				.showDialog(getString(R.string.nochapterforsUBJECT),
						"Ok", "Cancel");
			} else {
				for (SubjectDto chap : subChapters) {
					mRequestType = WSConfig.FETCH_DETAILS;
					Bundle detailsBundle = new Bundle();
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_BRANCH_ID,
							PreferenceConfig.getBranchId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SEM_ID,
							PreferenceConfig.getSemId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID,
							PreferenceConfig.getChapterId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID,
							PreferenceConfig.getSubId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID,
							chap.getSubChapterId());
					detailRequestId = mRequestManager.getDetails(
							DownloadFormat.RETURN_FORMAT_JSON, detailsBundle);
				}

			}
		}
	};

	private final Runnable mRunnableChapterHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			Toast.makeText(getActivity(),
					getString(R.string.nochapterforsUBJECT), 0).show();
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nochapterforsUBJECT),
					"Ok", "Cancel");
		}
	};
	private final Runnable mRunnableSubjectHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			chapterListData.clear();
			ProgressBarHelper.dismissProgressBar(mHandler);
			chapters = mResponseBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_SUB_SUBJECT_LIST);

			if (chapters == null || chapters.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
				.showDialog(getString(R.string.nochaptersforbranch),
						"Ok", "Cancel");
			} else {
				for (SubjectDto chap : chapters) {
					mRequestType = WSConfig.FETCH_SUB_CHAPTER;
					Bundle semesterBundle = new Bundle();
					semesterBundle.putString(JSONTag.JSONTagConstants.SUBCHAPTERID,
							chap.getChapterId());
					SubChapterRequestedId = mRequestManager.getSubChapterList(
							DownloadFormat.RETURN_FORMAT_JSON, semesterBundle);
				}
			}
		}
	};
	private final Runnable mRunnableSubjectHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			Toast.makeText(getActivity(),
					getString(R.string.nochaptersforbranch), 0).show();
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nochaptersforbranch),
					"Ok", "Cancel");
		}
	};
	private final Runnable mRunnableHandleOnRequestSucjectFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast(getString(R.string.nosubjectssforsemester));
			/*Toast.makeText(getActivity(),
					getString(R.string.nosubjectssforsemester), 0).show();*/
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nosubjectssforsemester),
					"Ok", "Cancel");
		}
	};
	private final Runnable mRunnableHandleOnRequestSubjectFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			subjectListData.clear();
			ProgressBarHelper.dismissProgressBar(mHandler);
			subjects = mResponseBundle.getParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST);

			if (subjects == null || subjects.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
				.showDialog(getString(R.string.nosubjectssforsemester),
						"Ok", "Cancel");
			} else {
				for (SubjectDto branch : subjects) {
					mRequestType = WSConfig.FETCH_SUB_SUBJECT;
					Bundle semesterBundle = new Bundle();
					semesterBundle.putString(JSONTag.JSONTagConstants.SUBSUBJECTID,
							branch.getSubjectId());
					SubSsubjectRequestedId = mRequestManager.getChapterList(
							DownloadFormat.RETURN_FORMAT_JSON, semesterBundle);
				}
			}
		}
	};
	private final Runnable mRunnableSemesterHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			branchListData.clear();
			ProgressBarHelper.dismissProgressBar(mHandler);
			semesters = mResponseBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_LIST);

			if (semesters == null || semesters.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
				.showDialog(getString(R.string.nosemetersforbranch),
						"Ok", "Cancel");
			} else {
				for (SemesterDto branch : semesters) {
					mRequestType = WSConfig.FETCH_SUBJECT;
					Bundle semesterBundle=new Bundle();
					semesterBundle.putString(JSONTag.JSONTagConstants.SEMESTERID, branch.getSemesterId());
					subjectRequestedId = mRequestManager.getSubjectList(
							DownloadFormat.RETURN_FORMAT_JSON, semesterBundle);
				}
			}
		}
	};
	private final Runnable mRunnableSemesterHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast(getString(R.string.nosemetersforbranch));
			/*Toast.makeText(getActivity(),
					getString(R.string.nosemetersforbranch), 0).show();*/
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nosemetersforbranch),
					"Ok", "Cancel");
		}
	};
	private final Runnable mBranchRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast("There are some problem in getting response");
			/*Toast.makeText(getActivity(),
					"There are some problem in getting response", 0).show();*/
		}
	};
	private final Runnable mBranchRunnableHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
//			 ProgressBarHelper.dismissProgressBar(mHandler);
			branches = mResponseBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_BRANCH_LIST);

			for (BranchDto branch : branches) {
				mRequestType = WSConfig.FETCH_SEMESTER;
				mRequestManager.addOnRequestFinishedListener(LoginFragment.this);
				Bundle savedInstanceState = new Bundle();
				PreferenceConfig.setBranchNewId(branch.getBranchId(), getActivity());
				mRequestId = mRequestManager.getSemesterList(
						DownloadFormat.RETURN_FORMAT_JSON, savedInstanceState );
			}

		}
	};

	private void loginToBCollegeDirectly(final String userName,
			final String password) {
		if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
			Bundle loginData = new Bundle();
			if (!TextUtils.isEmpty(userName)) {
				emailId = userName;
				tempPassword = password;
				PreferenceConfig.setLoggedIn(true, getActivity());
				loginData.putString(JSONTag.JSONTagConstants.LOGINENAILID,
						userName);
				loginData.putString(JSONTag.JSONTagConstants.LOGINPASSWORD,
						password);
				mRequestManager
				.addOnRequestFinishedListener(LoginFragment.this);
				mRequestType = WSConfig.LOGIN_USER;
				mRequestId = mRequestManager.login(
						DownloadFormat.RETURN_FORMAT_JSON, loginData);
				// args.putString("email", emailId);

			}
		} else {
			// Internet connection is not present
			// Ask user to connect to Internet
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper
			.showDialog("Check Internet Connection", "Ok", "Cancel");
		}

	}

	private void loginToBCollege() {
		if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_please_wait, true, mHandler,
					getActivity());
			Bundle loginData = new Bundle();
			if (TextUtils.isEmpty(email.getText())) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				((BaseFragmentActivity) getActivity()).Toast("Please enter email Id");
				/*Toast.makeText(getActivity(), "Please enter email Id", 0)
				.show();*/
				return;
			}
			if (TextUtils.isEmpty(password.getText())) {
				ProgressBarHelper.dismissProgressBar(mHandler);
				((BaseFragmentActivity) getActivity()).Toast("Please enter password");
				/*Toast.makeText(getActivity(), "Please enter password", 0)
				.show();*/
				return;
			}
			Bundle args = new Bundle();
			if (!TextUtils.isEmpty(email.getEditableText())) {

				emailId = email.getEditableText().toString();
				tempPassword = password.getEditableText().toString();
				if (isRememberMeChecked) {
					PreferenceConfig.setEmail(emailId, getActivity());
					PreferenceConfig.setPassword(tempPassword, getActivity());
					PreferenceConfig.setLoggedIn(isRememberMeChecked, getActivity());

				}
				loginData.putString(JSONTag.JSONTagConstants.LOGINENAILID,
						email.getText().toString());
				loginData.putString(JSONTag.JSONTagConstants.LOGINPASSWORD,
						password.getText().toString());
				mRequestManager
				.addOnRequestFinishedListener(LoginFragment.this);
				mRequestType = WSConfig.REGISTER_USER;
				mRequestId = mRequestManager.login(
						DownloadFormat.RETURN_FORMAT_JSON, loginData);
				// args.putString("email", emailId);

			}

			/*
			 * FragmentOperation fragmentOperation = FragmentOperation
			 * .getInstance(getActivity());
			 * 
			 * fragmentOperation.switchFragment(WSConfig.MODULE_BRANCH, args);
			 */

		} else {
			// Internet connection is not present
			// Ask user to connect to Internet
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper
			.showDialog("Check Internet Connection", "Ok", "Cancel");
		}
	}

	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			responseMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			String branchId = mResponseBundle
					.getString(JSONTag.JSONTagConstants.BRANCH_ID);
			String studentId = mResponseBundle
					.getString(JSONTag.JSONTagConstants.STUDENT_ID);
			PreferenceConfig.setStudentId(studentId, getActivity());
			PreferenceConfig.setEmail(emailId, getActivity());
			PreferenceConfig.setBranchId(branchId, getActivity());
			PreferenceConfig.setPassword(tempPassword, getActivity());
			//			PreferenceConfig.setLoggedIn(isRememberMeChecked, getActivity());
			((BaseFragmentActivity) getActivity()).Toast(" Your Email is: "
					+ PreferenceConfig.getEmail(getActivity())
					+ " and Your Brach Id is: "
					+ PreferenceConfig.getBranchId(getActivity()));
			/*Toast.makeText(
					getActivity(),
					" Your Email is: "
							+ PreferenceConfig.getEmail(getActivity())
							+ " and Your Brach Id is: "
							+ PreferenceConfig.getBranchId(getActivity()), 0)
							.show();*/
			FragmentOperation fragmentOperation = FragmentOperation
					.getInstance(getActivity());

			Bundle args = new Bundle();
			fragmentOperation.switchFragment(WSConfig.MODULE_SEMESTER, args);
			// getActivity().finish();
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			responseMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);
			/*
			 * responseMessage = mResponseBundle.getString(
			 * JSONTagConstants.RESPONSE_TAG_DATA);
			 */
			if (TextUtils.isEmpty(responseMessage)) {
				((BaseFragmentActivity) getActivity()).Toast("Some Problem");
//				Toast.makeText(getActivity(), "Some Problem", 0).show();
			} else {
				
				((BaseFragmentActivity) getActivity()).Toast(responseMessage);
				
//				Toast.makeText(getActivity(), responseMessage, 0).show();
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper.showDialog(responseMessage, "Ok", "Cancel");
				PreferenceConfig.setEmail("", getActivity());
				PreferenceConfig.setPassword("", getActivity());
				PreferenceConfig.setLoggedIn(false, getActivity());
				email.setText("");
				password.setText("");
				rememberMe.setChecked(false);
				
			}

			/* Toast.makeText(getActivity(), responseMessage, 0).show(); */
		}
	};

}
