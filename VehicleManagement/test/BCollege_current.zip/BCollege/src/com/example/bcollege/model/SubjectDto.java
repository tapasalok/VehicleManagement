package com.example.bcollege.model;

import android.os.Parcel;
import android.os.Parcelable;

public class SubjectDto implements Parcelable{
	private String subChapterId;
	public String getSubChapterId() {
		return subChapterId;
	}
	public void setSubChapterId(String subChapterId) {
		this.subChapterId = subChapterId;
	}
	public String getSubChapterName() {
		return subChapterName;
	}
	public void setSubChapterName(String subChapterName) {
		this.subChapterName = subChapterName;
	}
	private String subChapterName;
	private String subjectId;
	private String chapterId;
	public String getChapterId() {
		return chapterId;
	}
	public void setChapterId(String chapterId) {
		this.chapterId = chapterId;
	}
	public String getChapter_name() {
		return chapter_name;
	}
	public void setChapter_name(String chapter_name) {
		this.chapter_name = chapter_name;
	}
	private String chapter_name;
	private String subjectName;
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		// TODO Auto-generated method stub
		
	}
	

}
