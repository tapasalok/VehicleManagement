package com.example.bcollege.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.view.KeyEvent;

import com.bcollege.ematerial.R;

public class DialogHelper {

	private static DialogHelper fragmentOpration;
	private static Context activity;

	private DialogHelper(final Context context) {
		// TODO Auto-generated constructor stub

	}

	public static DialogHelper getInstance(final Context context) {
		activity = context;
		if (fragmentOpration == null) {
			fragmentOpration = new DialogHelper(context);
		}
		return fragmentOpration;
	}

	/** Method to show dialog on the basis of different dialog ids. */
	public void showDialog(final String message,
			final String positiveMessage, final String negativeMessage) {
		AlertDialog mAlertDialog = null;
		AlertDialog.Builder dlg = new AlertDialog.Builder(activity);
		dlg.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_SEARCH
						&& event.getRepeatCount() == 0) {
					return true;
				}
				return false;
			}
		});

		dlg.setIcon(R.drawable.ic_launcher)
				.setTitle(R.string.app_name)
				.setMessage(message)
				.setCancelable(false)
				.setPositiveButton(positiveMessage,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								
								dialog.dismiss();

							}
						})
				.setNegativeButton(negativeMessage,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();

							}
						});

		if (mAlertDialog != null) {
			mAlertDialog.dismiss();
		}
		mAlertDialog = dlg.create();
		mAlertDialog.show();
	}
}
