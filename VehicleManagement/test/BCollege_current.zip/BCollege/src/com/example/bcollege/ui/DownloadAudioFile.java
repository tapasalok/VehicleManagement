package com.example.bcollege.ui;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.text.BreakIterator;

import com.bcollege.ematerial.R;
import com.example.bcollege.utils.DialogHelper;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.StatFs;

public class DownloadAudioFile extends AsyncTask<String, Integer, String> {
	String[] mainAudioName;
	
	private Context context;

	public DownloadAudioFile(Context context) {
		// TODO Auto-generated constructor stub
		this.context = context;
	}
	
	@Override
	protected String doInBackground(String... params) {
		int count;
		boolean sdcardStaus = false;
		//	final MediaPlayer mediaPlayer = null;
		try {
			URL url = new URL(params[0] + params[1]);
			URI uri = new URI(url.getProtocol(), url.getUserInfo(),
					url.getHost(), url.getPort(), url.getPath(),
					url.getQuery(), url.getRef());
			url = uri.toURL();
			/*
			 * URL url = new URL(
			 * "http://phonecallmanagement.com/branch/audio/143771313604%20-%20Behke%20Behke(MyMp3Song.Com).mp3"
			 * );
			 */
			URLConnection conexion = url.openConnection();
			conexion.connect();
			// this will be useful so that you can show a tipical 0-100%
			// progress bar
			int lenghtOfFile = conexion.getContentLength();

			// downlod the file
			InputStream input = new BufferedInputStream(url.openStream());
			// File SDCardRoot =
			// Environment.getExternalStorageDirectory()+"/"+params[1];
			String PATH = Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/" + "BCollege";
			File SDCardRoot = new File(PATH);
			SDCardRoot.mkdirs();
		 mainAudioName=params[1].split("[/]");
			File file = new File(SDCardRoot.getAbsolutePath(),mainAudioName[1]);
			FileOutputStream output = new FileOutputStream(
					file);
			Environment.getExternalStorageState();
			//// check external memory size
			StatFs stat=new StatFs(Environment.getExternalStorageDirectory().getPath());
			long bytesAvailable=(long)stat.getBlockSize()*(long)stat.getAvailableBlocks();
			long megAvailable=bytesAvailable/(1024*1024);
			byte data[] = new byte[1024];
			/// check internal memory size
			StatFs statInternal=new StatFs(Environment.getDataDirectory().getPath());
			long bytesInternalAvailable=(long)stat.getBlockSize()*(long)stat.getAvailableBlocks();
			long internalMemoryAvailable=bytesInternalAvailable/(1024*1024);

			long total = 0;
			if (megAvailable>=input.read(data)) {
				sdcardStaus=true;
				while ((count = input.read(data)) != -1) {
					total += count;
					// publishing the progress....
					publishProgress((int) (total * 100 / lenghtOfFile));
					output.write(data, 0, count);

				}
			} else if (internalMemoryAvailable>=input.read(data)) {
				sdcardStaus=true;
				while ((count = input.read(data)) != -1) {
					total += count;
					// publishing the progress....
					publishProgress((int) (total * 100 / lenghtOfFile));
					output.write(data, 0, count);

				}
			} else {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(context);
				dialogHelper.showDialog(
						context.getString(R.string.nomemory),
						"Ok", "Cancel");


			}


/*			if (sdcardStaus) {



				if (input.read(data) == -1) {

					try {
						if (FileListAdapter.mediaPlayer.isPlaying()) {
							FileListAdapter.mediaPlayer.stop();
							// mediaPlayer.release();
						}
						FileListAdapter.mediaPlayer = new MediaPlayer();
						FileListAdapter.mediaPlayer
						.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
							@Override
							public void onPrepared(
									MediaPlayer mp) {
								if (mp == FileListAdapter.mediaPlayer) {
									FileListAdapter.mediaPlayer.start();
								}
							}
						});
						FileListAdapter.mediaPlayer
						.setAudioStreamType(AudioManager.STREAM_MUSIC);

						FileListAdapter.mediaPlayer.setDataSource(file
								.getAbsolutePath());

					} catch (IllegalArgumentException e1) {

						e1.printStackTrace();
					} catch (SecurityException e1) {

						e1.printStackTrace();
					} catch (IllegalStateException e1) {

						e1.printStackTrace();
					} catch (IOException e1) {

						e1.printStackTrace();
					}
					// mediaPlayer.setOnPreparedListener(onPreparedListener);
					try {
						FileListAdapter.mediaPlayer.prepare();
					} catch (IOException e) {

						e.printStackTrace();
					}
					// mediaPlayer.prepareAsync();
					catch (IllegalStateException e) {

						e.printStackTrace();
					}
					FileListAdapter.mediaPlayer.start();
					sdcardStaus=false;
				}
			}*/
			output.flush();
			output.close();
			input.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("---Message----" + e.getMessage());
			SubjectFragment.pd.dismiss();
		}
		return null;
	}

	private void playAudio() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		SubjectFragment.pd.setTitle("Please wait");
		SubjectFragment.pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		SubjectFragment.pd.setMessage("Dowloading / Playing audio stream..");
		SubjectFragment.pd.setIndeterminate(true);
		SubjectFragment.pd.setCancelable(false);
		SubjectFragment.pd.setInverseBackgroundForced(true);
		SubjectFragment.pd.show();
	}

	@Override
	protected void onProgressUpdate(Integer... values) {
		// TODO Auto-generated method stub
		super.onProgressUpdate(values);
	}

	@Override
	protected void onPostExecute(String result) {
		SubjectFragment.pd.dismiss();
		File	file = new File(Environment
				.getExternalStorageDirectory()
				.getAbsolutePath()
				+ "/"
				+ "BCollege"
				+ "/"
				+ /* "newAdio" */mainAudioName[1]);
		Intent playNow=new Intent(android.content.Intent.ACTION_VIEW);
		playNow.setDataAndType(Uri.fromFile(file), "audio/*");
		context.startActivity(playNow);
		// TODO Auto-generated method stub
		super.onPostExecute(result);
	}
}
