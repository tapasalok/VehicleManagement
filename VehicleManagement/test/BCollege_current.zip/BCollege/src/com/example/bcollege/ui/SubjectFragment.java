package com.example.bcollege.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.model.SubjectDto;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.requestmanager.WorkerService;
import com.example.bcollege.utils.DialogHelper;
import com.example.bcollege.utils.FragmentOperation;
import com.example.bcollege.utils.ProgressBarHelper;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class SubjectFragment extends BaseFragment implements
OnRequestFinishedListener {
	private Dialog dialog;
	private ImageView logout;
	private ListView subjectListView;
	private SubjectAdapter subjectAdapter;
	private List<SubjectDto> subjectListData1 = new ArrayList<SubjectDto>();
	private View view;
	private ViewGroup mainLayout;
	private Bundle mResponseBundle;
	private Handler mHandler;
	MediaPlayer mp;
	public static RequestManager mRequestManager;
	private int SubSsubjectRequestedId = -1;
	private static byte mRequestType;
	public static List<SubjectDto> chapterListData = new ArrayList<SubjectDto>();
	private List<SubjectDto> chapters;
	public static ProgressDialog pd;
	private SeekBar sb;
	Handler handle = new Handler();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		mHandler = new Handler();
		pd = new ProgressDialog(getActivity(),
				ProgressDialog.THEME_DEVICE_DEFAULT_DARK);
		mRequestManager = RequestManager.from(getActivity());
		mRequestManager.addOnRequestFinishedListener(SubjectFragment.this);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		view = inflater.inflate(R.layout.subject_layout, container, false);
		initApp();

		return view;
	}

	private void initApp() {
		logout=(ImageView) view.findViewById(R.id.logout);
		logout.setOnClickListener(logoutListener);

		subjectListView = (ListView) view.findViewById(R.id.subjectListView);
		//
		// chapterList=(ListView) view.findViewById(R.id.chapterList);
		// subChapterList=(ListView) view.findViewById(R.id.subChapterList);
		// subChapterList.setOnItemClickListener(new OnItemClickListener() {
		//
		// @Override
		// public void onItemClick(AdapterView<?> parent, View view,
		// int position, long id) {
		// SubjectDto selectedSubChapter= (SubjectDto)
		// parent.getItemAtPosition(position);
		// mRequestManager.addOnRequestFinishedListener(SubjectFragment.this);
		//
		// mRequestType = WSConfig.FETCH_DETAILS;
		// Bundle detailsBundle=new Bundle();
		// detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_BRANCH_ID,
		// PreferenceConfig.getBranchId(getActivity()));
		// detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_SEM_ID,
		// PreferenceConfig.getSemId(getActivity()));
		// detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID,
		// PreferenceConfig.getChapterId(getActivity()));
		// detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID,
		// PreferenceConfig.getSubId(getActivity()));
		// detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID,
		// selectedSubChapter.getSubChapterId());
		//
		// detailRequestId = mRequestManager.getDetails(
		// DownloadFormat.RETURN_FORMAT_JSON, detailsBundle);
		// // TODO Auto-generated method stub
		//
		// }
		// });

		subjectListData1 = getArguments().getParcelableArrayList(
				JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST);
		subjectAdapter = new SubjectAdapter(getActivity(),
				R.layout.grid_branch_layout, subjectListData1);
		subjectListView.setAdapter(subjectAdapter);
		subjectAdapter.notifyDataSetChanged();
		subjectShowEvent();
		subjectListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, true, mHandler,
							getActivity());
					SubjectDto selectedSubject = (SubjectDto) parent
							.getItemAtPosition(position);
					PreferenceConfig.setSubId(selectedSubject.getSubjectId(),
							getActivity());
					mRequestManager
					.addOnRequestFinishedListener(SubjectFragment.this);

					mRequestType = WSConfig.FETCH_SUB_SUBJECT;
					Bundle semesterBundle = new Bundle();
					// ///here
					/*
					 * if (((BaseFragmentActivity)
					 * getActivity()).isConnectingToInternet()) {
					 * semesterBundle.putString
					 * (JSONTag.JSONTagConstants.SUBSUBJECTID,
					 * selectedSubject.getSubjectId()); SubSsubjectRequestedId =
					 * mRequestManager.getChapterList(
					 * DownloadFormat.RETURN_FORMAT_JSON, semesterBundle); } else {
					 * List<SubjectDto>
					 * data=BaseFragmentActivity.dbAdapter.fetchChapters
					 * (selectedSubject.getSubjectId()); FragmentOperation
					 * fragmentOperation = FragmentOperation
					 * .getInstance(getActivity());
					 * 
					 * Bundle args = new Bundle(); args.putParcelableArrayList(
					 * JSONTagConstants.RESPONSE_CHAPTER_LIST, (ArrayList<? extends
					 * Parcelable>) data);
					 * 
					 * fragmentOperation.switchFragment(WSConfig.MODULE_CHAPTER,
					 * args);
					 * 
					 * }
					 */
					// tohere
					semesterBundle.putString(JSONTag.JSONTagConstants.SUBSUBJECTID,
							selectedSubject.getSubjectId());
					SubSsubjectRequestedId = mRequestManager.getChapterList(
							DownloadFormat.RETURN_FORMAT_JSON, semesterBundle);
				} else {
					DialogHelper dialogHelper = DialogHelper
							.getInstance(getActivity());
					dialogHelper
					.showDialog(getString(R.string.internetStatus),
							"Ok", "Cancel");

				}
			
				// TODO Auto-generated method stub

			}
		});
		// TODO Auto-generated method stub

	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == SubSsubjectRequestedId) {
			mResponseBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(SubjectFragment.this);
			SubSsubjectRequestedId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			}
		}
		// TODO Auto-generated method stub

	}

	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast(getString(R.string.nochaptersforbranch));
			/*Toast.makeText(getActivity(),
					getString(R.string.nochaptersforbranch), 0).show();*/
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nochaptersforbranch),
					"Ok", "Cancel");
		}
	};
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			chapterListData.clear();
			ProgressBarHelper.dismissProgressBar(mHandler);
			chapters = mResponseBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_SUB_SUBJECT_LIST);

			if (chapters == null || chapters.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
				.showDialog(getString(R.string.nochaptersforbranch),
						"Ok", "Cancel");
			} else {
				for (SubjectDto chap : chapters) {
					SubjectDto dto = new SubjectDto();
					dto.setChapterId(chap.getChapterId());
					dto.setChapter_name(chap.getChapter_name());
					chapterListData.add(dto);
				}
				subjectAdapter.notifyDataSetChanged();
				FragmentOperation fragmentOperation = FragmentOperation
						.getInstance(getActivity());

				Bundle args = new Bundle();
				args.putParcelableArrayList(
						JSONTagConstants.RESPONSE_CHAPTER_LIST,
						(ArrayList<? extends Parcelable>) chapters);

				fragmentOperation.switchFragment(WSConfig.MODULE_CHAPTER, args);
			}
		}
	};

	protected void subjectShowEvent() {

		// Animation bottomDown = AnimationUtils.loadAnimation(getActivity(),
		// R.anim.bottom_down);
		//
		// mainLayout.startAnimation(bottomDown);

	}
	public OnClickListener logoutListener=new OnClickListener() {

		@Override
		public void onClick(View v) {

			dialog = new Dialog(getActivity());
			dialog.setContentView(R.layout.logout_layout);
			dialog.setTitle("Are you sure want to logout?");
			dialog.setCancelable(true);
			Button logOutButton = (Button) dialog.findViewById(R.id.logoutButton);

			logOutButton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					((BaseFragmentActivity) getActivity()).logout(v);
					dialog.dismiss();
					// TODO Auto-generated method stub

				}
			});
			dialog.show();
			// speak();

			// TODO Auto-generated method stub

		}
	};

}
