package com.example.bcollege.worker;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;
import android.os.Parcelable;

import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.worker.NetworkConnection.Method;

public class BranchSemesterWorker extends BaseWorker {

	/** Start processing the request. */
	public static Bundle start(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_GETBRANCHES;
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parseBranchResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(JSONTagConstants.RESPONSE_BRANCH_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_BRANCH_LIST));
		/*List<BranchDto> branchDataForSqlite = bundle.getParcelableArrayList(JSONTagConstants.RESPONSE_BRANCH_LIST);
//		List<BranchDto> data=BaseFragmentActivity.dbAdapter.fetchBranch();
		List<BranchDto> dummyData=new ArrayList<BranchDto>();

		if (branchDataForSqlite!=null) {
			dummyData.clear();
			for(BranchDto tmp1: branchDataForSqlite) {
				dummyData.clear();
				BranchDto dto=new BranchDto();
	        	dto.setBranchId(tmp1.getBranchId());
	        	dto.setBranchName(tmp1.getBranchName());
	        	dummyData.add(dto);
	        	String data=BaseFragmentActivity.dbAdapter.fetchBranch(tmp1.getBranchId());
	        	if (data==null) {
	        		BaseFragmentActivity.dbAdapter.insertBranches(dummyData);
				} else {
					BaseFragmentActivity.dbAdapter.updateBranch(dummyData);
				}


			}

		}*/
		return bundle;
	}

	/** Start processing the request. */
	public static Bundle fetchSemester(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_FETCHSEMESTER + "&"
				+ JSONTagConstants.BRID + "="
				+ PreferenceConfig.getBranchId(inContext);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parseSemesterResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_SEMESTER_LIST));
		/*List<SemesterDto> seemsterDataForSqlite = bundle.getParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_LIST);
	List<SemesterDto> dummyData=new ArrayList<SemesterDto>();

	if (seemsterDataForSqlite!=null) {
		dummyData.clear();
		for(SemesterDto tmp1: seemsterDataForSqlite) {
			dummyData.clear();
			SemesterDto dto=new SemesterDto();
        	dto.setSemesterId(tmp1.getSemesterId());
        	dto.setSemesterName(tmp1.getSemesterName());
        	dummyData.add(dto);
        	String data=BaseFragmentActivity.dbAdapter.fetchSemesters(tmp1.getSemesterId());
        	if (data==null) {
        		BaseFragmentActivity.dbAdapter.insertSemester(dummyData,PreferenceConfig.getBranchId(inContext));
			} else {
				BaseFragmentActivity.dbAdapter.updateBranch(dummyData,PreferenceConfig.getBranchNewId(inContext));
			}


		}

	}
	if (seemsterDataForSqlite!=null) {
		BaseFragmentActivity.dbAdapter.insertSemester(seemsterDataForSqlite,PreferenceConfig.getBranchId(inContext));

	}*/
		return bundle;
	}

	public static Bundle fetchSemesterWiseSubject(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_FETCHSEMESTERWISESUBJECT
				+ "&"
				+ JSONTagConstants.SEMESTERID
				+ "="
				+ inBudleData
				.getString(JSONTag.JSONTagConstants.SEMESTERID);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parseSemesterWiseSubjectResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(
				JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST));
		/*List<SubjectDto> subjectDataForSqlite = bundle.getParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST);
		if (subjectDataForSqlite!=null) {
			BaseFragmentActivity.dbAdapter.insertSubjets(subjectDataForSqlite,inBudleData
					.getString(JSONTag.JSONTagConstants.SEMESTERID));

		}*/
		return bundle;
	}

	public static Bundle fetchChapterList(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_FETCHCHAPTERLIST
				+ "&"
				+ JSONTagConstants.SUBSUBJECTID
				+ "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.SUBSUBJECTID);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parseChapterResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(
				JSONTagConstants.RESPONSE_SUB_SUBJECT_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_SUB_SUBJECT_LIST));
		/*List<SubjectDto> chapterDataForSqlite = bundle.getParcelableArrayList(JSONTagConstants.RESPONSE_SUB_SUBJECT_LIST);
		if (chapterDataForSqlite!=null) {
			BaseFragmentActivity.dbAdapter.insertChapter(chapterDataForSqlite,inBudleData
					.getString(JSONTag.JSONTagConstants.SUBSUBJECTID));

		}*/
		return bundle;
	}

	public static Bundle fetchSubChapterList(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_FETCHSUBCHAPTERLIST
				+ "&"
				+ JSONTagConstants.SUBCHAPTERID
				+ "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.SUBCHAPTERID);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parseSubChapterResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(
				JSONTagConstants.RESPONSE_SUB_CHAPTER_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_SUB_CHAPTER_LIST));
		/*List<SubjectDto> subChapterDataForSqlite = bundle.getParcelableArrayList(JSONTagConstants.RESPONSE_SUB_CHAPTER_LIST);
		if (subChapterDataForSqlite!=null) {
			BaseFragmentActivity.dbAdapter.insertSubChapter(subChapterDataForSqlite,inBudleData
					.getString(JSONTag.JSONTagConstants.SUBCHAPTERID));

		}*/
		return bundle;
	}

	public static Bundle fetchDetails(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_GET_DETAILS
				+ "&"
				+ JSONTagConstants.DETAILS_BRANCH_ID
				+ "="
				+ inBudleData.getString(
						JSONTag.JSONTagConstants.DETAILS_BRANCH_ID)
						+ "&"
						+ JSONTagConstants.DETAILS_SEM_ID
						+ "="
						+ inBudleData.getString(
								JSONTag.JSONTagConstants.DETAILS_SEM_ID)
								+ "&"
								+ JSONTagConstants.DETAILS_SUBJECT_ID
								+ "="
								+ inBudleData.getString(
										JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID)
										+ "&"
										+ JSONTagConstants.DETAILS_CHAPTER_ID
										+ "="
										+ inBudleData.getString(
												JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID)
												+ "&"
												+ JSONTagConstants.DETAILS_SUB_CHAAPTER_ID
												+ "="
												+ inBudleData.getString(
														JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parseDetailsResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(JSONTagConstants.RESPONSE_FILE_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_FILE_LIST));
		/*List<FileListDto> fileDataForSqlite = bundle.getParcelableArrayList(JSONTagConstants.RESPONSE_FILE_LIST);
		if (fileDataForSqlite!=null) {
			BaseFragmentActivity.dbAdapter.insertFileDetails(fileDataForSqlite,inBudleData
					.getString(JSONTag.JSONTagConstants.DETAILS_BRANCH_ID),inBudleData
					.getString(JSONTag.JSONTagConstants.DETAILS_SEM_ID),inBudleData
					.getString(JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID),inBudleData
					.getString(JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID),inBudleData
					.getString(JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID));

		}*/
		return bundle;
	}
	public static Bundle fetchAudio(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_GET_DETAILS
				+ "&"
				+ JSONTagConstants.DETAILS_BRANCH_ID
				+ "="
				+ inBudleData.getString(
						JSONTag.JSONTagConstants.DETAILS_BRANCH_ID)
						+ "&"
						+ JSONTagConstants.DETAILS_SEM_ID
						+ "="
						+ inBudleData.getString(
								JSONTag.JSONTagConstants.DETAILS_SEM_ID)
								+ "&"
								+ JSONTagConstants.DETAILS_SUBJECT_ID
								+ "="
								+ inBudleData.getString(
										JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID)
										+ "&"
										+ JSONTagConstants.DETAILS_CHAPTER_ID
										+ "="
										+ inBudleData.getString(
												JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parseChapterWithAudio(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(JSONTagConstants.RESPONSE_AUDIO_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_AUDIO_LIST));

		return bundle;
	}
	public static Bundle postComment(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_POST_COMMENT
				+ "&"
				+ JSONTagConstants.DETAILS_BRANCH_ID
				+ "="
				+ inBudleData.getString(
						JSONTag.JSONTagConstants.DETAILS_BRANCH_ID)
						+ "&"
						+ JSONTagConstants.DETAILS_SEM_ID
						+ "="
						+ inBudleData.getString(
								JSONTag.JSONTagConstants.DETAILS_SEM_ID)
								+ "&"
								+ JSONTagConstants.DETAILS_SUBJECT_ID
								+ "="
								+ inBudleData.getString(
										JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID)
										+ "&"
										+ JSONTagConstants.DETAILS_CHAPTER_ID
										+ "="
										+ inBudleData.getString(
												JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID)
		+ "&"
		+ JSONTagConstants.DETAILS_SUB_CHAAPTER_ID
		+ "="
		+ inBudleData.getString(
				JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID)
				+ "&"
		+ JSONTagConstants.STUDENT_ID
		+ "="
		+ inBudleData.getString(
				JSONTag.JSONTagConstants.STUDENT_ID)+ "&"+ JSONTagConstants.POST_COMMENT
				+ "="
				+ inBudleData.getString(
						JSONTag.JSONTagConstants.POST_COMMENT);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		PostCommentParser postParser = PostCommentParser
				.getInstance(inContext);
		hashMap = postParser.parsePostCommentResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
		/*bundle.putString(JSONTagConstants.POST_COMMENT,
				(String) hashMap.get(JSONTagConstants.POST_COMMENT));*/
		bundle.putString(JSONTagConstants.RESPONSE_TAG_DATA,
				(String) hashMap.get(JSONTagConstants.RESPONSE_TAG_DATA));
		

		return bundle;
	}
	public static Bundle fetchPostViewrs(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
					throws IllegalStateException, IOException, URISyntaxException,
					ParserConfigurationException, SAXException, JSONException,
					Exception, OperationApplicationException, ConnectException {

		Bundle bundle = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_POST_VIEWS
				+ "&"
				+ JSONTagConstants.DETAILS_BRANCH_ID
				+ "="
				+ inBudleData.getString(
						JSONTag.JSONTagConstants.DETAILS_BRANCH_ID)
						+ "&"
						+ JSONTagConstants.DETAILS_SEM_ID
						+ "="
						+ inBudleData.getString(
								JSONTag.JSONTagConstants.DETAILS_SEM_ID)
								+ "&"
								+ JSONTagConstants.DETAILS_SUBJECT_ID
								+ "="
								+ inBudleData.getString(
										JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID)
										+ "&"
										+ JSONTagConstants.DETAILS_CHAPTER_ID
										+ "="
										+ inBudleData.getString(
												JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID)+ "&"
														+ JSONTagConstants.DETAILS_SUB_CHAAPTER_ID
														+ "="
														+ inBudleData.getString(
																JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID);
		Method method = Method.GET;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		BranchSemesterParser branchParser = BranchSemesterParser
				.getInstance(inContext);
		hashMap = branchParser.parsePostedViewsResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS, responseStatus);
		bundle.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		bundle.putParcelableArrayList(JSONTagConstants.RESPONSE_POST_VIEWS_LIST,
				(ArrayList<? extends Parcelable>) hashMap
				.get(JSONTagConstants.RESPONSE_POST_VIEWS_LIST));
		return bundle;
	}
}
