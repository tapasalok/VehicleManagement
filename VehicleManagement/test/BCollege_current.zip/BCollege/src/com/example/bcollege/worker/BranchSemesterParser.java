package com.example.bcollege.worker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;

import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.model.BranchDto;
import com.example.bcollege.model.FileListDto;
import com.example.bcollege.model.SemesterDto;
import com.example.bcollege.model.SubjectDto;
import com.example.bcollege.model.ViewPostDto;

public class BranchSemesterParser extends BaseJsonParser {

	private static BranchSemesterParser branchParser;
	private static Context activity;

	private BranchSemesterParser(final Context context) {
		// TODO Auto-generated constructor stub

	}

	public static BranchSemesterParser getInstance(final Context context) {
		activity = context;
		if (branchParser == null) {
			branchParser = new BranchSemesterParser(context);
		}
		return branchParser;
	}

	/** Call to Parse category response from JSON string. */
	public synchronized Map<String, Object> parseBranchResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<BranchDto> branchs = new ArrayList<BranchDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					BranchDto branch = new BranchDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					branch.setBranchId(jsonObject.optString("id"));
					branch.setBranchName(jsonObject.optString("branch_name"));
					branchs.add(branch);
				}
				map.put(JSONTagConstants.RESPONSE_BRANCH_LIST, branchs);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
	
	/** Call to Parse category response from JSON string. */
	public synchronized Map<String, Object> parseSemesterResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<SemesterDto> semesters = new ArrayList<SemesterDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					SemesterDto semester = new SemesterDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					semester.setSemesterId(jsonObject.optString("id"));
					semester.setSemesterName(jsonObject.optString("sem_name"));
					semesters.add(semester);
				}
				map.put(JSONTagConstants.RESPONSE_SEMESTER_LIST, semesters);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
	public synchronized Map<String, Object> parseSemesterWiseSubjectResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<SubjectDto> subjects = new ArrayList<SubjectDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					SubjectDto subject = new SubjectDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					subject.setSubjectId(jsonObject.optString("id"));
					subject.setSubjectName(jsonObject.optString("subject_name"));
					subjects.add(subject);
				}
				map.put(JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST, subjects);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
	public synchronized Map<String, Object> parseChapterResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<SubjectDto> subjects = new ArrayList<SubjectDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					SubjectDto subject = new SubjectDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					subject.setChapterId(jsonObject.optString("id"));
					subject.setChapter_name(jsonObject.optString("chapter_name"));
					subjects.add(subject);
				}
				map.put(JSONTagConstants.RESPONSE_SUB_SUBJECT_LIST, subjects);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
	public synchronized Map<String, Object> parseSubChapterResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<SubjectDto> subjects = new ArrayList<SubjectDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					SubjectDto subject = new SubjectDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					subject.setSubChapterId(jsonObject.optString("id"));
					subject.setSubChapterName(jsonObject.optString("sub_chapter_name"));
					subjects.add(subject);
				}
				map.put(JSONTagConstants.RESPONSE_SUB_CHAPTER_LIST, subjects);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
	public synchronized Map<String, Object> parseDetailsResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<FileListDto> fileList = new ArrayList<FileListDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					FileListDto fileDetails = new FileListDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					fileDetails.setFileId(jsonObject.optString("id"));
					fileDetails.setAudiofileName(jsonObject.optString("audio_file"));
					fileDetails.setChapterText(jsonObject.optString("chapter_text"));
					fileDetails.setDescription(jsonObject.optString("designation"));
					fileDetails.setFacultyName(jsonObject.optString("faculty_name"));
					fileDetails.setExperiance(jsonObject.optString("experience"));
					fileDetails.setAudioText(jsonObject.optString("text_file"));
					fileDetails.setImageName(jsonObject.optString("faculty_img"));
					fileList.add(fileDetails);
				}
				map.put(JSONTagConstants.RESPONSE_FILE_LIST, fileList);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
	public synchronized Map<String, Object> parseChapterWithAudio(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<FileListDto> fileList = new ArrayList<FileListDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					FileListDto fileDetails = new FileListDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					fileDetails.setFileId(jsonObject.optString("id"));
					fileDetails.setAudiofileName(jsonObject.optString("audio_file"));
					fileDetails.setChapterText(jsonObject.optString("chapter_text"));
					fileDetails.setDescription(jsonObject.optString("designation"));
					fileDetails.setFacultyName(jsonObject.optString("faculty_name"));
					fileDetails.setExperiance(jsonObject.optString("experience"));
					fileDetails.setAudioText(jsonObject.optString("text_file"));
					fileList.add(fileDetails);
				}
				map.put(JSONTagConstants.RESPONSE_AUDIO_LIST, fileList);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
	public synchronized Map<String, Object> parsePostedViewsResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseBranchErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				JSONArray jsonArray = response
						.optJSONArray(JSONTagConstants.RESPONSE_TAG_DATA);
				List<ViewPostDto> fileList = new ArrayList<ViewPostDto>();
				int jsonArrayLength = 0;
				if (jsonArray != null) {
					jsonArrayLength = jsonArray.length();
				}
				for (int i = 0; i < jsonArrayLength; i++) {
					ViewPostDto postDetails = new ViewPostDto();
					JSONObject jsonObject = jsonArray.optJSONObject(i);
					postDetails.setReplyText(jsonObject.optString("reply_text"));
					postDetails.setPostedText(jsonObject.optString("posted_text"));
					postDetails.setStudentName(jsonObject.optString("st_name"));
					postDetails.setReplyDate(jsonObject.optString("reply_date"));
					postDetails.setPostedDate(jsonObject.optString("posted_date"));
					postDetails.setStudentId(jsonObject.optString("student_id"));
					fileList.add(postDetails);
				}
				map.put(JSONTagConstants.RESPONSE_POST_VIEWS_LIST, fileList);
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
}

