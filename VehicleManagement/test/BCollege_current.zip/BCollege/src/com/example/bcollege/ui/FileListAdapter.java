package com.example.bcollege.ui;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.bcollege.ematerial.R;
import com.example.bcollege.model.FileListDto;
import com.example.bcollege.utils.DialogHelper;

/**
 * @author tapas
 *
 */
public class FileListAdapter extends ArrayAdapter<FileListDto> {
	private String audioUrl = "http://phonecallmanagement.com/branch/";
	private Context context;
	static StringBuilder textString = new StringBuilder();
	public ProgressDialog pb;
	private List<FileListDto> finalData;
	private View vi;
	private int pos;
	public static AlertDialog.Builder dlg;
	private ViewHolder holder;
	public static MediaPlayer mediaPlayer = new MediaPlayer();
	public static File file;
	public static boolean fileStatus = false;
	private static String audioName;
	private static String textAudio;

	public class ViewHolder {
		TextView branchName;
		TextView facultyTextValue;
		TextView experianceTextValue;
		TextView chapterTextValue;
		Button playAudio, playAudioSeekBar, playText;
		SeekBar audioSeekBar;
		ViewGroup seekGroup;

	}

	public FileListAdapter(Context context, int gridBranchLayout,
			List<FileListDto> chapterListData) {
		super(context, gridBranchLayout, chapterListData);
		this.context = context;
		this.finalData = chapterListData;

		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		vi = convertView;
		pos = position;
		if (vi == null) {
			new Handler();
			holder = new ViewHolder();
			LayoutInflater inflater = LayoutInflater.from(context);
			vi = inflater.inflate(R.layout.detail_layout, parent, false);
			/*
			 * holder.seekGroup=(ViewGroup) vi.findViewById(R.id.uperLayout5);
			 * holder.seekGroup.setVisibility(View.INVISIBLE);
			 */
			holder.playText = (Button) vi.findViewById(R.id.playText);
			holder.playText.setTag(position);
			holder.audioSeekBar = (SeekBar) vi.findViewById(R.id.audioSeekBar);
			holder.facultyTextValue = (TextView) vi
					.findViewById(R.id.facultyTextValue);
			holder.experianceTextValue = (TextView) vi
					.findViewById(R.id.experianceTextValue);
			holder.chapterTextValue = (TextView) vi
					.findViewById(R.id.chapterTextValue);
			holder.playAudio = (Button) vi.findViewById(R.id.playAudio);

			holder.playAudio.setTag(position);
			holder.playAudio.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (((BaseFragmentActivity) context).isConnectingToInternet()) {
						int pos = (Integer) v.getTag();

						audioName = finalData.get(pos).getAudiofileName();

						if (isExternalStorageWritable()) {
							String[] mainAudioName = audioName.split("[/]");
							file = new File(Environment
									.getExternalStorageDirectory()
									.getAbsolutePath()
									+ "/"
									+ "BCollege"
									+ "/"
									+ /* "newAdio" */mainAudioName[1]);

							if (!file.exists()
									/*|| !checkSameFileSize(file, audioUrl, audioName)*/) {
								new DownloadAudioFile(context).execute(audioUrl,
										audioName);
							}
							if (file.exists()) {
								Intent playNow = new Intent(
										android.content.Intent.ACTION_VIEW);
								playNow.setDataAndType(Uri.fromFile(file),
										"audio/*");
								context.startActivity(playNow);

							}

						} else {
							DialogHelper dialogHelper = DialogHelper
									.getInstance((Activity) context);
							dialogHelper.showDialog(context
									.getString(R.string.noexternalstoragepresent),
									"Ok", "Cancel");
						}
					} else {
						DialogHelper dialogHelper = DialogHelper.getInstance(context);
						dialogHelper.showDialog(context.getString(R.string.internetStatus),
								"Ok", "Cancel");

					}
				
					
				}
			});
			holder.playText.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (((BaseFragmentActivity) context).isConnectingToInternet()) {
						int pos = (Integer) v.getTag();
						textAudio = finalData.get(pos).getAudioText();
						if (textAudio.endsWith(".txt")) {
							if (isExternalStorageWritable()) {
								String[] mainAudioName = textAudio.split("[/]");
								file = new File(Environment
										.getExternalStorageDirectory()
										.getAbsolutePath()
										+ "/"
										+ "BCollege"
										+ "/"
										+ /* "newAdio" */mainAudioName[1]);
								if (!file.exists()
										/*|| !checkSameFileSize(file, audioUrl,
												textAudio)*/) {
									new DownloadFile(context).execute(audioUrl,
											textAudio);
								}
								if (file.exists()) {
									new checkUrlSize(context).execute(audioUrl,
											textAudio,file.getAbsolutePath());
						/*			if (checkSameFileSize(file, audioUrl,
												textAudio)) {
										File file = new File(Environment
												.getExternalStorageDirectory()
												.getAbsolutePath()
												+ "/"
												+ "BCollege"
												+ "/"
												+  "newAdio" mainAudioName[1]);
										try {
											BufferedReader br = new BufferedReader(
													new FileReader(file));
											String line;

											while ((line = br.readLine()) != null) {
												textString.append(line);
												textString.append('\n');
											}

											Intent intent = new Intent(context,
													TextWatchActivity.class);
											intent.putExtra("fileExitString", textString.toString());
											intent.putExtra("textFilePath", file.getAbsolutePath());
//											intent.putExtra("status", true);
											context.startActivity(intent);
										} catch (IOException e) {
											// You'll need to add proper error handling
											// here
										}
										
									} else {
										

									}*/

								
								}
							} else {
								DialogHelper dialogHelper = DialogHelper
										.getInstance((Activity) context);
								dialogHelper.showDialog(
										context.getString(R.string.noexternalstoragepresent),
										"Ok", "Cancel");

							}
						} else {
							DialogHelper dialogHelper = DialogHelper
									.getInstance((Activity) context);
							dialogHelper.showDialog(
									context.getString(R.string.formatCheck), "Ok",
									"Cancel");
						}
					} else {
						DialogHelper dialogHelper = DialogHelper.getInstance(context);
						dialogHelper.showDialog(context.getString(R.string.internetStatus),
								"Ok", "Cancel");


					}
				
				}

			});
			holder.branchName = (TextView) vi.findViewById(R.id.branchName);
			vi.setTag(holder);
		} else {
			holder = (ViewHolder) vi.getTag();

		}
		// holder.branchName.setText(finalData.get(position).getAudiofileName());
		// TODO Auto-generated method stub
		holder.facultyTextValue.setText(finalData.get(position)
				.getFacultyName());
		holder.chapterTextValue.setText(finalData.get(position)
				.getChapterText());
		holder.experianceTextValue.setText(finalData.get(position)
				.getExperiance());
		if (!finalData.get(pos).getAudioText().equals("")) {
			holder.playText.setVisibility(View.VISIBLE);

		} else {
			holder.playText.setVisibility(View.GONE);
		}
		if (!finalData.get(pos).getAudiofileName().equals("")) {
			holder.playAudio.setVisibility(View.VISIBLE);

		} else {
			holder.playAudio.setVisibility(View.GONE);
		}
		return vi;
	}

	/**
	 * We need to write method to check whether the file in server is same as
	 * the file present in SD Card
	 * 
	 * @param textAudio2
	 * @param audioUrl2
	 * @param file2
	 * @return boolean
	 */
	/*protected boolean checkSameFileSize(File file2, String audioUrl2,
			String textAudio2) {
		int file_size=Integer.parseInt(String.valueOf(file2.length()/1024));
		AsyncTask<String, Integer, String> dataValue = new checkUrlSize(context).execute(audioUrl2,
				textAudio2);
		try {
		String abc = dataValue.get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}*/

	protected void openTextDialog() {
		Intent intent = new Intent(context, TextWatchActivity.class);
		context.startActivity(intent);

	}

	/* Checks if external storage is available for read and write */
	public boolean isExternalStorageWritable() {
		String state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(state)) {
			return true;
		}
		return false;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		super.clear();
	}
	public class checkUrlSize extends AsyncTask<String, Integer, String> {
		private Context context;
		InputStream input;
		int urlSize;
		public checkUrlSize(Context context) {
			// TODO Auto-generated constructor stub
			this.context = context;
		}

		

		String[] mainAudioName;

		@Override
		protected String doInBackground(String... params) {
			try {
				URL url = new URL(params[0] + params[1]);
				URI uri = new URI(url.getProtocol(), url.getUserInfo(),
						url.getHost(), url.getPort(), url.getPath(),
						url.getQuery(), url.getRef());
				url = uri.toURL();

				URLConnection conexion = url.openConnection();
				conexion.connect();
				int lenghtOfFile = conexion.getContentLength();

				 input = new BufferedInputStream(url.openStream());
				 mainAudioName = params[1].split("[/]");

				 byte data[] = new byte[1024];
					urlSize=input.read(data);
					
				input.close();
				
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("---Message----" + e.getMessage());
				SubjectFragment.pd.dismiss();
			}
			return null;
		}


		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			// TODO Auto-generated method stub
			super.onProgressUpdate(values);
		}

		protected void onPostExecute(String result) {
			
			int file_size=Integer.parseInt(String.valueOf(file.length()));
		if (file_size>=urlSize) {
			File file = new File(Environment
					.getExternalStorageDirectory()
					.getAbsolutePath()
					+ "/"
					+ "BCollege"
					+ "/"
					+ /* "newAdio" */mainAudioName[1]);
			try {
				BufferedReader br = new BufferedReader(
						new FileReader(file));
				textString.setLength(0);
				String line;

				while ((line = br.readLine()) != null) {
					textString.append(line);
					textString.append('\n');
				}

				Intent intent = new Intent(context,
						TextWatchActivity.class);
				intent.putExtra("fileExitString", textString.toString());
				intent.putExtra("textFilePath", mainAudioName[1]);
//				intent.putExtra("status", true);
				context.startActivity(intent);
			} catch (IOException e) {
				// You'll need to add proper error handling
				// here
			}
			
			
		} else {
			new DownloadFile(context).execute(audioUrl,
					textAudio);

		}
			super.onPostExecute(result);
		}
	}


}
