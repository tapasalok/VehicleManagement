package com.example.bcollege.requestmanager;

/**
 * {@link BaseRequestManager} is the superclass of the classes that will be
 * implemented in our project. It contains constants used.
 * 
 */
public abstract class BaseRequestManager {

	public static final String RECEIVER_EXTRA_REQUEST_ID = "com.bcollege.ematerial.requestId";
	public static final String RECEIVER_EXTRA_RESULT_CODE = "com.bcollege.ematerial.code";
	public static final String RECEIVER_EXTRA_PAYLOAD = "com.bcollege.ematerial.payload";
	public static final String RECEIVER_EXTRA_ERROR_TYPE = "com.bcollege.ematerial.error";
	public static final int RECEIVER_EXTRA_VALUE_ERROR_TYPE_CONNEXION = 1;
	public static final int RECEIVER_EXTRA_VALUE_ERROR_TYPE_DATA = 2;
}
