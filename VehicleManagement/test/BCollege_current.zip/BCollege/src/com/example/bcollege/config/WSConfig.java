package com.example.bcollege.config;

public interface WSConfig {

	// Request Types
	public byte FETCH_BRANCH = 1;
	public byte LOGIN_USER = 2;
	public byte REGISTER_USER = 3;
	public byte FORGOT_PASSWORD = 4;
	public byte FETCH_SEMESTER = 5;
	public byte FETCH_SUBJECT = 6;
	public byte FETCH_SUB_SUBJECT = 7;
	public byte FETCH_SUB_CHAPTER = 8;
	public byte FETCH_DETAILS = 9;
	public byte POST_COMMENT = 10;
	public byte POST_VIEW = 11;

	// Different Modules
	public final String MODULE_SEMESTER = "MODULE_SEMESTER";
	public final String MODULE_SUBJECT = "MODULE_SUBJECT";
	public final String MODULE_CHAPTER = "MODULE_CHAPTER";
	public final String MODULE_SUB_CHAPTER = "MODULE_SUB_CHAPTER";
	public final String MODULE_FILE_DETAILS = "MODULE_FILE_DETAILS";
	public final String MODULE_POST_VIEWS = "MODULE_POST_VIEWS";
	
	// Action Names
	public final String WS_ACTION_GETBRANCHES = "getbranches";
	public final String WS_ACTION_REGISTER = "register";
	public final String WS_ACTION_UPDATEPASSWORD = "updatepassword";
	// public final String WS_ACTION_LOGIN = "login";
	public final String WS_ACTION_LOGIN = "login";
	public final String WS_ACTION_FETCHSEMESTER = "getsemisters";
	public final String WS_ACTION_SEMESTERWISESUBJECT = "getsubjects";
	public final String WS_ACTION_CHAPTER_LIST = "getchapters";
	public final String WS_ACTION_SUB_CHAPTER_LIST = "getsubchapters";
	public final String WS_ACTION_DETAILS = "getdetails";
	public final String WS_ACTION_POST_COMMENT = "newpost";
	public final String WS_ACTION_VIEWPOST = "viewposts";
	public final String API_BASE_URL = "http://phonecallmanagement.com/college/br-api/json-api.php";
	public String URL_GETBRANCHES = API_BASE_URL + "?action="
			+ WS_ACTION_GETBRANCHES;
	
	public String URL_REGISTER = API_BASE_URL + "?action=" + WS_ACTION_REGISTER;
	
	public String URL_LOGIN = API_BASE_URL + "?action=" + WS_ACTION_LOGIN;
	
	public String URL_UPDATEPASSWORD = API_BASE_URL + "?action="
			+ WS_ACTION_UPDATEPASSWORD;
	
	public String URL_FETCHSEMESTER = API_BASE_URL + "?action="
			+ WS_ACTION_FETCHSEMESTER;
	public String URL_FETCHSEMESTERWISESUBJECT = API_BASE_URL + "?action="
			+ WS_ACTION_SEMESTERWISESUBJECT;
	public String URL_FETCHCHAPTERLIST = API_BASE_URL + "?action="
			+ WS_ACTION_CHAPTER_LIST;
	public String URL_FETCHSUBCHAPTERLIST = API_BASE_URL + "?action="
			+ WS_ACTION_SUB_CHAPTER_LIST;
	public String URL_GET_DETAILS = API_BASE_URL + "?action="
			+ WS_ACTION_DETAILS;
	public String URL_POST_COMMENT = API_BASE_URL + "?action="
			+ WS_ACTION_POST_COMMENT;
	public String URL_POST_VIEWS = API_BASE_URL + "?action="
			+ WS_ACTION_VIEWPOST;
	
}
