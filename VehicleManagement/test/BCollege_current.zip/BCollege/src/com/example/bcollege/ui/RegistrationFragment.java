package com.example.bcollege.ui;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.model.BranchDto;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.requestmanager.WorkerService;
import com.example.bcollege.utils.DialogHelper;
import com.example.bcollege.utils.ProgressBarHelper;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class RegistrationFragment extends BaseFragment implements
		OnRequestFinishedListener {
	private EditText name, emaiId, rollNo, password, confirmPassword, phoneNo,
			semester, year;
	private Button register;
	private static byte mRequestType;
	private RequestManager mRequestManager;
	private Bundle mResponseBundle;
	private int mRequestId = -1;
	private int branchRequestId = -1;
	private Handler mHandler;
	private String responseMessage;
	private List<BranchDto> branches;
	private Spinner branchSpinner;
	private String branchName;
	private ArrayAdapter<BranchDto> spinnerAdapter;
	private List<BranchDto> branchListData = new ArrayList<BranchDto>();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		mHandler = new Handler();

		mRequestManager = RequestManager.from(getActivity());
		mHandler = new Handler();
		getBranchList(savedInstanceState);
	}

	private void getBranchList(Bundle savedInstanceState) {

		mRequestType = WSConfig.FETCH_BRANCH;
		mRequestManager.addOnRequestFinishedListener(RegistrationFragment.this);
		branchRequestId = mRequestManager.getBranchList(
				DownloadFormat.RETURN_FORMAT_JSON, savedInstanceState);
		// TODO Auto-generated method stub

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.fragment_registration, container,
				false);

		setHasOptionsMenu(true);
		initApp(view);
		return view;
	}

	private void initApp(final View view) {

		branchSpinner = (Spinner) view.findViewById(R.id.branch);
		branchSpinner.setOnItemSelectedListener(spinnerListener);
		semester = (EditText) view.findViewById(R.id.semester);
		year = (EditText) view.findViewById(R.id.year);
		name = (EditText) view.findViewById(R.id.name);
		emaiId = (EditText) view.findViewById(R.id.email);
		rollNo = (EditText) view.findViewById(R.id.rollNo);
		password = (EditText) view.findViewById(R.id.password);
		confirmPassword = (EditText) view.findViewById(R.id.confirmPassword);
		phoneNo = (EditText) view.findViewById(R.id.phoneNo);
		register = (Button) view.findViewById(R.id.btnRegister);
		register.setOnClickListener(registerListener);

	}

	public OnItemSelectedListener spinnerListener = new OnItemSelectedListener() {

		@Override
		public void onItemSelected(AdapterView<?> parent, View view,
				int position, long id) {
			branchName = parent.getItemAtPosition(position).toString();
			// TODO Auto-generated method stub

		}

		@Override
		public void onNothingSelected(AdapterView<?> parent) {
			// TODO Auto-generated method stub

		}
	};
	public OnClickListener registerListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			Bundle registerData = new Bundle();

			if (TextUtils.isEmpty(name.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Name");
//				Toast.makeText(getActivity(), "Please enter Name", 0).show();
				return;
			}
			if (branchName.matches("")) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Branch");
//				Toast.makeText(getActivity(), "Please enter Branch", 0).show();
				return;
			}
			if (TextUtils.isEmpty(year.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Year");
//				Toast.makeText(getActivity(), "Please enter Year", 0).show();
				return;
			}
			if (TextUtils.isEmpty(semester.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Semester");
				/*Toast.makeText(getActivity(), "Please enter Semester", 0)
						.show();*/
				return;
			}
			if (TextUtils.isEmpty(rollNo.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Roll No");
//				Toast.makeText(getActivity(), "Please enter Roll No", 0).show();
				return;
			}
			if (TextUtils.isEmpty(emaiId.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Email id");
				/*Toast.makeText(getActivity(), "Please enter Email id", 0)
						.show();*/
				return;
			}

			if (TextUtils.isEmpty(password.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Password");
				/*Toast.makeText(getActivity(), "Please enter Password", 0)
						.show();*/
				return;
			}
			if (TextUtils.isEmpty(confirmPassword.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Confirm Password");
				/*Toast.makeText(getActivity(), "Please enter Confirm Password",
						0).show();*/
				return;
			}
			if (TextUtils.isEmpty(phoneNo.getText())) {
				((BaseFragmentActivity) getActivity()).Toast("Please enter Phone Number");
				/*Toast.makeText(getActivity(), "Please enter Phone Number", 0)
						.show();*/
				return;
			}

			String password1 = password.getText().toString();
			String confirmPassword1 = confirmPassword.getText().toString();

			if (!(password1.equals(confirmPassword1))) {
				((BaseFragmentActivity) getActivity()).Toast("Password should be the same as Confirm Password");
				/*Toast.makeText(getActivity(),
						"Password should be the same as Confirm Password", 0)
						.show();*/
				return;
			}

			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDNAME,
					name.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.BRANCH_ID,
					getBranchIdFromBranchName(branchName));
			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDYEAR,
					year.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDSEMESTER,
					semester.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDROLLNO,
					rollNo.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDEMAILID,
					emaiId.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDPASSWORD,
					password.getText().toString());
			registerData.putString(JSONTag.JSONTagConstants.REGISTEREDPHONENO,
					phoneNo.getText().toString());
			mRequestManager
					.addOnRequestFinishedListener(RegistrationFragment.this);
			mRequestType = WSConfig.REGISTER_USER;
			ProgressBarHelper.showProgressBarSmall(
					R.string.progress_bar_regiter_please_wait, true, mHandler,
					getActivity());
			mRequestId = mRequestManager.register(
					DownloadFormat.RETURN_FORMAT_JSON, registerData);

		}

		private String getBranchIdFromBranchName(final String branchName) {
			// TODO Auto-generated method stub
			String userBranchId = "0";
			for (BranchDto branchDto : branchListData) {
				if (branchName.equals(branchDto.getBranchName())) {
					userBranchId = branchDto.getBranchId();
					break;
				}
			}
			return userBranchId;
		}
	};

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(RegistrationFragment.this);
			mRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")
					&& data.equals(getString(R.string.registration_success))) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			}
		}
		if (requestId == branchRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(RegistrationFragment.this);
			mRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mBranchRunnableHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mBranchRunnableHandleOnRequestFinishedSuccessState);
			}
		}
	}

	private final Runnable mBranchRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast("There are some problem in getting response");
			/*Toast.makeText(getActivity(),
					"There are some problem in getting response", 0).show();*/
		}
	};
	private final Runnable mBranchRunnableHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			 ProgressBarHelper.dismissProgressBar(mHandler);
			branches = mResponseBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_BRANCH_LIST);

			for (BranchDto branch : branches) {
				BranchDto dto = new BranchDto();
				dto.setBranchId(branch.getBranchId());
				dto.setBranchName(branch.getBranchName());
				branchListData.add(dto);
				/*
				 * textView.append("\n Branch Id: " + branch.getmId() +
				 * " Branch: " + branch.getMbranch_name());
				 */
			}
			spinnerAdapter = new ArrayAdapter<BranchDto>(getActivity(),
					android.R.layout.simple_spinner_dropdown_item,
					branchListData);
			branchSpinner.setAdapter(spinnerAdapter);
			spinnerAdapter.notifyDataSetChanged();
			/*
			 * branchAdapter = new BranchNameAdapter(getActivity(),
			 * R.layout.grid_branch_layout, branchListData);
			 * branch.setAdapter(branchAdapter);
			 * branchAdapter.notifyDataSetChanged();
			 */

		}
	};

	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			responseMessage = mResponseBundle.getString(
					JSONTagConstants.RESPONSE_TAG_DATA);
			((BaseFragmentActivity) getActivity()).Toast(responseMessage);
//			Toast.makeText(getActivity(), responseMessage, 0).show();
			getActivity().finish();
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			responseMessage = mResponseBundle.getString(
					JSONTagConstants.RESPONSE_TAG_DATA);
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(responseMessage, "Ok", "Cancel");
			((BaseFragmentActivity) getActivity()).Toast(responseMessage);
//			Toast.makeText(getActivity(), responseMessage, 0).show();
		}
	};

}
