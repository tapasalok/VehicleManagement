package com.example.bcollege.ui;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.bcollege.ematerial.R;

public class RegistrationActivity extends BaseFragmentActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);
		addRegisterFragment();
	}

	private void addRegisterFragment() {
		FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();
		RegistrationFragment fragment = new RegistrationFragment();
		fragmentTransaction.add(R.id.registationContainer, fragment);
		fragmentTransaction.commit();
	}
}
