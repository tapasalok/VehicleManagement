package com.example.bcollege.config;

public class JSONTag {

	/**
	 * An interface that holds the various json related constants.
	 *
	 */
	public interface JSONTagConstants {
		// Response status tags
		public final String RESPONSE_TAG_STATUS = "status";
		public final String RESPONSE_TAG_STATUS_MESSAGE = "status_message";
		public final String RESPONSE_TAG_DATA = "data";

		// Response Codes
		public final String RESPONSE_OK = "200";
		public final String RESPONSE_FAILURE = "9999";

		// Response Tags name for Bundle
		public final String RESPONSE_BRANCH_LIST = "RESPONSE_BRANCH_LIST";
		public final String RESPONSE_SEMESTER_LIST = "RESPONSE_SEMESTER_LIST";
		public final String RESPONSE_SEMESTER_WISE_LIST = "RESPONSE_SEMESTER_WISE_LIST";
		public final String RESPONSE_SUB_SUBJECT_LIST = "RESPONSE_SUB_SUBJECT_LIST";
		public final String RESPONSE_CHAPTER_LIST = "RESPONSE_CHAPTER_LIST";
		public final String RESPONSE_SUB_CHAPTER_LIST = "RESPONSE_SUB_CHAPTER_LIST";
		public final String RESPONSE_FILE_LIST = "RESPONSE_FILE_LIST";
		public final String RESPONSE_POST_VIEWS_LIST = "RESPONSE_POST_VIEWS_LIST";
		public final String RESPONSE_AUDIO_LIST = "RESPONSE_AUDIO_LIST";
		public final String RESPONSE_SEMESTER_LIST_WITHOUT_INTERNET = "RESPONSE_SEMESTER_LIST_WITHOUT_INTERNET";
		
		public final String REGISTEREDNAME = "stname";
		public final String REGISTEREDYEAR = "year";
		public final String REGISTEREDSEMESTER = "sem";
		public final String REGISTEREDROLLNO = "rollno";
		public final String REGISTEREDEMAILID = "email";
		public final String REGISTEREDPASSWORD = "password";
		public final String REGISTEREDPHONENO = "imei";
		public final String LOGINENAILID = "email";
		public final String LOGINPASSWORD = "pwd";
		public final String BRANCH_ID = "branch_id";
		public final String STU_ID = "id";
		public final String OPWD = "opwd";
		public final String NPWD = "npwd";
		public final String BRID = "brid";
		public final String SEMESTERID = "semid";
		public final String SUBSUBJECTID = "subid";
		public final String SUBCHAPTERID = "chapterid";
		public final String DETAILS_BRANCH_ID = "brid";
		public final String DETAILS_SEM_ID = "semid";
		public final String DETAILS_SUBJECT_ID = "subid";
		public final String DETAILS_CHAPTER_ID = "chapterid";
		public final String DETAILS_SUB_CHAAPTER_ID = "subchapterid";
		public final String POST_COMMENT = "postedtext";
		public final String STUDENT_ID = "stid";
		
		

	}

}
