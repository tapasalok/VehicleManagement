package com.example.bcollege.worker;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;

import com.example.bcollege.config.JSONTag.JSONTagConstants;

public class PostCommentParser extends BaseJsonParser{



	private static PostCommentParser postParser;
	private static Context activity;

	private PostCommentParser(final Context context) {
		// TODO Auto-generated constructor stub

	}

	public static PostCommentParser getInstance(final Context context) {
		activity = context;
		if (postParser == null) {
			postParser = new PostCommentParser(context);
		}
		return postParser;
	}

	/** Call to Parse category response from JSON string. */
	public synchronized Map<String, Object> parsePostCommentResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.optString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parsePostCommentErrorJSON(response, map)) {
				return map;
			}
			
			/*JSONObject jsonDataObject =  response.optJSONObject(JSONTagConstants.RESPONSE_TAG_DATA);
			if (jsonDataObject.has(JSONTagConstants.POST_COMMENT)) {
				String postComment = jsonDataObject.optString(JSONTagConstants.POST_COMMENT);
				map.put(JSONTagConstants.BRANCH_ID, postComment);
			}*/
			
			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
			}
		} else {
			if (!parsePostErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}




}
