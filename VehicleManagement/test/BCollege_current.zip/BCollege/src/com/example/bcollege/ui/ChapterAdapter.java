package com.example.bcollege.ui;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.bcollege.ematerial.R;
import com.example.bcollege.model.SubjectDto;

public class ChapterAdapter extends ArrayAdapter<SubjectDto>{


	Context context;
	List<SubjectDto> finalData;
	public class ViewHolder{
		TextView branchName;


	}
	public ChapterAdapter(Context context, int gridBranchLayout,
			List<SubjectDto> chapterListData) {
		super(context,gridBranchLayout,chapterListData);
		this.context=context;
		this.finalData=chapterListData;

		// TODO Auto-generated constructor stub
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View vi = convertView;
		final ViewHolder holder;
		if (vi==null) {
			holder = new ViewHolder();
			LayoutInflater inflater = LayoutInflater.from(context);
			vi = inflater.inflate(R.layout.grid_branch_layout, parent,false);
			holder.branchName=(TextView) vi.findViewById(R.id.branchName);
			vi.setTag( holder );
		} else {
			holder=(ViewHolder)vi.getTag();

		}
		holder.branchName.setText(finalData.get(position).getChapter_name());
		// TODO Auto-generated method stub
		return vi;
	}
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		super.clear();
	}





}
