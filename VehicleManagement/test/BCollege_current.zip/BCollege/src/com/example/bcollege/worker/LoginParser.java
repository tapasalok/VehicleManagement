package com.example.bcollege.worker;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;

import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.PreferenceConfig;

public class LoginParser extends BaseJsonParser {


	private static LoginParser loginParser;
	private static Context activity;

	private LoginParser(final Context context) {
		// TODO Auto-generated constructor stub

	}

	public static LoginParser getInstance(final Context context) {
		activity = context;
		if (loginParser == null) {
			loginParser = new LoginParser(context);
		}
		return loginParser;
	}

	/** Call to Parse category response from JSON string. */
	public synchronized Map<String, Object> parseLoginResponse(String jsonData)
			throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.optString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseLoginErrorJSON(response, map)) {
				return map;
			}
			
			JSONObject jsonDataObject =  response.optJSONObject(JSONTagConstants.RESPONSE_TAG_DATA);
			if (jsonDataObject.has(JSONTagConstants.BRANCH_ID)&&jsonDataObject.has(JSONTagConstants.STU_ID)) {
				String branchId = jsonDataObject.optString(JSONTagConstants.BRANCH_ID);
				String studentId=jsonDataObject.optString(JSONTagConstants.STU_ID);
				map.put(JSONTagConstants.STUDENT_ID, studentId);
				map.put(JSONTagConstants.BRANCH_ID, branchId);
			}
			
			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}


}
