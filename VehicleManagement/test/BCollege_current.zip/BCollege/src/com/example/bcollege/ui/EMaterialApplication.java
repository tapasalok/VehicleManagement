package com.example.bcollege.ui;

import android.app.Application;

public class EMaterialApplication extends Application {

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
	}

}
