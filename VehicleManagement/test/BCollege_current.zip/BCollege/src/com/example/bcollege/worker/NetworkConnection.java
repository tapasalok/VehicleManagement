package com.example.bcollege.worker;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.message.BasicNameValuePair;

import android.content.Context;

public class NetworkConnection {

	private static NetworkConnection fragmentOpration;
	private static Context activity;

	private NetworkConnection(final Context context) {
		// TODO Auto-generated constructor stub

	}

	public static NetworkConnection getInstance(final Context context) {
		activity = context;
		if (fragmentOpration == null) {
			fragmentOpration = new NetworkConnection(context);
		}
		return fragmentOpration;
	}

	public static enum Method {
		GET, POST, PUT, DELETE
	}

	/**
	 * Call the webservice using the given parameters to construct the request
	 * and return the result.
	 *
	 * @param context
	 *            The context to use for this operation. Used to generate the
	 *            user agent if needed.
	 * @param urlValue
	 *            The webservice URL.
	 * @param method
	 *            The request method to use.
	 * @param parameterList
	 *            The parameters to add to the request.
	 * @param headerMap
	 *            The headers to add to the request.
	 * 
	 * @return The String JSON of the webservice call.
	 */
	public String execute(Context context, String urlValue, Method method,
			ArrayList<BasicNameValuePair> parameterList,
			HashMap<String, String> headerMap) throws ConnectException {
		String returnContent = null;
		String error = null;
		String data = "";
		try {
			// Set Request parameter
			data += "&" + URLEncoder.encode("data", "UTF-8");

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BufferedReader reader = null;

		// Send data
		try {

			// Defined URL where to send data
			urlValue = urlValue.replaceAll(" ", "%20");
			URL url = new URL(urlValue);

			// Send POST data request

			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(
					conn.getOutputStream());
			wr.write(data);
			wr.flush();

			// Get the server response

			reader = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			StringBuilder sb = new StringBuilder();
			String line = null;

			// Read Server Response
			while ((line = reader.readLine()) != null) {
				// Append server response in string
				sb.append(line + " ");
			}

			// Append Server Response To Content String
			returnContent = sb.toString();
		} catch (Exception ex) {
			error = ex.getMessage();
		} finally {
			try {
				reader.close();
			}

			catch (Exception ex) {
			}
		}

		return returnContent;
	}
}
