package com.example.bcollege.worker;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.example.bcollege.config.JSONTag.JSONTagConstants;

/**
 * A base json parser class that holds the common methods that can be called
 * from by its sub classes who extends this class.
 *
 */
public abstract class BaseJsonParser {

	protected static boolean parseRegisterErrorJSON(JSONObject response,
			HashMap<String, Object> map) throws JSONException {
		if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
			boolean nonErrorMessage = response
					.optBoolean(JSONTagConstants.RESPONSE_TAG_DATA);
			if (nonErrorMessage) {
				return false;
			} else {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
			}
		}
		return true;
	}
	protected static boolean parsePostErrorJSON(JSONObject response,
			HashMap<String, Object> map) throws JSONException {
		if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
			boolean nonErrorMessage = response
					.optBoolean(JSONTagConstants.RESPONSE_TAG_DATA);
			if (nonErrorMessage) {
				return false;
			} else {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
			}
		}
		return true;
	}
	protected static boolean parseLoginErrorJSON(JSONObject response,
			HashMap<String, Object> map) throws JSONException {
		
		if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS)) {
			String statusCode = response.optString(JSONTagConstants.RESPONSE_TAG_STATUS);
			if (!statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
				return true;
			}else{
				return false;
			}
		}else{
			map.put(JSONTagConstants.RESPONSE_TAG_DATA,
					response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
			return true;
		}
	}
	protected static boolean parsePostCommentErrorJSON(JSONObject response,
			HashMap<String, Object> map) throws JSONException {
		
		if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS)) {
			String statusCode = response.optString(JSONTagConstants.RESPONSE_TAG_STATUS);
			if (!statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
				return true;
			}else{
				return false;
			}
		}else{
			map.put(JSONTagConstants.RESPONSE_TAG_DATA,
					response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
			return true;
		}
	}
	
	protected static boolean parseupdatePasswordErrorJSON(JSONObject response,
			HashMap<String, Object> map) throws JSONException {
		
		if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS)) {
			String statusCode = response.optString(JSONTagConstants.RESPONSE_TAG_STATUS);
			if (!statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
				return true;
			}else{
				return false;
			}
		}else{
			map.put(JSONTagConstants.RESPONSE_TAG_DATA,
					response.optString(JSONTagConstants.RESPONSE_TAG_DATA));
			return true;
		}
	}

	protected static boolean parseBranchErrorJSON(JSONObject response,
			HashMap<String, Object> map) throws JSONException {
		if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
			String nonErrorMessage = response
					.optString(JSONTagConstants.RESPONSE_TAG_DATA);
			if (nonErrorMessage == null) {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						"There are some problem");
				return true;
			} else {
				return false;
			}
		}
		return true;
	}
}
