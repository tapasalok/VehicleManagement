package com.example.bcollege.ui;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.bcollege.ematerial.R;

public class ForgotPasswordActivity extends BaseFragmentActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);
		addForgotPasswordFragment();
	}

	private void addForgotPasswordFragment() {
		FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();
		ForgotPasswordFragment fragment = new ForgotPasswordFragment();
		fragmentTransaction.add(R.id.registationContainer, fragment);
		fragmentTransaction.commit();
	}
}
