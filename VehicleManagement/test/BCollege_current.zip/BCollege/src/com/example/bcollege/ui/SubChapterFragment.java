package com.example.bcollege.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.model.FileListDto;
import com.example.bcollege.model.SubjectDto;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.requestmanager.WorkerService;
import com.example.bcollege.utils.DialogHelper;
import com.example.bcollege.utils.FragmentOperation;
import com.example.bcollege.utils.ProgressBarHelper;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class SubChapterFragment extends BaseFragment implements
		OnRequestFinishedListener {
	private Dialog dialog;
	private ImageView logout;
	private SubChapterAdapter subChapterAdapter;
	private List<SubjectDto> subchapterData = new ArrayList<SubjectDto>();
	private View view;
	private ViewGroup subchapterGroup;
	private Bundle mResponseBundle;
	private Handler mHandler;
	private FileListAdapter audioeAdapter;
	private ListView subchapterList, subChapterAudioList;
	public static RequestManager mRequestManager;
	private int detailRequestId = -1;
	private List<FileListDto> audioListAfterChapter = new ArrayList<FileListDto>();
	private static byte mRequestType;
	public static List<FileListDto> chapterListData = new ArrayList<FileListDto>();
	private List<FileListDto> fileDetails;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		mHandler = new Handler();
		mRequestManager = RequestManager.from(getActivity());
		mRequestManager.addOnRequestFinishedListener(SubChapterFragment.this);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		view = inflater.inflate(R.layout.sub_chapter_layout, container, false);
		initApp();
		return view;
	}

	private void initApp() {
		logout=(ImageView) view.findViewById(R.id.logout);
		logout.setOnClickListener(logoutListener);
		subchapterList = (ListView) view.findViewById(R.id.subChapterList);
		subChapterAudioList = (ListView) view
				.findViewById(R.id.subChapterAudioList);
		audioListAfterChapter = getArguments().getParcelableArrayList(
				JSONTagConstants.RESPONSE_AUDIO_LIST);
		if (audioListAfterChapter != null) {
			audioeAdapter = new FileListAdapter(getActivity(),
					R.layout.detail_layout, audioListAfterChapter);
			subChapterAudioList.setAdapter(audioeAdapter);
			audioeAdapter.notifyDataSetChanged();
		}

		subchapterData = getArguments().getParcelableArrayList(
				JSONTagConstants.RESPONSE_SUB_CHAPTER_LIST);
		subChapterAdapter = new SubChapterAdapter(getActivity(),
				R.layout.grid_branch_layout, subchapterData);
		subchapterList.setAdapter(subChapterAdapter);
		subChapterAdapter.notifyDataSetChanged();
//		chapterShowEvent();
		subchapterList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
					SubjectDto selectedSubChapter = (SubjectDto) parent
							.getItemAtPosition(position);
					PreferenceConfig.setSubChapterId(selectedSubChapter.getSubChapterId(), getActivity());
					mRequestManager
							.addOnRequestFinishedListener(SubChapterFragment.this);

					mRequestType = WSConfig.FETCH_DETAILS;
					Bundle detailsBundle = new Bundle();
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_BRANCH_ID,
							PreferenceConfig.getBranchId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SEM_ID,
							PreferenceConfig.getSemId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID,
							PreferenceConfig.getChapterId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID,
							PreferenceConfig.getSubId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID,
							selectedSubChapter.getSubChapterId());

					detailRequestId = mRequestManager.getDetails(
							DownloadFormat.RETURN_FORMAT_JSON, detailsBundle);
				} else {
					DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
					dialogHelper.showDialog(getString(R.string.internetStatus),
							"Ok", "Cancel");

				}
					
				
				

				// TODO Auto-generated method stub

			}
		});

	}

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {

		if (requestId == detailRequestId) {
			mResponseBundle = payload;
			mRequestManager
					.removeOnRequestFinishedListener(SubChapterFragment.this);
			detailRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableChapterHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableChapterHandleOnRequestFinishedSuccessState);
			}
		}
		// TODO Auto-generated method stub

	}

	private final Runnable mRunnableChapterHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast(getString((R.string.nochapterforFiles)));
			/*oast.makeText(getActivity(),
					getString(R.string.nochapterforFiles), 0).show();*/
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nofilesforThisChapter),
					"Ok", "Cancel");
		}
	};
	private final Runnable mRunnableChapterHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			chapterListData.clear();
			ProgressBarHelper.dismissProgressBar(mHandler);
			fileDetails = mResponseBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_FILE_LIST);

			if (fileDetails == null || fileDetails.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
						.showDialog(getString(R.string.nochapterforsUBJECT),
								"Ok", "Cancel");
			} else {
				for (FileListDto chap : fileDetails) {
					FileListDto dto = new FileListDto();
					dto.setFileId(chap.getFileId());
					dto.setChapterText(chap.getChapterText());
					dto.setAudiofileName(chap.getAudiofileName());
					dto.setAudioText(chap.getAudioText());
					chapterListData.add(dto);
				}

				FragmentOperation fragmentOperation = FragmentOperation
						.getInstance(getActivity());

				Bundle args = new Bundle();
				args.putParcelableArrayList(
						JSONTagConstants.RESPONSE_FILE_LIST,
						(ArrayList<? extends Parcelable>) fileDetails);
				fragmentOperation.switchFragment(WSConfig.MODULE_FILE_DETAILS,
						args);

			}
		}
	};

	/*protected void chapterShowEvent() {

		// Show the panel
		Animation bottomUp = AnimationUtils.loadAnimation(getActivity(),
				R.anim.bottom_up);

		subchapterGroup.startAnimation(bottomUp);
		// subchapterGroup.setVisibility(View.VISIBLE);

	}*/
public OnClickListener logoutListener=new OnClickListener() {
		
		@Override
		public void onClick(View v) {

			dialog = new Dialog(getActivity());
			dialog.setContentView(R.layout.logout_layout);
			dialog.setTitle("Are you sure want to logout?");
			dialog.setCancelable(true);
			Button logOutButton = (Button) dialog.findViewById(R.id.logoutButton);
			
			logOutButton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					((BaseFragmentActivity) getActivity()).logout(v);
					dialog.dismiss();
					// TODO Auto-generated method stub
					
				}
			});
			dialog.show();
			// speak();
		
			// TODO Auto-generated method stub
			
		}
	};

}
