package com.example.bcollege.worker;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.json.JSONException;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.OperationApplicationException;
import android.os.Bundle;

import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.worker.NetworkConnection.Method;

public class LoginRegisterWorker extends BaseWorker {

	public static Bundle forgotPassword(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
			throws IllegalStateException, IOException, URISyntaxException,
			ParserConfigurationException, SAXException, JSONException,
			Exception, OperationApplicationException, ConnectException {

		Bundle registrationResult = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);

		// action=updatepassword&email=tapasalok@gmail.com&opwd=newpassword13&npwd=newpassword13
		String urlValue = WSConfig.URL_UPDATEPASSWORD + "&"
				+ JSONTag.JSONTagConstants.LOGINENAILID + "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.LOGINENAILID)
				+ "&" + JSONTag.JSONTagConstants.OPWD + "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.OPWD) + "&"
				+ JSONTag.JSONTagConstants.NPWD + "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.NPWD);

		Method method = Method.POST;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		RegisterParser registerParser = RegisterParser.getInstance(inContext);
		hashMap = registerParser.parseUpdatePasswordResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		registrationResult.putString(JSONTagConstants.RESPONSE_TAG_STATUS,
				responseStatus);
		registrationResult.putString(
				JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE, (String) hashMap
						.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		registrationResult.putString(JSONTagConstants.RESPONSE_TAG_DATA,
				(String) hashMap.get(JSONTagConstants.RESPONSE_TAG_DATA));

		return registrationResult;
	}

	public static Bundle register(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
			throws IllegalStateException, IOException, URISyntaxException,
			ParserConfigurationException, SAXException, JSONException,
			Exception, OperationApplicationException, ConnectException {

		Bundle registrationResult = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_REGISTER
				+ "&"
				+ JSONTag.JSONTagConstants.REGISTEREDNAME
				+ "="
				+ inBudleData
						.getString(JSONTag.JSONTagConstants.REGISTEREDNAME)
				+ "&"
				+ JSONTag.JSONTagConstants.BRANCH_ID
				+ "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.BRANCH_ID)
				+ "&"
				+ JSONTag.JSONTagConstants.REGISTEREDYEAR
				+ "="
				+ inBudleData
						.getString(JSONTag.JSONTagConstants.REGISTEREDYEAR)
				+ "&"
				+ JSONTag.JSONTagConstants.REGISTEREDSEMESTER
				+ "="
				+ inBudleData
						.getString(JSONTag.JSONTagConstants.REGISTEREDSEMESTER)
				+ "&"
				+ JSONTag.JSONTagConstants.REGISTEREDROLLNO
				+ "="
				+ inBudleData
						.getString(JSONTag.JSONTagConstants.REGISTEREDROLLNO)
				+ "&"
				+ JSONTag.JSONTagConstants.REGISTEREDEMAILID
				+ "="
				+ inBudleData
						.getString(JSONTag.JSONTagConstants.REGISTEREDEMAILID)
				+ "&"
				+ JSONTag.JSONTagConstants.REGISTEREDPASSWORD
				+ "="
				+ inBudleData
						.getString(JSONTag.JSONTagConstants.REGISTEREDPASSWORD)
				+ "&"
				+ JSONTag.JSONTagConstants.REGISTEREDPHONENO
				+ "="
				+ inBudleData
						.getString(JSONTag.JSONTagConstants.REGISTEREDPHONENO);

		Method method = Method.PUT;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);
		RegisterParser registerParser = RegisterParser.getInstance(inContext);
		hashMap = registerParser.parseRegisterResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		registrationResult.putString(JSONTagConstants.RESPONSE_TAG_STATUS,
				responseStatus);
		registrationResult.putString(
				JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE, (String) hashMap
						.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));

		registrationResult.putString(JSONTagConstants.RESPONSE_TAG_DATA,
				(String) hashMap.get(JSONTagConstants.RESPONSE_TAG_DATA));

		return registrationResult;
	}

	public static Bundle login(final Context inContext,
			final int inReturnFormat, final Bundle inBudleData)
			throws IllegalStateException, IOException, URISyntaxException,
			ParserConfigurationException, SAXException, JSONException,
			Exception, OperationApplicationException, ConnectException {

		Bundle loginResult = new Bundle();
		Map<String, Object> hashMap = new HashMap<String, Object>(1);

		// TODO Call Network Connection and get the Response in JSON

		NetworkConnection networkConnection = NetworkConnection
				.getInstance(inContext);
		String urlValue = WSConfig.URL_LOGIN + "&"
				+ JSONTag.JSONTagConstants.LOGINENAILID + "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.LOGINENAILID)
				+ "&" + JSONTag.JSONTagConstants.LOGINPASSWORD + "="
				+ inBudleData.getString(JSONTag.JSONTagConstants.LOGINPASSWORD);
		Method method = Method.PUT;
		String result = networkConnection.execute(inContext, urlValue, method,
				null, null);

		LoginParser loginParser = LoginParser.getInstance(inContext);
		hashMap = loginParser.parseLoginResponse(result);

		final String responseStatus = (String) hashMap
				.get(JSONTagConstants.RESPONSE_TAG_STATUS);
		loginResult.putString(JSONTagConstants.RESPONSE_TAG_STATUS,
				responseStatus);
		loginResult.putString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
				(String) hashMap
						.get(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
		loginResult.putString(JSONTagConstants.BRANCH_ID,
				(String) hashMap.get(JSONTagConstants.BRANCH_ID));
		loginResult.putString(JSONTagConstants.STUDENT_ID,
				(String) hashMap.get(JSONTagConstants.STUDENT_ID));
		loginResult.putString(JSONTagConstants.RESPONSE_TAG_DATA,
				(String) hashMap.get(JSONTagConstants.RESPONSE_TAG_DATA));
		/*
		 * String insertBranchIdToSqlite = (String)
		 * hashMap.get(JSONTagConstants.BRANCH_ID); if
		 * (insertBranchIdToSqlite!=null) {
		 * BaseFragmentActivity.dbAdapter.insertBranchId(insertBranchIdToSqlite
		 * );
		 * 
		 * }
		 */
		return loginResult;
	}
}
