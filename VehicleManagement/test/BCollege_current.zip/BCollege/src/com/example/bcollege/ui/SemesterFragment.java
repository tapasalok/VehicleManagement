package com.example.bcollege.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.model.SemesterDto;
import com.example.bcollege.model.SubjectDto;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.requestmanager.WorkerService;
import com.example.bcollege.utils.DialogHelper;
import com.example.bcollege.utils.FragmentOperation;
import com.example.bcollege.utils.ProgressBarHelper;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class SemesterFragment extends BaseFragment implements
OnRequestFinishedListener {
	private ListView semesterName;
	private View view;
	private Dialog dialog;
	private ImageView logout;
	private SemesterNameAdapter semesterAdaptr;
	private List<String> branchData = new ArrayList<String>();
	private RequestManager mRequestManager;
	private int mRequestId = -1;
	private int subjectRequestedId=-1;
	private static byte mRequestType;
	private Bundle mResponseBundle;
	private Handler mHandler;
	private TextView textView;
	private List<SemesterDto> semesters;
	private List<SubjectDto> subjects;
	private List<SemesterDto> branchListData = new ArrayList<SemesterDto>();
	private List<SubjectDto> subjectListData = new ArrayList<SubjectDto>();
	private List<SemesterDto> branchListWithOutInternetData = new ArrayList<SemesterDto>();
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);

	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		mHandler = new Handler();
		mRequestManager = RequestManager.from(getActivity());
		mRequestManager.addOnRequestFinishedListener(SemesterFragment.this);
		ProgressBarHelper.showProgressBarSmall(
				R.string.progress_bar_please_wait, true, mHandler,
				getActivity());
		mRequestType = WSConfig.FETCH_SEMESTER;
		Bundle savedInstanceState = new Bundle();
		//////here
		/*if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
			mRequestType = WSConfig.FETCH_SEMESTER;
			Bundle savedInstanceState = new Bundle();
			mRequestId = mRequestManager.getSemesterList(
					DownloadFormat.RETURN_FORMAT_JSON, savedInstanceState );
		} else {
			branchListWithOutInternetData=getArguments().getParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_LIST_WITHOUT_INTERNET);
			semesterAdaptr = new SemesterNameAdapter(getActivity(),
					R.layout.grid_branch_layout, branchListWithOutInternetData);
			semesterName.setAdapter(semesterAdaptr);
			semesterAdaptr.notifyDataSetChanged();
			ProgressBarHelper.dismissProgressBar(mHandler);

		}*/
		////here
		mRequestId = mRequestManager.getSemesterList(
					DownloadFormat.RETURN_FORMAT_JSON, savedInstanceState );
		mRequestId = mRequestManager.getSemesterList(
				DownloadFormat.RETURN_FORMAT_JSON, savedInstanceState );
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		view = inflater.inflate(R.layout.fragment_branches, container, false);
		logout=(ImageView) view.findViewById(R.id.logout);
		logout.setOnClickListener(logoutListener);
		semesterName = (ListView) view.findViewById(R.id.branchName);
		semesterName.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, true, mHandler,
							getActivity());
					SemesterDto selectedSemester=	(SemesterDto) parent.getItemAtPosition(position);
					PreferenceConfig.setSemId(selectedSemester.getSemesterId(), getActivity());

					mRequestManager.addOnRequestFinishedListener(SemesterFragment.this);

					mRequestType = WSConfig.FETCH_SUBJECT;
					Bundle semesterBundle=new Bundle();
					/*if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
						semesterBundle.putString(JSONTag.JSONTagConstants.SEMESTERID, selectedSemester.getSemesterId());
						subjectRequestedId = mRequestManager.getSubjectList(
								DownloadFormat.RETURN_FORMAT_JSON, semesterBundle);
					} else {
						List<SubjectDto> data=BaseFragmentActivity.dbAdapter.fetchSubjects(selectedSemester.getSemesterId());
						FragmentOperation fragmentOperation = FragmentOperation
								.getInstance(getActivity());

						Bundle args = new Bundle();
						args.putParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST, (ArrayList<? extends Parcelable>) data);
						fragmentOperation.switchFragment(WSConfig.MODULE_SUBJECT, args);
					}*/
					semesterBundle.putString(JSONTag.JSONTagConstants.SEMESTERID, selectedSemester.getSemesterId());
				subjectRequestedId = mRequestManager.getSubjectList(
						DownloadFormat.RETURN_FORMAT_JSON, semesterBundle);
				} else {
					DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
					dialogHelper.showDialog(getString(R.string.internetStatus),
							"Ok", "Cancel");

				}
		

				// TODO Auto-generated method stub

			}
		});
		textView = (TextView) view.findViewById(R.id.textView);
		// initApp();
		return view;
	}

	/*
	 * private void initApp() { branchData.add("MEC"); branchData.add("IT");
	 * branchData.add("EEE"); branchData.add("CIVIL"); branchData.add("CSE");
	 * 
	 * branchAdapter=new
	 * BranchNameAdapter(getActivity(),R.layout.grid_branch_layout,branchData);
	 * branchName.setAdapter(branchAdapter) ;
	 * branchAdapter.notifyDataSetChanged(); // TODO Auto-generated method stub
	 * 
	 * }
	 */

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {
		if (requestId == mRequestId) {
			mResponseBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(SemesterFragment.this);
			mRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestFinishedSuccessState);
			}
		}
		if (requestId == subjectRequestedId) {
			mResponseBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(SemesterFragment.this);
			subjectRequestedId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestSucjectFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnableHandleOnRequestSubjectFinishedSuccessState);
			}
		}
	}

	/** Runnable to handle the server success response. */
	private final Runnable mRunnableHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			branchListData.clear();
			ProgressBarHelper.dismissProgressBar(mHandler);
			semesters = mResponseBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_LIST);

			if (semesters == null || semesters.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
				.showDialog(getString(R.string.nosemetersforbranch),
						"Ok", "Cancel");
			} else {
				for (SemesterDto branch : semesters) {
					SemesterDto dto = new SemesterDto();
					dto.setSemesterId(branch.getSemesterId());
					dto.setSemesterName(branch.getSemesterName());
					branchListData.add(dto);
					/*
					 * textView.append("\n Branch Id: " + branch.getmId() +
					 * " Branch: " + branch.getMbranch_name());
					 */
				}
				semesterAdaptr = new SemesterNameAdapter(getActivity(),
						R.layout.grid_branch_layout, semesters);
				semesterName.setAdapter(semesterAdaptr);
				semesterAdaptr.notifyDataSetChanged();
			}
		}
	};
	private final Runnable mRunnableHandleOnRequestSubjectFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			subjectListData.clear();
			ProgressBarHelper.dismissProgressBar(mHandler);
			subjects = mResponseBundle.getParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST);

			if (subjects == null || subjects.size() <= 0) {
				DialogHelper dialogHelper = DialogHelper
						.getInstance(getActivity());
				dialogHelper
				.showDialog(getString(R.string.nosubjectssforsemester),
						"Ok", "Cancel");
			} else {
				for (SubjectDto branch : subjects) {
					SubjectDto dto = new SubjectDto();
					dto.setSubjectId(branch.getSubjectId());
					dto.setSubjectName(branch.getSubjectName());
					subjectListData.add(dto);
					/*
					 * textView.append("\n Branch Id: " + branch.getmId() +
					 * " Branch: " + branch.getMbranch_name());
					 */
				}
				//				Intent subjectIntent=new Intent(getActivity(), SubjectActivity.class);
				//				startActivity(subjectIntent);
				FragmentOperation fragmentOperation = FragmentOperation
						.getInstance(getActivity());

				Bundle args = new Bundle();
				args.putParcelableArrayList(JSONTagConstants.RESPONSE_SEMESTER_WISE_LIST, (ArrayList<? extends Parcelable>) subjectListData);
				fragmentOperation.switchFragment(WSConfig.MODULE_SUBJECT, args);
			}
		}
	};

	/** Runnable to handle the server error response. */
	private final Runnable mRunnableHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nosemetersforbranch),
					"Ok", "Cancel");
		}
	};
	private final Runnable mRunnableHandleOnRequestSucjectFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast(getString(R.string.nosubjectssforsemester));
			/*Toast.makeText(getActivity(),
					getString(R.string.nosubjectssforsemester), 0).show();*/
			
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nosubjectssforsemester),
					"Ok", "Cancel");
		}
	};
	


	public void onCreateOptionsMenu(android.view.Menu menu,
			MenuInflater inflater) {
		inflater.inflate(R.menu.logout_menu, menu);
		super.onCreateOptionsMenu(menu, inflater);
	};
	public OnClickListener logoutListener=new OnClickListener() {
		
		@Override
		public void onClick(View v) {

			dialog = new Dialog(getActivity());
			dialog.setContentView(R.layout.logout_layout);
			dialog.setTitle("Are you sure want to logout?");
			dialog.setCancelable(true);
			Button logOutButton = (Button) dialog.findViewById(R.id.logoutButton);
			
			logOutButton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					((BaseFragmentActivity) getActivity()).logout(v);
					dialog.dismiss();
					// TODO Auto-generated method stub
					
				}
			});
			dialog.show();
			// speak();
		
			// TODO Auto-generated method stub
			
		}
	};

}
