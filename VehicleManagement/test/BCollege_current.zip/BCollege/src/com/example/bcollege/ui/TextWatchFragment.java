package com.example.bcollege.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Parcelable;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.TextToSpeech.OnUtteranceCompletedListener;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.model.FileListDto;
import com.example.bcollege.model.ViewPostDto;
import com.example.bcollege.requestmanager.RequestManager;
import com.example.bcollege.requestmanager.WorkerService;
import com.example.bcollege.requestmanager.RequestManager.OnRequestFinishedListener;
import com.example.bcollege.utils.DialogHelper;
import com.example.bcollege.utils.FragmentOperation;
import com.example.bcollege.utils.ProgressBarHelper;
import com.example.bcollege.worker.BaseWorker.DownloadFormat;

public class TextWatchFragment extends Fragment implements
TextToSpeech.OnInitListener, OnRequestFinishedListener {
	private TextToSpeech mTts;
	private int mStatus = 0;
	private MediaPlayer mMediaPlayer;
	private boolean mProcessed = false;	
	private final String FILENAME = "/bcollege.wav";
	private ProgressDialog mProgressDialog;

	@SuppressWarnings("deprecation")
	@TargetApi(15)
	public void setTts(TextToSpeech tts)
	{
		this.mTts = tts;

		if( Build.VERSION.SDK_INT  >= 15 ){
			this.mTts.setOnUtteranceProgressListener(new UtteranceProgressListener()
			{

				@Override
				public void onDone(String utteranceId)
				{
					// Speech file is created
					mProcessed = true;

					// Initializes Media Player
					initializeMediaPlayer();

					// Start Playing Speech
					playMediaPlayer(0);
				}

				@Override
				public void onError(String utteranceId)
				{
				}

				@Override
				public void onStart(String utteranceId)
				{
				}
			});

		}else{
			this.mTts.setOnUtteranceCompletedListener(new OnUtteranceCompletedListener()
			{
				@Override
				public void onUtteranceCompleted(String utteranceId)
				{
					// Speech file is created
					mProcessed = true;

					// Initializes Media Player
					initializeMediaPlayer();

					// Start Playing Speech
					playMediaPlayer(0);              	
				}
			});
		}
	}
	protected void playMediaPlayer(int status) {


		mProgressDialog.dismiss();

		// Start Playing
		if(status==0){	
			mMediaPlayer.start();
		}

		// Pause Playing
		if(status==1){
			mMediaPlayer.pause();
		}		

		// TODO Auto-generated method stub

	}
	protected void initializeMediaPlayer() {

		String fileName = Environment.getExternalStorageDirectory().getAbsolutePath() + FILENAME;	

		Uri uri  = Uri.parse("file://"+fileName);

		mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

		try {
			mMediaPlayer.setDataSource(getActivity(), uri);
			mMediaPlayer.prepare();

		} catch (Exception e) {        				
			e.printStackTrace();
		}		

		// TODO Auto-generated method stub

	}
	//////
	private TextView dataFromServer;
	private TextToSpeech textSpeech;
	private Dialog dialog;
	private boolean isPanelShown = false;
	private View view;
	private ViewGroup commentGroup;
	private ImageView playText;
	private Button commentButton, postButton;
	private EditText commentBox;
	private Bundle mResponseBundle;
	private Bundle postAllViwsBundle;
	private Handler mHandler;
	private static byte mRequestType;
	private int postRequestId = -1;
	private int postViewsRequestId = -1;
	public static RequestManager mRequestManager;
	private List<ViewPostDto> postDetails;
	private ViewPostAdapter postAdapter;
	private ListView commentListView;
	PowerManager.WakeLock wakeLock;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		mHandler = new Handler();

		mRequestManager = RequestManager.from(getActivity());
		mRequestManager.addOnRequestFinishedListener(TextWatchFragment.this);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		view = inflater.inflate(R.layout.text_watch_layout, container, false);
		mRequestManager.addOnRequestFinishedListener(TextWatchFragment.this);
		textSpeech = new TextToSpeech(getActivity(), this);
		keepScreenWokeUp();
		mTts = new TextToSpeech(getActivity(), this);


		mProgressDialog = new ProgressDialog(getActivity()); 

		mMediaPlayer = new MediaPlayer();

		mProgressDialog.setCancelable(true);

		mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);

		mProgressDialog.setMessage("Please wait ...");

		initApp();
		listener();
		loadPostViewer();

		return view;
	}

	private void keepScreenWokeUp() {
		PowerManager pm = (PowerManager) getActivity().getSystemService(Context.POWER_SERVICE);
		wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK,
				"My wakelook");
		wakeLock.acquire();

		// TODO Auto-generated method stub

	}

	private void loadPostViewer() {
		Bundle detailsBundle = new Bundle();
		detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_BRANCH_ID,
				PreferenceConfig.getBranchId(getActivity()));
		detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_SEM_ID,
				PreferenceConfig.getSemId(getActivity()));
		detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID,
				PreferenceConfig.getChapterId(getActivity()));
		detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID,
				PreferenceConfig.getSubId(getActivity()));
		detailsBundle.putString(
				JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID,
				PreferenceConfig.getSubChapterId(getActivity()));
		mRequestManager
		.addOnRequestFinishedListener(TextWatchFragment.this);
		mRequestType = WSConfig.POST_VIEW;
		postViewsRequestId = mRequestManager.postViews(
				DownloadFormat.RETURN_FORMAT_JSON, detailsBundle);
		// TODO Auto-generated method stub

	}

	private void listener() {
		playText.setOnTouchListener(playListener);
		commentButton.setOnClickListener(commentListener);
		postButton.setOnClickListener(postCommentListener);
		// TODO Auto-generated method stub

	}

	private void initApp() {
		commentListView = (ListView) view.findViewById(R.id.commentListView);
		commentBox = (EditText) view.findViewById(R.id.commentBox);
		postButton = (Button) view.findViewById(R.id.post);
		commentButton = (Button) view.findViewById(R.id.commentButton);
		commentGroup = (ViewGroup) view.findViewById(R.id.commentLayout);
		commentGroup.setVisibility(View.INVISIBLE);
		playText = (ImageView) view.findViewById(R.id.speechText);
		dataFromServer = (TextView) view.findViewById(R.id.textView1);
		Intent intent = getActivity().getIntent();
		if (null != intent && intent.getBooleanExtra("status", false)) {
			dataFromServer.setText(DownloadFile.text);
		} else {
			// dataFromServer.setText(FileListAdapter.textString);
			dataFromServer.setText(intent.getStringExtra("fileExitString"));
		}
	}

	public OnTouchListener playListener = new OnTouchListener() {

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			dialog = new Dialog(getActivity());
			dialog.setContentView(R.layout.pop_layout);
			dialog.setTitle("Text To Speech");
			dialog.setCancelable(true);
			Button play = (Button) dialog.findViewById(R.id.playButton);
			Button stop = (Button) dialog.findViewById(R.id.stopButton);
			stop.setOnTouchListener(stopListener);
			play.setOnClickListener(playTextListener);
			dialog.show();
			// speak();
			return false;
		}
	};

	public void onDestroy() {

		// Stop the TextToSpeech Engine
		mTts.stop();

		// Shutdown the TextToSpeech Engine
		mTts.shutdown();

		// Stop the MediaPlayer
		mMediaPlayer.stop();

		// Release the MediaPlayer
		mMediaPlayer.release();

		super.onDestroy();    	
	};

	public void onPause() {
		if (textSpeech != null) {

			textSpeech.playSilence(3000, TextToSpeech.QUEUE_FLUSH, null);
		}
		super.onPause();
	}

	public void onInit(int status) {
		mStatus = status;
		setTts(mTts);
	}

	protected void speak() {
		textSpeech.speak(dataFromServer.getText().toString(),
				TextToSpeech.QUEUE_ADD, null);
		// TODO Auto-generated method stub

	};


	public OnTouchListener stopListener = new OnTouchListener() {

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			onStop();
			dialog.dismiss();
			// TODO Auto-generated method stub
			return false;
		}
	};

	public void onStop() {
		if (mTts != null) {
			mTts.stop();

			mTts.shutdown();

			mMediaPlayer.stop();
			initializeMediaPlayer();


			//			mTts.stop();
		}
		super.onStop();

	};

	protected void addEvent(View v) {

		if (!isPanelShown) {
			// Show the panel
			Animation bottomUp = AnimationUtils.loadAnimation(getActivity(),
					R.anim.bottom_up);

			commentGroup.startAnimation(bottomUp);
			commentGroup.setVisibility(View.VISIBLE);
			isPanelShown = true;
		} else {

			Animation bottomDown = AnimationUtils.loadAnimation(getActivity(),
					R.anim.bottom_down);

			commentGroup.startAnimation(bottomDown);
			commentGroup.setVisibility(View.INVISIBLE);
			isPanelShown = false;
		}

		// TODO Auto-generated method stub

	}

	public OnClickListener commentListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			addEvent(v);
			// TODO Auto-generated method stub

		}
	};
	public OnClickListener postCommentListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (((BaseFragmentActivity) getActivity()).isConnectingToInternet()) {
				if (!commentBox.getText().toString().matches("")) {
					ProgressBarHelper.showProgressBarSmall(
							R.string.progress_bar_please_wait, true, mHandler,
							getActivity());
					Bundle detailsBundle = new Bundle();
					detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_BRANCH_ID,
							PreferenceConfig.getBranchId(getActivity()));
					detailsBundle.putString(JSONTag.JSONTagConstants.DETAILS_SEM_ID,
							PreferenceConfig.getSemId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_CHAPTER_ID,
							PreferenceConfig.getChapterId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SUBJECT_ID,
							PreferenceConfig.getSubId(getActivity()));
					detailsBundle.putString(
							JSONTag.JSONTagConstants.DETAILS_SUB_CHAAPTER_ID,
							PreferenceConfig.getSubChapterId(getActivity()));

					detailsBundle.putString(JSONTag.JSONTagConstants.STUDENT_ID,
							PreferenceConfig.getStudentId(getActivity()));
					detailsBundle.putString(JSONTag.JSONTagConstants.POST_COMMENT,
							commentBox.getText().toString());
					commentBox.setText("");
					mRequestManager
					.addOnRequestFinishedListener(TextWatchFragment.this);
					mRequestType = WSConfig.POST_COMMENT;


					postRequestId = mRequestManager.postComment(
							DownloadFormat.RETURN_FORMAT_JSON, detailsBundle);
				} else {
					DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
					dialogHelper.showDialog("Please type some post",
							"Ok", "Cancel");
					//					((BaseFragmentActivity) getActivity()).Toast("Please type commment");

				}

			} else {
				DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
				dialogHelper.showDialog(getString(R.string.internetStatus),
						"Ok", "Cancel");

			}




		}
	};

	@Override
	public void onRequestFinished(int requestId, int resultCode, Bundle payload) {

		if (mRequestType == WSConfig.POST_COMMENT) {
			mResponseBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(TextWatchFragment.this);
			postRequestId = -1;

			String statusCode = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = mResponseBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnablePostHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// loadPostViewer();
				// take further actions inside runnable.
				mHandler.post(mRunnablePostHandleOnRequestFinishedSuccessState);
			}
		}
		if (mRequestType == WSConfig.POST_VIEW) {
			postAllViwsBundle = payload;
			mRequestManager
			.removeOnRequestFinishedListener(TextWatchFragment.this);
			postViewsRequestId = -1;

			String statusCode = postAllViwsBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS);
			String statusMessage = postAllViwsBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE);
			String data = postAllViwsBundle
					.getString(JSONTag.JSONTagConstants.RESPONSE_TAG_DATA);

			if (TextUtils.isEmpty(statusCode)
					|| TextUtils.isEmpty(statusMessage)) {
				// take further actions inside runnable.
				mHandler.post(mRunnablePostViewsHandleOnRequestFinishedErrorState);
			} else if (resultCode != WorkerService.ERROR_CODE
					&& statusCode.equals(JSONTag.JSONTagConstants.RESPONSE_OK)
					&& statusMessage.equals("true")) {
				// take further actions inside runnable.
				mHandler.post(mRunnablePostViewsHandleOnRequestFinishedSuccessState);
			}
		}

		// TODO Auto-generated method stub

		// TODO Auto-generated method stub

	}

	private final Runnable mRunnablePostViewsHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			((BaseFragmentActivity) getActivity()).Toast(getString((R.string.noPostViews)));
			/*Toast.makeText(getActivity(), getString(R.string.noPostViews), 0)
					.show();*/
			/*DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.nochapterforFiles),
					"Ok", "Cancel");*/
		}
	};
	private final Runnable mRunnablePostViewsHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			postDetails = postAllViwsBundle
					.getParcelableArrayList(JSONTagConstants.RESPONSE_POST_VIEWS_LIST);
			FragmentOperation fragmentOperation = FragmentOperation
					.getInstance(getActivity());
			postAdapter = new ViewPostAdapter(getActivity(),
					R.layout.posted_view_layout, postDetails);
			commentListView.setAdapter(postAdapter);
			postAdapter.notifyDataSetChanged();

		}
	};

	private final Runnable mRunnablePostHandleOnRequestFinishedSuccessState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			Toast.makeText(getActivity(), getString(R.string.successfulpost), 0)
			.show();
			/*DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(getString(R.string.successfulpost), "Ok",
					"Cancel");*/
			loadPostViewer();
		}
	};

	private final Runnable mRunnablePostHandleOnRequestFinishedErrorState = new Runnable() {
		@Override
		public void run() {
			ProgressBarHelper.dismissProgressBar(mHandler);
			Toast.makeText(getActivity(), getString(R.string.noPost), 0).show();
			DialogHelper dialogHelper = DialogHelper.getInstance(getActivity());
			dialogHelper.showDialog(
					getString(R.string.nocommentschapterforFiles), "Ok",
					"Cancel");
		}
	};
	public OnClickListener playTextListener=new OnClickListener() {

		@Override
		public void onClick(View v) {

			if(mStatus==TextToSpeech.SUCCESS){

				// Getting reference to the Button
				Button btnSpeak = (Button)dialog. findViewById(R.id.playButton);

				btnSpeak.setText("Pause");


				if(mMediaPlayer != null && mMediaPlayer.isPlaying()){
					playMediaPlayer(1);
					btnSpeak.setText("Speak");
					return;
				}

				mProgressDialog.show();

				// Getting reference to the EditText et_content
				TextView etContent = (TextView)view. findViewById(R.id.textView1);			

				HashMap<String, String> myHashRender = new HashMap();
				String utteranceID = "wpta";					
				myHashRender.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceID);

				String fileName = Environment.getExternalStorageDirectory().getAbsolutePath() + FILENAME;

				if(!mProcessed){
					int status = mTts.synthesizeToFile(etContent.getText().toString(), myHashRender, fileName);					
				}else{						
					playMediaPlayer(0);
				}

			}else{
				String msg = "TextToSpeech Engine is not initialized";
				Toast.makeText(getActivity(),msg, Toast.LENGTH_SHORT).show();
			}
		}
	};
	/*
	 * private final Runnable mRunnablePostHandleOnRequestFinishedSuccessState =
	 * new Runnable() {
	 * 
	 * @Override public void run() { if (mResponseBundle
	 * .getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS).equals("200") &&
	 * mResponseBundle
	 * .getString(JSONTag.JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE
	 * ).equals("true") ) { loadPostViewer();
	 * 
	 * 
	 * } else { DialogHelper dialogHelper =
	 * DialogHelper.getInstance(getActivity());
	 * dialogHelper.showDialog(getString(R.string.postStatus), "Ok", "Cancel");
	 * 
	 * }
	 * 
	 * 
	 * } };
	 */

}