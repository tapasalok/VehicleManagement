package com.example.bcollege.model;

import android.os.Parcel;
import android.os.Parcelable;

public class ViewPostDto implements Parcelable{
	private String studentId;
private String postedText;
public String getPostedText() {
	return postedText;
}
public void setPostedText(String postedText) {
	this.postedText = postedText;
}
public String getReplyText() {
	return replyText;
}
public void setReplyText(String replyText) {
	this.replyText = replyText;
}
public String getPostedDate() {
	return postedDate;
}
public void setPostedDate(String postedDate) {
	this.postedDate = postedDate;
}
public String getReplyDate() {
	return replyDate;
}
public void setReplyDate(String replyDate) {
	this.replyDate = replyDate;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
private String replyText;
private String postedDate;
private String replyDate;
private String studentName;
@Override
public int describeContents() {
	// TODO Auto-generated method stub
	return 0;
}
@Override
public void writeToParcel(Parcel dest, int flags) {
	// TODO Auto-generated method stub
	
}
public String getStudentId() {
	return studentId;
}
public void setStudentId(String studentId) {
	this.studentId = studentId;
}

}
