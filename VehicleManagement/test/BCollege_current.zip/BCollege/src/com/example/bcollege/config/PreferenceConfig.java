package com.example.bcollege.config;

import android.content.Context;
import android.content.SharedPreferences;

import com.bcollege.ematerial.R;

/**
 * A configuration class that holds the Shared preference related constants and
 * keys.
 * 
 * 
 */
public class PreferenceConfig {

	/**
	 * An interface to hold the constants used for preference data storing.
	 *
	 */
	public interface PreferenceConstants {

		public final String EMAIL_ID = "email_id";
		public final String BRANCH_ID = "brid";
		public final String PASSWORD = "password";
		public final String LOGGEDIN = "loggedIn";
		public final String SEM_ID = "semid";
		public final String SUB_ID = "subid";
		public final String CHAPTER_ID = "chapterid";
		public final String SUB_CHAPTER_ID = "subchapterid";
		public final String STUDENT_ID = "id";
	}

	/**
	 * Call this method to get the singleton instance of
	 * {@link PreferenceConfig} class object.
	 */
	public static SharedPreferences getInstance(Context context) {
		return context.getSharedPreferences(
				context.getResources().getString(R.string.app_name), 0);
	}

	public static String getChapterId(Context context) {
		return getInstance(context).getString(PreferenceConstants.CHAPTER_ID,
				"");
	}
	/** Call to set the student id set by user. */
	public static void setStudentId(String chapterid, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.STUDENT_ID, chapterid).commit();
	}
	public static String getStudentId(Context context) {
		return getInstance(context).getString(PreferenceConstants.STUDENT_ID,
				"");
	}
	/** Call to set the email id set by user. */
	public static void setChapterId(String chapterid, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.CHAPTER_ID, chapterid).commit();
	}
	public static String getBranchNewId(Context context) {
		return getInstance(context).getString(PreferenceConstants.BRANCH_ID,
				"");
	}

	/** Call to set the email id set by user. */
	public static void setSubChapterId(String subChapterId, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.SUB_CHAPTER_ID, subChapterId).commit();
	}
	public static String getSubChapterId(Context context) {
		return getInstance(context).getString(PreferenceConstants.SUB_CHAPTER_ID, "");
	}
	/** Call to set the subChapter id set by user. */
	public static void setBranchNewId(String branchId, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.BRANCH_ID, branchId).commit();
	}
	public static String getSubId(Context context) {
		return getInstance(context).getString(PreferenceConstants.SUB_ID, "");
	}

	/** Call to set the email id set by user. */
	public static void setSubId(String subid, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.SUB_ID, subid).commit();
	}

	public static String getSemId(Context context) {
		return getInstance(context).getString(PreferenceConstants.SEM_ID, "");
	}

	public static void setSemId(String semid, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.SEM_ID, semid).commit();
	}

	/** Call to get the email id set by user. */
	public static String getEmail(Context context) {
		return getInstance(context).getString(PreferenceConstants.EMAIL_ID, "");
	}

	/** Call to set the email id set by user. */
	public static void setEmail(String emailId, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.EMAIL_ID, emailId).commit();
	}

	/** Call to get the Branch Id set by user. */
	public static String getBranchId(Context context) {
		return getInstance(context)
				.getString(PreferenceConstants.BRANCH_ID, "");
	}

	/** Call to set the Branch Id set by user. */
	public static void setBranchId(String zipcode, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.BRANCH_ID, zipcode).commit();
	}

	/** Call to get the Branch Id set by user. */
	public static String getPassword(Context context) {
		return getInstance(context).getString(PreferenceConstants.PASSWORD, "");
	}

	/** Call to set the Branch Id set by user. */
	public static void setPassword(String zipcode, Context context) {
		getInstance(context).edit()
				.putString(PreferenceConstants.PASSWORD, zipcode).commit();
	}

	/** Call to get the Branch Id set by user. */
	public static boolean getLoggedIn(Context context) {
		return getInstance(context).getBoolean(PreferenceConstants.LOGGEDIN, false);
	}

	/** Call to set the Branch Id set by user. */
	public static void setLoggedIn(boolean zipcode, Context context) {
		getInstance(context).edit()
				.putBoolean(PreferenceConstants.LOGGEDIN, zipcode).commit();
	}

}
