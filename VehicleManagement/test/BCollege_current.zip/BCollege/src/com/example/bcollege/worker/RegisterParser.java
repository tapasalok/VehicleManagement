package com.example.bcollege.worker;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;

import com.example.bcollege.config.JSONTag.JSONTagConstants;

public class RegisterParser extends BaseJsonParser {

	private static RegisterParser branchParser;
	private static Context activity;

	private RegisterParser(final Context context) {
		// TODO Auto-generated constructor stub

	}

	public static RegisterParser getInstance(final Context context) {
		activity = context;
		if (branchParser == null) {
			branchParser = new RegisterParser(context);
		}
		return branchParser;
	}

	/** Call to Parse category response from JSON string. */
	public synchronized Map<String, Object> parseRegisterResponse(
			String jsonData) throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseRegisterErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						"Registration Successful");
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseRegisterErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}

	/** Call to Parse category response from JSON string. */
	public synchronized Map<String, Object> parseUpdatePasswordResponse(
			String jsonData) throws JSONException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject response = new JSONObject(new JSONTokener(jsonData));

		String statusCode = response
				.getString(JSONTagConstants.RESPONSE_TAG_STATUS);
		if (statusCode.equals(JSONTagConstants.RESPONSE_OK)) {
			if (parseupdatePasswordErrorJSON(response, map)) {
				return map;
			}
			if (response.has(JSONTagConstants.RESPONSE_TAG_DATA)) {
				map.put(JSONTagConstants.RESPONSE_TAG_DATA,
						"Password Changed Successful");
			}

			map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);

			if (response.has(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE)) {
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE,
						response.optString(JSONTagConstants.RESPONSE_TAG_STATUS_MESSAGE));
			}
		} else {
			if (!parseupdatePasswordErrorJSON(response, map)) {
				// If there is not error tag in response then set status as
				// failure.
				map.put(JSONTagConstants.RESPONSE_TAG_STATUS, statusCode);
			}
		}
		return map;
	}
}
