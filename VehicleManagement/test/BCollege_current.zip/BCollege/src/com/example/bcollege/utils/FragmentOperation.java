package com.example.bcollege.utils;

import android.app.Activity;
import android.os.Bundle;

import com.example.bcollege.ui.BaseFragmentActivity;

public class FragmentOperation {
	private static FragmentOperation fragmentOpration;
	private static Activity activity;

	private FragmentOperation(final Activity context) {
		// TODO Auto-generated constructor stub

	}

	public static FragmentOperation getInstance(final Activity context) {
		activity = context;
		if (fragmentOpration == null) {
			fragmentOpration = new FragmentOperation(context);
		}
		return fragmentOpration;
	}

	public void switchFragment(String tag, Bundle args) {
		if (activity == null)
			return;

		if (activity instanceof BaseFragmentActivity) {
			BaseFragmentActivity fca = (BaseFragmentActivity) activity;
			fca.switchContent(tag, args);
		}
	}

}
