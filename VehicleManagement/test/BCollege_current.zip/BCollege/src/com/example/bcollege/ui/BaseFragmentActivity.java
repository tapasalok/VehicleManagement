package com.example.bcollege.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.PreferenceConfig;
import com.example.bcollege.config.WSConfig;
import com.example.bcollege.utils.DialogHelper;

public class BaseFragmentActivity extends FragmentActivity {
	public static boolean internetStatus = false;
	DialogHelper dialogHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		super.onCreate(savedInstanceState);

	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	public boolean isConnectingToInternet() {
		internetStatus = false;
		ConnectivityManager connectivity = (ConnectivityManager) getApplicationContext()
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity != null) {
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null)
				for (int i = 0; i < info.length; i++)
					if (info[i].getState() == NetworkInfo.State.CONNECTED) {
						internetStatus = true;
						return true;
					}

		}
		return false;
	}
	public  void logout(View view)
	{
		PreferenceConfig.setEmail("", getApplicationContext());
		PreferenceConfig.setPassword("", getApplicationContext());
		PreferenceConfig.setLoggedIn(false, getApplicationContext());
		Intent intent=new Intent(getApplicationContext(), LoginActivity.class);
		startActivity(intent);
		finish();

	}
	public void Toast(String msg)
	{
	LayoutInflater inflater = getLayoutInflater();

	View layout = inflater.inflate(R.layout.my_fancy_toast,
			(ViewGroup)findViewById(R.id.my_fancy_toast_root));
	TextView text = (TextView) layout.findViewById(R.id.text);

	Toast toast = new Toast(getApplicationContext());
	text.setText(msg);
	toast.setGravity(Gravity.BOTTOM, 0, 0);
	toast.setDuration(Toast.LENGTH_SHORT);
	toast.setView(layout);
	toast.show();}

	public void switchContent(String tag, Bundle args) {

		// Create fragment and give it an argument specifying the article it
		// should show
		BaseFragment newFragment = null;

		if (tag.equals(WSConfig.MODULE_SEMESTER)) {
			newFragment = new SemesterFragment();
		} else if (tag.equals(WSConfig.MODULE_SUBJECT)) {
			newFragment = new SubjectFragment();
		} else if (tag.equals(WSConfig.MODULE_CHAPTER)) {
			newFragment = new ChapterFragment();
		} else if (tag.equals(WSConfig.MODULE_SUB_CHAPTER)) {
			newFragment = new SubChapterFragment();
		} else if (tag.equals(WSConfig.MODULE_FILE_DETAILS)) {
			newFragment = new FileListFragment();
		} else {
			newFragment = new LoginFragment();
		}

		if (args != null) {
			newFragment.setArguments(args);
		}

		FragmentTransaction transaction = getSupportFragmentManager()
				.beginTransaction();

		// Replace whatever is in the fragment_container view with this
		// fragment,
		// and add the transaction to the back stack so the user can navigate
		// back
		transaction.replace(R.id.fragment_container, newFragment);
		if (tag.equals(WSConfig.MODULE_SUBJECT)
				|| tag.equals(WSConfig.MODULE_CHAPTER)
				|| tag.equals(WSConfig.MODULE_SUB_CHAPTER)
				|| tag.equals(WSConfig.MODULE_FILE_DETAILS)) {
			transaction.addToBackStack(null);
		}
		// transaction.addToBackStack(null);

		// Commit the transaction
		transaction.commit();

	}
}
