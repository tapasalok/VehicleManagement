package com.example.bcollege.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import com.bcollege.ematerial.R;
import com.example.bcollege.config.JSONTag.JSONTagConstants;
import com.example.bcollege.model.FileListDto;
import com.example.bcollege.requestmanager.RequestManager;

public class FileListFragment extends BaseFragment {
	private Dialog dialog;
	private ImageView logout;
	private FileListAdapter fileAdapter;
	private List<FileListDto> fileList = new ArrayList<FileListDto>();
	private View view;
	private ListView fileListView;
	public static RequestManager mRequestManager;
	public static List<FileListDto> fileListData = new ArrayList<FileListDto>();

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		view = inflater.inflate(R.layout.file_layout, container, false);
		initApp();
		return view;
	}

	private void initApp() {
		logout=(ImageView) view.findViewById(R.id.logout);
		logout.setOnClickListener(logoutListener);
		fileListView = (ListView) view.findViewById(R.id.fileList);

		fileList = getArguments().getParcelableArrayList(
				JSONTagConstants.RESPONSE_FILE_LIST);
		fileAdapter = new FileListAdapter(getActivity(),
				R.layout.detail_layout, fileList);
		fileListView.setAdapter(fileAdapter);
		fileAdapter.notifyDataSetChanged();

	}
public OnClickListener logoutListener=new OnClickListener() {
		
		@Override
		public void onClick(View v) {

			dialog = new Dialog(getActivity());
			dialog.setContentView(R.layout.logout_layout);
			dialog.setTitle("Are you sure want to logout?");
			dialog.setCancelable(true);
			Button logOutButton = (Button) dialog.findViewById(R.id.logoutButton);
			
			logOutButton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					((BaseFragmentActivity) getActivity()).logout(v);
					dialog.dismiss();
					// TODO Auto-generated method stub
					
				}
			});
			dialog.show();
			// speak();
		
			// TODO Auto-generated method stub
			
		}
	};



}
