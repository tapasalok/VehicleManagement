package com.example.bcollege.worker;

public class BaseWorker {

	/**
	 * Constants to represent the returning data format from server as response.
	 */
	public interface DownloadFormat {
		public final int RETURN_FORMAT_XML = 0;
		public final int RETURN_FORMAT_JSON = 1;
	}

}
