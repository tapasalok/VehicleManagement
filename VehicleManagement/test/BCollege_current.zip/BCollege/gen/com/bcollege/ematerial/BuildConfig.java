/** Automatically generated file. DO NOT MODIFY */
package com.bcollege.ematerial;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}