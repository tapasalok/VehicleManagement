package org.koushik.javabrains.action;

import org.koushik.javabrains.service.TutorialFinderService;

public class TutorialAction {
	private String bestTutorialSite;
	private String language;
	public String execute() {
		// TODO Auto-generated method stub
		TutorialFinderService tutorialFinderService = new TutorialFinderService();
		
		System.out.println(getLanguage());
		setBestTutorialSite(tutorialFinderService.getBestTutorialSites(getLanguage()));
		// System.out.println("bestTutorialSite: " + bestTutorialSite);
		return "success";
	}

	public String getBestTutorialSite() {
		return bestTutorialSite;
	}

	public void setBestTutorialSite(String bestTutorialSite) {
		this.bestTutorialSite = bestTutorialSite;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
}
