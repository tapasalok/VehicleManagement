package org.koushik.javabrains.service;

public class TutorialFinderService {

	public String getBestTutorialSites(String language) {
		// TODO Auto-generated method stub
		if (language.equalsIgnoreCase("Java")) {
			return "Java Tapas";
		} else if (language.equalsIgnoreCase("dotnet")) {
			return "Java dotnet";
		}
		return "Default";
	}
}
