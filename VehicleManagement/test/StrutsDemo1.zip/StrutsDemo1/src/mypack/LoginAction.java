package mypack;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name, password;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public void validate() {
		// TODO Auto-generated method stub
		// super.validate();

		Client client = ClientBuilder.newClient();

		WebTarget target = client
				.target("http://rest-service.guides.spring.io/greeting");

		if (name == null || name.length() <= 0) {

			String string = target.request(MediaType.APPLICATION_JSON).get(
					String.class);
			System.out.println(string);
			
			JsonObject jsonObject = new JsonParser().parse(string).getAsJsonObject();

//			System.out.println(jsonObject.get("content").getAsString());
//			
//			System.out.println("content: "+jsonObject.get("content").getAsString());
			
//			JSONObject jsonObject = JSONObject.fromObject(string);
//
//			System.out.println("jsonObject"+jsonObject);
//			
			int id = jsonObject.get("id").getAsInt();
			String content = jsonObject.get("content").getAsString();
//
			name = String.valueOf(id);
			password = String.valueOf(content);
//
//			System.out.println("name: " + name);
//			System.out.println("password: " + password);
			this.addFieldError("name", "Name is required !!!");
			this.addFieldError("password", "Name is required !!!");
		} else if (password == null || password.length() <= 0) {
			this.addFieldError("password", "Password is required !!!");
		} else if (password.length() < 4) {
			this.addFieldError("password",
					"Password should be of at least 4 characters  !!!");
		}
	}
}
